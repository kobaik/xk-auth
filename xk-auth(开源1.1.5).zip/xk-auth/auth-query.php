<?php
// 尝试加载WordPress环境
$current_dir = dirname(__FILE__);
$wp_load_path = null;

// 最多向上查找5级目录
for ($i = 0; $i < 5; $i++) {
    $test_path = $current_dir . DIRECTORY_SEPARATOR . 'wp-load.php';
    if (file_exists($test_path)) {
        $wp_load_path = $test_path;
        break;
    }
    // 向上移动一级目录
    $parent_dir = dirname($current_dir);
    // 检查是否已经到达文件系统根目录
    if ($parent_dir === $current_dir) {
        break;
    }
    $current_dir = $parent_dir;
}

// 如果找到wp-load.php，则加载它
if ($wp_load_path && file_exists($wp_load_path)) {
    require_once $wp_load_path;
} else {
    // 如果是AJAX请求，返回JSON格式错误
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('error' => 1, 'message' => '无法加载WordPress环境', 'data' => null));
    } else {
        die('无法加载WordPress环境，请检查文件路径是否正确');
    }
    exit;
}

// 检查是否是AJAX请求
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' && 
    isset($_POST['action']) && $_POST['action'] === 'xk_auth_query') {
    
    // 设置JSON响应头
    header('Content-Type: application/json; charset=utf-8');
    
    // 禁用PHP错误显示
    @ini_set('display_errors', 0);
    
    try {
        // 检查函数是否存在
        if (!function_exists('xk_auth')) {
            throw new Exception('缺少必要的函数 xk_auth');
        }
        
        // 检查是否启用了授权查询功能
        if (!xk_auth('auth_query_enabled', true)) {
            throw new Exception('授权查询功能未启用');
        }
        
        // 获取查询参数
        $product_id = isset($_POST['product_id']) ? sanitize_text_field($_POST['product_id']) : '';
        $domain = isset($_POST['domain']) ? sanitize_text_field(trim($_POST['domain'])) : '';
        
        // 参数验证
        if (empty($product_id) || empty($domain)) {
            throw new Exception('请填写完整的查询信息');
        }
        
        // 验证域名长度（RFC标准）
        if (strlen($domain) > 253) {
            throw new Exception('域名长度不能超过253个字符');
        }
        
        // IP地址请求频率限制
        $client_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ip_key = 'xk_auth_query_ip_' . md5($client_ip);
        $max_requests_per_minute = 5; // 每分钟最多5次请求
        $cooldown_time = 60; // 冷却时间60秒
        
        // 获取当前请求次数，确保是有效的数值
        $transient_value = get_transient($ip_key);
        $current_requests = 0; // 默认值
        if (is_numeric($transient_value)) {
            $current_requests = intval($transient_value);
        }
        
        // 检查请求频率限制
        if ($current_requests >= $max_requests_per_minute) {
            // 获取剩余冷却时间（兼容WordPress < 5.5.0）
            $remaining_time = 60; // 默认值
            throw new Exception(json_encode(array('message' => '请求过于频繁，请稍后重试', 'remaining_time' => $remaining_time)));
        }
        
        // 更新请求次数
        set_transient($ip_key, $current_requests + 1, $cooldown_time);
        
        // 检查每个标签的长度（RFC标准：每个标签不超过63字符）
        $labels = explode('.', $domain);
        foreach ($labels as $label) {
            if (strlen($label) > 63) {
                throw new Exception('域名中的子域名部分不能超过63个字符');
            }
        }
        
        // 验证域名格式（后端验证，双重保障）
        if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?(\.[a-zA-Z]{2,})+$/', $domain)) {
            throw new Exception('请输入有效的域名格式，例如：example.com');
        }
        
        // 过滤危险字符（除了域名允许的字符外）
        $sanitized_domain = preg_replace('/[^a-zA-Z0-9.-]/', '', $domain);
        if ($sanitized_domain !== $domain) {
            throw new Exception('域名包含不允许的特殊字符');
        }
        
        // 域名白名单/黑名单检查（可通过WordPress选项配置）
        // 默认获取白名单/黑名单配置，为空则使用默认配置
        $domain_whitelist = xk_auth('domain_whitelist', array()); // 白名单域名数组
        $domain_blacklist = xk_auth('domain_blacklist', array()); // 黑名单域名数组
        $use_whitelist = xk_auth('use_whitelist', false); // 是否启用白名单模式
        
        // 检查黑名单
        if (!empty($domain_blacklist) && is_array($domain_blacklist)) {
            // 将域名转换为小写进行比较，避免大小写问题
            $domain_lower = strtolower($domain);
            foreach ($domain_blacklist as $blocked_domain) {
                $blocked_domain = trim(strtolower($blocked_domain));
                if (!empty($blocked_domain) && ($domain_lower === $blocked_domain || 
                    substr($domain_lower, -strlen($blocked_domain) - 1) === '.' . $blocked_domain)) {
                    throw new Exception('抱歉，该域名不允许进行授权查询');
                }
            }
        }
        
        // 如果启用了白名单模式，检查域名是否在白名单中
        if ($use_whitelist && !empty($domain_whitelist) && is_array($domain_whitelist)) {
            $domain_lower = strtolower($domain);
            $is_whitelisted = false;
            
            foreach ($domain_whitelist as $allowed_domain) {
                $allowed_domain = trim(strtolower($allowed_domain));
                if (!empty($allowed_domain) && ($domain_lower === $allowed_domain || 
                    substr($domain_lower, -strlen($allowed_domain) - 1) === '.' . $allowed_domain)) {
                    $is_whitelisted = true;
                    break;
                }
            }
            
            if (!$is_whitelisted) {
                throw new Exception('抱歉，只有白名单内的域名可以进行授权查询');
            }
        }
        

        
        // 查询数据库
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        
        // 检查wpdb对象是否存在
        if (!isset($wpdb)) {
            throw new Exception('数据库连接失败');
        }
        
        // 检查并获取缓存
        $cache_key = 'xk_auth_query_' . md5($product_id . $domain);
        $auth_record = wp_cache_get($cache_key, 'xk_auth');
        
        if (!$auth_record) {
            // 直接查询记录，不单独检查表是否存在（如果表不存在，查询会返回false）
            $auth_record = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM $table_name WHERE product_id = %s AND domain = %s",
                    $product_id, $domain
                ),
                ARRAY_A
            );
            
            // 缓存查询结果5分钟
            if ($auth_record) {
                wp_cache_set($cache_key, $auth_record, 'xk_auth', 300);
            }
        }
        
        // 检查数据库错误
        if ($wpdb->last_error) {
            error_log('数据库查询错误: ' . $wpdb->last_error . '，查询SQL: SELECT * FROM ' . $table_name . ' WHERE product_id = ' . $product_id . ' AND domain = ' . $domain);
            throw new Exception('数据库查询失败');
        }
        
        if (!$auth_record) {
            error_log('未找到匹配的授权记录: product_id=' . $product_id . ', domain=' . $domain);
            throw new Exception('未找到匹配的授权记录');
        }
        
        // 更新日志记录：查询成功
        $request_log['status'] = 'success';
        $request_log['user_id'] = $auth_record['user_id'];
        $request_log['expire_time'] = $auth_record['expire_time'];
        $request_log['status_code'] = $auth_record['status'];
        error_log('授权查询成功: ' . json_encode($request_log));
        
        // 获取用户信息
        $user_info = get_userdata($auth_record['user_id']);
        $username = $user_info ? $user_info->user_login : '未知用户';
        
        // 获取产品名称
        $product_name = $product_id;
        $product_settings = xk_auth('product_settings', array());
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (is_array($product) && isset($product['product_id']) && $product['product_id'] === $product_id) {
                    $product_name = isset($product['product_name']) ? $product['product_name'] : $product_id;
                    break;
                }
            }
        }
        
        // 判断授权状态
        $is_valid = true;
        $status = '正常';
        
        // 检查是否过期
        $is_expired = false;
        if (!empty($auth_record['expire_time']) && $auth_record['expire_time'] !== '0000-00-00 00:00:00') {
            $current_time = current_time('mysql');
            if ($current_time > $auth_record['expire_time']) {
                $is_valid = false;
                $is_expired = true;
                $status = '已过期';
            }
        }
        
        // 检查是否被封禁，但只有在未过期的情况下才设置为封禁状态
        if ($auth_record['status'] != '1' && !$is_expired) {
            $is_valid = false;
            $status = '已封禁';
        }
        
        // 构建响应数据
        $response = array(
            'error' => 0,
            'message' => $is_valid ? '查询成功，授权有效' : '查询成功，但授权无效',
            'data' => array(
                'username' => $username,
                'product_name' => $product_name,
                'domain' => $auth_record['domain'],
                'is_valid' => $is_valid,
                'status' => $status,
                'expire_time' => !empty($auth_record['expire_time']) && $auth_record['expire_time'] !== '0000-00-00 00:00:00' ? $auth_record['expire_time'] : '永久有效',
                'create_time' => $auth_record['operation_time']
            )
        );
    } catch (Exception $e) {
        // 捕获所有异常
        $response = array(
            'error' => 1,
            'message' => $e->getMessage(),
            'data' => null
        );
        
        // 更新日志记录：查询失败
        $request_log['status'] = 'error';
        $request_log['error_type'] = 'Exception';
        $request_log['error_message'] = $e->getMessage();
        $request_log['error_file'] = $e->getFile();
        $request_log['error_line'] = $e->getLine();
    } catch (Error $e) {
        // 捕获PHP致命错误
        $response = array(
            'error' => 1,
            'message' => '服务器内部错误',
            'data' => null
        );
        
        // 更新日志记录：查询失败
        $request_log['status'] = 'error';
        $request_log['error_type'] = 'Fatal Error';
        $request_log['error_message'] = $e->getMessage();
        $request_log['error_file'] = $e->getFile();
        $request_log['error_line'] = $e->getLine();
    } catch (Throwable $e) {
        // 捕获所有可抛出的错误
        $response = array(
            'error' => 1,
            'message' => '服务器内部错误',
            'data' => null
        );
        
        // 更新日志记录：查询失败
        $request_log['status'] = 'error';
        $request_log['error_type'] = 'Throwable';
        $request_log['error_message'] = $e->getMessage();
        $request_log['error_file'] = $e->getFile();
        $request_log['error_line'] = $e->getLine();
    }
    
    // 确保正确输出JSON
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// 不是AJAX请求，继续加载页面

// 检查是否启用了授权查询功能
if (!xk_auth('auth_query_enabled', true)) {
    wp_die('授权查询功能未启用');
}

// 添加验证码加载脚本
if (!wp_script_is('jquery', 'enqueued')) {
    wp_enqueue_script('jquery');
}

// 确保captcha相关脚本被加载
function load_zib_captcha_scripts() {
    wp_enqueue_script('captcha', get_template_directory_uri() . '/js/captcha.js', array('jquery'), false, true);
    wp_enqueue_script('slidercaptcha', get_template_directory_uri() . '/js/slidercaptcha.js', array('jquery'), false, true);
}
add_action('wp_enqueue_scripts', 'load_zib_captcha_scripts');

// 获取产品列表
function get_product_options() {
    $product_options = '';
    $product_settings = xk_auth('product_settings', array());
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            if (is_array($product) && isset($product['product_id'], $product['product_name'])) {
                $product_id = esc_attr($product['product_id']);
                $product_name = esc_html($product['product_name']);
                $product_options .= "<option value=\"$product_id\">$product_name</option>";
            }
        }
    }
    return $product_options;
}

// 加载主题头部
get_header();

// 获取产品选项
$product_options = get_product_options();

// 页面标题设置
$GLOBALS['zib_page_title'] = '官方授权查询系统';

// 输出页面内容
?>
<main class="container" machine-verification="slider">
    <div class="content-wrap">
        <div class="content-layout">
            <article class="article page-article main-bg theme-box box-body radius8 main-shadow">
                <div class="wp-posts-content">
                    <!-- 授权查询表单 -->
                    <div class="auth-query-container">
                        <?php
                        // 获取后台设置的Logo和宽度
                        $auth_query_logo = xk_auth('auth_query_logo', '');
                        $auth_query_logo_width = xk_auth('auth_query_logo_width', 150);
                        
                        // 如果设置了Logo，则显示Logo
                        if (!empty($auth_query_logo)) {
                            echo '<div class="text-center mb20">
                                <img src="' . esc_url($auth_query_logo) . '" alt="Logo" style="width: ' . intval($auth_query_logo_width) . 'px; max-width: 100%; height: auto;">
                            </div>';
                        }
                        ?>
                        <h2 class="title-h2 text-center mb30">官方授权查询系统</h2>
                        <form id="auth-query-form">
                            <input type="hidden" name="action" value="xk_auth_query">

                            <div class="form-group mb20">
                                <label for="product_id" class="block mb6 text-main">产品名称 <span
                                        class="text-danger">*</span></label>
                                <select id="product_id" name="product_id" class="form-control" required>
                                    <option value="">请选择产品</option>
                                    <?php echo $product_options; ?>
                                </select>
                            </div>

                            <div class="form-group mb20">
                                <label for="domain" class="block mb6 text-main">授权域名 <span
                                        class="text-danger">*</span></label>
                                <input type="text" id="domain" name="domain" class="form-control"
                                    placeholder="请输入授权域名，例如：example.com" required>
                            </div>



                            <button type="submit" class="but jb-blue btn-block padding-lg radius">
                                <span id="btn-text">查询授权</span>
                                <div id="btn-spinner" class="spinner" style="display: none;"></div>
                                <span id="cooldown-timer" class="cooldown-timer" style="display: none;"></span>
                            </button>
                        </form>

                        <!-- 查询结果 -->
                        <div id="result" class="result-container mt30 p20 bg-muted rounded" style="display: none;">
                            <div id="result-details" class="result-details">
                                <h3 class="title-h3 mb20 text-center">授权详情</h3>
                                <div id="result-message" class="result-message p-4 mb20"></div>

                                <!-- 详情表格 - 子比主题风格 -->
                                <div class="bg-white rounded-lg overflow-hidden shadow-sm">
                                    <table class="w-full table-auto">
                                        <tbody>
                                            <tr class="border-b border-main-border">
                                                <td class="py12 px20 bg-light text-muted w1/3">
                                                    <span class="inline-block mr8 text-gray-400">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round">
                                                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                            <circle cx="12" cy="7" r="4"></circle>
                                                        </svg>
                                                    </span>
                                                    授权用户
                                                </td>
                                                <td class="py12 px20 text-key font-medium" id="result-username">--</td>
                                            </tr>
                                            <tr class="border-b border-main-border">
                                                <td class="py12 px20 bg-light text-muted w1/3">
                                                    <span class="inline-block mr8 text-gray-400">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round">
                                                            <rect x="2" y="3" width="20" height="14" rx="2" ry="2">
                                                            </rect>
                                                            <line x1="8" y1="21" x2="16" y2="21"></line>
                                                            <line x1="12" y1="17" x2="12" y2="21"></line>
                                                        </svg>
                                                    </span>
                                                    产品名称
                                                </td>
                                                <td class="py12 px20 text-key font-medium" id="result-product-name">--
                                                </td>
                                            </tr>
                                            <tr class="border-b border-main-border">
                                                <td class="py12 px20 bg-light text-muted w1/3">
                                                    <span class="inline-block mr8 text-gray-400">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round">
                                                            <path
                                                                d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71">
                                                            </path>
                                                            <path
                                                                d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71">
                                                            </path>
                                                        </svg>
                                                    </span>
                                                    授权域名
                                                </td>
                                                <td class="py12 px20 text-key font-medium" id="result-domain">--</td>
                                            </tr>
                                            <tr class="border-b border-main-border">
                                                <td class="py12 px20 bg-light text-muted w1/3">
                                                    <span class="inline-block mr8 text-gray-400">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round">
                                                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z">
                                                            </path>
                                                        </svg>
                                                    </span>
                                                    授权状态
                                                </td>
                                                <td class="py12 px20" id="result-status">--</td>
                                            </tr>
                                            <tr>
                                                <td class="py12 px20 bg-light text-muted w1/3">
                                                    <span class="inline-block mr8 text-gray-400">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round">
                                                            <circle cx="12" cy="12" r="10"></circle>
                                                            <polyline points="12 6 12 12 16 14"></polyline>
                                                        </svg>
                                                    </span>
                                                    授权有效期
                                                </td>
                                                <td class="py12 px20 text-key font-medium" id="result-expire-time">--
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</main>

<style>
/* 授权查询样式 - 子比主题风格 */
.auth-query-container {
    background: var(--main-bg-color);
    padding: 30px;
    border-radius: var(--main-radius);
}

/* 加载动画 */
.spinner {
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-top: 2px solid #fff;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-left: 8px;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

/* 按钮状态管理 */
button:disabled {
    opacity: 0.7;
    cursor: not-allowed;
}

/* 结果消息状态样式 - 子比主题风格 */
.result-message {
    border-radius: 8px;
    font-size: 14px;
    line-height: 1.5;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    text-align: center;
    /* 消息文本居中显示 */
}

.result-message.success {
    background-color: var(--success-bg);
    color: var(--success-color);
    border: 1px solid var(--success-color);
    background-image: linear-gradient(135deg, var(--success-bg) 0%, rgba(240, 249, 255, 0.8) 100%);
}

.result-message.error {
    background-color: var(--danger-bg);
    color: var(--danger-color);
    border: 1px solid var(--danger-color);
    background-image: linear-gradient(135deg, var(--danger-bg) 0%, rgba(254, 240, 240, 0.8) 100%);
}

/* 状态标签样式 - 子比主题风格 */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 50px;
    font-size: 12px;
    font-weight: 500;
    margin-right: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}

.status-badge.valid {
    background-color: var(--success-bg);
    color: var(--success-color);
    border: 1px solid var(--success-color);
}

.status-badge.invalid {
    background-color: var(--danger-bg);
    color: var(--danger-color);
    border: 1px solid var(--danger-color);
}

/* 卡片悬停效果 */
.bg-white {
    transition: all 0.3s ease;
}

.bg-white:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* 表格样式优化 */
.table-auto {
    border-collapse: collapse;
}

.table-auto tr:last-child {
    border-bottom: none;
}

/* 图标样式 */
.text-gray-400 svg {
    vertical-align: middle;
}

/* 响应式设计 */
@media (max-width: 768px) {
    .auth-query-container {
        padding: 15px !important;
        margin: 0 -15px;
    }

    /* 表格响应式设计 */
    .table-auto {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        /* 增加滚动体验 */
    }

    /* 移动设备上优化表格布局 */
    .bg-white.rounded-lg {
        border-radius: 0;
        overflow: hidden;
    }

    .table-auto tbody {
        display: block;
    }

    .table-auto tr {
        display: block;
        border-bottom: 1px solid var(--main-border);
        margin-bottom: 10px;
        padding-bottom: 10px;
    }

    .table-auto td {
        display: block;
        width: 100% !important;
        text-align: left;
        border-bottom: 1px dotted var(--main-border);
        padding: 8px 12px !important;
    }

    .table-auto td:last-child {
        border-bottom: none;
    }

    /* 调整标签宽度，使其在移动设备上更美观 */
    .table-auto td:first-child {
        font-weight: 600;
        background-color: rgba(0, 0, 0, 0.02);
        margin-bottom: 5px;
    }

    /* 调整按钮大小 */
    .btn-block {
        padding: 12px 15px;
        font-size: 16px;
        /* 增加触摸区域 */
    }

    /* 调整表单元素 */
    .form-control {
        padding: 5px 12px;
        font-size: 16px;
        /* 防止iOS缩放 */
    }

    /* 调整标题大小 */
    .title-h2 {
        font-size: 20px;
        margin-bottom: 20px;
    }

    /* 调整状态标签 */
    .status-badge {
        display: inline-block;
        margin-bottom: 5px;
        margin-right: 10px;
        font-size: 11px;
        padding: 3px 8px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('auth-query-form');
    const result = document.getElementById('result');
    const resultMessage = document.getElementById('result-message');
    const btnText = document.getElementById('btn-text');
    const btnSpinner = document.getElementById('btn-spinner');

    // 定义全局重置函数
    function resetResultFields() {
        document.getElementById('result-username').textContent = '--';
        document.getElementById('result-product-name').textContent = '--';
        document.getElementById('result-domain').textContent = '--';
        document.getElementById('result-status').innerHTML = '--';
        document.getElementById('result-expire-time').textContent = '--';

        // 恢复按钮的原始点击行为，确保下次点击时使用表单的submit事件
        const submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.onclick = null;
        }
    }

    // 表单提交处理函数
    function submitForm() {
        // 获取提交按钮
        const submitButton = form.querySelector('button[type="submit"]');

        // 显示加载状态
        btnText.style.display = 'none';
        btnSpinner.style.display = 'inline-block';
        if (submitButton) submitButton.disabled = true;

        // 隐藏之前的结果
        result.style.display = 'none';

        // 只重置结果显示字段，不重置验证码
        document.getElementById('result-username').textContent = '--';
        document.getElementById('result-product-name').textContent = '--';
        document.getElementById('result-domain').textContent = '--';
        document.getElementById('result-status').innerHTML = '--';
        document.getElementById('result-expire-time').textContent = '--';

        // 收集表单数据
        const formData = new FormData(form);

        // 发送AJAX请求
        fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('查询响应状态:', response.status);
                // 先获取原始响应文本
                return response.text().then(text => {
                    return {
                        text,
                        status: response.status,
                        ok: response.ok
                    };
                });
            })
            .then(({
                text,
                status,
                ok
            }) => {
                // 恢复按钮状态
                btnText.style.display = 'inline-block';
                btnSpinner.style.display = 'none';
                if (submitButton) submitButton.disabled = false;

                // 显示结果容器
                result.style.display = 'block';

                // 尝试解析JSON
                try {
                    console.log('原始响应:', text);
                    const data = JSON.parse(text);

                    if (data.error === 0 && data.data) {
                        // 成功结果
                        result.classList.remove('error');
                        result.classList.add('success');
                        resultMessage.classList.remove('error');
                        resultMessage.classList.add('success');
                        resultMessage.textContent = data.message;

                        // 填充详情表格
                        document.getElementById('result-username').textContent = data.data.username || '--';
                        document.getElementById('result-product-name').textContent = data.data
                            .product_name || '--';
                        document.getElementById('result-domain').textContent = data.data.domain || '--';

                        // 显示状态标签
                        const statusHtml = data.data.is_valid ?
                            '<span class="status-badge valid">有效</span>' :
                            '<span class="status-badge invalid">无效</span>';
                        document.getElementById('result-status').innerHTML = statusHtml +
                            '<span class="text-key font-medium">' + (data.data.status || '--') + '</span>';

                        document.getElementById('result-expire-time').textContent = data.data.expire_time ||
                            '--';
                    } else {
                        // 失败结果
                        result.classList.remove('success');
                        result.classList.add('error');
                        resultMessage.classList.remove('success');
                        resultMessage.classList.add('error');

                        // 检查是否包含剩余冷却时间信息
                        let errorMessage = data.message || '查询失败，请稍后重试';
                        let remainingTime = 0;

                        // 尝试解析错误信息是否为JSON格式
                        try {
                            const errorData = JSON.parse(data.message);
                            if (errorData.message && errorData.remaining_time) {
                                errorMessage = errorData.message;
                                remainingTime = errorData.remaining_time;

                                // 显示倒计时
                                showCooldownTimer(remainingTime);
                            }
                        } catch (e) {
                            // 不是JSON格式，直接使用
                        }

                        resultMessage.textContent = errorMessage;
                    }
                } catch (parseError) {
                    // JSON解析错误处理
                    console.error('JSON解析错误:', parseError);

                    result.classList.remove('success');
                    result.classList.add('error');
                    resultMessage.classList.remove('success');
                    resultMessage.classList.add('error');

                    // 提取错误信息
                    let errorMsg = '服务器返回了非JSON格式的响应';

                    // 检查是否包含PHP错误信息
                    if (text.includes('<b>Notice</b>') || text.includes('<b>Warning</b>') || text.includes(
                            '<b>Fatal error</b>')) {
                        // 尝试提取错误文本
                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = text;
                        const errorElements = tempDiv.querySelectorAll('b, p');
                        if (errorElements.length > 0) {
                            errorMsg = '服务器错误: ' + errorElements[0].textContent.replace(
                                /^<[^>]+>|<[^>]+>$/g, '');
                        }
                    }

                    resultMessage.textContent = errorMsg;
                }

                // 滚动到结果区域
                result.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });

                // 显示倒计时功能
                function showCooldownTimer(remainingTime) {
                    const submitButton = form.querySelector('button[type="submit"]');
                    const btnText = document.getElementById('btn-text');
                    const cooldownTimer = document.getElementById('cooldown-timer');

                    // 禁用提交按钮
                    if (submitButton) {
                        submitButton.disabled = true;
                    }

                    // 显示倒计时
                    btnText.textContent = '请稍候';
                    cooldownTimer.style.display = 'inline-block';

                    // 更新倒计时
                    function updateTimer() {
                        if (remainingTime > 0) {
                            cooldownTimer.textContent = ` (${remainingTime}s)`;
                            remainingTime--;
                            setTimeout(updateTimer, 1000);
                        } else {
                            // 恢复按钮状态
                            if (submitButton) {
                                submitButton.disabled = false;
                            }
                            btnText.textContent = '查询授权';
                            cooldownTimer.style.display = 'none';
                        }
                    }

                    // 开始倒计时
                    updateTimer();
                }
            })
            .catch(error => {
                // 网络或其他请求错误
                console.error('查询请求错误:', error);

                btnText.style.display = 'inline-block';
                btnSpinner.style.display = 'none';
                if (submitButton) submitButton.disabled = false;

                result.style.display = 'block';
                result.classList.remove('success');
                result.classList.add('error');
                resultMessage.classList.remove('success');
                resultMessage.classList.add('error');
                resultMessage.textContent = '网络请求错误: ' + (error.message || '未知错误');

                // 滚动到结果区域
                result.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });


            });
    }

    // 域名格式验证函数
    function validateDomain(domain) {
        // 检查域名长度（RFC标准：完整域名不超过253字符）
        if (domain.length > 253) {
            return false;
        }

        // 检查每个标签的长度（RFC标准：每个标签不超过63字符）
        const labels = domain.split('.');
        for (const label of labels) {
            if (label.length > 63) {
                return false;
            }
        }

        // 域名正则表达式：允许字母、数字、连字符，必须包含至少一个点，不允许协议和路径
        const domainPattern = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?(\.[a-zA-Z]{2,})+$/;
        return domainPattern.test(domain);
    }

    // 表单提交处理
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // 验证表单必填项
        const productId = form.querySelector('[name="product_id"]').value;
        const domain = form.querySelector('[name="domain"]').value.trim();

        if (!productId || !domain) {
            alert('请填写完整的查询信息');
            return;
        }

        // 验证域名格式
        if (!validateDomain(domain)) {
            alert('请输入有效的域名格式，例如：example.com');
            return;
        }

        // 直接提交表单，无需验证码
        submitForm();
    });
});
</script>

<?php
// 加载主题底部
get_footer();