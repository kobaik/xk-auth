<?php
/*
 * @Author: 星空
 * @Url: xkzhi.com
 * @Date: 2024-12-15 05:17:45
 * @LastEditTime: 2026-1-2 08:07:45
 * @Email: 1397403557@qq.com
 * @Project: 星空授权插件
 * @Description: 子比多功能授权插件
 * @Remind: 使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (!defined('ABSPATH')) exit; // 防止直接访问文件

// 安全启动检查
function xk_auth_secure_boot() {
    // 检查PHP版本
    if (version_compare(PHP_VERSION, '7.0.0', '<')) {
        die('授权系统要求PHP 7.0或更高版本。');
    }
    
    // 检查必要的PHP扩展
    $required_extensions = array('openssl', 'json');
    foreach ($required_extensions as $ext) {
        if (!extension_loaded($ext)) {
            die('授权系统需要PHP扩展：' . $ext);
        }
    }
    
    // 检查WordPress常量
    if (!defined('AUTH_KEY') || !defined('AUTH_SALT')) {
        die('WordPress安全常量未设置，请重新配置wp-config.php。');
    }
}
xk_auth_secure_boot();

if (class_exists('xk_auth_Core_license')) {
    // 检查类是否为真正的授权类
    $reflection = new ReflectionClass('xk_auth_Core_license');
    $class_file = $reflection->getFileName();
    $plugin_dir = plugin_dir_path(__FILE__);
    
    // 标准化路径分隔符
    $class_file_norm = str_replace('\\', '/', $class_file);
    $plugin_dir_norm = str_replace('\\', '/', $plugin_dir);
    
    // 验证类文件是否来自我们的插件目录
    if (strpos($class_file_norm, $plugin_dir_norm) === false) {
        // 类被恶意覆盖，强制退出
        die('授权系统检测到安全异常：检测到未授权的类覆盖。请移除可疑文件后重新安装插件。');
    }
    
    // 检查类是否被篡改
    if (!method_exists('xk_auth_Core_license', 'is_aut') || !method_exists('xk_auth_Core_license', 'auth') || !method_exists('xk_auth_Core_license', 'update')) {
        // 类被篡改，强制退出
        die('授权系统检测到安全异常：授权类结构不完整。请重新安装插件。');
    }
}

define('XK_AUTH_VERSION', '1.1.5'); // 版本号更新

// 安全常量定义
define('XK_AUTH_SECURITY_KEY', hash('sha256', AUTH_KEY . AUTH_SALT . __FILE__));
define('XK_AUTH_CLASS_PREFIX', 'xk_auth_secure_' . substr(md5(XK_AUTH_SECURITY_KEY), 0, 16));

// 硬件指纹生成函数
function xk_auth_generate_hardware_fingerprint() {
    // 收集指纹参数
    $server_name = $_SERVER['SERVER_NAME'] ?? '';
    $http_host = $_SERVER['HTTP_HOST'] ?? '';
    $server_software = $_SERVER['SERVER_SOFTWARE'] ?? '';
    $php_version = PHP_VERSION;
    $php_os = PHP_OS;
    $uname = php_uname('s') . ' ' . php_uname('r');
    $mysql_version = function_exists('mysqli_get_server_info') && isset($GLOBALS['wpdb']) && isset($GLOBALS['wpdb']->dbh) ? @mysqli_get_server_info($GLOBALS['wpdb']->dbh) : '';
    $sapi_name = php_sapi_name();
    $site_url = get_site_url();
    $max_execution_time = ini_get('max_execution_time');
    
    $fingerprint = array(
        $server_name,
        $http_host,
        $server_software,
        $php_version,
        $php_os,
        $uname,
        $mysql_version,
        $sapi_name,
        $site_url,
        $max_execution_time
    );
    
    // 移除空值，保持指纹稳定
    $stable_fingerprint = array_filter($fingerprint, function($value) {
        return !empty($value);
    });
    
    return hash('sha256', implode('|', $stable_fingerprint));
}

// 防过滤器绕过措施
function xk_auth_prevent_filter_bypass() {
    // 移除可能的恶意过滤器
    remove_all_filters('pre_http_request');
    remove_all_filters('pre_transient');
    remove_all_filters('pre_option_Xk_Auth_License_Auth_Key');
    remove_all_filters('pre_option_Xk_Auth_License_Dynamic_Token');
    remove_all_filters('pre_option_Xk_Auth_License_Signature');
}

// 增强的过滤器清理，在关键操作前调用
function xk_auth_ensure_clean_filters() {
    // 立即清理过滤器
    xk_auth_prevent_filter_bypass();
    
    // 验证过滤器是否真的被清理
    $http_request_filters = has_filter('pre_http_request');
    $transient_filters = has_filter('pre_transient');
    $option_filters = has_filter('pre_option_Xk_Auth_License_Auth_Key');
    
    if ($http_request_filters || $transient_filters || $option_filters) {
        // 过滤器清理失败，可能存在深层注入
        die('授权系统检测到安全异常：无法清理可疑过滤器。请检查系统环境后重新安装插件。');
    }
    
    // 检查是否有可疑的钩子添加
    global $wp_filter;
    if (isset($wp_filter['pre_http_request']) || isset($wp_filter['pre_transient'])) {
        die('授权系统检测到安全异常：发现可疑的过滤器注册。');
    }
}

// 在plugins_loaded钩子上运行，更早清理过滤器
add_action('plugins_loaded', 'xk_auth_prevent_filter_bypass', 1);

// 定期清理机制
function xk_auth_schedule_filter_cleanup() {
    if (!wp_next_scheduled('xk_auth_filter_cleanup')) {
        wp_schedule_event(time(), 'twicedaily', 'xk_auth_filter_cleanup');
    }
}
add_action('wp', 'xk_auth_schedule_filter_cleanup');

function xk_auth_filter_cleanup_callback() {
    xk_auth_prevent_filter_bypass();
}
add_action('xk_auth_filter_cleanup', 'xk_auth_filter_cleanup_callback');

// 验证类的完整性
function xk_auth_verify_class_integrity() {
    if (class_exists('xk_auth_Core_license')) {
        $reflection = new ReflectionClass('xk_auth_Core_license');
        $methods = $reflection->getMethods();
        $required_methods = array('auth', 'auth_page', 'is_aut', 'del_aut', 'update', 'get_class_name', 'verify_class_authenticity', 'check_runtime_environment');
        
        foreach ($required_methods as $method) {
            if (!$reflection->hasMethod($method)) {
                // 类被篡改，清除授权
                delete_option('Xk_Auth_License_Auth_Key');
                delete_option('Xk_Auth_License_Dynamic_Token');
                delete_option('Xk_Auth_License_Token_Expire');
                delete_option('Xk_Auth_License_Last_Communication');
                delete_option('Xk_Auth_License_Signature');
                delete_option('Xk_Auth_License_Encrypted_Data');
                delete_option('Xk_Auth_License_Last_Verification');
                delete_option('Xk_Auth_Hardware_Fingerprint');
                break;
            }
        }
    }
}
add_action('init', 'xk_auth_verify_class_integrity');

// 添加定期授权检查
function xk_auth_schedule_license_check() {
    if (!wp_next_scheduled('xk_auth_license_check')) {
        wp_schedule_event(time(), 'hourly', 'xk_auth_license_check');
    }
}
add_action('wp', 'xk_auth_schedule_license_check');

function xk_auth_license_check_callback() {
    if (class_exists('xk_auth_Core_license')) {
        xk_auth_Core_license::is_aut();
    }
}
add_action('xk_auth_license_check', 'xk_auth_license_check_callback');

// 检查请求冷却时间
function xk_auth_check_simple_cooldown($request_type, $identifier, $cool_down_time = 60) {
    $cache_key = 'xk_auth_' . $request_type . '_cooldown_' . md5($identifier);
    $last_request_time = get_transient($cache_key);
    
    if ($last_request_time && (time() - $last_request_time) < $cool_down_time) {
        return false;
    }
    
    set_transient($cache_key, time(), $cool_down_time);
    return true;
}

/**
 * 获取产品的时间套餐设置
 *
 * @param int $product_id 产品ID
 * @return array 时间套餐列表
 */
function xk_auth_get_product_time_packages($product_id) {
    $product_settings = xk_auth('product_settings', array());
    $time_packages = array();
    
    foreach ($product_settings as $product) {
        if (intval($product['product_id']) === intval($product_id) && isset($product['time_packages'])) {
            $time_packages = $product['time_packages'];
            break;
        }
    }
    
    return $time_packages;
}

/**
 * 获取随机订单号
 *
 * @param int $length 订单号长度
 * @return string 生成的订单号
 */
function get_order($length = 19) {
    $n = $length - 10;
 
    // 1、年月日
    $date = date('Ymd');
    // 2、基于微秒生成随机串
    $id = uniqid();
    // 3、截取随机串的随机后7位
    $sub = substr($id, 7, 13);
    // 4、将随机串分割成数组
    $str_arr = str_split($sub, 1);
    // 5、转换成ASCLL值,并取第一位连接成字符串
    $ascll_arr = array_map('ord', $str_arr);
    $ascll_str = implode('', $ascll_arr);
    // 6、随机取连续的4位
    $max_start_index = strlen($ascll_str)- 1 - 4;
    $start_index = rand(0, $max_start_index);
    $str = substr($ascll_str, $start_index, 4);
    // 7、生成末尾的n位随机数
    $rand = mt_rand('1' . str_repeat('0', $n-1), str_repeat('9', $n));
 
    $order = $date . $str . $rand;
 
    return $order;
}

/**
 * 检查用户是否被限制更换授权
 * 
 * @param int $user_id 用户ID
 * @return bool 返回true表示用户被限制更换授权，false表示允许
 */
function xk_auth_check_user_restriction($user_id) {
    // 获取全局设置
    $disable_for_all = xk_auth('disable_auth_change_for_all', false);
    
    // 如果全局禁止更换授权，则所有用户都被限制
    if ($disable_for_all) {
        return true;
    }
    
    // 获取限制用户列表
    $restricted_users = xk_auth('restricted_users_display', '');
    
    if (empty($restricted_users)) {
        return false; // 没有限制用户
    }
    
    // 将用户ID列表转换为数组
    $restricted_ids = explode(',', $restricted_users);
    $restricted_ids = array_map('trim', $restricted_ids);
    $restricted_ids = array_filter($restricted_ids);
    
    // 检查当前用户是否在限制列表中
    return in_array(strval($user_id), $restricted_ids);
}

/**
 * 处理设置保存逻辑
 * 确保用户ID列表格式正确并与隐藏字段同步
 */
function xk_auth_save_settings_handler($options, $unique, $sections) {
    // 检查是否是授权设置页面
    if ($unique !== 'xk_auth_setting') {
        return $options;
    }
    
    // 处理用户ID列表
    if (isset($options['restricted_users_display'])) {
        $user_ids = $options['restricted_users_display'];
        
        // 清理和格式化用户ID列表
        $user_ids = trim($user_ids);
        if (!empty($user_ids)) {
            $id_array = explode(',', $user_ids);
            $id_array = array_map('trim', $id_array);
            $id_array = array_filter($id_array);
            
            // 确保每个ID都是有效的数字
            $valid_ids = array();
            foreach ($id_array as $id) {
                if (is_numeric($id) && intval($id) > 0) {
                    $valid_ids[] = intval($id);
                }
            }
            
            // 去重并排序
            $valid_ids = array_unique($valid_ids);
            sort($valid_ids);
            
            // 转换回逗号分隔的字符串
            $options['restricted_users_display'] = implode(',', $valid_ids);
            // 同步更新隐藏字段
            $options['restricted_users'] = $options['restricted_users_display'];
        } else {
            // 空列表时也要同步
            $options['restricted_users'] = '';
        }
    }
    
    return $options;
}
add_filter('cs_framework_save_options', 'xk_auth_save_settings_handler', 10, 3);

/**
 * 检查并更新过期的授权状态
 * 当授权到期时，自动将状态更新为0（无效）
 */
if (!function_exists('xk_auth_check_expired_licenses')) {
function xk_auth_check_expired_licenses() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';
    $current_time = current_time('mysql');
    
    // 使用自定义SQL查询来更新过期的授权，因为wpdb->update()不支持复杂的条件
    $result = $wpdb->query($wpdb->prepare(
        "UPDATE $table_name SET status = 0 WHERE status = 1 AND expire_time < %s AND expire_time IS NOT NULL",
        $current_time
    ));
    
    return $result;
}
} // 闭合function_exists检查

// 注册定时任务钩子
function xk_auth_schedule_checks() {
    if (!wp_next_scheduled('xk_auth_daily_check_expired')) {
        wp_schedule_event(time(), 'hourly', 'xk_auth_daily_check_expired');
    }
}
add_action('wp', 'xk_auth_schedule_checks');

// 执行定时检查
function xk_auth_daily_check_expired_callback() {
    xk_auth_check_expired_licenses();
}
add_action('xk_auth_daily_check_expired', 'xk_auth_daily_check_expired_callback');

// 在管理页面加载时也执行检查，确保状态及时更新
function xk_auth_check_on_admin_load() {
    if (isset($_GET['page']) && strpos($_GET['page'], 'xk-auth') !== false) {
        xk_auth_check_expired_licenses();
    }
}
add_action('admin_init', 'xk_auth_check_on_admin_load');


// 添加授权购买页面meta
function xk_auth_add_meta_box_meta($meta)
{
    $meta['post_type'] = array('post', 'page');
    return $meta;
}
add_filter('zib_add_pay_meta_box_meta', 'xk_auth_add_meta_box_meta');

// 添加页面配置参数
add_filter('zib_add_pay_meta_box_args', 'xk_auth_add_meta_box_args', 99999);

/**
 * @description: 用户中心第一行的显示按钮
 * @param {*} $tabs_array
 * @return {*}
 */
function xk_auth_user_ctnter_main_tabs_array_filter_main($tabs_array)
{
    $tabs_array['product'] = array(
        'title' => '授权管理',
        'nav_attr' => 'drawer-title="所有授权管理"',
        'loader' => '<div class="zib-widget"><div class="mt10"><div class="placeholder k1 mb10"></div><div class="placeholder k1 mb10"></div><div class="placeholder s1"></div></div><p class="placeholder k1 mb30"></p><div class="placeholder t1 mb30"></div><p class="placeholder k1 mb30"></p><p style="height: 120px;" class="placeholder t1"></p></div>',
    );
    $tabs_array['log'] = array(
        'title' => '日志查询',
        'nav_attr' => 'drawer-title="授权日志查询"',
        'loader' => '<div class="zib-widget"><div class="mt10"><div class="placeholder k1 mb10"></div><div class="placeholder k1 mb10"></div><div class="placeholder s1"></div></div><p class="placeholder k1 mb30"></p><div class="placeholder t1 mb30"></div><p class="placeholder k1 mb30"></p><p style="height: 120px;" class="placeholder t1"></p></div>',
    );

    return $tabs_array;
}
add_filter('user_ctnter_main_tabs_array', 'xk_auth_user_ctnter_main_tabs_array_filter_main');

/**
 * 更改用户授权信息中的域名
 *
 * @param string $user_id 要更改授权信息的用户ID。如果未提供，则使用当前登录用户的ID。
 * @param string $product_id 要更改授权信息的产品ID。
 * @param string $old_domain 原始域名。
 * @param string $new_domain 新域名。
 */
function xk_auth_change_api($user_id = '', $product_id = '', $old_domain = '', $new_domain = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';
    $data = array('domain' => $new_domain);
    $where = array('user_id' => $user_id, 'product_id' => $product_id, 'domain' => $old_domain);
    $wpdb->update($table_name, $data, $where);
}


// 授权/更新代码class核心
class xk_auth_Core_license
{
    // 基础类名前缀
    const CLASS_PREFIX = XK_AUTH_CLASS_PREFIX;
    
    public static function auth()
    {
        // 实时验证类的真实性
        self::verify_class_authenticity();
        
        $aut = array(
            array(
                'type' => 'submessage',
                'style' => 'warning',
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 感谢您使用星空子比插件</h3>
                <p>由原创开发的空白授权插件！创作不易，支持正版，从我做起！</p>
                <p>请确认已在授权站将本站域名<badge class="c-red">' . $_SERVER['HTTP_HOST'] . '</badge>添加授权</p>
                <div style="margin: 10px 14px;">
                <li>官网：<a target="_bank" href="https://www.xkzhi.cn/">https://www.xkzhi.cn/</a></li>
                <li>作者联系方式：<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=1397403557&amp;site=qq&amp;menu=yes">QQ 1397403557</a></li>
                <li>管理我的授权：<a href="https://www.xkzhi.cn/user/product">https://www.xkzhi.cn/user/product</a></li>
                </div>',
            ),
            xk_auth_Core_license::auth_page()
        );
        return $aut;
    }
    public static function auth_page()
    {
        if (!xk_auth_Core_license::is_aut()) {
            $aut =   array(
                'content' => '<div id="authorization_form" class="ajax-form" ajax-url="' . esc_url(admin_url('admin-ajax.php')) . '">
            <div class="ok-icon"><svg class="icon" style="font-size: 1.2em;width: 1em; height: 1em;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024"><path d="M880 502.3V317.1c0-34.9-24.4-66-60.8-77.4l-80.4-30c-37.8-14.1-73.4-32.9-105.7-55.7l-84.6-60c-19.2-15.2-47.8-15.2-67 0l-84.7 59.9c-32.3 22.8-67.8 41.6-105.7 55.7l-80.4 30c-36.4 11.4-60.8 42.5-60.8 77.4v185.2c0 123.2 63.9 239.2 172.5 313.2l158.5 108c20.2 13.7 47.9 13.7 68.1 0l158.5-108C816.1 741.6 880 625.5 880 502.3z" fill="#0DCEA7" p-id="17337"></path><path d="M150 317.1v3.8c13.4-27.6 30-53.3 49.3-76.7C169.4 258 150 286 150 317.1zM880 317.1c0-34.9-24.4-66-60.8-77.4l-43.5-16.2c57.7 60.6 95.8 140 104.2 228.1l0.1-134.5zM572.8 111.2L548.5 94c-19.2-15.2-47.8-15.2-67 0l-15.3 10.8c10-0.8 20.2-1.2 30.5-1.2 26 0.1 51.5 2.7 76.1 7.6zM496.7 873.9c-39.5 0-77.6-5.9-113.4-17l97.7 66.6c20.2 13.7 47.9 13.7 68.1 0l158.5-108C816.1 741.6 880 625.5 880 502.3z" fill="#0DCEA7" p-id="17338"></path><path d="M875.8 557.2c2.8-18.1 4.3-36.4 4.3-54.9v-50.8c-8.5-88.1-46.6-167.4-104.2-228.1L739 209.6c-37.8-14.1-73.4-32.9-105.7-55.7l-60.5-42.7c-24.6-4.9-50-7.5-76.1-7.5-10.3 0-20.4 0.4-30.5 1.2l-58.7 41.5c23.4-5.2 47.7-8 72.7-8 183.6 0 332.4 148.8 332.4 332.4S663.9 803 480.3 803c-170.8 0-311.5-128.9-330.2-294.7 2 121 65.6 234.5 172.4 307.2l60.8 41.4c35.9 11 74 17 113.4 17 189.3 0 346.8-136.6 379.1-316.7zM261.2 220.8l-50.4 18.8c-4 1.3-7.8 2.8-11.5 4.5-19.3 23.4-35.9 49.2-49.3 76.7v112.7c9.4-84.5 50.5-159.4 111.2-212.7z" fill="#1DD49C" p-id="17339"></path><path d="M480.3 803c183.6 0 332.4-148.8 332.4-332.4S663.9 138.3 480.3 138.3c-25 0-49.3 2.8-72.7 8l-10.7 7.6c-32.3 22.8-67.8 41.6-105.7 55.7l-30 11.2C200.5 274.1 159.4 349 150 433.6v68.8c0 2 0 4 0.1 6C168.8 674.1 309.5 803 480.3 803z m-16.4-630c154.4 0 279.6 125.2 279.6 279.6S618.3 732.2 463.9 732.2 184.3 607 184.3 452.6 309.5 173 463.9 173z" fill="#2DDB92" p-id="17340"></path><path d="M463.9 732.2c154.4 0 279.6-125.2 279.6-279.6S618.3 173 463.9 173 184.3 298.2 184.3 452.6s125.2 279.6 279.6 279.6z m-16.4-524.5c125.3 0 226.8 101.5 226.8 226.8S572.8 661.3 447.5 661.3 220.7 559.8 220.7 434.5s101.6-226.8 226.8-226.8z" fill="#3DE188" p-id="17341" data-spm-anchor-id="a313x.7781069.0.i7"></path><path d="M447.5 661.3c125.3 0 226.8-101.5 226.8-226.8S572.8 207.7 447.5 207.7 220.7 309.2 220.7 434.5s101.6 226.8 226.8 226.8z m-16.4-419c96.1 0 174 77.9 174 174s-77.9 174-174 174-174-77.9-174-174 77.9-174 174-174z" fill="#4CE77D" p-id="17342"></path><path d="M431.1 590.4c96.1 0 174-77.9 174-174s-77.9-174-174-174-174 77.9-174 174 77.9 174 174 174zM414.7 277c67 0 121.3 54.3 121.3 121.3s-54.3 121.3-121.3 121.3-121.3-54.3-121.3-121.3S347.8 277 414.7 277z" fill="#5CEE73" p-id="17343"></path><path d="M414.7 398.3m-121.3 0a121.3 121.3 0 1 0 242.6 0 121.3 121.3 0 1 0-242.6 0Z" fill="#6CF468" p-id="17344"></path><path d="M515 100.7c8.3 0 16.2 2.7 22.3 7.5l0.4 0.3 0.4 0.3 84.7 59.9c33.5 23.7 70.5 43.2 109.8 57.9l80.4 30 0.4 0.2 0.5 0.1c28.8 9.1 48.2 33.3 48.2 60.3v185.2c0 28.9-3.7 57.8-11.1 86-7.3 27.8-18.1 54.8-32.2 80.4-14.1 25.6-31.5 49.8-51.7 71.8-20.5 22.4-43.9 42.6-69.6 60.1L539 908.6c-6.8 4.6-15.3 7.2-23.9 7.2s-17.1-2.6-23.9-7.2l-158.5-108c-25.7-17.5-49.1-37.7-69.6-60.1-20.2-22-37.6-46.2-51.7-71.8-14.1-25.6-24.9-52.6-32.2-80.4-7.4-28.1-11.1-57-11.1-86V317.1c0-27 19.4-51.2 48.2-60.3l0.5-0.1 0.4-0.2 80.4-30c39.3-14.7 76.2-34.1 109.8-57.9l84.7-59.9 0.4-0.3 0.4-0.3c5.9-4.8 13.9-7.4 22.1-7.4m0-18c-11.9 0-23.9 3.8-33.5 11.4L396.8 154c-32.3 22.8-67.8 41.6-105.7 55.7l-80.4 30c-36.4 11.4-60.8 42.5-60.8 77.4v185.2c0 123.2 63.9 239.2 172.5 313.2l158.5 108c10.1 6.9 22.1 10.3 34 10.3 12 0 24-3.4 34-10.3l158.5-108c108.6-74 172.5-190 172.5-313.2V317.1c0-34.9-24.4-66-60.8-77.4l-80.4-30c-37.8-14.1-73.4-32.9-105.7-55.7l-84.5-60c-9.6-7.5-21.5-11.3-33.5-11.3z" fill="#0EC69A" p-id="17345"></path><path d="M688.8 496.7V406c0-17.1-11.6-32.3-28.9-37.9l-38.3-14.7c-18-6.9-35-16.1-50.3-27.3L531 296.8c-9.1-7.4-22.8-7.4-31.9 0l-40.3 29.3a218.45 218.45 0 0 1-50.3 27.3l-38.3 14.7c-17.3 5.6-28.9 20.8-28.9 37.9v90.7c0 60.3 30.4 117.1 82.1 153.3l75.5 52.9c9.6 6.7 22.8 6.7 32.4 0l75.5-52.9c51.6-36.2 82-93 82-153.3z" fill="#9CFFBD" p-id="17346"></path><path d="M325.6 287.5c-7.2 0-14.1-4.4-16.8-11.6-3.5-9.3 1.1-19.7 10.4-23.2 68.5-26.2 110.5-60.3 110.9-60.6 7.7-6.3 19-5.2 25.3 2.5s5.2 19-2.5 25.3c-1.9 1.5-47 38.2-120.9 66.4-2.1 0.8-4.2 1.2-6.4 1.2z" fill="#FFFFFF" p-id="17347"></path><path d="M260.2 311.7c-7.3 0-14.2-4.5-16.9-11.7-3.5-9.3 1.3-19.7 10.6-23.1l10.5-3.9c9.3-3.5 19.7 1.3 23.1 10.6 3.5 9.3-1.3 19.7-10.6 23.1l-10.5 3.9c-2.1 0.7-4.2 1.1-6.2 1.1z" fill="#FFFFFF" p-id="17348"></path></svg></div>
            <p style="color:#fd4c73;">激动人心的时候到了！即将开启优雅的建站之旅！</p>
            <input class="regular-text" name="authcode" type="text" value="" placeholder="请输入授权码">
            <input type="hidden" ajax-name="action" value="xk_auth_license_ajax">
            <a id="authorization_submit" class="but c-blue ajax-submit">一键授权</a>
            <div class="ajax-notice"></div>
            </div>',
                'type'    => 'submessage',
            );
        } else {
            $aut =   array(
                'content' => '<div id="authorization_form" class="ajax-form" ajax-url="' . esc_url(admin_url('admin-ajax.php')) . '">
            <div class="ok-icon"><svg t="1585712312243" class="icon" style="width: 1em; height: 1em;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3845" data-spm-anchor-id="a313x.7781069.0.i0"><path d="M115.456 0h793.6a51.2 51.2 0 0 1 51.2 51.2v294.4a102.4 102.4 0 0 1-102.4 102.4h-691.2a102.4 102.4 0 0 1-102.4-102.4V51.2a51.2 51.2 0 0 1 51.2-51.2z m0 0" fill="#FF6B5A" p-id="3846"></path><path d="M256 13.056h95.744v402.432H256zM671.488 13.056h95.744v402.432h-95.744z" fill="#FFFFFF" p-id="3847"></path><path d="M89.856 586.752L512 1022.72l421.632-435.2z m0 0" fill="#6DC1E2" p-id="3848"></path><path d="M89.856 586.752l235.52-253.952h372.736l235.52 253.952z m0 0" fill="#ADD9EA" p-id="3849"></path><path d="M301.824 586.752L443.136 332.8h137.216l141.312 253.952z m0 0" fill="#E1F9FF" p-id="3850"></path><path d="M301.824 586.752l209.92 435.2 209.92-435.2z m0 0" fill="#9AE6F7" p-id="3851"></path></svg></div>
            <p style=" color: #0087e8; font-size: 15px; "><svg class="icon" style="width: 1em;height: 1em;vertical-align: -.2em;fill: currentColor;overflow: hidden;font-size: 1.4em;" viewBox="0 0 1024 1024"><path d="M492.224 6.72c11.2-8.96 26.88-8.96 38.016 0l66.432 53.376c64 51.392 152.704 80.768 243.776 80.768 27.52 0 55.104-2.624 81.92-7.872a30.08 30.08 0 0 1 24.96 6.4 30.528 30.528 0 0 1 11.008 23.424V609.28c0 131.84-87.36 253.696-228.288 317.824L523.52 1021.248a30.08 30.08 0 0 1-24.96 0l-206.464-94.08C151.36 862.976 64 741.12 64 609.28V162.944a30.464 30.464 0 0 1 36.16-29.888 425.6 425.6 0 0 0 81.92 7.936c91.008 0 179.84-29.504 243.712-80.768z m19.008 62.528l-47.552 38.208c-75.52 60.8-175.616 94.144-281.6 94.144-19.2 0-38.464-1.024-57.472-3.328V609.28c0 107.84 73.92 208.512 192.768 262.72l193.856 88.384 193.92-88.384c118.912-54.208 192.64-154.88 192.64-262.72V198.272a507.072 507.072 0 0 1-57.344 3.328c-106.176 0-206.144-33.408-281.728-94.08l-47.488-38.272z m132.928 242.944c31.424 0 56.832 25.536 56.832 56.832H564.544v90.944h121.92a56.448 56.448 0 0 1-56.384 56.384H564.48v103.424h150.272a56.832 56.832 0 0 1-56.832 56.832H365.056a56.832 56.832 0 0 1-56.832-56.832h60.608v-144c0-33.92 27.52-61.44 61.44-61.44v205.312h71.68V369.024H324.8c0-31.424 25.472-56.832 56.832-56.832z" p-id="4799"></path></svg> 恭喜您! 已完成授权</p>
            <input type="hidden" ajax-name="action" value="xk_auth_license_ajax">
            <a id="authorization_submit" class="but c-red ajax-submit">撤销授权</a>
            <div class="ajax-notice"></div>
            </div>',
                'type'    => 'submessage',
            );
        }
        return $aut;
    }
    // 生成安全的类名
    public static function get_class_name() {
        return XK_AUTH_CLASS_PREFIX . '_Core_license_' . substr(hash('sha256', XK_AUTH_SECURITY_KEY), 0, 16);
    }
    
    // 验证类的真实性
    public static function verify_class_authenticity() {
        // 获取当前类的反射信息
        $reflection = new ReflectionClass(__CLASS__);
        $class_file = $reflection->getFileName();
        $plugin_dir = plugin_dir_path(__FILE__);
        
        // 标准化路径分隔符
        $class_file_norm = str_replace('\\', '/', $class_file);
        $plugin_dir_norm = str_replace('\\', '/', $plugin_dir);
        
        // 验证类文件是否来自我们的插件目录
        if (strpos($class_file_norm, $plugin_dir_norm) === false) {
            die('授权系统检测到安全异常：调用了未授权的类方法。');
        }
        
        // 验证类是否包含所有必需的方法
        $required_methods = array('auth', 'auth_page', 'is_aut', 'del_aut', 'update', 'get_class_name', 'verify_class_authenticity', 'check_runtime_environment');
        foreach ($required_methods as $method) {
            if (!method_exists(__CLASS__, $method)) {
                die('授权系统检测到安全异常：类方法不完整。');
            }
        }
    }
    
    // 检查运行环境
    public static function check_runtime_environment() {
        // 检查PHP配置
        if (ini_get('allow_url_fopen') !== '1') {
            die('授权系统需要启用allow_url_fopen。');
        }
        
        // 检查是否在CLI模式下运行
        if (php_sapi_name() === 'cli') {
            die('授权系统不能在CLI模式下运行。');
        }
        
        // 检查WordPress环境
        if (!defined('WPINC')) {
            die('授权系统必须在WordPress环境中运行。');
        }
        
        // 检查是否有可疑的全局变量
        if (isset($GLOBALS['xk_auth_bypass'])) {
            die('授权系统检测到安全异常：发现可疑的全局变量。');
        }
        
        // 检查是否有可疑的函数重定义
        if (function_exists('override_function') || function_exists('runkit_function_redefine')) {
            die('授权系统检测到安全异常：发现可疑的函数修改工具。');
        }
    }
    
    public static function is_aut()
    {
        //error_log('[星空授权] 开始执行授权验证');
        
        // 实时验证类的真实性
        self::verify_class_authenticity();
        //error_log('[星空授权] 类真实性验证通过');
        
        // 检查运行环境
        self::check_runtime_environment();
        //error_log('[星空授权] 运行环境检查通过');
        
        // 检查硬件指纹
        $current_fingerprint = xk_auth_generate_hardware_fingerprint();
        $stored_fingerprint = get_option('Xk_Auth_Hardware_Fingerprint');
        //error_log('[星空授权] 当前硬件指纹: ' . $current_fingerprint);
        //error_log('[星空授权] 存储的硬件指纹: ' . $stored_fingerprint);
        
        if ($stored_fingerprint && $current_fingerprint !== $stored_fingerprint) {
            //error_log('[星空授权] 硬件环境改变，需要重新授权');
            return false;
        }
        
        $auth_key = get_option('Xk_Auth_License_Auth_Key');
        $dynamic_token = get_option('Xk_Auth_License_Dynamic_Token');
        $token_expire = get_option('Xk_Auth_License_Token_Expire', 0);
        $last_communication = get_option('Xk_Auth_License_Last_Communication', 0);
        $signature = get_option('Xk_Auth_License_Signature');
        $encrypted_data = get_option('Xk_Auth_License_Encrypted_Data');
        
        //error_log('[星空授权] 授权密钥: ' . $auth_key);
        //error_log('[星空授权] 动态Token: ' . $dynamic_token);
        //error_log('[星空授权] Token过期时间: ' . date('Y-m-d H:i:s', $token_expire));
        //error_log('[星空授权] 签名: ' . $signature);
        //error_log('[星空授权] 加密数据: ' . ($encrypted_data ? '存在' : '不存在'));
        
        // 检查必要数据是否存在
        if (empty($auth_key) || empty($dynamic_token) || empty($token_expire) || empty($encrypted_data)) {
            //error_log('[星空授权] 必要授权数据缺失');
            //error_log('[星空授权] auth_key: ' . ($auth_key ? '存在' : '不存在'));
            //error_log('[星空授权] dynamic_token: ' . ($dynamic_token ? '存在' : '不存在'));
            //error_log('[星空授权] token_expire: ' . ($token_expire ? '存在' : '不存在'));
            //error_log('[星空授权] encrypted_data: ' . ($encrypted_data ? '存在' : '不存在'));
            return false;
        }
        
        // 解密数据并验证
        $decrypted_data = openssl_decrypt($encrypted_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
        //error_log('[星空授权] 解密数据结果: ' . ($decrypted_data ? '成功' : '失败'));
        if (!$decrypted_data) {
            return false;
        }
        
        $auth_data = json_decode($decrypted_data, true);
        //error_log('[星空授权] 解密后数据: ' . json_encode($auth_data));
        if (!$auth_data || !isset($auth_data['auth_key']) || $auth_data['auth_key'] !== $auth_key) {
            //error_log('[星空授权] 授权数据验证失败');
            return false;
        }
        //error_log('[星空授权] 授权数据验证通过');
        
        // 检查Token是否过期
        $current_time = time();
        //error_log('[星空授权] 当前时间: ' . date('Y-m-d H:i:s', $current_time));
        //error_log('[星空授权] Token过期时间: ' . date('Y-m-d H:i:s', $token_expire));
        //error_log('[星空授权] Token是否过期: ' . ($current_time > $token_expire ? '是' : '否'));
        
        if ($current_time > $token_expire) {
            //error_log('[星空授权] Token已过期，尝试刷新');
            
            // 检查请求冷却时间（使用域名作为标识符，300秒冷却）
            $domain = $_SERVER['HTTP_HOST'];
            $cache_key = 'xk_auth_token_refresh_cooldown_' . md5($domain . self::get_class_name());
            $last_refresh_time = get_transient($cache_key);
            //error_log('[星空授权] 上次刷新时间: ' . ($last_refresh_time ? date('Y-m-d H:i:s', $last_refresh_time) : '从未刷新'));
            //error_log('[星空授权] 是否在冷却期: ' . ($last_refresh_time && ($current_time - $last_refresh_time) <= 300 ? '是' : '否'));
            
            if (!$last_refresh_time || ($current_time - $last_refresh_time) > 300) {
                // Token过期，尝试刷新
                $auth_request_url = 'https://www.xkzhi.cn/wp-json/Authorization/v1/Xkzhisqqwer?product_id=6994&domain=' . $domain . '&auth_key=' . $auth_key . '&action=get_dynamic_token&fingerprint=' . $current_fingerprint;
                //error_log('[星空授权] 刷新Token请求URL: ' . $auth_request_url);
                $auth_response = wp_remote_get($auth_request_url, array('timeout' => 30));
                
                if (!is_wp_error($auth_response)) {
                    //error_log('[星空授权] 刷新Token请求成功');
                    $auth_data = json_decode(wp_remote_retrieve_body($auth_response), true);
                    //error_log('[星空授权] 刷新Token响应: ' . json_encode($auth_data));
                    
                    if ($auth_data && isset($auth_data['status']) && $auth_data['status'] == 1) {
                        //error_log('[星空授权] 刷新Token成功');

                        
                        // 保存新的动态Token
                        $new_dynamic_token = $auth_data['dynamic_token'];
                        $new_expire_time = $auth_data['expire_time'];
                        //error_log('[星空授权] 新动态Token: ' . $new_dynamic_token);
                        //error_log('[星空授权] 新过期时间: ' . date('Y-m-d H:i:s', $new_expire_time));
                        
                        // 加密存储授权数据
                        $encrypt_data = json_encode(array(
                            'auth_key' => $auth_key,
                            'dynamic_token' => $new_dynamic_token,
                            'expire_time' => $new_expire_time,
                            'timestamp' => $current_time,
                            'fingerprint' => $current_fingerprint
                        ));
                        $new_encrypted_data = openssl_encrypt($encrypt_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
                        //error_log('[星空授权] 新加密数据: ' . ($new_encrypted_data ? '成功' : '失败'));
                        
                        update_option('Xk_Auth_License_Dynamic_Token', $new_dynamic_token);
                        update_option('Xk_Auth_License_Token_Expire', $new_expire_time);
                        update_option('Xk_Auth_License_Last_Communication', $current_time);
                        update_option('Xk_Auth_License_Encrypted_Data', $new_encrypted_data);
                        update_option('Xk_Auth_Hardware_Fingerprint', $current_fingerprint);
                        //error_log('[星空授权] 新Token已保存');
                        
                        // 保存加密的授权数据（如果返回）
                        if (isset($auth_data['encrypted_auth_data'])) {
                            update_option('Xk_Auth_License_Encrypted_Auth_Data', $auth_data['encrypted_auth_data']);
                            //error_log('[星空授权] 加密授权数据已保存');
                        }
                        
                        // 设置刷新冷却时间
                        set_transient($cache_key, $current_time, 300);
                        //error_log('[星空授权] 刷新冷却时间已设置');
                    } else {
                        // 刷新失败，设置冷却时间，返回未授权
                        //error_log('[星空授权] 刷新Token失败: ' . ($auth_data['message'] ?? '未知错误'));
                        set_transient($cache_key, $current_time, 300);
                        return false;
                    }
                } else {
                    // 请求失败，设置冷却时间，返回未授权
                    //error_log('[星空授权] 刷新Token请求失败: ' . $auth_response->get_error_message());
                    set_transient($cache_key, $current_time, 300);
                    return false;
                }
            } else {
                // 冷却时间内，Token已过期，返回未授权
                //error_log('[星空授权] 在冷却期内，Token已过期');
                return false;
            }
        } else {
            //error_log('[星空授权] Token未过期，继续验证');
        }
        
        // 定期与授权服务器验证（每小时验证一次）
        $last_verification = get_option('Xk_Auth_License_Last_Verification', 0);
        //error_log('[星空授权] 上次验证时间: ' . ($last_verification ? date('Y-m-d H:i:s', $last_verification) : '从未验证'));
        //error_log('[星空授权] 是否需要验证: ' . ($current_time - $last_verification > 3600 ? '是' : '否'));
        
        if ($current_time - $last_verification > 3600) {
            //error_log('[星空授权] 开始执行定期验证');
            $domain = $_SERVER['HTTP_HOST'];
            $verify_url = 'https://www.xkzhi.cn/wp-json/Authorization/v1/Xkzhisqqwer?product_id=6994&domain=' . $domain . '&auth_key=' . $auth_key . '&dynamic_token=' . $dynamic_token . '&fingerprint=' . $current_fingerprint;
            //error_log('[星空授权] 验证请求URL: ' . $verify_url);
            // 检查请求冷却时间（使用域名作为标识符，300秒冷却）
            $cooldown_key = 'xk_auth_verification_cooldown_' . md5($domain . self::get_class_name());
            $last_verification_time = get_transient($cooldown_key);
            //error_log('[星空授权] 上次验证冷却时间: ' . ($last_verification_time ? date('Y-m-d H:i:s', $last_verification_time) : '从未设置'));
            
            if (!$last_verification_time || (time() - $last_verification_time) > 300) {
                $verification_response = wp_remote_get($verify_url, array('timeout' => 15));
                if (!is_wp_error($verification_response)) {
                    //error_log('[星空授权] 验证请求成功');
                    $verification_data = json_decode(wp_remote_retrieve_body($verification_response), true);
                    //error_log('[星空授权] 验证响应: ' . json_encode($verification_data));
                    if (!$verification_data || !isset($verification_data['status']) || $verification_data['status'] != 1) {
                        // 验证失败，设置冷却时间
                        //error_log('[星空授权] 验证失败');
                        set_transient($cooldown_key, $current_time, 300);
                        return false;
                    }
                    //error_log('[星空授权] 验证成功，更新验证时间');
                    update_option('Xk_Auth_License_Last_Verification', $current_time);
                } else {
                    // 请求失败，设置冷却时间
                    //error_log('[星空授权] 验证请求失败: ' . $verification_response->get_error_message());
                    set_transient($cooldown_key, $current_time, 300);
                }
            } else {
                //error_log('[星空授权] 验证在冷却期内，跳过');
            }
        }
        
        // 检查是否超过10800秒未通讯
        //error_log('[星空授权] 上次通讯时间: ' . ($last_communication ? date('Y-m-d H:i:s', $last_communication) : '从未通讯'));
        //error_log('[星空授权] 是否需要更新通讯时间: ' . ($current_time - $last_communication > 10800 ? '是' : '否'));
        
        if ($current_time - $last_communication > 10800) {
            // 更新最后通讯时间
            //error_log('[星空授权] 更新最后通讯时间');
            update_option('Xk_Auth_License_Last_Communication', $current_time);
        }
        
        //error_log('[星空授权] 授权验证通过，返回true');
        return true;
    }
    public static function del_aut()
    {
        $deta = get_option('Xk_Auth_License_Auth_Key');
        if (!empty($deta)) {
            // 清除所有授权相关数据
            delete_option('Xk_Auth_License_Auth_Key');
            delete_option('Xk_Auth_License_Dynamic_Token');
            delete_option('Xk_Auth_License_Token_Expire');
            delete_option('Xk_Auth_License_Last_Communication');
            delete_option('Xk_Auth_License_Signature');
            delete_option('Xk_Auth_License_Encrypted_Data');
            delete_option('Xk_Auth_License_Last_Verification');
            delete_option('Xk_Auth_Hardware_Fingerprint');
            return true;
        }
        return false;
    }

    public static function update()
    {
        // 实时验证类的真实性
        self::verify_class_authenticity();
        
        $csf           = array();
        // 使用授权插件自己的版本常量，避免依赖主插件
        $current_version = defined('XK_AUTH_VERSION') ? XK_AUTH_VERSION : '1.0.1';
        $notice = '            <div class="ajax-form" ajax-url="' . esc_url(admin_url('admin-ajax.php')) . '">
            <h3 class="c-red"><i class="fa fa-thumbs-o-up fa-fw" aria-hidden="true"></i> 当前插件已经是最新版啦</h3>
            <p><b>当前插件版本：V ' . $current_version . ' </b></p>
            <p class="ajax-notice"></p>
            <p><a href="javascript:;" class="but jb-blue ajax-submit">检测更新</a></p>
            <input type="hidden" ajax-name="action" value="xk_auth_license_update_ajax">
            </div>';

        $csf[] = array(
            'type'    => 'notice',
            'style'   => 'info',
            'content' => $notice,
        );

        $csf[] = array(
            'title'   => '系统环境',
            'type'    => 'content',
            'content' => '<div style="margin-left:14px;"><li><strong>操作系统</strong>： ' . PHP_OS . ' </li>
            <li><strong>运行环境</strong>： ' . $_SERVER["SERVER_SOFTWARE"] . ' </li>
            <li><strong>PHP版本</strong>： ' . PHP_VERSION . ' </li>
            <li><strong>PHP上传限制</strong>： ' . ini_get('upload_max_filesize') . ' </li>
            <li><strong>WordPress版本</strong>： ' . get_bloginfo('version') . '</li>
            <li><strong>系统信息</strong>： ' . php_uname() . ' </li>
            <li><strong>服务器时间</strong>： ' . current_time('mysql') . '</li></div>
            <a class="but c-yellow" href="' . admin_url('site-health.php?tab=debug') . '">查看更多系统信息</a>',
        );
        $csf[] = array(
            'title'   => '推荐环境',
            'type'    => 'content',
            'content' => '<div style="margin-left:14px;"><li><strong>WordPress</strong>：5.0+，推荐使用最新版</li>
            <li><strong>PHP</strong>：PHP7.0及以上，推荐使用7.2版本</li>
            <li><strong>服务器配置</strong>：无要求，最低配都行</li>
            <li><strong>操作系统</strong>：无要求，不推荐使用Windows系统</li></div>',
        );
        return $csf;
    }
}

//  授权验证AJAX
function xk_auth_license_ajax()
{
    //error_log('[星空授权] 开始执行授权AJAX');
    
    // 确保过滤器被清理
    xk_auth_ensure_clean_filters();
    //error_log('[星空授权] 过滤器清理完成');
    
    // 获取授权码，处理撤销授权情况
    $authcode = $_REQUEST['authcode'] ?? '';
    $aut = preg_replace('/[^A-Za-z0-9]/', '', $authcode);
    //error_log('[星空授权] 接收到的授权码: ' . $authcode);
    //error_log('[星空授权] 处理后的授权码: ' . $aut);
    
    // 检查当前授权状态
    $current_auth_status = xk_auth_Core_license::is_aut();
    //error_log('[星空授权] 当前授权状态: ' . ($current_auth_status ? '已授权' : '未授权'));
    
    if ($current_auth_status) {
        //error_log('[星空授权] 执行撤销授权操作');
        // 已授权状态，执行撤销授权
        delete_option('Xk_Auth_License_Auth_Key');
        delete_option('Xk_Auth_License_Dynamic_Token');
        delete_option('Xk_Auth_License_Token_Expire');
        delete_option('Xk_Auth_License_Last_Communication');
        delete_option('Xk_Auth_License_Signature');
        delete_option('Xk_Auth_License_Encrypted_Data');
        delete_option('Xk_Auth_License_Last_Verification');
        delete_option('Xk_Auth_Hardware_Fingerprint');
        //error_log('[星空授权] 授权数据已清除');
        echo wp_send_json(array('error' => 0, 'reload' => true, 'msg' => '授权已撤销,请刷新页面'));
        exit;
    } else {
        //error_log('[星空授权] 执行授权操作');
        // 未授权状态，执行授权操作 - 添加请求冷却检查，防止频繁请求
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $cache_key = 'xk_auth_license_cooldown_' . md5($ip);
        $last_request_time = get_transient($cache_key);
        $cool_down_time = 60; // 60秒冷却时间
        
        //error_log('[星空授权] 请求IP: ' . $ip);
        //error_log('[星空授权] 上次请求时间: ' . ($last_request_time ? date('Y-m-d H:i:s', $last_request_time) : '从未请求'));
        
        if ($last_request_time && (time() - $last_request_time) < $cool_down_time) {
            $remaining_time = $cool_down_time - (time() - $last_request_time);
            //error_log('[星空授权] 请求过于频繁，剩余冷却时间: ' . $remaining_time . '秒');
            echo wp_send_json(array('error_type' => 'error', 'msg' => '请求过于频繁，请等待' . $remaining_time . '秒后重试'));
            exit;
        }
        
        // 设置冷却时间
        set_transient($cache_key, time(), $cool_down_time);
        //error_log('[星空授权] 冷却时间已设置');
        
        // 验证授权码
        if (empty($aut)) {
            //error_log('[星空授权] 授权码为空');
            echo wp_send_json(array('error_type' => 'error', 'msg' => '请输入授权码'));
            exit;
        } elseif (strlen($aut) !== 32) {
            //error_log('[星空授权] 授权码格式错误，长度: ' . strlen($aut));
            echo wp_send_json(array('error_type' => 'error', 'msg' => '授权码类型错误'));
            exit;
        }
        
        // 使用更可靠的域名获取方式
        $domain = $_SERVER['HTTP_HOST'];
        //error_log('[星空授权] 域名: ' . $domain);
        
        // 生成硬件指纹
        $fingerprint = xk_auth_generate_hardware_fingerprint();
        //error_log('[星空授权] 生成的硬件指纹: ' . $fingerprint);
        
        // Step 1: 发起授权请求，获取动态Token
        $auth_request_url = 'https://www.xkzhi.cn/wp-json/Authorization/v1/Xkzhisqqwer?product_id=6994&domain=' . $domain . '&auth_key=' . $aut . '&action=get_dynamic_token';
        
        $auth_response = wp_remote_get($auth_request_url, array('timeout' => 30));
        
        if (is_wp_error($auth_response)) {
            //error_log('[星空授权] 授权请求失败: ' . $auth_response->get_error_message());
            echo wp_send_json(array('error_type' => 'error', 'reload' => false, 'msg' => '连接授权服务器失败，请稍后重试'));
            exit;
        }
        
        $auth_response_body = wp_remote_retrieve_body($auth_response);
        //error_log('[星空授权] 授权响应: ' . $auth_response_body);
        
        $auth_data = json_decode($auth_response_body, true);
        
        if (!$auth_data || !isset($auth_data['status']) || $auth_data['status'] != 1) {
            //error_log('[星空授权] 获取动态Token失败: ' . ($auth_data['message'] ?? '未知错误'));
            echo wp_send_json(array('error_type' => 'error', 'reload' => false, 'msg' => $auth_data['message'] ?? '获取动态Token失败'));
            exit;
        }
        
        //error_log('[星空授权] 获取动态Token成功');
        

        
        // Step 2: 使用动态Token进行授权验证
        $dynamic_token = $auth_data['dynamic_token'];
        //error_log('[星空授权] 动态Token: ' . $dynamic_token);
        
        $verify_url = 'https://www.xkzhi.cn/wp-json/Authorization/v1/Xkzhisqqwer?&product_id=6994&domain=' . $domain . '&auth_key=' . $aut . '&dynamic_token=' . urlencode($dynamic_token);
        $verify_response = wp_remote_get($verify_url, array('timeout' => 30));
        
        if (is_wp_error($verify_response)) {
            //error_log('[星空授权] 验证请求失败: ' . $verify_response->get_error_message());
            echo wp_send_json(array('error_type' => 'error', 'reload' => false, 'msg' => '连接授权服务器失败，请稍后重试'));
            exit;
        }
        
        $verify_response_body = wp_remote_retrieve_body($verify_response);
        //error_log('[星空授权] 验证响应: ' . $verify_response_body);
        
        $verify_data = json_decode($verify_response_body, true);
        
        if ($verify_data && isset($verify_data['status'])) {
            if ($verify_data['status'] == 1) {
                //error_log('[星空授权] 授权验证成功');
                // 保存授权信息和动态Token
                $auth_key = $aut;
                $dynamic_token = $auth_data['dynamic_token'];
                $token_expire = $auth_data['expire_time'];
                $current_time = time();
                
                //error_log('[星空授权] 授权密钥: ' . $auth_key);
                //error_log('[星空授权] 动态Token: ' . $dynamic_token);
                //error_log('[星空授权] Token过期时间: ' . date('Y-m-d H:i:s', $token_expire));
                
                // 加密存储授权数据
                $encrypt_data = json_encode(array(
                    'auth_key' => $auth_key,
                    'dynamic_token' => $dynamic_token,
                    'expire_time' => $token_expire,
                    'timestamp' => $current_time,
                    'fingerprint' => $fingerprint
                ));
                //error_log('[星空授权] 加密前数据: ' . $encrypt_data);
                
                $new_encrypted_data = openssl_encrypt($encrypt_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
                //error_log('[星空授权] 加密后数据: ' . ($new_encrypted_data ? '成功' : '失败'));
                
                // 保存授权数据
                update_option('Xk_Auth_License_Auth_Key', $auth_key);
                update_option('Xk_Auth_License_Dynamic_Token', $dynamic_token);
                update_option('Xk_Auth_License_Token_Expire', $token_expire);
                update_option('Xk_Auth_License_Last_Communication', $current_time);
                update_option('Xk_Auth_License_Encrypted_Data', $new_encrypted_data);
                update_option('Xk_Auth_License_Last_Verification', $current_time);
                update_option('Xk_Auth_Hardware_Fingerprint', $fingerprint);
                //error_log('[星空授权] 授权数据已保存');
                
                // 保存加密的授权数据（如果返回）
                if (isset($auth_data['encrypted_auth_data'])) {
                    update_option('Xk_Auth_License_Encrypted_Auth_Data', $auth_data['encrypted_auth_data']);
                    //error_log('[星空授权] 加密授权数据已保存');
                }
                
                // 验证保存是否成功
                $saved_auth_key = get_option('Xk_Auth_License_Auth_Key');
                $saved_fingerprint = get_option('Xk_Auth_Hardware_Fingerprint');
                //error_log('[星空授权] 保存后的授权密钥: ' . $saved_auth_key);
                //error_log('[星空授权] 保存后的硬件指纹: ' . $saved_fingerprint);
                //error_log('[星空授权] 保存验证: ' . ($saved_auth_key === $auth_key ? '成功' : '失败'));
                //error_log('[星空授权] 硬件指纹验证: ' . ($saved_fingerprint === $fingerprint ? '成功' : '失败'));
                
                echo wp_send_json(array('error_type' => 'info', 'reload' => true, 'msg' => $verify_data['message']));
            } elseif ($verify_data['status'] == 0) {
                //error_log('[星空授权] 授权验证失败: ' . $verify_data['message']);
                echo wp_send_json(array('error_type' => 'error', 'reload' => false, 'msg' => $verify_data['message']));
            } else {
                //error_log('[星空授权] 未知错误');
                echo wp_send_json(array('error_type' => 'error', 'reload' => false, 'msg' => '未知错误，请联系开发者'));
            }
        } else {
            //error_log('[星空授权] 服务器响应格式错误');
            echo wp_send_json(array('error_type' => 'error', 'reload' => false, 'msg' => '服务器响应格式错误'));
        }
        exit;
    }
}
add_action('wp_ajax_xk_auth_license_ajax', 'xk_auth_license_ajax');


// 未授权限制保存设置
function xk_auth_license_save_before_wp_options($data)
{
    if (!xk_auth_Core_license::is_aut()) {
        $return = array('errors' => array(), "notice" => "<i class='fa fa-info-circle fa-fw'></i> 请先完成插件授权!");
        wp_send_json_success($return);
        exit;
    } else {
        return $data;
    }
}
add_action('csf_xk_auth_setting_save_before', 'xk_auth_license_save_before_wp_options');
function xk_auth_license_save_wp_options($data)
{
    if (!xk_auth_Core_license::is_aut()) {
        $return = array('errors' => array(), "notice" => "<i class='fa fa-info-circle fa-fw'></i> 请先完成插件授权!");
        wp_send_json_success($return);
        exit;
    } else {
        return $data;
    }
}
add_action('csf_xk_auth_setting_save', 'xk_auth_license_save_wp_options');
function xk_auth_license_reset_section_before_wp_options()
{
    if (!xk_auth_Core_license::is_aut()) {
        $return = array('errors' => array(), "notice" => "<i class='fa fa-info-circle fa-fw'></i> 请先完成插件授权!");
        wp_send_json_success($return);
        exit;
    } else {
        return true;
    }
}
add_action('csf_xk_auth_setting_reset_section_before', 'xk_auth_license_reset_section_before_wp_options');
function xk_auth_license_reset_before_wp_options()
{
    if (!xk_auth_Core_license::is_aut()) {
        $return = array('errors' => array(), "notice" => "<i class='fa fa-info-circle fa-fw'></i> 请先完成插件授权!");
        wp_send_json_success($return);
        exit;
    } else {
        return true;
    }
}
add_action('csf_xk_auth_setting_reset_before', 'xk_auth_license_reset_before_wp_options');

// 未授权首页提示
function xk_auth_license_unauth()
{
    if (!xk_auth_Core_license::is_aut()) {
        echo '<footer class="footer text-center">
                <a class="but c-blue" data-toggle="tooltip" title="" target="_blank" href="https://www.xkzhi.cn" data-original-title="完成插件授权后，此处内容会自动消失">本站由星空授权插件提供部分服务</a>
                <a class="but c-red ml10" target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1397403557&amp;site=qq&amp;menu=yes">联系作者</a>
              </footer>';
    }
}
add_action('wp_footer', 'xk_auth_license_unauth');

// 获取或刷新动态Token
function xk_auth_license_get_dynamic_token() {
    // 尝试从缓存获取
    $cache_key = 'xk_auth_dynamic_token_' . md5(get_site_url());
    $cached_token = wp_cache_get($cache_key, 'xk_auth');
    if ($cached_token) {
        return $cached_token;
    }
    
    $domain = $_SERVER['HTTP_HOST'];
    $auth_key = get_option('Xk_Auth_License_Auth_Key');
    $current_token = get_option('Xk_Auth_License_Dynamic_Token');
    $token_expire = get_option('Xk_Auth_License_Token_Expire', 0);
    
    // 如果Token不存在或即将过期（30分钟内），则刷新Token
    if (empty($current_token) || time() > $token_expire - 1800) {
        // 检查请求冷却时间（使用域名作为标识符，300秒冷却）
        $cooldown_key = 'xk_auth_token_refresh_cooldown_' . md5($domain);
        $last_refresh_time = get_transient($cooldown_key);
        
        if (!$last_refresh_time || (time() - $last_refresh_time) > 300) {
            // 发起授权请求，获取新的动态Token
            $auth_request_url = 'https://www.xkzhi.cn/wp-json/Authorization/v1/Xkzhisqqwer?product_id=6994&domain=' . $domain . '&auth_key=' . $auth_key . '&action=get_dynamic_token';
            $auth_response = wp_remote_get($auth_request_url, array('timeout' => 10));
            
            if (!is_wp_error($auth_response)) {
                $auth_data = json_decode(wp_remote_retrieve_body($auth_response), true);
                
                if ($auth_data && isset($auth_data['status']) && $auth_data['status'] == 1) {
                    // 保存新的动态Token
                    $current_time = time();
                    $new_dynamic_token = $auth_data['dynamic_token'];
                    $new_expire_time = $auth_data['expire_time'];
                    
                    // 加密存储授权数据
                    $encrypt_data = json_encode(array(
                        'auth_key' => $auth_key,
                        'dynamic_token' => $new_dynamic_token,
                        'expire_time' => $new_expire_time,
                        'timestamp' => $current_time
                    ));
                    $new_encrypted_data = openssl_encrypt($encrypt_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
                    
                    update_option('Xk_Auth_License_Dynamic_Token', $new_dynamic_token);
                    update_option('Xk_Auth_License_Token_Expire', $new_expire_time);
                    update_option('Xk_Auth_License_Last_Communication', $current_time);
                    update_option('Xk_Auth_License_Encrypted_Data', $new_encrypted_data);
                    update_option('Xk_Auth_License_Last_Verification', $current_time);
                    
                    // 保存加密的授权数据（如果返回）
                    if (isset($auth_data['encrypted_auth_data'])) {
                        update_option('Xk_Auth_License_Encrypted_Auth_Data', $auth_data['encrypted_auth_data']);
                    }
                    
                    // 设置刷新冷却时间
                    set_transient($cooldown_key, $current_time, 300);
                    
                    // 缓存Token，有效期10分钟
                    wp_cache_set($cache_key, $new_dynamic_token, 'xk_auth', 600);
                    
                    return $new_dynamic_token;
                } else {
                    // 刷新失败，设置冷却时间
                    set_transient($cooldown_key, time(), 300);
                }
            } else {
                // 请求失败，设置冷却时间
                set_transient($cooldown_key, time(), 300);
            }
        }
    }
    
    // 缓存Token，有效期10分钟
    wp_cache_set($cache_key, $current_token, 'xk_auth', 600);
    
    return $current_token;
}

// 在插件初始化时添加版本检查
function xk_auth_license_check_update_notice() {
    
    // 只在管理员页面显示
    if (!current_user_can('manage_options')) {
        return;
    }
    
    if (!xk_auth_Core_license::is_aut()) {
        return;
    }

    // 检查请求冷却时间（使用域名作为标识符，3600秒冷却）
    $domain = $_SERVER['HTTP_HOST'];
    if (!xk_auth_check_simple_cooldown('update_check', $domain, 3600)) {
        return;
    }

    // 准备数据
    $auth_key = get_option('Xk_Auth_License_Auth_Key');
    $current_version = defined('XK_AUTH_VERSION') ? XK_AUTH_VERSION : '1.0.0';
    
    // 获取动态Token
    $dynamic_token = xk_auth_license_get_dynamic_token();
    if (empty($dynamic_token)) {
        return;
    }

    // 插件更新API - 添加动态Token参数
    $update_url = 'https://www.xkzhi.cn/wp-json/Update/v1/Xkzhiupqwer?product_id=6994&domain=' . urlencode($domain) . '&auth_key=' . urlencode($auth_key) . '&dynamic_token=' . urlencode($dynamic_token) . '&current_version=' . $current_version;
    
    $response = wp_remote_get($update_url, array('timeout' => 10));

    if (is_wp_error($response)) {
        return;
    }

    $response_body = wp_remote_retrieve_body($response);
    
    $data = json_decode($response_body, true);
    
    // 去掉缓存，直接保存到全局变量供显示函数使用
    global $xk_auth_license_latest_update_data;
    $xk_auth_license_latest_update_data = $data;
    
}
add_action('admin_init', 'xk_auth_license_check_update_notice');

// 显示更新提示
function xk_auth_license_update_available_notice() {
    
    // 使用全局变量获取最新更新数据
    global $xk_auth_license_latest_update_data;
    $update_data = $xk_auth_license_latest_update_data;
    
    if (!$update_data || !isset($update_data['status']) || $update_data['status'] != 1 || !isset($update_data['has_update']) || $update_data['has_update'] !== true) {
        return;
    }
    
    
    $current_version = defined('XK_AUTH_VERSION') ? XK_AUTH_VERSION : '1.0.0';
    $latest_version = $update_data['latest_version'] ?? '';
    $update_description = $update_data['update_description'] ?? '';
    $release_time = $update_data['release_time'] ?? '';
    
    
    echo '<div class="notice notice-warning is-dismissible">';
    echo '<h3>📦 插件有新版本可用！</h3>';
    echo '<p><strong>当前版本：</strong>' . esc_html($current_version) . '</p>';
    echo '<p><strong>最新版本：</strong>' . esc_html($latest_version) . '</p>';
    
    if ($release_time) {
        echo '<p><strong>发布时间：</strong>' . esc_html($release_time) . '</p>';
    }
    
    if ($update_description) {
        echo '<p><strong>更新内容：</strong>' . esc_html($update_description) . '</p>';
    }
    
    echo '<p>';
    echo '<a href="' . admin_url('admin.php?page=xk_auth_setting#tab=文档更新') . '" class="button button-primary">立即更新</a>';
    /*echo ' <a href="#" class="button" onclick="jQuery(this).closest(\'.notice\').fadeOut(); return false;">稍后提醒</a>';*/
    echo '</p>';
    echo '</div>';
    
}
add_action('admin_notices', 'xk_auth_license_update_available_notice');

// 注册接收主站推送Token的API路由
add_action('rest_api_init', function () {
    register_rest_route(
        'xk-auth/v1',
        '/receive-token',
        array(
            'methods' => 'POST',
            'callback' => 'xk_auth_license_receive_token_callback',
            'permission_callback' => '__return_true'
        )
    );
});

/**
 * 处理接收主站推送Token的回调函数
 */
function xk_auth_license_receive_token_callback($request) {
    // 支持GET和POST请求，正确处理JSON格式的POST请求
    if (is_array($request)) {
        $data = $request;
    } else {
        // 检查请求方法
        $method = $request->get_method();
        
        if ($method === 'POST') {
            // 对于POST请求，先尝试获取JSON请求体
            $json_body = $request->get_json_params();
            if (!empty($json_body)) {
                $data = $json_body;
            } else {
                // 如果没有JSON请求体，再尝试获取普通参数
                $data = $request->get_params();
            }
        } else {
            // 对于GET请求，直接获取参数
            $data = $request->get_params();
        }
    }
    
    
    // 验证必要参数
    $required_params = ['product_id', 'domain', 'auth_key', 'dynamic_token', 'signature'];
    $missing_params = [];
    
    foreach ($required_params as $param) {
        if (!isset($data[$param]) || empty(trim($data[$param]))) {
            $missing_params[] = $param;
        }
    }
    
    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }
    
    // 验证签名
    // 使用AUTH_KEY作为签名密钥，确保主站和被授权站使用相同的密钥
    $expected_signature = hash('sha256', $data['product_id'] . $data['domain'] . $data['auth_key'] . $data['dynamic_token'] . $data['expire_time'] . $data['timestamp'] . AUTH_KEY);
    if ($data['signature'] !== $expected_signature) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '签名验证失败'],
            401
        );
    }
    
    // 验证域名是否匹配
    if ($data['domain'] !== $_SERVER['HTTP_HOST']) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '域名不匹配'],
            401
        );
    }
    
    // 保存接收到的Token和相关信息
    $current_time = time();
    $auth_key = get_option('Xk_Auth_License_Auth_Key');
    
    // 加密存储授权数据
    $encrypt_data = json_encode(array(
        'auth_key' => $auth_key,
        'dynamic_token' => $data['dynamic_token'],
        'expire_time' => $data['expire_time'],
        'timestamp' => $current_time
    ));
    $new_encrypted_data = openssl_encrypt($encrypt_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
    
    update_option('Xk_Auth_License_Dynamic_Token', $data['dynamic_token']);
    update_option('Xk_Auth_License_Token_Expire', $data['expire_time']);
    update_option('Xk_Auth_License_Last_Communication', $current_time);
    update_option('Xk_Auth_License_Encrypted_Data', $new_encrypted_data);
    update_option('Xk_Auth_License_Last_Verification', $current_time);
    
    // 保存加密的授权数据（如果返回）
    if (isset($data['encrypted_auth_data'])) {
        update_option('Xk_Auth_License_Encrypted_Auth_Data', $data['encrypted_auth_data']);
    }
    
    
    return new WP_REST_Response(
        ['status' => 1, 'message' => 'Token接收成功'],
        200
    );
}

// 更新处理AJAX
function xk_auth_license_update_ajax()
{
    // 检查用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json(array('error_type' => 'error', 'msg' => '权限不足'));
        exit;
    }
    
    if (!xk_auth_Core_license::is_aut()) {
        wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "请先完成插件授权！"));
        exit;
    }
    
    // 添加更新请求冷却检查，防止频繁请求
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $cache_key = 'xk_auth_update_ajax_cooldown_' . md5($ip);
    $last_request_time = get_transient($cache_key);
    $cool_down_time = 300; // 5分钟冷却时间
    
    if ($last_request_time && (time() - $last_request_time) < $cool_down_time) {
        $remaining_time = $cool_down_time - (time() - $last_request_time);
        wp_send_json(array('error_type' => 'error', 'msg' => '请求过于频繁，请等待' . $remaining_time . '秒后重试'));
        exit;
    }
    
    // 设置冷却时间
    set_transient($cache_key, time(), $cool_down_time);

    // 准备数据
    $domain = $_SERVER['HTTP_HOST'];
    $auth_key = get_option('Xk_Auth_License_Auth_Key');
    $current_version = defined('XK_AUTH_VERSION') ? XK_AUTH_VERSION : '1.0.0';
    
    // 获取动态Token
    $dynamic_token = xk_auth_license_get_dynamic_token();
    if (empty($dynamic_token)) {
        wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "获取动态Token失败"));
        exit;
    }

    // 插件更新API - 添加动态Token参数
    $update_url = 'https://www.xkzhi.cn/wp-json/Update/v1/Xkzhiupqwer?product_id=6994&domain=' . urlencode($domain) . '&auth_key=' . urlencode($auth_key) . '&dynamic_token=' . urlencode($dynamic_token) . '&current_version=' . $current_version;
    
    $response = wp_remote_get($update_url, array('timeout' => 300));

    // 检查API请求是否成功
    if (is_wp_error($response)) {
        wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "授权服务器链接失败，请稍后重试"));
        exit;
    }

    // 解析API返回数据
    $data = json_decode(wp_remote_retrieve_body($response), true);

    // 检查响应是否有效
    if (!$data || !isset($data['status'])) {
        wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "服务器响应格式错误"));
        exit;
    }

    // 检查是否有更新
    if ($data['status'] == 1 && isset($data['has_update']) && $data['has_update'] === true) {
        // 检查是否有更新URL
        if (!isset($data['update_url']) || empty($data['update_url'])) {
            wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "更新文件URL缺失"));
            exit;
        }
        
        $update_file_url = $data['update_url'];

        // 获取当前插件目录
        $current_plugin_dir = WP_PLUGIN_DIR . '/xk-auth';
        
        // 初始化WordPress文件系统
        if (!function_exists('WP_Filesystem')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $creds = request_filesystem_credentials(site_url());
        if (!WP_Filesystem($creds)) {
            wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "无法获取文件系统权限"));
            exit;
        }
        
        global $wp_filesystem;

        // 创建临时目录
        $temp_dir = get_temp_dir() . 'xk_update_' . time();
        if (!$wp_filesystem->is_dir($temp_dir)) {
            if (!$wp_filesystem->mkdir($temp_dir)) {
                wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "无法创建临时目录"));
                exit;
            }
        }

        // 下载更新文件
        $update_file = $temp_dir . '/update.zip';
        $update_response = wp_remote_get($update_file_url, array('timeout' => 300));
        
        if (is_wp_error($update_response)) {
            $wp_filesystem->delete($temp_dir, true);
            wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "更新文件下载失败"));
            exit;
        }

        // 保存更新文件
        if (!$wp_filesystem->put_contents($update_file, wp_remote_retrieve_body($update_response), FS_CHMOD_FILE)) {
            $wp_filesystem->delete($temp_dir, true);
            wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "更新文件保存失败"));
            exit;
        }

        // 方法1: 直接解压到插件目录
        $unzip_result = unzip_file($update_file, $current_plugin_dir);
        
        if (is_wp_error($unzip_result)) {
            // 方法1失败，尝试方法2: 使用ZipArchive手动解压
            if (!class_exists('ZipArchive')) {
                $wp_filesystem->delete($temp_dir, true);
                wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "解压失败且服务器未安装Zip扩展"));
                exit;
            }
            
            $zip = new ZipArchive();
            if ($zip->open($update_file) === TRUE) {
                // 解压到插件目录
                if ($zip->extractTo($current_plugin_dir)) {
                    $zip->close();
                    $wp_filesystem->delete($update_file);
                    $wp_filesystem->delete($temp_dir, true);
                    
                    // 清除更新提示缓存
                    delete_transient('xk_auth_license_update_available');
                    
                    // 返回成功信息
                    $version_msg = isset($data['latest_version']) ? 'V' . $data['latest_version'] . ' 更新成功' : '更新已完成';
                    wp_send_json(array(
                        'error_type' => 'info', 
                        'reload' => true, 
                        'msg' => $version_msg, 
                        'version' => $data['latest_version'] ?? ''
                    ));
                } else {
                    $zip->close();
                    $wp_filesystem->delete($temp_dir, true);
                    wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "手动解压失败"));
                    exit;
                }
            } else {
                $wp_filesystem->delete($temp_dir, true);
                wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "无法打开zip文件"));
                exit;
            }
        } else {
            // 方法1成功
            $wp_filesystem->delete($update_file);
            $wp_filesystem->delete($temp_dir, true);
            
            // 清除更新提示缓存
            delete_transient('xk_auth_license_update_available');
            
            // 返回成功信息
            $version_msg = isset($data['latest_version']) ? 'V' . $data['latest_version'] . ' 更新成功' : '更新已完成';
            wp_send_json(array(
                'error_type' => 'info', 
                'reload' => true, 
                'msg' => $version_msg, 
                'version' => $data['latest_version'] ?? ''
            ));
        }
        
    } elseif ($data['status'] == 1 && isset($data['has_update']) && $data['has_update'] === false) {
        // 如果没有更新，也清除可能的旧提示
        delete_transient('xk_auth_license_update_available');
        
        wp_send_json(array('error_type' => 'info', 'reload' => false, "msg" => $data['message'] ?? "暂无更新，您当前的版本已是最新版"));
        exit;
    } else {
        wp_send_json(array('error_type' => 'error', 'reload' => false, "msg" => "更新检查失败: " . ($data['message'] ?? "未知错误")));
        exit;
    }
}

add_action('wp_ajax_xk_auth_license_update_ajax', 'xk_auth_license_update_ajax');

// 卡密相关函数

/**
 * 生成卡密
 *
 * @param int $product_id 产品ID
 * @param int $expire_days 有效期（天），0表示永久
 * @param string $allowed_users 允许使用的用户ID，多个用逗号分隔
 * @param int $auth_count 授权域名数量，0表示不限制
 * @return string 生成的卡密
 */
function xk_auth_generate_card($product_id, $expire_days = 365, $allowed_users = '', $auth_count = 1) {
    // 生成随机卡密
    $card_code = strtoupper(substr(md5(uniqid() . time() . mt_rand()), 0, 20));
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_cards';
    
    // 计算到期时间
    $expire_time = $expire_days > 0 ? date('Y-m-d H:i:s', strtotime('+' . $expire_days . ' days')) : NULL;
    
    // 插入数据库
    $wpdb->insert(
        $table_name,
        array(
            'card_code' => $card_code,
            'product_id' => $product_id,
            'expire_time' => $expire_time,
            'auth_count' => $auth_count,
            'status' => 'unused',
            'allowed_users' => $allowed_users,
            'create_time' => current_time('mysql')
        )
    );
    
    return $card_code;
}

/**
 * 获取卡密列表
 *
 * @return string 卡密列表HTML
 */
function xk_auth_get_cards_list() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_cards';
    
    // 获取所有卡密
    $cards = $wpdb->get_results("SELECT * FROM $table_name ORDER BY create_time DESC");
    
    $html = '<div style="margin-bottom: 10px;"><button type="button" class="button button-danger" onclick="xk_auth_batch_delete_cards()">批量删除选中的卡密</button></div>';
    $html .= '<table class="wp-list-table widefat fixed striped">';
    $html .= '<thead><tr><th><input type="checkbox" id="select_all_cards"></th><th>ID</th><th>卡密</th><th>产品ID</th><th>到期时间</th><th>授权数量</th><th>状态</th><th>允许使用的用户</th><th>创建时间</th><th>使用时间</th><th>使用用户</th><th>操作</th></tr></thead>';
    $html .= '<tbody>';
    
    if ($cards) {
        foreach ($cards as $card) {
            // 获取产品名称
            $product_name = get_the_title($card->product_id) ?: '未知产品';
            
            // 格式化到期时间
            $expire_time = $card->expire_time ? $card->expire_time : '永久';
            
            // 格式化授权数量
            $auth_count_display = $card->auth_count > 0 ? $card->auth_count : '不限制';
            
            // 格式化状态
            $status_text = array(
                'unused' => '未使用',
                'used' => '已使用',
                'expired' => '已过期'
            );
            $status_display = isset($status_text[$card->status]) ? $status_text[$card->status] : $card->status;
            
            // 格式化允许使用的用户
            $allowed_users_text = $card->allowed_users ? $card->allowed_users : '所有用户';
            
            // 格式化使用用户
            $used_user_text = '未使用';
            if (!empty($card->used_user_id)) {
                if (function_exists('get_user_by')) {
                    $user = get_user_by('ID', $card->used_user_id);
                    if ($user) {
                        $used_user_text = isset($user->user_login) ? $user->user_login : '用户ID: ' . $card->used_user_id;
                    } else {
                        $used_user_text = '用户ID: ' . $card->used_user_id;
                    }
                } else {
                    $used_user_text = '用户ID: ' . $card->used_user_id;
                }
            }
            
            $html .= '<tr>';
            $html .= '<td><input type="checkbox" class="card_checkbox" value="' . $card->id . '"></td>';
            $html .= '<td>' . $card->id . '</td>';
            $html .= '<td>' . $card->card_code . '</td>';
            $html .= '<td>' . $card->product_id . ' (' . $product_name . ')</td>';
            $html .= '<td>' . $expire_time . '</td>';
            $html .= '<td>' . $auth_count_display . '</td>';
            $html .= '<td>' . $status_display . '</td>';
            $html .= '<td>' . $allowed_users_text . '</td>';
            $html .= '<td>' . $card->create_time . '</td>';
            $html .= '<td>' . ($card->use_time ?: '未使用') . '</td>';
            $html .= '<td>' . $used_user_text . '</td>';
            $html .= '<td><button type="button" class="button button-danger" onclick="xk_auth_delete_card(' . $card->id . ')">删除</button></td>';
            $html .= '</tr>';
        }
    } else {
        $html .= '<tr><td colspan="12" style="text-align: center;">暂无卡密</td></tr>';
    }
    
    $html .= '</tbody>';
    $html .= '</table>';
    
    return $html;
}

/**
 * 删除卡密
 *
 * @param int $card_id 卡密ID
 * @return bool 是否删除成功
 */
function xk_auth_delete_card($card_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_cards';
    
    return $wpdb->delete($table_name, array('id' => $card_id)) !== false;
}

/**
 * 使用卡密
 *
 * @param string $card_code 卡密代码
 * @param int $user_id 用户ID
 * @param int $product_id 当前产品ID
 * @param string $auth_domain 要授权的域名
 * @return array 结果数组
 */
function xk_auth_use_card($card_code, $user_id, $product_id = 0, $auth_domain = '') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_cards';
    
    // 查找卡密
    $card = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE card_code = %s", $card_code));
    
    if (!$card) {
        return array('success' => false, 'message' => '卡密不存在');
    }
    
    // 检查卡密状态
    if ($card->status == 'used') {
        return array('success' => false, 'message' => '卡密已被使用');
    }
    
    if ($card->status == 'expired') {
        return array('success' => false, 'message' => '卡密已过期');
    }
    
    // 检查卡密是否过期
    if ($card->expire_time && strtotime($card->expire_time) < time()) {
        // 更新卡密状态为过期
        $wpdb->update(
            $table_name,
            array('status' => 'expired'),
            array('id' => $card->id)
        );
        return array('success' => false, 'message' => '卡密已过期');
    }
    
    // 检查用户是否被允许使用
    if ($card->allowed_users) {
        $allowed_users = explode(',', $card->allowed_users);
        $allowed_users = array_map('trim', $allowed_users);
        if (!in_array(strval($user_id), $allowed_users)) {
            return array('success' => false, 'message' => '您没有权限使用此卡密');
        }
    }
    
    // 检查产品是否匹配
    if ($product_id && $card->product_id != $product_id) {
        return array('success' => false, 'message' => '此卡密只能用于指定产品');
    }
    
    // 检查域名参数
    if (empty($auth_domain)) {
        return array('success' => false, 'message' => '请输入要授权的域名');
    }
    
    // 更新卡密状态为已使用
    $wpdb->update(
        $table_name,
        array(
            'status' => 'used',
            'use_time' => current_time('mysql'),
            'used_user_id' => $user_id
        ),
        array('id' => $card->id)
    );
    
    // 为用户添加授权
    $product_id = $card->product_id;
    $expire_time = $card->expire_time;
    
    // 使用卡密中存储的授权数
    $auth_count = $card->auth_count;
    // 如果卡密中没有授权数（兼容旧卡密），则从产品配置中获取
    if (empty($auth_count)) {
        $product_settings = xk_auth('product_settings', array());
        $auth_count = 1; // 默认授权数
        
        // 遍历配置中的产品，匹配当前产品ID
        if (!empty($product_settings)) {
            foreach ($product_settings as $product) {
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    // 从配置中获取授权个数（转为整数）
                    $auth_count = intval($product['auth_count']);
                    break;
                }
            }
        }
    }
    
    // 创建订单
    $post_id = $product_id;
    $pay_time = current_time('mysql');
    
    // 构建订单对象
    $order_obj = array(
        'user_id' => $user_id,
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'product_id' => $product_id,
        'post_id' => $post_id,
        'post_author' => get_post_field('post_author', $post_id),
        'income_price' => 0.00,
        'income_status' => '',
        'income_detail' => '',
        'order_num' => 'card_' . date('YmdHis') . '_' . mt_rand(1000, 9999),
        'order_price' => 0.00,
        'order_type' => 15,
        'create_time' => current_time('mysql'),
        'pay_num' => '',
        'pay_type' => 'card_pass',
        'pay_price' => 0.00,
        'pay_detail' => '',
        'pay_time' => $pay_time,
        'status' => 1,
        'other' => '卡密价格',
        'referrer_id' => 0,
        'rebate_price' => 0.00,
        'rebate_status' => '',
        'rebate_detail' => '',
    );
    
    // 检查ZibPay类是否存在
    if (class_exists('ZibPay')) {
        // 创建本地新订单
        $order = ZibPay::add_order($order_obj);
    }
    
    // 添加授权记录
    // 使用用户输入的域名
    $domain = $auth_domain;
    xk_auth_insert_product_authorization_data($user_id, $product_id, $domain, '通过卡密获取授权', $expire_time);
    
    // 插入授权日志
    xk_auth_insert_authorization_log($user_id, $product_id, $auth_count, $auth_count, '通过卡密获取授权', $expire_time);
    
    // 清除仪表盘数据缓存，确保下次访问时显示最新数据
    delete_transient('xk_auth_dashboard_data');
    
    return array('success' => true, 'message' => '卡密使用成功，授权已添加', 'product_id' => $product_id, 'expire_time' => $expire_time);
}

// 生成卡密AJAX处理
function xk_auth_generate_cards_ajax() {
    // 检查权限
    if (!current_user_can('manage_options')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '权限不足'));
    }
    
    // 验证nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'wp_rest')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '验证失败'));
    }
    
    $product_id = intval($_POST['product_id']);
    $count = intval($_POST['count']);
    $expire_days = intval($_POST['expire_days']);
    $auth_count = intval($_POST['auth_count']);
    $allowed_users = sanitize_text_field($_POST['allowed_users']);
    
    if (!$product_id) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请填写产品ID'));
    }
    
    if ($count < 1 || $count > 100) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '生成数量必须在1-100之间'));
    }
    
    $cards = array();
    for ($i = 0; $i < $count; $i++) {
        $card = xk_auth_generate_card($product_id, $expire_days, $allowed_users, $auth_count);
        $cards[] = $card;
    }
    
    // 清除仪表盘数据缓存，确保下次访问时显示最新数据
    delete_transient('xk_auth_dashboard_data');
    
    wp_send_json_success(array('cards' => $cards));
}
add_action('wp_ajax_xk_auth_generate_cards', 'xk_auth_generate_cards_ajax');

// 获取卡密列表AJAX处理
function xk_auth_get_cards_list_ajax() {
    // 检查权限
    if (!current_user_can('manage_options')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '权限不足'));
    }
    
    // 验证nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'wp_rest')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '验证失败'));
    }
    
    $html = xk_auth_get_cards_list();
    wp_send_json_success(array('html' => $html));
}
add_action('wp_ajax_xk_auth_get_cards_list', 'xk_auth_get_cards_list_ajax');

// 删除卡密AJAX处理
function xk_auth_delete_card_ajax() {
    // 检查权限
    if (!current_user_can('manage_options')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '权限不足'));
    }
    
    // 验证nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'wp_rest')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '验证失败'));
    }
    
    $card_id = intval($_POST['card_id']);
    if (!$card_id) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '卡密ID无效'));
    }
    
    $result = xk_auth_delete_card($card_id);
    if ($result) {
        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        wp_send_json_success(array('message' => '删除成功'));
    } else {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '删除失败'));
    }
}
add_action('wp_ajax_xk_auth_delete_card', 'xk_auth_delete_card_ajax');

// 使用卡密AJAX处理
function xk_auth_use_card_ajax() {
    // 检查用户是否登录
    if (!is_user_logged_in()) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请先登录'));
    }
    
    $user_id = get_current_user_id();
    $card_code = sanitize_text_field($_POST['card_code']);
    $product_id = intval($_POST['product_id']);
    $auth_domain = sanitize_text_field($_POST['auth_domain']);
    
    if (!$card_code) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请输入卡密'));
    }
    
    if (!$auth_domain) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请输入要授权的域名'));
    }
    
    $result = xk_auth_use_card($card_code, $user_id, $product_id, $auth_domain);
    if ($result['success']) {
        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        wp_send_json_success($result);
    } else {
        zib_send_json_error(array('ys' => 'danger', 'msg' => $result['message']));
    }
}
add_action('wp_ajax_xk_auth_use_card', 'xk_auth_use_card_ajax');

// 批量删除卡密AJAX处理
function xk_auth_batch_delete_cards_ajax() {
    // 检查权限
    if (!current_user_can('manage_options')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '权限不足'));
    }
    
    // 验证nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'wp_rest')) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '验证失败'));
    }
    
    $card_ids = sanitize_text_field($_POST['card_ids']);
    if (!$card_ids) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请选择要删除的卡密'));
    }
    
    $card_id_array = explode(',', $card_ids);
    $success_count = 0;
    
    foreach ($card_id_array as $card_id) {
        $card_id = intval($card_id);
        if ($card_id > 0) {
            $result = xk_auth_delete_card($card_id);
            if ($result) {
                $success_count++;
            }
        }
    }
    
    // 清除仪表盘数据缓存，确保下次访问时显示最新数据
    delete_transient('xk_auth_dashboard_data');
    
    wp_send_json_success(array('message' => '成功删除 ' . $success_count . ' 个卡密'));
}
add_action('wp_ajax_xk_auth_batch_delete_cards', 'xk_auth_batch_delete_cards_ajax');

// 其他支付方式AJAX处理
function xk_auth_pay_with_other_method() {
    // 检查用户是否登录
    $user_id = get_current_user_id();
    if (!$user_id) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请先登录'));
    }
    
    // 获取参数
    $product_id = intval($_POST['product_id']);
    $package_index = intval($_POST['package_index']);
    $selected_price = floatval($_POST['selected_price']);
    $selected_duration = intval($_POST['selected_duration']);
    $selected_payment_method = sanitize_text_field($_POST['selected_payment_method']);
    
    if (!$product_id) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '产品ID错误'));
    }
    
    if ($selected_price <= 0) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '价格错误'));
    }
    
    // 获取产品信息
    $product = get_post($product_id);
    if (!$product || $product->post_status !== 'publish') {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '产品不存在'));
    }
    
    // 获取时间套餐信息
    $time_packages = xk_auth_get_product_time_packages($product_id);
    $package_info = array();
    
    if (!empty($time_packages) && isset($time_packages[$package_index])) {
        $package_info = $time_packages[$package_index];
    } else {
        // 使用默认套餐
        $package_info = array(
            'package_name' => '默认授权套餐',
            'package_price' => $selected_price,
            'package_duration' => $selected_duration
        );
    }
    
    // 生成订单描述
    $order_description = $product->post_title . ' - ' . $package_info['package_name'];
    
    // 检查ZibPay类是否可用
    if (class_exists('ZibPay')) {
        try {
            // 创建支付数据 - 使用正确的参数格式
            $payment_data = array(
                'method' => $selected_payment_method, // 支付方式
                'price' => $selected_price, // 支付金额
                'order_data' => array(
                    'user_id' => $user_id,
                    'product_id' => $product_id,
                    'package_index' => $package_index,
                    'duration' => $selected_duration,
                    'package_info' => $package_info,
                    'order_description' => $order_description,
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                )
            );
            
            // 使用ZibPay类创建支付
            $payment_result = ZibPay::add_payment($payment_data);
            
            if ($payment_result && isset($payment_result['id'])) {
                $payment_id = $payment_result['id'];
                $order_num = $payment_result['order_num'];
                
                // 创建订单 - 使用正确的参数格式
                $order_data = array(
                    'user_id' => $user_id,
                    'ip_address' => $_SERVER['REMOTE_ADDR'],
                    'post_id' => $product_id,
                    'post_author' => $product->post_author,
                    'order_price' => $selected_price,
                    'pay_price' => $selected_price,
                    'pay_type' => $selected_payment_method,
                    'order_type' => 13, // 授权产品订单类型（使用有效的索引值）
                    'payment_id' => $payment_id,
                    'pay_num' => $order_num,
                    'status' => 0, // 待支付
                    'meta' => array(
                        'auth_product_id' => $product_id,
                        'auth_package_index' => $package_index,
                        'auth_duration' => $selected_duration,
                        'auth_package_info' => $package_info,
                        'order_description' => $order_description
                    )
                );
                
                $order = ZibPay::add_order($order_data);
                
                if ($order && isset($order['id'])) {
                    // 准备支付数据
                    $initiate_pay_data = array(
                        'user_id' => $user_id,
                        'order_num' => $order_num,
                        'payment_method' => $selected_payment_method,
                        'order_price' => $selected_price,
                        'order_name' => $order_description,
                        'ip_address' => $_SERVER['REMOTE_ADDR'],
                        'desc' => $order_description,
                        'return_url' => get_permalink($product_id)
                    );
                    
                    // 直接发起支付
                    $initiate_pay = zibpay_initiate_pay($initiate_pay_data);
                    
                    if (!empty($initiate_pay['error'])) {
                        zib_send_json_error(array('ys' => 'danger', 'msg' => $initiate_pay['msg']));
                    }
                    
                    // 返回支付结果
                    wp_send_json_success($initiate_pay);
                } else {
                    zib_send_json_error(array('ys' => 'danger', 'msg' => '订单创建失败'));
                }
            } else {
                zib_send_json_error(array('ys' => 'danger', 'msg' => '支付数据创建失败'));
            }
        } catch (Exception $e) {
            zib_send_json_error(array('ys' => 'danger', 'msg' => '支付处理失败：' . $e->getMessage()));
        }
    } else {
        // 如果zibll支付系统不可用，使用备用方案
        zib_send_json_error(array('ys' => 'danger', 'msg' => '支付系统暂不可用，请使用余额支付'));
    }
}
add_action('wp_ajax_xk_auth_pay_with_other_method', 'xk_auth_pay_with_other_method');



// 卡密管理JavaScript
function xk_auth_admin_scripts() {
    ?>  
    <script type="text/javascript">
    function xk_auth_generate_cards() {
        // 直接通过ID获取元素，CSF框架会为字段生成唯一ID
        var product_id_input = document.querySelector('[data-id="card_product_id"] input') || 
                              document.querySelector('input[id*="card_product_id"]') ||
                              document.querySelector('input[name*="card_product_id"]');
        var count_input = document.querySelector('[data-id="card_count"] input') || 
                         document.querySelector('input[id*="card_count"]') ||
                         document.querySelector('input[name*="card_count"]');
        var expire_days_input = document.querySelector('[data-id="card_expire_days"] input') || 
                               document.querySelector('input[id*="card_expire_days"]') ||
                               document.querySelector('input[name*="card_expire_days"]');
        var auth_count_input = document.querySelector('[data-id="card_auth_count"] input') || 
                              document.querySelector('input[id*="card_auth_count"]') ||
                              document.querySelector('input[name*="card_auth_count"]');
        var allowed_users_input = document.querySelector('[data-id="card_allowed_users"] textarea') || 
                                 document.querySelector('textarea[id*="card_allowed_users"]') ||
                                 document.querySelector('textarea[name*="card_allowed_users"]');
        var result_div = document.getElementById('cards_result');
        
        // 获取输入值，添加默认值以防止错误
        var product_id = product_id_input ? product_id_input.value.trim() : '';
        var count = count_input ? count_input.value.trim() || '1' : '1';
        var expire_days = expire_days_input ? expire_days_input.value.trim() || '365' : '365';
        var auth_count = auth_count_input ? auth_count_input.value.trim() || '1' : '1';
        var allowed_users = allowed_users_input ? allowed_users_input.value.trim() : '';
        
        if (!product_id) {
            result_div.innerHTML = '<div class="notice notice-error"><p>请填写产品ID</p></div>';
            result_div.style.display = 'block';
            return;
        }
        
        result_div.innerHTML = '<div class="notice notice-info"><p>正在生成卡密，请稍候...</p></div>';
        result_div.style.display = 'block';
        
        fetch(ajaxurl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=xk_auth_generate_cards&product_id=' + product_id + '&count=' + count + '&expire_days=' + expire_days + '&auth_count=' + auth_count + '&allowed_users=' + encodeURIComponent(allowed_users) + '&_wpnonce=' + wpApiSettings.nonce
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                result_div.innerHTML = '<div class="notice notice-success"><p>卡密生成成功！</p><p>生成的卡密：<br>' + data.data.cards.join('<br>') + '</p></div>';
                // 刷新卡密列表
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=xk_auth_get_cards_list&_wpnonce=' + wpApiSettings.nonce
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('cards_list_container').innerHTML = data.data.html;
                    }
                });
            } else {
                result_div.innerHTML = '<div class="notice notice-error"><p>卡密生成失败：' + data.data.message + '</p></div>';
            }
        })
        .catch(error => {
            result_div.innerHTML = '<div class="notice notice-error"><p>发生错误：' + error.message + '</p></div>';
        });
    }
    
    function xk_auth_delete_card(card_id) {
        if (confirm('确定要删除这个卡密吗？')) {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=xk_auth_delete_card&card_id=' + card_id + '&_wpnonce=' + wpApiSettings.nonce
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // 刷新卡密列表
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'action=xk_auth_get_cards_list&_wpnonce=' + wpApiSettings.nonce
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('cards_list_container').innerHTML = data.data.html;
                        }
                    });
                } else {
                    alert('删除失败：' + data.data.message);
                }
            });
        }
}
    
    // 全选/取消全选
    document.addEventListener('DOMContentLoaded', function() {
        var selectAllCheckbox = document.getElementById('select_all_cards');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                var checkboxes = document.querySelectorAll('.card_checkbox');
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });
        }
    });
    
    // 批量删除卡密
    function xk_auth_batch_delete_cards() {
        var checkboxes = document.querySelectorAll('.card_checkbox:checked');
        var cardIds = [];
        
        checkboxes.forEach(function(checkbox) {
            cardIds.push(checkbox.value);
        });
        
        if (cardIds.length === 0) {
            alert('请先选择要删除的卡密');
            return;
        }
        
        if (confirm('确定要删除选中的 ' + cardIds.length + ' 个卡密吗？')) {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=xk_auth_batch_delete_cards&card_ids=' + cardIds.join(',') + '&_wpnonce=' + wpApiSettings.nonce
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // 刷新卡密列表
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'action=xk_auth_get_cards_list&_wpnonce=' + wpApiSettings.nonce
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('cards_list_container').innerHTML = data.data.html;
                        }
                    });
                } else {
                    alert('删除失败：' + data.data.message);
                }
            });
        }
    }
    </script>
    <?php
}
add_action('admin_footer', 'xk_auth_admin_scripts');

// 获取备份列表
function xk_auth_get_backup_list() {
    $prefix = 'xk_auth_setting';
    $options = get_option($prefix . '_backup');
    $lists = '暂无备份数据！';
    $admin_ajax_url = admin_url('admin-ajax.php', 'relative');
    
    if ($options) {
        $lists = '';
        $options = array_reverse($options);
        $count = 0;
        
        foreach ($options as $key => $val) {
            $ajax_url = add_query_arg('key', $key, $admin_ajax_url);
            $del = '<a href="javascript:;" ajax-url="' . add_query_arg('action', 'xk_auth_options_backup_delete', $ajax_url) . '" data-confirm="确认要删除此备份[' . $key . ']？删除后不可恢复！" class="but c-yellow ajax-get ml10">删除</a>';
            $restore = '<a href="javascript:;" ajax-url="' . add_query_arg('action', 'xk_auth_options_backup_restore', $ajax_url) . '" data-confirm="确认将插件设置恢复到此备份吗？[' . $key . ']？" class="but c-blue ajax-get ml10">恢复</a>';
            
            $lists .= '<div class="backup-item flex ac jsb">';
            $lists .= '<div class="item-left"><div>' . $val['time'] . '</div><div> [' . $val['type'] . ']</div></div>';
            $lists .= '<span class="shrink-0">' . $restore . $del . '</span>';
            $lists .= '</div>';
            $count++;
        }
    }
    
    return $lists;
}

// 备份插件设置
function xk_auth_options_backup($type = '自动备份') {
    $prefix = 'xk_auth_setting';
    $options = get_option($prefix);

    $options_backup = get_option($prefix . '_backup');
    if (!$options_backup) {
        $options_backup = array();
    }

    $time = current_time('Y-m-d H:i:s');
    $options_backup[$time] = array(
        'time' => $time,
        'type' => $type,
        'data' => $options,
    );

    // 保留20次数据，删除多余的
    if (count($options_backup) > 20) {
        $options_backup = array_slice($options_backup, -20);
    }

    return update_option($prefix . '_backup', $options_backup);
}

// 导入插件设置
function xk_auth_ajax_options_import() {
    if (!is_super_admin()) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }

    $data = !empty($_REQUEST['import_data']) ? $_REQUEST['import_data'] : '';

    if (!$data) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请粘贴需导入配置的json代码')));
        exit();
    }

    $import_data = json_decode(wp_unslash(trim($data)), true);

    if (empty($import_data) || !is_array($import_data)) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => 'json代码格式错误，无法导入')));
        exit();
    }

    xk_auth_options_backup('导入配置 自动备份');

    $prefix = 'xk_auth_setting';
    update_option($prefix, $import_data);
    echo(json_encode(array('error' => 0, 'reload' => 1, 'msg' => '插件设置已导入，请刷新页面')));
    exit();
}
add_action('wp_ajax_xk_auth_options_import', 'xk_auth_ajax_options_import');

// 备份插件设置
function xk_auth_ajax_options_backup() {

    $type = !empty($_REQUEST['type']) ? $_REQUEST['type'] : '手动备份';
    $backup = xk_auth_options_backup($type);
    echo(json_encode(array('error' => 0, 'reload' => 1, 'msg' => '当前配置已经备份')));
    exit();
}
add_action('wp_ajax_xk_auth_options_backup', 'xk_auth_ajax_options_backup');

// 删除备份
function xk_auth_ajax_options_backup_delete() {

    if (!is_super_admin()) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }
    if (empty($_REQUEST['key'])) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit();
    }

    $prefix = 'xk_auth_setting';
    if ('xk_auth_options_backup_delete_all' == $_REQUEST['action']) {
        update_option($prefix . '_backup', false);
        echo(json_encode(array('error' => 0, 'reload' => 1, 'msg' => '已删除全部备份数据')));
        exit();
    }

    $options_backup = get_option($prefix . '_backup');

    if ('xk_auth_options_backup_delete_surplus' == $_REQUEST['action']) {
        if ($options_backup) {
            $options_backup = array_reverse($options_backup);
            update_option($prefix . '_backup', array_reverse(array_slice($options_backup, 0, 3)));
            echo(json_encode(array('error' => 0, 'reload' => 1, 'msg' => '已删除多余备份数据，仅保留最新3份')));
            exit();
        }
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '暂无可删除的数据')));
        exit();
    }

    if (!$options_backup) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '暂无可删除的数据')));
        exit();
    }

    if (isset($options_backup[$_REQUEST['key']])) {
        unset($options_backup[$_REQUEST['key']]);

        update_option($prefix . '_backup', $options_backup);
        echo(json_encode(array('error' => 0, 'reload' => 1, 'msg' => '所选备份已删除')));
    } else {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '此备份已删除')));
    }
    exit();
}
add_action('wp_ajax_xk_auth_options_backup_delete', 'xk_auth_ajax_options_backup_delete');
add_action('wp_ajax_xk_auth_options_backup_delete_all', 'xk_auth_ajax_options_backup_delete');
add_action('wp_ajax_xk_auth_options_backup_delete_surplus', 'xk_auth_ajax_options_backup_delete');

// 恢复备份
function xk_auth_ajax_options_backup_restore() {
    if (!is_super_admin()) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '操作权限不足')));
        exit();
    }
    if (empty($_REQUEST['key'])) {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '参数传入错误')));
        exit();
    }

    $prefix = 'xk_auth_setting';
    $options_backup = get_option($prefix . '_backup');
    if (isset($options_backup[$_REQUEST['key']]['data'])) {
        update_option($prefix, $options_backup[$_REQUEST['key']]['data']);
        echo(json_encode(array('error' => 0, 'reload' => 1, 'msg' => '插件设置已恢复到所选备份[' . $_REQUEST['key'] . ']')));
    } else {
        echo(json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '备份恢复失败，未找到对应数据')));
    }
    exit();
}
add_action('wp_ajax_xk_auth_options_backup_restore', 'xk_auth_ajax_options_backup_restore');

// 导出插件设置
function xk_auth_ajax_options_export() {
    if (!is_super_admin()) {
        wp_die('操作权限不足');
    }

    $prefix = 'xk_auth_setting';
    $options = get_option($prefix);

    $json_data = json_encode($options, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="xk-auth-settings-' . date('Y-m-d') . '.json"');
    header('Content-Length: ' . strlen($json_data));

    echo $json_data;
    exit();
}
add_action('wp_ajax_xk_auth_options_export', 'xk_auth_ajax_options_export');
