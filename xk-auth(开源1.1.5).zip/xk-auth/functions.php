<?php
/*
plugin name: 星空授权插件
plugin URI: https://www.xkzhi.cn
description: 子比多功能授权插件 支持对接WP主题、插件授权、PHP网页授权等多功能程序授权
author: 空白
author URI: https://www.xkzhi.cn
version: 1.1.5
*/

// 定义插件常量
define('XK_AUTH_DIR_PATH', plugin_dir_path(__FILE__));
define('XK_AUTH_DIR_URL', plugin_dir_url(__FILE__));

// 注册插件固定管理链接
function xk_auth_add_action_plugin($actions, $plugin_file)
{
    static $plugin;
    if (!isset($plugin))
        $plugin = plugin_basename(__FILE__);
    if ($plugin == $plugin_file) {
        $site_link = array('support' => '<a href="/wp-admin/admin.php?page=xk_auth_setting">设置</a>');
        $actions = array_merge($site_link, $actions);
    }
    return $actions;
}
add_filter('plugin_action_links', 'xk_auth_add_action_plugin', 10, 5);

// 引入核心文件
include_once 'core/functions/xk-sql.php';

include_once 'core/core.php';
include_once 'xk-functions.php';
include_once 'core/functions/widgets/xk-auth-widget.php';


// 加密扩展检测
/*if (!function_exists('sg_load')) {
    $message = sprintf(
        '<div style="text-align: center; padding: 50px 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;">
            <div style="max-width: 600px; margin: 0 auto;">
                <h2 style="color: #dc3545; margin-bottom: 30px; font-weight: 300;">
                    <span style="font-size: 48px; display: block; margin-bottom: 10px;">🔒</span>
                    环境依赖缺失
                </h2>
                <div style="background: #f8f9fa; border-radius: 8px; padding: 30px; margin: 25px 0; border-left: 4px solid #dc3545;">
                    <p style="color: #6c757d; margin: 0; line-height: 1.6;">
                        本插件(星空授权插件)需要 <strong>Source Guardian Compiler</strong> 扩展支持才能正常运行。
                    </p>
                </div>
                <a href="%s" target="_blank" 
                   style="display: inline-block; 
                          background: #007cba; 
                          color: white; 
                          text-decoration: none; 
                          padding: 12px 32px; 
                          border-radius: 4px; 
                          font-weight: 500;
                          transition: all 0.3s ease;">
                    查看安装教程
                </a>
                <p style="color: #868e96; margin-top: 25px; font-size: 14px;">
                    安装完成后，请重新启用插件
                </p>
            </div>
        </div>',
        esc_url(XK_AUTH_DIR_URL . 'help/source-guardian-loader-helper.php')
    );
    
    wp_die($message, '环境检测', ['response' => 503, 'back_link' => false]);
}
// 引入核心函数
if (function_exists('sg_load')) {
    include_once 'core/core.php';
    include_once 'xk-functions.php';
    include_once 'core/functions/widgets/xk-auth-widget.php';
}*/

// 插件依赖检测
register_activation_hook(__FILE__, 'xk_auth_check_theme_before_activation');

// 添加插件激活钩子
register_activation_hook(__FILE__, 'xk_auth_sql');