<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 插件依赖表单
function xk_auth_sql()
{
    xk_auth_log_table();
    xk_auth_product_table();
    xk_auth_requestlog_table();
    xk_auth_product_update_table();
    xk_auth_product_update_log_table();
    xk_auth_product_targeted_push_table();
    xk_auth_xk_log_table(); // 添加新的表创建函数
    xk_auth_frontend_admin_logs_table(); // 添加前端管理操作日志表
    xk_auth_cards_table(); // 添加卡密表
    xk_auth_promo_codes_table(); // 添加优惠码表
    xk_auth_reports_table(); // 添加举报信息表
}


/**
 * 创建xk_auth_log表（兼容旧代码）
 */
function xk_auth_xk_log_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'xk_auth_log';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) COMMENT '用户ID',
        product_id mediumint(9) COMMENT '产品ID',
        action varchar(50) NOT NULL COMMENT '操作类型',
        result tinyint(1) COMMENT '操作结果',
        ip varchar(45) NOT NULL COMMENT 'IP地址',
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '操作时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 添加索引：user_id, product_id
    $index_name = 'idx_user_product';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (user_id, product_id)");
    }
    
    // 添加索引：user_id, product_id
    $index_name = 'idx_user_product';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (user_id, product_id)");
    }
}

/**
 * 创建授权日志表
 */
function xk_auth_log_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_logs'; 

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) COMMENT '用户ID',
        product_id mediumint(9) COMMENT '产品ID',
        total_auths int COMMENT '全部可授权数',
        remaining_auths int COMMENT '可授权数',
        operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '操作时间',
        other_operations text COMMENT '其他操作记录',
        expire_time datetime DEFAULT NULL COMMENT '到期时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 添加索引：user_id, product_id
    $index_name = 'idx_user_product';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (user_id, product_id)");
    }
}

/**
 * 创建产品授权数据表
 */
function xk_auth_product_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL COMMENT '用户ID',
        product_id mediumint(9) NOT NULL COMMENT '产品ID',
        domain varchar(255) NOT NULL COMMENT '授权域名',
        auth_key varchar(100) NOT NULL COMMENT '授权码',
        operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '操作时间',
        expire_time datetime DEFAULT NULL COMMENT '到期时间',
        status varchar(20) NOT NULL COMMENT '授权状态',
        log text COMMENT '操作日志',
        encrypted_auth_data longtext COMMENT '加密的授权数据',
        last_communication_time datetime DEFAULT NULL COMMENT '最后通讯时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 检查并添加expire_time字段（如果不存在）
    $column_exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table_name LIKE %s", 'expire_time'));
    if (!$column_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN expire_time datetime DEFAULT NULL COMMENT '到期时间'");
    }
    
    // 检查并添加encrypted_auth_data字段（如果不存在）
    $column_exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table_name LIKE %s", 'encrypted_auth_data'));
    if (!$column_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN encrypted_auth_data longtext COMMENT '加密的授权数据'");
    }
    
    // 检查并添加last_communication_time字段（如果不存在）
    $column_exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table_name LIKE %s", 'last_communication_time'));
    if (!$column_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN last_communication_time datetime DEFAULT NULL COMMENT '最后通讯时间'");
    }
    
    // 添加联合索引：user_id, product_id, domain
    $index_name = 'idx_user_product_domain';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (user_id, product_id, domain)");
    }
}

/**
 * 插入产品授权数据
 * 
 * @param int $user_id 用户ID
 * @param int $product_id 产品ID
 * @param string $increase_domain 增加的域名
 * @param string $log 日志信息
 * @param string $expire_time 到期时间（可选）
 */
function xk_auth_insert_product_authorization_data($user_id = '', $product_id = '', $increase_domain = '', $log = '', $expire_time = NULL)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    // 验证必填参数
    if (empty($user_id) || empty($product_id) || empty($increase_domain)) {
        return;
    }

    // 检查是否存在相同的记录
    $existing_auth_key = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT auth_key FROM $table_name WHERE user_id = %d AND product_id = %d AND domain = %s",
            $user_id,
            $product_id,
            $increase_domain
        )
    );
    if ($existing_auth_key) {
        return; // 避免重复插入
    }

    // 初始化授权系统类型为默认值（本地数据库）
    $auth_system_type = '0';
    $auth_key = '';

    // 获取产品配置
    $product_settings = xk_auth('product_settings', array());
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            if (isset($product['product_id'], $product['auth_system_type']) && $product['product_id'] == $product_id) {
                $auth_system_type = (string) sanitize_text_field($product['auth_system_type']);
                break;
            }
        }
    }

    if ($auth_system_type == '0') { // 本地数据库
        $auth_key = xk_auth_generate_license_code();
    } elseif ($auth_system_type == '1') { // 南逸授权系统
        $auth_qq = get_user_meta($user_id, 'auth_qq', true);
        $nanyi_site_domain = '';
        $nanyi_product_id = '';
        $nanyi_webkey = '';

        // 重新获取南逸配置（确保正确拿到）
        foreach ($product_settings as $product) {
            if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                $nanyi_site_domain = rtrim(sanitize_text_field($product['nanyi_site_domain']), '/');
                $nanyi_product_id = sanitize_text_field($product['nanyi_product_id']);
                $nanyi_webkey = sanitize_text_field($product['nanyi_webkey']);
                break;
            }
        }

        // 验证南逸配置
        if (!empty($nanyi_site_domain) && !empty($nanyi_product_id) && !empty($nanyi_webkey) && !empty($auth_qq)) {
            // 构建API请求（使用wp_remote_get更可靠）
            $api_url = add_query_arg([
                'appid' => $nanyi_product_id,
                'type' => 'qq',
                'value' => urlencode($auth_qq),
                'webkey' => $nanyi_webkey
            ], $nanyi_site_domain . '/api/index/qq_auth');

            $response = wp_remote_get($api_url, ['timeout' => 5]);
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
                $response_body = wp_remote_retrieve_body($response);
                $data = json_decode($response_body, true);

                // 解析并匹配当前域名的authcode
                if (isset($data['code']) && $data['code'] === '1' && !empty($data['data']) && is_array($data['data'])) {
                    foreach ($data['data'] as $item) {
                        // 找到当前域名对应的授权码
                        if (is_array($item) && isset($item['url'], $item['authcode']) && $item['url'] == $increase_domain) {
                            $auth_key = sanitize_text_field($item['authcode']);
                            break; // 只取当前域名的授权码
                        }
                    }
                }
            }
        }
    }

    // 插入数据库（确保auth_key有值）
    if (!empty($auth_key)) {
        // 构建插入数据
        $insert_data = [
            'user_id' => $user_id,
            'product_id' => $product_id,
            'domain' => $increase_domain,
            'auth_key' => $auth_key,
            'operation_time' => current_time('mysql'),
            'status' => '1',
            'log' => $log
        ];
        
        // 添加调试日志
        // error_log('[XK Auth] 插入授权数据 - 初始参数:');
        // error_log('[XK Auth] user_id: ' . $user_id);
        // error_log('[XK Auth] product_id: ' . $product_id);
        // error_log('[XK Auth] domain: ' . $increase_domain);
        // error_log('[XK Auth] initial_expire_time: ' . ($expire_time ? $expire_time : 'NULL'));
        
        // 如果提供了expire_time，使用传入的到期时间
        // 如果没有提供expire_time，从授权记录中获取该用户对该产品的授权信息，包括到期时间
        if ($expire_time === NULL) {
            $auth_log_table = $wpdb->prefix . 'auth_logs';
            $auth_info = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT expire_time FROM $auth_log_table WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
                    $user_id, $product_id
                )
            );
            
            // 添加调试日志
            // error_log('[XK Auth] 插入授权数据 - 从auth_logs表获取的信息:');
            // error_log('[XK Auth] auth_info: ' . print_r($auth_info, true));
            
            // 如果有授权信息，使用该到期时间（包括NULL值，即永久授权）
            if ($auth_info) {
                $expire_time = $auth_info->expire_time;
            }
        }
        
        // 无论如何都添加expire_time字段，包括NULL值（即永久授权）
        $insert_data['expire_time'] = $expire_time;
        
        // 添加调试日志
        // error_log('[XK Auth] 插入授权数据 - 最终插入数据:');
        // error_log('[XK Auth] insert_data: ' . print_r($insert_data, true));
        
        // 定义数据类型
        $data_types = array(
            'user_id' => '%d',
            'product_id' => '%d',
            'domain' => '%s',
            'auth_key' => '%s',
            'operation_time' => '%s',
            'status' => '%s',
            'log' => '%s',
            'expire_time' => '%s' // 使用%s类型，允许NULL值
        );
        
        // 插入数据
        $wpdb->insert($table_name, $insert_data, $data_types);
        
        // 添加调试日志
        // if ($wpdb->last_error) {
        //     error_log('[XK Auth] 插入授权数据 - 错误: ' . $wpdb->last_error);
        // } else {
        //     error_log('[XK Auth] 插入授权数据 - 成功，ID: ' . $wpdb->insert_id);
        // }
    }
}

/**
 * 插入授权日志记录
 *
 * @param int $user_id 用户ID
 * @param int $product_id 产品ID
 * @param int $total_auths 全部可授权数
 * @param int $remaining_auths 可授权数
 * @param string $other_operations 其他操作记录
 * @param string $expire_time 到期时间（可选）
 * @return bool 成功插入返回 true，否则返回 false
 */
function xk_auth_insert_authorization_log($user_id = '', $product_id = '', $total_authorizations = '', $remaining_authorizations = '', $other_operations = '', $expire_time = NULL)
{
    global $wpdb;
    
    // 写入标准表
    $table_name = $wpdb->prefix . 'auth_logs';
    
    // 添加调试日志
    // error_log('[XK Auth] 插入授权日志 - 初始参数:');
    // error_log('[XK Auth] user_id: ' . $user_id);
    // error_log('[XK Auth] product_id: ' . $product_id);
    // error_log('[XK Auth] total_authorizations: ' . $total_authorizations);
    // error_log('[XK Auth] remaining_authorizations: ' . $remaining_authorizations);
    // error_log('[XK Auth] other_operations: ' . $other_operations);
    // error_log('[XK Auth] expire_time: ' . ($expire_time ? $expire_time : 'NULL'));
    
    // 检查并删除超过500条的日志
    xk_auth_manage_logs($table_name);
    
    $data = array(
        'user_id' => $user_id,
        'product_id' => $product_id,
        'total_auths' => $total_authorizations,
        'remaining_auths' => $remaining_authorizations,
        'operation_time' => current_time('mysql'),
        'other_operations' => $other_operations,
        'expire_time' => $expire_time // 总是添加expire_time字段，包括NULL值
    );
    
    // 添加调试日志
    // error_log('[XK Auth] 插入授权日志 - 插入数据:');
    // error_log('[XK Auth] data: ' . print_r($data, true));
    
    // 定义数据类型
    $data_types = array(
        'user_id' => '%d',
        'product_id' => '%d',
        'total_auths' => '%d',
        'remaining_auths' => '%d',
        'operation_time' => '%s',
        'other_operations' => '%s',
        'expire_time' => '%s' // 使用%s类型，允许NULL值
    );
    
    // 先尝试写入标准表
    $result = $wpdb->insert($table_name, $data, $data_types);
    
    // // 添加调试日志
    // if ($wpdb->last_error) {
    //     error_log('[XK Auth] 插入授权日志 - 错误: ' . $wpdb->last_error);
    // } else {
    //     error_log('[XK Auth] 插入授权日志 - 成功，ID: ' . $wpdb->insert_id);
    // }
    
    // 不再尝试写入xk_auth_log表，因为两个表结构不同
    // 如果需要写入xk_auth_log表，应该使用专门的函数处理
    
    return $result;
}

/**
 * 插入xk_auth_log表（兼容旧代码）
 * 
 * @param int $user_id 用户ID
 * @param int $product_id 产品ID
 * @param string $action 操作类型
 * @param int $result 操作结果
 * @param string $ip IP地址
 * @return bool 成功返回true，失败返回false
 */
function xk_auth_insert_xk_log($user_id = '', $product_id = '', $action = '', $result = 0, $ip = '')
{
    global $wpdb;
    
    // 如果IP地址为空，获取当前IP
    if (empty($ip)) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    }
    
    $table_name = $wpdb->prefix . 'xk_auth_log';
    $data = array(
        'user_id' => $user_id,
        'product_id' => $product_id,
        'action' => $action,
        'result' => $result,
        'ip' => $ip,
        'time' => current_time('mysql')
    );
    
    return $wpdb->insert($table_name, $data);
}

/**
 * 通用日志管理函数，检查并删除超过指定数量的日志，只保留最新记录
 *
 * @param string $table_name 完整的表名（含前缀）
 * @param int $max_logs 最大日志数量，默认500
 * @return bool 成功返回true，失败返回false
 */
function xk_auth_manage_logs($table_name, $max_logs = 500)
{
    global $wpdb;
    
    // 检查表中记录数量
    $log_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
    $log_count = intval($log_count);
    
    // 如果记录数量超过最大值，只保留最新的$max_logs条记录
    if ($log_count > $max_logs) {
        // 获取要保留的最小ID
        $min_id_to_keep = $wpdb->get_var("SELECT id FROM {$table_name} ORDER BY id DESC LIMIT 1 OFFSET {$max_logs}");
        
        if ($min_id_to_keep) {
            // 删除小于该ID的所有记录
            $result = $wpdb->query($wpdb->prepare("DELETE FROM {$table_name} WHERE id < %d", $min_id_to_keep));
            return $result !== false;
        }
    }
    
    return true;
}

/**
 * 创建授权日志表
 */
function xk_auth_requestlog_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_request_logs';
    $charset_collate = $wpdb->get_charset_collate();
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;
    
    if ($table_exists) {
        // Check if id column has AUTO_INCREMENT
        $columns = $wpdb->get_results("DESCRIBE $table_name");
        $has_auto_increment = false;
        
        foreach ($columns as $column) {
            if ($column->Field === 'id') {
                $has_auto_increment = strpos($column->Extra, 'auto_increment') !== false;
                break;
            }
        }
        
        if (!$has_auto_increment) {
            // Table exists but id column doesn't have AUTO_INCREMENT - need to fix
            $temp_table = $table_name . '_temp';
            
            // Create temporary table with correct structure
            $sql = "CREATE TABLE $temp_table (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                product_id mediumint(9) COMMENT '产品ID',
                ip varchar(45) NOT NULL COMMENT 'IP地址',
                domain varchar(255) NOT NULL COMMENT '请求域名',
                auth_key varchar(100) NOT NULL COMMENT '授权码',
                status varchar(50) NOT NULL COMMENT '请求状态',
                operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '请求时间',
                PRIMARY KEY  (id)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
            
            // Insert unique records into temporary table, ignoring duplicates
            $sql = "INSERT INTO $temp_table (product_id, ip, domain, auth_key, status, operation_time)
                    SELECT DISTINCT product_id, ip, domain, auth_key, status, operation_time
                    FROM $table_name;";
            $wpdb->query($sql);
            
            // Drop original table and rename temporary table
            $wpdb->query("DROP TABLE $table_name;");
            $wpdb->query("RENAME TABLE $temp_table TO $table_name;");
            
            return;
        }
    } else {
        // Table doesn't exist, create it with correct structure
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            product_id mediumint(9) COMMENT '产品ID',
            ip varchar(45) NOT NULL COMMENT 'IP地址',
            domain varchar(255) NOT NULL COMMENT '请求域名',
            auth_key varchar(100) NOT NULL COMMENT '授权码',
            status varchar(50) NOT NULL COMMENT '请求状态',
            operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '请求时间',
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    // 添加索引：ip, domain, auth_key
    $index_name = 'idx_ip_domain_auth';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (ip, domain, auth_key)");
    }
}

/**
 * 记录授权请求日志并自动清理
 *
 * @param int $product_id 产品ID
 * @param string $ip IP地址
 * @param string $domain 请求域名
 * @param string $auth_key 授权码
 * @param string $status 请求状态
 * @param array $extra_data 额外日志数据（可选）
 * @return bool 成功返回true，失败返回false
 */
function xk_auth_insert_request_log($product_id, $ip, $domain, $auth_key, $status, $extra_data = array())
{
    global $wpdb;
    $log_table = $wpdb->prefix . 'auth_request_logs';
    
    // 检查是否需要记录日志（可通过设置控制）
    $enable_logging = xk_auth('enable_request_logging', true);
    if (!$enable_logging) {
        return true;
    }
    
    // 检查是否是重复请求（1秒内相同参数的请求只记录一次）
    $cache_key = 'xk_auth_log_' . md5($product_id . $ip . $domain . $auth_key . $status);
    $cached = wp_cache_get($cache_key, 'xk_auth');
    if ($cached) {
        return true;
    }
    
    // 检查并删除超过500条的日志
    xk_auth_manage_logs($log_table);
    
    $current_time = current_time('mysql');
    
    // 插入日志记录
    $result = $wpdb->insert(
        $log_table,
        array(
            'product_id' => $product_id,
            'ip' => $ip,
            'domain' => $domain,
            'auth_key' => $auth_key,
            'status' => $status,
            'operation_time' => $current_time
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s')
    );
    
    // 设置1秒缓存，避免重复记录
    wp_cache_set($cache_key, true, 'xk_auth', 1);
    
    return $result !== false;
}

/**
 * 创建产品更新包数据表
 */
function xk_auth_product_update_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_update';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        product_id mediumint(9) NOT NULL COMMENT '产品ID',
        version varchar(20) NOT NULL COMMENT '版本号',
        update_package_url varchar(255) NOT NULL COMMENT '更新包URL',
        update_description text COMMENT '更新说明',
        original_versions text COMMENT '适用的原始版本列表',
        push_status tinyint(1) NOT NULL COMMENT '推送状态',
        operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '操作时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 检查并添加original_versions字段（如果不存在）
    $column_exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table_name LIKE %s", 'original_versions'));
    if (!$column_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN original_versions text COMMENT '适用的原始版本列表'");
    }
}

/**
 * 创建产品更新请求记录数据表
 */
function xk_auth_product_update_log_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_update_log';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        product_id mediumint(9) NOT NULL COMMENT '产品ID',
        ip varchar(45) NOT NULL COMMENT 'IP地址',
        domain varchar(255) NOT NULL COMMENT '请求域名',
        current_version varchar(20) NOT NULL COMMENT '版本',
        status varchar(20) NOT NULL COMMENT '请求状态',
        operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '请求时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 创建产品指定ID推送记录表
 */
function xk_auth_product_targeted_push_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_targeted_push';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        update_id mediumint(9) NOT NULL COMMENT '更新包ID',
        target_type varchar(20) NOT NULL COMMENT '目标类型(user_id/domain)',
        target_value varchar(255) NOT NULL COMMENT '目标值',
        push_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '推送时间',
        PRIMARY KEY  (id),
        UNIQUE KEY unique_push (update_id, target_type, target_value(191))
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 创建卡密表
 */
function xk_auth_cards_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_cards';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        card_code varchar(100) NOT NULL COMMENT '卡密代码',
        product_id mediumint(9) NOT NULL COMMENT '产品ID',
        expire_time datetime DEFAULT NULL COMMENT '到期时间',
        auth_count mediumint(9) NOT NULL DEFAULT 1 COMMENT '授权域名数量，0表示不限制',
        status varchar(20) NOT NULL DEFAULT 'unused' COMMENT '状态：unused(未使用), used(已使用), expired(已过期)',
        allowed_users text COMMENT '允许使用的用户ID，多个用逗号分隔',
        create_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '创建时间',
        use_time datetime DEFAULT NULL COMMENT '使用时间',
        used_user_id mediumint(9) DEFAULT NULL COMMENT '使用用户ID',
        PRIMARY KEY  (id),
        UNIQUE KEY unique_card (card_code)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 添加索引：card_code（已存在唯一键，不需要额外索引）
    
    // 添加索引：status
    $index_name = 'idx_card_status';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (status)");
    }
    
    // 添加索引：product_id
    $index_name = 'idx_card_product';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (product_id)");
    }
}

/**
 * 创建优惠码表
 */
function xk_auth_promo_codes_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_promo_codes';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        code varchar(50) NOT NULL COMMENT '优惠码',
        name varchar(100) NOT NULL COMMENT '优惠码名称',
        description text COMMENT '优惠码描述',
        type varchar(20) NOT NULL COMMENT '优惠类型：fixed(固定金额), percentage(百分比)',
        value decimal(10,2) NOT NULL COMMENT '优惠值',
        min_amount decimal(10,2) DEFAULT '0.00' COMMENT '最低消费金额',
        max_discount decimal(10,2) DEFAULT '999.00' COMMENT '最大优惠金额',
        usage_limit int DEFAULT NULL COMMENT '使用次数限制',
        usage_count int DEFAULT '0' COMMENT '已使用次数',
        product_ids text COMMENT '适用产品ID，多个用逗号分隔',
        user_ids text COMMENT '适用用户ID，多个用逗号分隔',
        start_time datetime DEFAULT NULL COMMENT '开始时间',
        end_time datetime DEFAULT NULL COMMENT '结束时间',
        status varchar(20) NOT NULL DEFAULT 'active' COMMENT '状态：active(有效), inactive(无效)',
        create_time datetime DEFAULT NULL COMMENT '创建时间',
        update_time datetime DEFAULT NULL COMMENT '更新时间',
        PRIMARY KEY  (id),
        UNIQUE KEY unique_code (code)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 添加索引：status
    $index_name = 'idx_promo_status';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (status)");
    }
    
    // 添加索引：code
    $index_name = 'idx_promo_code';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (code)");
    }
}

/**
 * 创建举报信息表
 */
function xk_auth_reports_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_reports';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL COMMENT '举报用户ID',
        product_id mediumint(9) NOT NULL COMMENT '产品ID',
        report_type varchar(50) NOT NULL COMMENT '举报类型',
        report_content text NOT NULL COMMENT '举报内容',
        report_url varchar(255) COMMENT '举报链接',
        report_ip varchar(45) NOT NULL COMMENT '举报IP地址',
        status varchar(20) NOT NULL DEFAULT 'pending' COMMENT '处理状态：pending(待处理), processed(已处理), rejected(已拒绝)',
        admin_note text COMMENT '管理员处理备注',
        operation_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '举报时间',
        process_time datetime DEFAULT NULL COMMENT '处理时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 添加索引：user_id, product_id
    $index_name = 'idx_user_product';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (user_id, product_id)");
    }
    
    // 添加索引：status
    $index_name = 'idx_status';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (status)");
    }
}

/**
 * 创建前端管理操作日志表
 */
function xk_auth_frontend_admin_logs_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_frontend_admin_logs';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        operator varchar(100) NOT NULL COMMENT '操作人',
        operator_id mediumint(9) NOT NULL COMMENT '操作人ID',
        action_type varchar(50) NOT NULL COMMENT '操作类型',
        target_user varchar(255) COMMENT '目标用户',
        target_product varchar(255) COMMENT '目标产品',
        action_detail text COMMENT '操作详情',
        request_ip varchar(45) NOT NULL COMMENT '请求IP地址',
        request_domain varchar(255) NOT NULL COMMENT '请求域名',
        action_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '操作时间',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 添加索引：operator_id, action_type
    $index_name = 'idx_operator_action';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (operator_id, action_type)");
    }
    
    // 添加索引：action_time
    $index_name = 'idx_action_time';
    $index_exists = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM $table_name WHERE Key_name = %s", $index_name));
    if (!$index_exists) {
        $wpdb->query("ALTER TABLE $table_name ADD INDEX $index_name (action_time)");
    }
}

/**
 * 插入前端管理操作日志
 *
 * @param string $action_type 操作类型
 * @param string $target_user 目标用户
 * @param string $target_product 目标产品
 * @param string $action_detail 操作详情
 * @return bool 成功返回true，失败返回false
 */
function xk_auth_insert_frontend_admin_log($action_type, $target_user = '', $target_product = '', $action_detail = '') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_frontend_admin_logs';
    
    // 检查并删除超过1000条的日志
    xk_auth_manage_logs($table_name, 1000);
    
    // 获取当前用户信息
    $current_user = wp_get_current_user();
    $operator = $current_user->display_name ?: $current_user->user_login;
    
    // 获取请求信息
    $request_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $request_domain = $_SERVER['HTTP_HOST'] ?? '';
    
    // 构建日志数据
    $data = array(
        'operator' => $operator,
        'operator_id' => $current_user->ID,
        'action_type' => $action_type,
        'target_user' => $target_user,
        'target_product' => $target_product,
        'action_detail' => $action_detail,
        'request_ip' => $request_ip,
        'request_domain' => $request_domain,
        'action_time' => current_time('mysql')
    );
    
    // 定义数据类型
    $data_types = array(
        'operator' => '%s',
        'operator_id' => '%d',
        'action_type' => '%s',
        'target_user' => '%s',
        'target_product' => '%s',
        'action_detail' => '%s',
        'request_ip' => '%s',
        'request_domain' => '%s',
        'action_time' => '%s'
    );
    
    // 插入数据
    $result = $wpdb->insert($table_name, $data, $data_types);
    
    return $result !== false;
}
