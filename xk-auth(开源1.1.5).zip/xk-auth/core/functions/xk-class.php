<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// Class部分
class xk_Auth
{
    /**
     * 检查用户是否购买了特定产品
     *
     * @param int $user_id 用户ID（可选）
     * @param int $post_id 帖子ID（产品ID）
     * @return bool 如果用户购买了指定产品，返回true；否则返回false
     */
    public static function is_product($user_id, $post_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'zibpay_order';

        // 如果未提供 $user_id，则使用当前登录用户的 ID
        if (!$user_id) {
            $user_id = get_current_user_id();
        }

        // 检查参数是否有效
        if (!$user_id || !$post_id) {
            return false;
        }

        // 查询数据库表
        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND post_id = %d AND status = 1",
            $user_id,
            $post_id
        );

        // 返回是否存在相应的订单
        return $wpdb->get_var($query) > 0;
    }

    // 判断域名是否已被授权
    public static function is_exists_domaint($user_id, $product_id, $domain)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';

        if (!$user_id) {
            $user_id = get_current_user_id();
        }

        $existing_domain = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT domain FROM $table_name WHERE user_id = %d AND product_id = %d AND domain = %s",
                $user_id, 
                $product_id, 
                $domain
            )
        );

        if ($existing_domain) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 检查用户是否已绑定至少一个域名
     *
     * @param int $user_id 用户ID（可选）
     * @param int $product_id 产品ID
     * @return bool 如果用户已绑定至少一个域名，返回true；否则返回false
     */
    public static function has_bound_domains($user_id, $product_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';

        if (!$user_id) {
            $user_id = get_current_user_id();
        }

        // 检查参数是否有效
        if (!$user_id || !$product_id) {
            return false;
        }

        // 查询用户是否已绑定至少一个域名
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND product_id = %d",
                $user_id, 
                $product_id
            )
        );

        // 返回是否有至少一个绑定的域名
        return $count > 0;
    }
}
