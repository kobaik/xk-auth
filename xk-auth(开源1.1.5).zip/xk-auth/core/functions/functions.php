<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 载入核心文件
include_once 'user/xk-side.php';
include_once 'user/xk-user.php';
include_once 'user/xk-query.php';
include_once 'user/xk-time-query.php';
include_once 'user/xk-log.php';
include_once 'user/xk-agent.php';
include_once 'user/xk-admin.php';

$include_once = array(
    "pay",
    "tools",
    "class",
    "links",
    "ajax",
    "modal",
    "rewrites",
);
foreach ($include_once as $inc) {
    include_once 'xk-' . $inc . '.php';
}

// 定义购买页class
function xk_auth_add_bodyclass($class)
{
    $class .= ' order-pay';
    return $class;
}

// 加载模板页面
function xk_auth_add_pay_page_template($original_template)
{
    global $post;
    if (!empty($post->ID) && is_page()) {
        $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);
        if ($pay_mate && 15 == $pay_mate['pay_type']) {
            add_filter('zib_add_bodyclass', 'xk_auth_add_bodyclass', 10, 2);
            add_filter('template_include', 'xk_auth_pay_page_template');
        }
    }
}
add_action('template_redirect', 'xk_auth_add_pay_page_template', 5);

// 引入模板文件
function xk_auth_pay_page_template($original_template)
{
    return XK_AUTH_DIR_PATH . 'page/pay-page.php';
}

// 授权管理页面到后台菜单
function xk_auth_register_product_page()
{
    add_menu_page(
        '授权管理中心',
        '授权管理中心',
        'manage_options',
        'admin',
        'xk_auth_admin_page',
        'dashicons-shield',
        98
    );
    // add_menu_page(
    //     '授权管理(旧版UI)',
    //     '授权管理(旧版UI)',
    //     'manage_options',
    //     'product_auth_manage',
    //     'xk_auth_render_product_page',
    //     'dashicons-shield',
    //     99
    // );
    // add_submenu_page(
    //     'product_auth_manage',
    //     '授权操作日志',
    //     '授权操作日志',
    //     'manage_options',
    //     'auth_render_operate_log',
    //     'xk_auth_render_operate_log_page'
    // );
    // add_submenu_page(
    //     'product_auth_manage',
    //     '授权请求日志',
    //     '授权请求日志',
    //     'manage_options',
    //     'auth_render_request_log',
    //     'xk_auth_render_request_log_page'
    // );
    // add_submenu_page(
    //     'product_auth_manage',
    //     '更新请求日志',
    //     '更新请求日志',
    //     'manage_options',
    //     'update_request_log',
    //     'xk_auth_update_log_page'
    // );
}
add_action('admin_menu', 'xk_auth_register_product_page');

// 新版UI
function xk_auth_admin_page()
{
    include_once 'admin/admin-main.php';
}

// // 授权管理页面
// function xk_auth_render_product_page()
// {
//     include_once 'admin/auth-manage.php';
// }

// 添加授权页面
// function xk_auth_render_add_page()
// {
//     include_once 'admin/auth-add.php';
// }

// // 授权操作日志页面
// function xk_auth_render_operate_log_page()
// {
//     include_once 'admin/auth-operatelog.php';
// }

// // 授权请求日志页面
// function xk_auth_render_request_log_page()
// {
//     include_once 'admin/auth-requestlog.php';
// }

function xk_auth_admin_page_vue_data_filter($vue_data) {
    add_filter('xk_auth_shop_page_vue_data', function ($__vue_data) use ($vue_data) {
        return array_merge($__vue_data, $vue_data);
    });
}

function xk_auth_admin_page_start() {
    return;
}


// // 添加更新页面
// function xk_auth_render_add_update_page()
// {
//     include_once 'admin/update-add.php';
// }

// // 管理更新页面
// function xk_auth_manage_update_page()
// {
//     include_once 'admin/update-manage.php';
// }

// // 管理更新页面
// function xk_auth_update_log_page()
// {
//     include_once 'admin/update_requestlog.php';
// }