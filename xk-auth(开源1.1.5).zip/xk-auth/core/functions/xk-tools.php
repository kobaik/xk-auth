<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * 获取用户购买特定产品的订单数据（已支付状态）
 *
 * 该函数用于查询数据库中特定用户购买特定产品的已支付订单，
 * 返回包含订单号、支付时间和订单价格的关联数组，支持防SQL注入处理。
 *
 * @param int $user_id 用户ID（可选，默认获取当前登录用户ID）
 * @param int $post_id 产品ID（对应文章ID，必填，用于指定查询的产品）
 * @return array 订单数据关联数组（格式：[['order_num' => 'xxx', 'pay_time' => 'xxx', 'order_price' => 'xxx'], ...]），无匹配订单时返回空数组
 */
function xk_auth_product_order_date($user_id = '', $post_id = '')
{
    global $wpdb; // 声明WordPress数据库全局对象

    // 处理用户ID：若未提供，则自动获取当前登录用户的ID
    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    // 获取订单表名（拼接WordPress前缀，适配多站点环境）
    $table_name = $wpdb->prefix . 'zibpay_order';

    // 构建查询语句：查询指定用户、指定产品且状态为"已支付"（status=1）的订单
    // 返回订单号（order_num）、支付时间（pay_time）、订单价格（order_price）和支付类型（pay_type）字段
    // 使用$wpdb->prepare()预处理查询，防止SQL注入
    $query = $wpdb->prepare(
        "SELECT order_num, pay_time, order_price, pay_type FROM $table_name WHERE user_id = %d AND post_id = %d AND status = 1",
        $user_id,  // 替换查询中的第一个%d（用户ID）
        $post_id   // 替换查询中的第二个%d（产品ID）
    );

    // 执行查询，通过ARRAY_A参数指定返回关联数组（键为字段名）
    $result = $wpdb->get_results($query, ARRAY_A);

    // 返回查询结果（无匹配时自动返回空数组）
    return $result;
}

/**
 * 获取产品标题
 *
 * 该函数用于从插件设置项中获取特定产品的标题。根据产品ID匹配设置中的产品，返回对应的标题。
 *
 * @param int|string $product_id 产品ID（可选，默认为空）
 * @return string 产品标题（未找到时返回默认文本）
 */
function men_get_product_title($product_id = '')
{
    // 如果未提供产品ID，则获取当前页面ID作为产品ID（产品ID与页面ID一致）
    if (empty($product_id)) {
        $product_id = get_the_ID();
    }

    // 从设置项中获取所有产品配置（使用之前定义的xk_auth函数）
    $product_settings = xk_auth('product_settings', array());

    // 遍历产品配置，匹配产品ID
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            // 检查当前产品配置是否包含有效ID和标题
            if (isset($product['product_id'], $product['product_name']) && $product['product_id'] == $product_id) {
                return esc_html($product['product_name']); // 返回匹配的产品标题（安全过滤）
            }
        }
    }

    // 未找到匹配的产品时，返回默认文本
    return '未命名产品';
}

/**
 * 获取产品选项的 HTML 字符串
 *
 * 该函数用于生成用于表单选择的产品选项的 HTML <option> 元素。
 * 它获取插件配置中设置的所有产品，并将它们作为选项返回。
 *
 * @return string 包含产品选项的 HTML 字符串
 */
function xk_auth_product_option()
{
    // 从插件配置中获取所有设置的产品
    $products = xk_auth('product_settings', array());

    // 初始化空字符串以存储 HTML 选项
    $options = '<option value="none">选择产品</option>';

    // 遍历配置中的产品，生成每个产品的选项
    foreach ($products as $product) {
        // 确保产品数据存在必要字段
        $product_id = isset($product['product_id']) ? $product['product_id'] : '';
        $product_name = isset($product['product_name']) ? $product['product_name'] : '未命名产品';

        // 判断当前选项是否需要选中
        $selected = '';
        if (!empty($_POST['product_id']) && $product_id == $_POST['product_id']) {
            $selected = 'selected="selected"';
        }

        // 生成<option>元素并添加到选项列表
        $options .= '<option value="' . esc_attr($product_id) . '" ' . $selected . '>' . esc_html($product_name) . '</option>';
    }

    // 返回产品选项的 HTML 字符串
    return $options;
}


/**
 * 获取用户产品授权信息
 *
 * 该函数直接从数据库获取指定用户和产品的授权信息，包括总授权次数和剩余授权次数。
 *
 * @param string $user_id 用户ID（默认为空字符串，如果未提供则使用当前用户ID）
 * @param string $product_id 产品ID（默认为空字符串）
 * @return array 返回包含授权信息的关联数组
 */
function xk_auth_change_transference($user_id = '', $product_id = '')
{
    global $wpdb;

    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    // 直接从product_auths表获取该用户该产品的所有授权记录
    $product_auths_table = $wpdb->prefix . 'product_auths';
    
    // 获取该用户在该产品下的所有授权记录数量（已使用的授权数）
    $used_auths = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $product_auths_table WHERE user_id = %d AND product_id = %d",
            $user_id,
            $product_id
        )
    );
    $used_auths = intval($used_auths);
    
    // 获取该产品的总授权数配置
    $total_auths = 0;
    
    // 方法1：首先尝试从产品设置中获取授权配置
    // 这里使用WordPress的get_option函数直接获取插件设置
    $xk_auth_settings = get_option('xk_auth_settings', array());
    if (!empty($xk_auth_settings) && isset($xk_auth_settings['product_settings']) && is_array($xk_auth_settings['product_settings'])) {
        foreach ($xk_auth_settings['product_settings'] as $product) {
            // 检查auth_count字段（根据代码中的使用模式，这是存储授权数量的字段）
            if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                if (isset($product['auth_count'])) {
                    $total_auths = intval($product['auth_count']);
                } elseif (isset($product['total_auths'])) {
                    $total_auths = intval($product['total_auths']);
                }
                break;
            }
        }
    }
    
    // 方法2：如果方法1失败，尝试从auth_logs表获取最近的授权记录
    // 这是为了兼容已有数据，确保授权信息能够正确显示
    if ($total_auths <= 0) {
        $table_name = $wpdb->prefix . 'auth_logs';
        $query = $wpdb->prepare(
            "SELECT total_auths FROM $table_name WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
            $user_id,
            $product_id
        );
        $result = $wpdb->get_var($query);
        if (!empty($result)) {
            $total_auths = intval($result);
        }
    }
    
    // 默认授权数：如果以上方法都失败，设置一个默认值
    if ($total_auths <= 0) {
        $total_auths = 1; // 默认值，可以根据实际需求调整
    }
    
    // 计算剩余授权数
    $remaining_auths = $total_auths - $used_auths;
    if ($remaining_auths < 0) {
        $remaining_auths = 0;
    }
    
    return array(
        'total_auths' => $total_auths,
        'remaining_auths' => $remaining_auths
    );
}


/**
 * 生成授权密钥
 *
 * 该函数用于生成一个带有特定格式的授权密钥，格式为'32位大小写字母+数字形式'或'类似于windows系统激活码'，其中X代表字母或数字。
 * 
 * @return string 返回生成的授权密钥
 */
function xk_auth_generate_license_code()
{
    // 定义序列号格式的模板
    $template = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'; // 32位大小写字母+数字形式
    $template_length = strlen($template);

    // 生成随机的字母和数字组合
    $code = '';
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code_length = strlen($characters);

    // 修复：生成与模板长度一致的随机字符
    for ($i = 0; $i < $template_length; $i++) {
        $code .= $characters[random_int(0, $code_length - 1)]; // 使用安全随机函数
    }

    // 将生成的随机字符插入模板中
    $license_code = '';
    for ($i = 0; $i < $template_length; $i++) {
        if ($template[$i] === 'X') {
            $license_code .= $code[$i];
        } else {
            $license_code .= $template[$i];
        }
    }

    return $license_code;
}



/**
 * 获取指定用户和产品的产品密钥
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 *
 * @return string 产品密钥
 */
function xk_auth_product_key($user_id = '', $product_id = '')
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    $key = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT auth_key FROM $table_name WHERE user_id = %d AND product_id = %d",
            $user_id, 
            $product_id
        )
    );

    // 检查数组是否为空，避免直接访问不存在的元素
    if (!empty($key) && isset($key[0])) {
        return $key[0]; // 返回查询满足条件的第一个密钥
    }
    
    // 修复：如果没有找到授权码，生成新的授权码并更新数据库中所有相关记录
    // 这样可以避免用户需要手动刷新授权码
    $new_auth_key = xk_auth_generate_license_code();
    
    // 更新该用户在该产品下的所有授权记录的授权码
    $wpdb->update(
        $table_name,
        array(
            'auth_key' => $new_auth_key,
            'operation_time' => current_time('mysql'),
            'log' => '系统自动生成了新的授权码'
        ),
        array(
            'user_id' => $user_id,
            'product_id' => $product_id
        ),
        array('%s', '%s', '%s'),
        array('%d', '%d')
    );
    
    return $new_auth_key;
}

/**
 * 获取指定用户和产品的授权域名列表
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 * @param int|string $status 授权状态（可选，默认为空字符串）
 * @param string $type 输出类型（可选，默认为空字符串）
 *
 * @return string HTML格式的授权域名列表
 */
function xk_auth_for_product_domain($user_id = '', $product_id = '', $type = '', $status = '')
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    // 添加状态过滤条件
    $status_where = '';
    $status_params = array($user_id, $product_id);
    
    // 如果指定了状态，则添加状态过滤
    if ($status !== '') {
        $status_where = ' AND status = %d';
        $status_params[] = intval($status);
    }

    // 查询时添加status字段和expire_time字段，并获取当前时间用于状态计算
    $current_time = current_time('mysql');
    $domains = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT domain, status, expire_time FROM $table_name WHERE user_id = %d AND product_id = %d$status_where ORDER BY domain ASC LIMIT 100",
            $status_params
        )
    );

    $html = '';
    if (empty($domains)) {
        // 如果没有找到任何域名记录，返回提示信息
        return '<span class="badg c-gray">暂无授权域名</span>';
    }
    

    
    // 添加必要的CSS样式
    $html .= '<style>
        .xk-domain-container {            position: relative;            display: inline-flex;            flex-direction: column;            margin: 0 10px 10px 0;            vertical-align: top;        }
        .xk-domain-badge {            cursor: pointer;            transition: all 0.2s ease;            position: relative;            display: inline-block;            user-select: none;        }
        .xk-domain-badge:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        .xk-domain-badge.active {
            transform: scale(0.98);
        }
        .xk-expire-time {            display: block;            margin-top: 8px;            padding: 8px 12px;            background: #f5f5f5;            border-radius: 6px;            font-size: 12px;            position: relative;            z-index: 10;            box-shadow: 0 2px 8px rgba(0,0,0,0.05);            border: 1px solid #e0e0e0;        }
        .xk-expire-time.c-red {
            background: #ffebee;
            border: 1px solid #ffcdd2;
        }
        .xk-expire-time.c-green {            background: #e8f5e8;            border: 1px solid #c8e6c9;        }
        .dark-theme .xk-expire-time.c-green {
            background: #313d49;
            border: 1px solid #313d49;
            color: #2996f6;
        }
        .dark-theme .xk-expire-time.c-red {
            background: #313d49;
            border: 1px solid #313d49;
            color: #2996f6;
        }
        /* 响应式布局优化 */
        @media (max-width: 768px) {
            .xk-domain-container {
                margin: 0 8px 8px 0;
            }
            .xk-domain-badge {
                font-size: 13px;
            }
            .xk-expire-time {
                font-size: 11px;
                padding: 6px 10px;
                margin-top: 6px;
            }
        }
        /* 小屏手机适配 */
        @media (max-width: 480px) {
            .xk-domain-container {
                display: block;
                margin: 0 0 10px 0;
                width: 100%;
            }
            .xk-domain-badge {
                display: block;
                text-align: center;
                padding: 8px 12px;
                font-size: 14px;
            }
            .xk-expire-time {
                text-align: center;
                font-size: 12px;
            }
        }
        /* 超小屏适配 */
        @media (max-width: 360px) {
            .xk-domain-badge {
                padding: 6px 10px;
                font-size: 13px;
            }
            .xk-expire-time {
                padding: 5px 8px;
                font-size: 11px;
            }
        }
        /* 触摸设备增强 */
        @media (hover: none) and (pointer: coarse) {
            .xk-domain-badge {
                touch-action: manipulation;
            }
            .xk-domain-badge:hover {
                /* 在触摸设备上移除悬停效果，避免意外触发 */
                transform: none;
                box-shadow: none;
            }
        }
    </style>';
    
    if ($type == 'select') {
        foreach ($domains as $domain_info) {
            $status_label = $domain_info->status ? '' : '（封禁）';
            $html .= '<label class="badg p2-10 mr10 pointer"><input type="radio" name="change_past_domain" value="' . esc_attr($domain_info->domain) . '"> ' . esc_html($domain_info->domain) . $status_label . '</label>';
        }
    } else {
        foreach ($domains as $domain_info) {
            // 根据状态使用不同的颜色标识
            $badge_class = $domain_info->status ? 'c-blue' : 'c-red';
            $status_label = $domain_info->status ? '' : '（封禁）';
            
            // 生成唯一的域名ID，用于关联点击事件
            $domain_id = 'domain_' . md5($domain_info->domain);
            
            // 处理到期时间显示
            $expire_content = '';
            $expire_class = '';
            
            // 先检查是否已过期（与后台逻辑保持一致）
            $is_expired = false;
            if (!empty($domain_info->expire_time) && $domain_info->expire_time != '0000-00-00 00:00:00') {
                $is_expired = strtotime($domain_info->expire_time) < strtotime($current_time);
            }
            
            // 根据过期状态和封禁状态显示相应内容
            if ($is_expired) {
                // 已过期状态（优先显示）
                $expire_class = 'c-red';
                $expire_date = date('Y-m-d', strtotime($domain_info->expire_time));
                $expire_content = '到期时间：' . $expire_date . '<br>状态：已过期';
            } else if ($domain_info->status == 0) {
                // 未过期但被封禁
                $expire_class = 'c-red';
                $expire_content = '状态：已封禁';
            } else {
                // 正常域名的到期时间显示逻辑
                if (!empty($domain_info->expire_time) && $domain_info->expire_time != '0000-00-00 00:00:00') {
                    // 格式化到期时间
                    $expire_date = date('Y-m-d', strtotime($domain_info->expire_time));
                    $expire_class = 'c-green';
                    $expire_content = '到期时间：' . $expire_date . '<br>状态：有效';
                } else {
                    $expire_class = 'c-green';
                    $expire_content = '永久有效';
                }
            }
            
            $html .= '<div class="xk-domain-container">
                        <span class="badg p5-10 ' . $badge_class . ' xk-domain-badge" data-domain-id="' . $domain_id . '">
                ' . esc_html($domain_info->domain) . $status_label . '
            </span>';
            
            $show_expire_time = xk_auth('show_auth_expire_time_auth', true);
            //error_log('show_expire_time value: ' . ($show_expire_time ? 'true' : 'false')); // 查看日志
            if ($show_expire_time) {
                $html .= '<div class="xk-expire-time ' . $expire_class . '" id="' . $domain_id . '_expire">
                            ' . $expire_content . '
                        </div>';
            }
            
            $html .= '</div>';
        }
    }

    return $html;
}

/**
 * 获取指定用户和产品的授权域名列表，包含每个域名对应的授权码
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 * @param int|string $status 授权状态（可选，默认为空字符串）
 *
 * @return string HTML格式的授权域名列表，包含授权码
 */
function xk_auth_for_product_domain_with_key($user_id = '', $product_id = '', $status = '')
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    // 添加状态过滤条件
    $status_where = '';
    $status_params = array($user_id, $product_id);
    
    // 如果指定了状态，则添加状态过滤
    if ($status !== '') {
        $status_where = ' AND status = %d';
        $status_params[] = intval($status);
    }

    // 查询时添加auth_key字段和expire_time字段，并获取当前时间用于状态计算
    $current_time = current_time('mysql');
    $domains = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT domain, status, expire_time, auth_key FROM $table_name WHERE user_id = %d AND product_id = %d$status_where ORDER BY domain ASC LIMIT 100",
            $status_params
        )
    );

    $html = '';
    if (empty($domains)) {
        // 如果没有找到任何域名记录，返回提示信息
        return '<div class="text-center c-gray">暂无授权域名</div>';
    }
    
    // 添加折叠功能的CSS和JS
    $html .= '<style>
        .auth-domains-container {
            position: relative;
            max-width: 100%;
            margin: 30px 0px 0px 0px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .auth-domains-list {
            margin: 0;
            padding: 0;
            width: 100%;
            max-width: 800px;
        }
        .auth-domains-item {
            margin-bottom: 10px;
            width: 100%;
        }
        .auth-domains-more {
            display: none;
        }
        .auth-domains-toggle {
            text-align: center;
            margin-top: 10px;
        }
        .auth-domains-toggle .but {
            cursor: pointer;
        }
        
        /* 响应式布局优化 */
        @media (max-width: 768px) {
            .auth-domains-container {
                margin: 20px 0 0 0;
            }
            .auth-domains-list {
                max-width: 100%;
            }
        }
        
        /* 小屏手机适配 */
        @media (max-width: 480px) {
            .auth-domains-item .zib-widget.theme-box {
                padding: 0px !important;
            }
            .auth-domains-item .flex.ac.hh {
                flex-direction: column;
                align-items: center;
                gap: 10px;
            }
            .auth-domains-item .flex-1 {
                width: 100%;
            }
            .auth-domains-item h3.theme-box-title {
                font-size: 16px;
                text-align: center;
                width: 100%;
            }
            /* 到期时间和状态在同一行且居中 */
            .auth-domains-item .flex.ac.hh .flex.ac.hh {
                flex-direction: row;
                justify-content: center;
                gap: 10px;
                width: 100%;
                margin: 5px 0;
            }
            .auth-domains-item .line-form .flex.ac.hh {
                flex-direction: column;
                align-items: center;
            }
            .auth-domains-item .line-form .flex-0 {
                margin-bottom: 8px;
                text-align: center;
            }
            .auth-domains-item .line-form .flex-1 {
                margin-left: 0 !important;
                width: 100%;
            }
            .auth-domains-item .line-form .flex.ac.hh .flex.ac.hh {
                flex-direction: row;
                gap: 10px;
                justify-content: center;
            }
            .auth-domains-item .line-form .flex.ac.hh .flex-0.ml10 {
                margin-left: 0 !important;
                margin-top: 5px;
            }
            .auth-domains-item .line-form button {
                width: 100%;
                margin-bottom: 5px;
            }
        }
        
        /* 超小屏适配 */
        @media (max-width: 360px) {
            .auth-domains-item h3.theme-box-title {
                font-size: 15px;
            }
            .auth-domains-item .badg {
                font-size: 12px;
                padding: 4px 8px;
            }
            .auth-domains-item .flex.ac.hh .flex.ac.hh {
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: center;
            }
            /* 复制和刷新按钮在超小屏幕上的适配 */
            .auth-domains-item .line-form .flex.ac.hh .flex.ac.hh {
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: center;
                gap: 8px;
            }
            .auth-domains-item button {
                font-size: 13px;
                padding: 6px 10px;
                flex: 1;
                min-width: 120px;
            }
        }
    </style>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // 授权域名折叠功能
        $(document).on(\'click\', \'.auth-domains-toggle\', function() {
            var $container = $(this).closest(\'.auth-domains-container\');
            var $moreItems = $container.find(\'.auth-domains-more\');
            var $toggleBtn = $(this).find(\'.but\');
            
            if ($moreItems.is(\':visible\')) {
                $moreItems.hide();
                $toggleBtn.html(\'<i class=\\"fa fa-chevron-down\\"></i> 查看更多授权\');
            } else {
                $moreItems.show();
                $toggleBtn.html(\'<i class=\\"fa fa-chevron-up\\"></i> 收起授权\');
            }
        });
        
        // 授权码显示/隐藏功能
        $(document).on(\'click\', \'.auth-key-toggle\', function() {
            var $this = $(this);
            var $authKey = $this.siblings(\'.auth-key-text\');
            var $authKeyHidden = $this.siblings(\'.auth-key-hidden\');
            
            if ($authKey.is(\':visible\')) {
                // 隐藏授权码
                $authKey.hide();
                $authKeyHidden.show();
                $this.html(\'<i class=\\"fa fa-eye\\"></i>\');
            } else {
                // 显示授权码
                $authKey.show();
                $authKeyHidden.hide();
                $this.html(\'<i class=\\"fa fa-eye-slash\\"></i>\');
            }
        });
    });
    </script>';
    
    // 添加授权码显示/隐藏的CSS
    $html .= '<style>
        .auth-key-toggle {
            cursor: pointer;
            margin: 0 5px;
            color: #666;
            font-size: 14px;
        }
        .auth-key-toggle:hover {
            color: #333;
        }
        .auth-key-text {
            display: none;
        }
        .auth-key-hidden {
            display: inline;
        }
    </style>';
    
    $domain_count = count($domains);
    $max_visible = 3;
    $show_toggle = $domain_count > $max_visible;
    
    $html .= '<div class="auth-domains-container">
                <div class="auth-domains-list">';
    
    $counter = 0;
    foreach ($domains as $domain_info) {
        $counter++;
        $is_more = $show_toggle && $counter > $max_visible;
        
        // 根据状态使用不同的颜色标识
        $status_class = $domain_info->status ? 'c-blue' : 'c-red';
        $status_text = $domain_info->status ? '正常' : '封禁';
        
        // 处理到期时间显示
        $expire_content = '';
        $expire_class = '';
        
        // 先检查是否已过期（与后台逻辑保持一致）
        $is_expired = false;
        if (!empty($domain_info->expire_time) && $domain_info->expire_time != '0000-00-00 00:00:00') {
            $is_expired = strtotime($domain_info->expire_time) < strtotime($current_time);
        }
        
        // 根据过期状态和封禁状态显示相应内容
        if ($is_expired) {
            // 已过期状态（优先显示）
            $expire_class = 'c-red';
            $expire_date = date('Y-m-d', strtotime($domain_info->expire_time));
            $expire_content = '到期时间：' . $expire_date . ' | 状态：已过期';
        } else if ($domain_info->status == 0) {
            // 未过期但被封禁
            $expire_class = 'c-red';
            $expire_content = '状态：已封禁';
        } else {
            // 正常域名的到期时间显示逻辑
            if (!empty($domain_info->expire_time) && $domain_info->expire_time != '0000-00-00 00:00:00') {
                // 格式化到期时间
                $expire_date = date('Y-m-d', strtotime($domain_info->expire_time));
                $expire_class = 'c-green';
                $expire_content = '到期时间：' . $expire_date . ' | 状态：有效';
            } else {
                $expire_class = 'c-green';
                $expire_content = '永久有效';
            }
        }
        
        $item_class = $is_more ? 'auth-domains-item auth-domains-more' : 'auth-domains-item';
        
        $html .= '<div class="' . $item_class . '">
                    <div class="zib-widget theme-box" style="padding: 0px 0px 0px 100px;">
                        <div class="box-body">
                            <div class="flex ac hh mb10">
                                <div class="flex-1">
                                    <h3 class="theme-box-title m0">' . esc_html($domain_info->domain) . '</h3>
                                </div>
                                <div class="flex ac hh">
                                    <div class="ml10">
                                        <span class="badg ' . $status_class . '">' . esc_html($status_text) . '</span>
                                    </div>
                                    <div class="ml10">
                                        <span class="badg em09 ' . $expire_class . '">' . esc_html($expire_content) . '</span>
                                    </div>
                                </div>
                            </div>
                            <div class="line-form theme-box mb10">
                                <div class="flex ac hh">
                                    <div class="flex-0">
                                        <span class="muted-2-color em09">授权码：</span>
                                    </div>
                                    <div class="flex-1 ml10">
                                        <div class="flex ac hh">
                                            <div class="flex-1 text-center">
                                                <b class="c-red">
                                                    <!-- 显示隐藏的授权码 -->
                                                    <span class="auth-key-hidden" data-clipboard-tag="授权码" data-clipboard-text="' . esc_attr($domain_info->auth_key) . '" class="clip-aut">' . substr(esc_html($domain_info->auth_key), 0, 4) . '********' . substr(esc_html($domain_info->auth_key), -4) . '</span>
                                                    <!-- 显示完整的授权码 -->
                                                    <span class="auth-key-text" data-clipboard-tag="授权码" data-clipboard-text="' . esc_attr($domain_info->auth_key) . '" class="clip-aut">' . esc_html($domain_info->auth_key) . '</span>
                                                    <!-- 切换按钮 -->
                                                    <span class="auth-key-toggle"><i class="fa fa-eye"></i></span>
                                                </b>
                                            </div>
                                            <div class="flex-0 ml10">
                                                <a data-clipboard-tag="授权码" data-clipboard-text="' . esc_attr($domain_info->auth_key) . '" class="clip-aut but c-yellow radius padding-sm">复制授权码</a>
                                            </div>
                                            <div class="flex-0 ml10">
                                                <button type="button" class="but c-green radius padding-sm" onclick="refreshDomainAuthKey(' . $product_id . ', \'' . esc_js($domain_info->domain) . '\', this)">刷新授权码</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
    }
    
    $html .= '</div>';
    
    // 添加查看更多按钮
    if ($show_toggle) {
        $html .= '<div class="auth-domains-toggle text-center">
                    <a class="but c-blue radius padding-sm">
                        <i class="fa fa-chevron-down"></i> 查看更多授权
                    </a>
                </div>';
    }
    
    $html .= '</div>';
    
    return $html;
}