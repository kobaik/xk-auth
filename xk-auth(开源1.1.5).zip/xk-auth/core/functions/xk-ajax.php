<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */



// 授权请求日志 - AJAX清空日志处理
function xk_auth_ajax_clear_request_logs()
{
    // 验证nonce
    check_ajax_referer('xk_auth_clear_logs', 'security');

    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => '您没有权限执行此操作'));
    }

    // 清空日志表
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_request_logs';
    $result = $wpdb->query("TRUNCATE TABLE {$table_name}");

    if ($result !== false) {
        wp_send_json_success(array('message' => '日志已成功清空'));
    } else {
        wp_send_json_error(array('message' => '清空日志失败，请重试'));
    }

    wp_die();
}

// 授权操作日志 - AJAX清空日志处理
function xk_auth_ajax_clear_operate_logs()
{
    // 验证nonce
    check_ajax_referer('xk_auth_clear_logs', 'security');

    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => '您没有权限执行此操作'));
    }

    // 清空日志表
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_logs';
    $result = $wpdb->query("TRUNCATE TABLE {$table_name}");

    if ($result !== false) {
        wp_send_json_success(array('message' => '日志已成功清空'));
    } else {
        wp_send_json_error(array('message' => '清空日志失败，请重试'));
    }

    wp_die();
}

// 更新请求日志 - AJAX清空日志处理
function xk_auth_ajax_clear_update_logs() {
    // 验证nonce
    check_ajax_referer('xk_auth_clear_logs', 'security');

    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => '您没有权限执行此操作'));
    }

    // 清空日志表
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_update_log';
    $result = $wpdb->query("TRUNCATE TABLE {$table_name}");

    if ($result !== false) {
        wp_send_json_success(array('message' => '日志已成功清空'));
    } else {
        wp_send_json_error(array('message' => '清空日志失败，请重试'));
    }

    wp_die();
}

// 前端管理操作日志 - AJAX清空日志处理
function xk_auth_ajax_clear_frontend_admin_logs() {
    // 验证nonce
    check_ajax_referer('xk_auth_clear_logs', 'security');

    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => '您没有权限执行此操作'));
    }

    // 清空日志表
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_frontend_admin_logs';
    $result = $wpdb->query("TRUNCATE TABLE {$table_name}");

    if ($result !== false) {
        wp_send_json_success(array('message' => '日志已成功清空'));
    } else {
        wp_send_json_error(array('message' => '清空日志失败，请重试'));
    }

    wp_die();
}

/**
 * 检查API请求频率限制
 * 
 * @return bool|array 如果请求被限制，返回包含错误信息的数组；否则返回true
 */
function xk_auth_check_api_rate_limit() {
    // 检查是否开启了API请求限制
    $enable_limit = xk_auth('enable_api_rate_limit', false);
    if (!$enable_limit) {
        return true;
    }
    
    // 获取请求限制设置
    $limit_count = xk_auth('api_rate_limit_count', 5);
    $limit_time = xk_auth('api_rate_limit_time', 60);
    $limit_message = xk_auth('api_rate_limit_message', '请求过于频繁，请稍后重试');
    
    // 获取客户端IP
    $client_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    // 生成缓存键
    $cache_key = 'xk_auth_rate_limit_' . md5($client_ip);
    
    // 获取当前请求计数
    $request_count = wp_cache_get($cache_key, 'xk_auth');
    if (false === $request_count) {
        $request_count = 0;
    }
    
    // 检查是否超过限制
    if ($request_count >= $limit_count) {
        return array(
            'error' => 1,
            'msg' => $limit_message
        );
    }
    
    // 更新请求计数
    $request_count++;
    wp_cache_set($cache_key, $request_count, 'xk_auth', $limit_time);
    
    return true;
}

// 注册AJAX处理函数（适用于登录用户）
function xk_auth_register_logs_ajax_handlers() {
    add_action('wp_ajax_xk_auth_clear_request_logs', 'xk_auth_ajax_clear_request_logs');
    add_action('wp_ajax_xk_auth_clear_operate_logs', 'xk_auth_ajax_clear_operate_logs');
    add_action('wp_ajax_xk_auth_clear_update_logs', 'xk_auth_ajax_clear_update_logs');
    add_action('wp_ajax_xk_auth_clear_frontend_admin_logs', 'xk_auth_ajax_clear_frontend_admin_logs');

    add_action('wp_ajax_get_auth_request_logs', 'xk_auth_ajax_get_auth_request_logs');
    add_action('wp_ajax_get_auth_operation_logs', 'xk_auth_ajax_get_auth_operation_logs');
    add_action('wp_ajax_get_update_request_logs', 'xk_auth_ajax_get_update_request_logs');
    add_action('wp_ajax_get_frontend_admin_logs', 'xk_auth_ajax_get_frontend_admin_logs');
    add_action('wp_ajax_remove_push_target', 'xk_auth_ajax_remove_push_target');
    
    // 获取产品列表
    add_action('wp_ajax_xk_auth_get_products', 'xk_auth_ajax_get_products');
}
add_action('admin_init', 'xk_auth_register_logs_ajax_handlers');

// 获取产品列表AJAX处理函数
function xk_auth_ajax_get_products() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误', 'data' => array());
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        check_ajax_referer('xk_auth_nonce', 'security');
        
        // 检查权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取产品设置
        $product_settings = xk_auth('product_settings', array());
        $products = array();
        
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $products[] = array(
                        'id' => intval($product['product_id']),
                        'name' => sanitize_text_field($product['product_name'])
                    );
                }
            }
        }
        
        $response = array(
            'error' => 0,
            'msg' => '获取产品列表成功',
            'data' => $products
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

// 获取授权请求日志AJAX处理
function xk_auth_ajax_get_auth_request_logs() {
    // 验证请求是否为AJAX请求
    if (!wp_doing_ajax()) {
        wp_send_json_error(array('error' => 1, 'msg' => '非法请求'));
    }
    
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');
    
    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('error' => 1, 'msg' => '权限不足'));
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_request_logs';
    
    // 获取请求参数
    $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;
    
    // 辅助函数：获取产品名
    function get_product_name_from_settings_log($product_id) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id_temp = intval($product['product_id']);
                    $product_list[$product_id_temp] = sanitize_text_field($product['product_name']);
                }
            }
        }
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
    
    // 辅助函数：格式化请求状态显示
    function format_request_status_log($status) {
        $status = strtolower($status);
        
        $status_map = array(
            'success' => array('text' => '验证成功', 'class' => 'success'),
            'token_generated_for_auth' => array('text' => 'Token生成成功', 'class' => 'success'),
            'token_generated_triple' => array('text' => '三重验证Token生成', 'class' => 'success'),
            'success_triple_verified' => array('text' => '三重验证成功', 'class' => 'success'),
            'success_push_token' => array('text' => 'Token推送成功', 'class' => 'success'),
            'failed_missing_params' => array('text' => '参数不完整', 'class' => 'danger'),
            'failed_invalid_product_id' => array('text' => '无效产品ID', 'class' => 'danger'),
            'failed_invalid_domain' => array('text' => '无效域名', 'class' => 'danger'),
            'failed_invalid_auth_key' => array('text' => '无效授权码', 'class' => 'danger'),
            'failed_invalid_token_format' => array('text' => '无效Token格式', 'class' => 'danger'),
            'failed' => array('text' => '验证失败', 'class' => 'danger'),
            'failed_pre_auth' => array('text' => '预验证失败', 'class' => 'danger'),
            'failed_token_invalid' => array('text' => 'Token无效', 'class' => 'danger'),
            'failed_token_mismatch' => array('text' => 'Token不匹配', 'class' => 'danger'),
            'failed_offline_expired' => array('text' => '离线授权过期', 'class' => 'danger'),
            'failed_auth_expired' => array('text' => '授权已过期', 'class' => 'danger'),
            'failed_auth_invalid' => array('text' => '授权无效', 'class' => 'danger'),
            'failed_auth_record_invalid' => array('text' => '授权记录无效', 'class' => 'danger'),
            'failed_token_verify_invalid' => array('text' => 'Token验证无效', 'class' => 'danger'),
            'failed_push_token' => array('text' => 'Token推送失败', 'class' => 'danger')
        );
        
        $default = array('text' => '未知状态', 'class' => 'warning');
        
        if (isset($status_map[$status])) {
            return $status_map[$status];
        } elseif (strpos($status, 'success') === 0) {
            return array('text' => '验证成功', 'class' => 'success');
        } elseif (strpos($status, 'failed') === 0) {
            $reason = str_replace('failed_', '', $status);
            $reason_text = str_replace('_', ' ', $reason);
            return array('text' => '验证失败: ' . ucfirst($reason_text), 'class' => 'danger');
        } else {
            return $default;
        }
    }
    
    // 获取总记录数
    $all_count = intval($wpdb->get_var("SELECT COUNT(*) FROM {$table_name}"));
    $total_pages = ceil($all_count / $per_page);
    
    // 查询日志数据
    $logs_list = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT %d, %d",
        $offset, $per_page
    ));
    
    // 格式化日志数据
    $formatted_auth_request_logs = array();
    foreach ($logs_list as $log) {
        $status_info = format_request_status_log($log->status);
        $formatted_auth_request_logs[] = array(
            'id' => $log->id,
            'productId' => $log->product_id,
            'productName' => get_product_name_from_settings_log($log->product_id),
            'requestIp' => $log->ip,
            'domain' => $log->domain,
            'authKey' => $log->auth_key,
            'status' => $log->status,
            'statusText' => $status_info['text'],
            'statusClass' => $status_info['class'],
            'message' => '',
            'requestTime' => date('Y-m-d H:i:s', strtotime($log->operation_time))
        );
    }
    
    // 返回JSON响应
    wp_send_json(array(
        'error' => 0,
        'authRequestLogs' => $formatted_auth_request_logs,
        'authRequestTotal' => $all_count,
        'authRequestCurrentPage' => $paged,
        'authRequestTotalPages' => $total_pages
    ));
}

// 获取授权操作日志AJAX处理
function xk_auth_ajax_get_auth_operation_logs() {
    // 验证请求是否为AJAX请求
    if (!wp_doing_ajax()) {
        wp_send_json_error(array('error' => 1, 'msg' => '非法请求'));
    }
    
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');
    
    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('error' => 1, 'msg' => '权限不足'));
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_logs';
    
    // 获取请求参数
    $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;
    
    // 辅助函数：获取产品名
    function get_product_name_from_settings_log($product_id) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id_temp = intval($product['product_id']);
                    $product_list[$product_id_temp] = sanitize_text_field($product['product_name']);
                }
            }
        }
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
    
    // 辅助函数：获取用户名
    function get_username_by_id($user_id) {
        $user_data = get_userdata($user_id);
        return $user_data ? $user_data->display_name . " (ID:{$user_id})" : "用户ID:{$user_id}";
    }
    
    // 获取总记录数
    $all_count = intval($wpdb->get_var("SELECT COUNT(*) FROM {$table_name}"));
    $total_pages = ceil($all_count / $per_page);
    
    // 查询日志数据
    $logs_list = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT %d, %d",
        $offset, $per_page
    ));
    
    // 格式化日志数据
    $formatted_auth_operation_logs = array();
    foreach ($logs_list as $log) {
        $formatted_auth_operation_logs[] = array(
            'id' => $log->id,
            'operator' => get_username_by_id($log->user_id),
            'targetUser' => get_username_by_id($log->user_id),
            'targetProduct' => get_product_name_from_settings_log($log->product_id),
            'detail' => $log->other_operations,
            'operationTime' => date('Y-m-d H:i:s', strtotime($log->operation_time)),
            'ip' => ''
        );
    }
    
    // 返回JSON响应
    wp_send_json(array(
        'error' => 0,
        'authOperationLogs' => $formatted_auth_operation_logs,
        'authOperationTotal' => $all_count,
        'authOperationCurrentPage' => $paged,
        'authOperationTotalPages' => $total_pages
    ));
}

// 获取更新请求日志AJAX处理
function xk_auth_ajax_get_update_request_logs() {
    // 验证请求是否为AJAX请求
    if (!wp_doing_ajax()) {
        wp_send_json_error(array('error' => 1, 'msg' => '非法请求'));
    }
    
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');
    
    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('error' => 1, 'msg' => '权限不足'));
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_update_log';
    
    // 获取请求参数
    $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;
    
    // 辅助函数：获取产品名
    function get_product_name_from_settings_log($product_id) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id_temp = intval($product['product_id']);
                    $product_list[$product_id_temp] = sanitize_text_field($product['product_name']);
                }
            }
        }
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
    
    // 辅助函数：格式化请求状态显示
    function format_request_status_log($status) {
        $status = strtolower($status);
        
        $status_map = array(
            'success' => array('text' => '成功', 'class' => 'success'),
            'failed' => array('text' => '失败', 'class' => 'danger'),
            'warning' => array('text' => '警告', 'class' => 'warning')
        );
        
        return isset($status_map[$status]) ? $status_map[$status] : array('text' => '未知状态', 'class' => 'warning');
    }
    
    // 获取总记录数
    $all_count = intval($wpdb->get_var("SELECT COUNT(*) FROM {$table_name}"));
    $total_pages = ceil($all_count / $per_page);
    
    // 查询日志数据
    $logs_list = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT %d, %d",
        $offset, $per_page
    ));
    
    // 格式化日志数据
    $formatted_update_request_logs = array();
    foreach ($logs_list as $log) {
        $status_info = format_request_status_log($log->status);
        $formatted_update_request_logs[] = array(
            'id' => $log->id,
            'productName' => get_product_name_from_settings_log($log->product_id),
            'currentVersion' => $log->current_version,
            'latestVersion' => '',
            'domain' => $log->domain,
            'requestIp' => $log->ip,
            'status' => $log->status,
            'statusText' => $status_info['text'],
            'statusClass' => $status_info['class'],
            'message' => '',
            'requestTime' => $log->operation_time && $log->operation_time !== '0000-00-00 00:00:00' ? date('Y-m-d H:i:s', strtotime($log->operation_time)) : '时间未知'
        );
    }
    
    // 返回JSON响应
    wp_send_json(array(
        'error' => 0,
        'updateRequestLogs' => $formatted_update_request_logs,
        'updateRequestTotal' => $all_count,
        'updateRequestCurrentPage' => $paged,
        'updateRequestTotalPages' => $total_pages
    ));
}

// 删除推送目标AJAX处理
function xk_auth_ajax_remove_push_target() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_targeted_push';
        
        // 获取请求参数
        $update_id = isset($_POST['update_id']) ? intval($_POST['update_id']) : 0;
        $target = isset($_POST['target']) ? sanitize_text_field($_POST['target']) : '';
        
        // 验证参数
        if (!$update_id || !$target) {
            throw new Exception('参数错误');
        }
        
        // 解析target，提取target_type和target_value
        $target_type = '';
        $target_value = '';
        
        if ($target === '全部') {
            $target_type = 'all';
            $target_value = 'all';
        } elseif (strpos($target, 'ID:') === 0) {
            $target_type = 'user_id';
            $target_value = substr($target, 3);
        } elseif (strpos($target, '域名:') === 0) {
            $target_type = 'domain';
            $target_value = substr($target, 4);
        }
        
        // 如果无法解析target，返回错误
        if (!$target_type) {
            throw new Exception('无效的推送目标');
        }
        
        // 删除推送目标
        $result = $wpdb->delete(
            $table_name,
            array(
                'update_id' => $update_id,
                'target_type' => $target_type,
                'target_value' => $target_value
            ),
            array('%d', '%s', '%s')
        );
        
        if ($result !== false) {

            delete_transient('xk_auth_dashboard_data');
            
            $response = array('error' => 0, 'msg' => '推送目标删除成功');
        } else {
            throw new Exception('删除失败: ' . $wpdb->last_error);
        }
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}

// 获取更新列表AJAX处理
function xk_auth_ajax_get_updates_list() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '获取更新列表失败');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_REQUEST['security']) ? sanitize_text_field($_REQUEST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        global $wpdb;
        
        // 获取产品列表
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id = intval($product['product_id']);
                    $product_list[$product_id] = sanitize_text_field($product['product_name']);
                }
            }
        }
        
        // 分页与排序
        $per_page = isset($_REQUEST['per_page']) ? intval($_REQUEST['per_page']) : 20;
        $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;
        
        // 排序处理
        $orderby = !empty($_REQUEST['orderby']) ? sanitize_text_field($_REQUEST['orderby']) : 'id';
        $order = !empty($_REQUEST['order']) ? sanitize_text_field($_REQUEST['order']) : 'DESC';
        $valid_orderby = array('id', 'product_id', 'version', 'operation_time', 'push_status');
        $orderby = in_array($orderby, $valid_orderby) ? $orderby : 'id';
        $order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';
        
        // 获取更新包列表
        $table_name = $wpdb->prefix . 'product_update';
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';
        
        // 构建查询条件
        $where_clauses = array();
        $query_params = array();
        
        // 关键词搜索
        $keyword = isset($_REQUEST['keyword']) ? sanitize_text_field($_REQUEST['keyword']) : '';
        $search_field = isset($_REQUEST['search_field']) ? sanitize_text_field($_REQUEST['search_field']) : '';
        if (!empty($keyword) && !empty($search_field)) {
            $where_clauses[] = "u.{$search_field} LIKE %s";
            $query_params[] = '%' . $keyword . '%';
        } elseif (!empty($keyword)) {
            // 全局搜索
            $where_clauses[] = "(u.version LIKE %s OR u.product_id LIKE %s OR u.original_versions LIKE %s)";
            $query_params[] = '%' . $keyword . '%';
            $query_params[] = '%' . $keyword . '%';
            $query_params[] = '%' . $keyword . '%';
        }
        
        // 产品ID筛选
        $product_id = isset($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';
        // 如果product_id存在且不为空字符串，则添加筛选条件
        if (isset($_REQUEST['product_id']) && $product_id !== '') {
            $where_clauses[] = "u.product_id = %d";
            $query_params[] = intval($product_id);
        }
        
        // 推送状态筛选
        $push_status = isset($_REQUEST['push_status']) ? $_REQUEST['push_status'] : '';
        // 如果push_status不是空字符串且不是'all'，则添加筛选条件
        if ($push_status !== '' && $push_status !== 'all') {
            $where_clauses[] = "u.push_status = %d";
            $query_params[] = intval($push_status);
        }
        
        // 时间范围筛选
        $start_time = isset($_REQUEST['start_time']) ? sanitize_text_field($_REQUEST['start_time']) : '';
        $end_time = isset($_REQUEST['end_time']) ? sanitize_text_field($_REQUEST['end_time']) : '';
        if (!empty($start_time) && !empty($end_time)) {
            $where_clauses[] = "u.operation_time BETWEEN %s AND %s";
            $query_params[] = $start_time . ' 00:00:00';
            $query_params[] = $end_time . ' 23:59:59';
        } elseif (!empty($start_time)) {
            $where_clauses[] = "u.operation_time >= %s";
            $query_params[] = $start_time . ' 00:00:00';
        } elseif (!empty($end_time)) {
            $where_clauses[] = "u.operation_time <= %s";
            $query_params[] = $end_time . ' 23:59:59';
        }
        
        // 构建WHERE子句
        $where_sql = '';
        if (!empty($where_clauses)) {
            $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
        }
        
        // 构建总数量查询 - 确保与完整查询使用相同的表连接和条件
        $count_query = "SELECT COUNT(*) FROM (
                           SELECT DISTINCT u.id FROM {$table_name} u 
                           LEFT JOIN {$targeted_push_table} tp ON u.id = tp.update_id 
                           {$where_sql}
                           GROUP BY u.id
                       ) as temp";
        $total_count = $wpdb->get_var($wpdb->prepare($count_query, $query_params));
        $total_pages = ceil($total_count / $per_page);
        
        // 构建完整查询
        $query_params[] = $offset;
        $query_params[] = $per_page;
        
        $updates_list = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                u.*, 
                GROUP_CONCAT(CASE WHEN tp.target_type = 'all' THEN '全部' 
                                 WHEN tp.target_type = 'user_id' THEN CONCAT('ID:', tp.target_value) 
                                 WHEN tp.target_type = 'domain' THEN CONCAT('域名:', tp.target_value) 
                                 ELSE tp.target_value END SEPARATOR ', ') as pushed_targets
             FROM {$table_name} u 
             LEFT JOIN {$targeted_push_table} tp ON u.id = tp.update_id 
             {$where_sql}
             GROUP BY u.id 
             ORDER BY u.{$orderby} {$order} 
             LIMIT %d, %d",
            $query_params
        ));
        
        // 格式化更新包数据
        $formatted_updates = array();
        foreach ($updates_list as $update) {
            $formatted_updates[] = array(
                'id' => $update->id,
                'productId' => $update->product_id,
                'productName' => isset($product_list[$update->product_id]) ? $product_list[$update->product_id] : "产品ID:{$update->product_id}",
                'version' => $update->version,
                'updatePackageUrl' => $update->update_package_url,
                'updateDescription' => $update->update_description ?: '',
                'pushStatus' => intval($update->push_status),
                'pushStatusText' => $update->push_status ? '已推送' : '未推送',
                'originalVersions' => $update->original_versions ?: '全版本',
                'pushedTargets' => $update->pushed_targets ?: '',
                'operationTime' => date('Y-m-d H:i', strtotime($update->operation_time))
            );
        }
        
        // 构建成功响应
        $response = array(
            'error' => 0,
            'msg' => '获取更新列表成功',
            'updatesList' => $formatted_updates,
            'updatesTotal' => $total_count,
            'updatesCurrentPage' => $paged,
            'updatesTotalPages' => $total_pages
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}
add_action('wp_ajax_get_updates_list', 'xk_auth_ajax_get_updates_list');

// 刷新授权码AJAX处理
function xk_auth_ajax_refresh_key()
{
    // 设置JSON响应头
    header('Content-Type: application/json');

    // 获取用户ID和产品ID
    $user_id = get_current_user_id();
    $product_id = !empty($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    // 初始化响应数据
    $response = array(
        'error' => 1,
        'ys' => 'danger',
        'msg' => '未知错误',
        'reload' => false
    );

    try {
        // 验证用户是否登录
        if (!$user_id) {
            throw new Exception('请先登录');
        }

        // 验证产品ID是否有效
        if (!$product_id) {
            throw new Exception('产品ID无效');
        }

        // 验证用户是否购买了该产品
        $order_info = xk_auth_product_order_date($user_id, $product_id);
        if (empty($order_info)) {
            throw new Exception('您未购买此产品，无法刷新授权码');
        }

        // 生成新的授权码
        $new_auth_key = xk_auth_generate_license_code();

        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';

        // 更新该用户在该产品下的所有授权记录的授权码
        $result = $wpdb->update(
            $table_name,
            array(
                'auth_key' => $new_auth_key,
                'operation_time' => current_time('mysql'),
                'log' => '用户刷新了授权码'
            ),
            array(
                'user_id' => $user_id,
                'product_id' => $product_id
            ),
            array('%s', '%s', '%s'),
            array('%d', '%d')
        );

        if ($result === false) {
            throw new Exception('更新授权码失败：' . $wpdb->last_error);
        }

        // 获取授权日志信息，记录操作
        $aut_logs = xk_auth_change_transference($user_id, $product_id);
        
        // 获取当前产品的到期时间
        $auth_log_table = $wpdb->prefix . 'auth_logs';
        $auth_info = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT expire_time FROM $auth_log_table WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
                $user_id, $product_id
            )
        );
        $expire_time = NULL;
        if ($auth_info && $auth_info->expire_time !== NULL) {
            $expire_time = $auth_info->expire_time;
        }
        
        xk_auth_insert_authorization_log($user_id, $product_id, $aut_logs['total_auths'], $aut_logs['remaining_auths'], '用户刷新了授权码', $expire_time);

        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        // 更新成功
        $response = array(
            'error' => 0,
            'ys' => 'success',
            'msg' => '授权码刷新成功',
            'reload' => true
        );
    } catch (Exception $e) {
        // 捕获异常并返回错误信息
        $response['msg'] = $e->getMessage();
    }

    // 返回JSON响应
    echo json_encode($response);
    exit;
}

// 保存举报设置AJAX处理
function xk_auth_save_report_settings() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取请求参数
        $report_types = isset($_POST['report_types']) ? $_POST['report_types'] : '';
        
        // 验证参数
        if (empty($report_types)) {
            throw new Exception('参数错误');
        }
        
        // 解析举报类型
        $report_types = json_decode($report_types, true);
        if (!is_array($report_types)) {
            // 尝试处理可能的转义问题
            $report_types = stripslashes($_POST['report_types']);
            $report_types = json_decode($report_types, true);
            if (!is_array($report_types)) {
                throw new Exception('举报类型格式错误');
            }
        }
        
        // 获取发送者名称
        $sender_name = isset($_POST['sender_name']) ? sanitize_text_field($_POST['sender_name']) : '星空授权';
        
        // 获取功能开关状态
        $enabled = isset($_POST['enabled']) ? ($_POST['enabled'] === 'true' || $_POST['enabled'] === true) : true;
        
        // 获取邮箱通知开关状态
        $email_notification = isset($_POST['email_notification']) ? ($_POST['email_notification'] === 'true' || $_POST['email_notification'] === true) : true;
        
        // 获取前端授权管理功能开关状态
        $frontend_auth_enabled = isset($_POST['frontend_auth_enabled']) ? ($_POST['frontend_auth_enabled'] === '1' || $_POST['frontend_auth_enabled'] === 1 || $_POST['frontend_auth_enabled'] === 'true' || $_POST['frontend_auth_enabled'] === true) : true;
        
        // 保存设置
        $options = get_option('xk_auth_setting', array());
        $options['report_types'] = $report_types;
        $options['report_sender_name'] = $sender_name;
        $options['report_enabled'] = $enabled;
        $options['report_email_notification'] = $email_notification;
        $options['frontend_auth_enabled'] = $frontend_auth_enabled;
        update_option('xk_auth_setting', $options);
        
        $response = array('error' => 0, 'msg' => '举报设置保存成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}
add_action('wp_ajax_xk_auth_save_report_settings', 'xk_auth_save_report_settings');

// 检查举报类型使用情况AJAX处理
function xk_auth_check_report_type_usage() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取请求参数
        $report_type_key = isset($_POST['report_type_key']) ? sanitize_text_field($_POST['report_type_key']) : '';
        
        // 验证参数
        if (empty($report_type_key)) {
            throw new Exception('参数错误');
        }
        
        // 检查数据库中是否有使用该举报类型的记录
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_reports';
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE report_type = %s",
            $report_type_key
        ));
        
        $response = array(
            'error' => 0,
            'data' => array(
                'is_used' => ($count > 0),
                'count' => intval($count)
            )
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}
add_action('wp_ajax_xk_auth_check_report_type_usage', 'xk_auth_check_report_type_usage');

// 加载举报设置AJAX处理
function xk_auth_load_report_settings() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_REQUEST['security']) ? sanitize_text_field($_REQUEST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 加载设置
        $report_types = xk_auth('report_types', array(
            array('key' => 'piracy', 'label' => '盗版使用'),
            array('key' => 'unauthorized', 'label' => '未授权使用'),
            array('key' => 'fake', 'label' => '假冒产品'),
            array('key' => 'other', 'label' => '其他问题')
        ));
        
        $sender_name = xk_auth('report_sender_name', '星空授权');
        $enabled = xk_auth('report_enabled', true);
        $email_notification = xk_auth('report_email_notification', true);
        $frontend_auth_enabled = xk_auth('frontend_auth_enabled', true);
        
        $response = array('error' => 0, 'reportTypes' => $report_types, 'senderName' => $sender_name, 'enabled' => $enabled, 'emailNotification' => $email_notification, 'frontendAuthEnabled' => $frontend_auth_enabled);
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}
add_action('wp_ajax_xk_auth_load_report_settings', 'xk_auth_load_report_settings');
add_action('wp_ajax_refresh_auth_key', 'xk_auth_ajax_refresh_key');

// 刷新单个域名的授权码
function xk_auth_ajax_refresh_domain_key()
{
    // 获取用户ID、产品ID和域名
    $user_id = get_current_user_id();
    $product_id = !empty($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $domain = !empty($_POST['domain']) ? sanitize_text_field($_POST['domain']) : '';

    // 初始化响应数据
    $response = array(
        'error' => 1,
        'ys' => 'danger',
        'msg' => '未知错误',
        'reload' => false
    );

    try {
        // 验证用户是否登录
        if (!$user_id) {
            throw new Exception('请先登录');
        }

        // 验证产品ID是否有效
        if (!$product_id) {
            throw new Exception('产品ID无效');
        }

        // 验证域名是否有效
        if (!$domain) {
            throw new Exception('域名无效');
        }

        // 验证用户是否购买了该产品
        $order_info = xk_auth_product_order_date($user_id, $product_id);
        if (empty($order_info)) {
            throw new Exception('您未购买此产品，无法刷新授权码');
        }

        // 生成新的授权码
        $new_auth_key = xk_auth_generate_license_code();

        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';

        // 检查该域名是否存在于该用户的该产品下
        $domain_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND product_id = %d AND domain = %s",
                $user_id, $product_id, $domain
            )
        );

        if (!$domain_exists) {
            throw new Exception('该域名不属于您的授权列表');
        }

        // 更新该用户在该产品下指定域名的授权码
        $result = $wpdb->update(
            $table_name,
            array(
                'auth_key' => $new_auth_key,
                'operation_time' => current_time('mysql'),
                'log' => '用户刷新了单个域名的授权码'
            ),
            array(
                'user_id' => $user_id,
                'product_id' => $product_id,
                'domain' => $domain
            ),
            array('%s', '%s', '%s'),
            array('%d', '%d', '%s')
        );

        if ($result === false) {
            throw new Exception('更新授权码失败：' . $wpdb->last_error);
        }

        // 获取授权日志信息，记录操作
        $aut_logs = xk_auth_change_transference($user_id, $product_id);
        
        // 获取当前产品的到期时间
        $auth_log_table = $wpdb->prefix . 'auth_logs';
        $auth_info = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT expire_time FROM $auth_log_table WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
                $user_id, $product_id
            )
        );
        $expire_time = NULL;
        if ($auth_info && $auth_info->expire_time !== NULL) {
            $expire_time = $auth_info->expire_time;
        }
        
        xk_auth_insert_authorization_log($user_id, $product_id, $aut_logs['total_auths'], $aut_logs['remaining_auths'], '用户刷新了单个域名的授权码：' . $domain, $expire_time);

        // 更新成功
        $response = array(
            'error' => 0,
            'ys' => 'success',
            'msg' => '授权码刷新成功',
            'reload' => true
        );
    } catch (Exception $e) {
        // 捕获异常并返回错误信息
        $response['msg'] = $e->getMessage();
    }

    // 返回JSON响应
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_refresh_domain_auth_key', 'xk_auth_ajax_refresh_domain_key');

// 添加授权的模态框AJAX
function add_xk_auth_increase_modal()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';
    echo xk_auth_increase_modal($user_id, $product_id);
    exit;
}
add_action('wp_ajax_increase_auth_modal', 'add_xk_auth_increase_modal');

// 添加授权域名处理AJAX
function xk_auth_ajax_increase()
{
    // 彻底清除所有之前的输出缓冲区，确保只返回JSON
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // 设置JSON响应头
    header('Content-Type: application/json; charset=UTF-8');
    // 禁用缓存
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // 声明全局变量
    global $wpdb;
    
    $user_id = get_current_user_id();

    $product_id = isset($_REQUEST['product_id']) ? intval($_REQUEST['product_id']) : 0;

    // 获取授权QQ
    $auth_qq = get_user_meta($user_id, 'auth_qq', true);

    // 初始化授权系统类型为默认值（本地数据库）
    $auth_system_type = '0';

    // 从设置项中获取所有产品配置
    $product_settings = xk_auth('product_settings', array());

    // 遍历产品配置，匹配产品ID并获取对应的授权系统类型
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            // 检查是否存在匹配的产品ID和授权系统类型配置
            if (isset($product['product_id'], $product['auth_system_type']) && $product['product_id'] == $product_id) {
                // 赋值并过滤授权系统类型
                $auth_system_type = (string) sanitize_text_field($product['auth_system_type']);
                break; // 找到匹配项后退出循环
            }
        }
    }

    // 检查用户ID
    if (!$user_id) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '权限不足'));
        exit;
    }

    // 检查域名是否为空
    if (empty($_POST['increase_domain'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入授权域名'));
        exit();
    }

    // 检查域名或IP地址格式
    if (!preg_match("/^(?:([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}|((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))$/i", $_POST['increase_domain'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入正确的域名或IP地址'));
        exit();
    }

    // 检查授权域名是否已经存在
    if (xk_Auth::is_exists_domaint($user_id, $product_id, $_POST['increase_domain'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '此域名已存在授权'));
        exit();
    }

    if ($auth_system_type == '1') { // 南逸授权系统    
        $nanyi_site_domain = '';
        $nanyi_product_id = '';
        $nanyi_username = '';
        $nanyi_password = '';

        // 从设置项中获取所有产品配置
        $product_settings = xk_auth('product_settings', array());

        // 遍历产品配置，匹配产品ID并获取相关配置
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    $nanyi_site_domain = sanitize_text_field($product['nanyi_site_domain']);
                    $nanyi_product_id = sanitize_text_field($product['nanyi_product_id']);
                    $nanyi_username = sanitize_text_field($product['nanyi_username']);
                    $nanyi_password = sanitize_text_field($product['nanyi_password']);
                    break; // 找到匹配项后退出循环
                }
            }
        }

        // 构建API请求参数数组
        $api_url = add_query_arg([
            'appid' => $nanyi_product_id,
            'url' => $_POST['increase_domain'],
            'qq' => $auth_qq,
            'authdate' => 0,
            'adminname' => $nanyi_username,
            'password' => $nanyi_password
        ], $nanyi_site_domain . 'api/Index/admin_add_auth');

        // 使用wp_remote_post发起请求，增加超时设置
        $response = wp_remote_post($api_url, ['timeout' => 5]);
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
            $response_body = wp_remote_retrieve_body($response);
            $data = json_decode($response_body, true);

            // 获取响应体并解析为数组
            if (isset($data['code']) && $data['code'] === "0") {
                echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '授权添加失败，请联系客服处理'));
                exit();
            }
        }
    }
    // 获取该用户对该产品的授权信息，包括到期时间
    $auth_log_table = $wpdb->prefix . 'auth_logs';
    $auth_info = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT expire_time FROM $auth_log_table WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
            $user_id, $product_id
        )
    );
    
    // 添加调试日志
    // error_log('[XK Auth] 绑定域名 - 授权信息查询结果:');
    // error_log('[XK Auth] auth_info: ' . print_r($auth_info, true));
    
    // 如果有授权信息，使用该到期时间（包括NULL值，即永久授权）
    $expire_time = NULL;
    if ($auth_info) {
        $expire_time = $auth_info->expire_time;
    }
    
    // 添加调试日志
    // error_log('[XK Auth] 绑定域名 - 到期时间处理:');
    // error_log('[XK Auth] expire_time: ' . ($expire_time ? $expire_time : 'NULL'));
    // error_log('[XK Auth] user_id: ' . $user_id);
    // error_log('[XK Auth] product_id: ' . $product_id);
    // error_log('[XK Auth] domain: ' . $_POST['increase_domain']);
    
    // 执行授权域名入库，传递到期时间
    xk_auth_insert_product_authorization_data($user_id, $product_id, $_POST['increase_domain'], '绑定授权域名' . $_POST['increase_domain'], $expire_time);
    
    // 执行更新授权日志
    $aut_logs = xk_auth_change_transference('', $product_id);
    xk_auth_insert_authorization_log($user_id, $product_id, $aut_logs['total_auths'], $aut_logs['remaining_auths'] - 1, '绑定授权域名' . $_POST['increase_domain'], $expire_time);

    // 清除仪表盘数据缓存，确保下次访问时显示最新数据
    delete_transient('xk_auth_dashboard_data');
    
    // 添加成功后刷新网页
    echo json_encode(array('error' => 0, 'ys' => '', 'msg' => '授权绑定添加成功', 'reload' => true));
    exit();
}
add_action('wp_ajax_increase_auth', 'xk_auth_ajax_increase');

// 举报功能的模态框AJAX
function add_xk_auth_report_modal()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';
    echo xk_auth_report_modal($user_id, $product_id);
    exit;
}
add_action('wp_ajax_add_ajax_admin_report', 'add_xk_auth_report_modal');
add_action('wp_ajax_nopriv_add_ajax_admin_report', 'add_xk_auth_report_modal');

// 提交举报信息AJAX处理
function xk_auth_ajax_submit_report()
{
    // 彻底清除所有之前的输出缓冲区，确保只返回JSON
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // 设置JSON响应头
    header('Content-Type: application/json; charset=UTF-8');
    // 禁用缓存
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // 获取用户ID
    $user_id = get_current_user_id();
    if (!$user_id) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请先登录'));
        exit;
    }
    
    // 验证nonce
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'submit_report_nonce')) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请求已过期，请刷新页面重试'));
        exit;
    }
    
    // 获取用户真实IP地址
    function xk_auth_get_real_ip() {
        if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
            $ip = getenv('HTTP_CLIENT_IP');
        } elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        } elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
            $ip = getenv('REMOTE_ADDR');
        } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
            $ip = $_SERVER['REMOTE_ADDR'];
        } else {
            $ip = 'unknown';
        }
        // 验证IP格式并提取有效IP
        return preg_match('/[\d\.]{7,15}/', $ip, $matches) ? $matches[0] : $ip;
    }
    
    $user_ip = xk_auth_get_real_ip();
    $cache_key = 'xk_auth_report_limit_' . md5($user_id . '_' . $user_ip);
    $last_submit_time = wp_cache_get($cache_key, 'xk_auth');
    $current_time = time();
    
    // 限制30秒内只能提交一次
    if ($last_submit_time && ($current_time - $last_submit_time) < 30) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '提交过于频繁，请30秒后再试'));
        exit;
    }
    
    // 获取表单数据
    $product_id = isset($_POST['report_product_id']) ? intval($_POST['report_product_id']) : 0;
    $report_type = isset($_POST['report_type']) ? sanitize_text_field($_POST['report_type']) : '';
    $report_url = isset($_POST['report_url']) ? sanitize_text_field($_POST['report_url']) : '';
    // 移除http或https前缀
    $report_url = preg_replace('/^https?:\/\//', '', $report_url);
    $report_content = isset($_POST['report_content']) ? sanitize_textarea_field($_POST['report_content']) : '';
    
    // 验证举报内容长度
    if (strlen($report_content) > 500) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '举报内容不能超过500字'));
        exit;
    }
    
    // 验证必填字段
    if (!$product_id || !$report_type || !$report_content) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请填写所有必填字段'));
        exit;
    }
    
    // 验证域名格式
    if (!empty($report_url)) {
        // 更严格的域名验证
        $domain_pattern = '/^(www\.)?([a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.)+[a-zA-Z]{2,}$/';
        if (!preg_match($domain_pattern, $report_url)) {
            echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入有效的域名格式'));
            exit;
        }
    }
    
    // 插入举报数据
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_reports';
    
    $data = array(
        'user_id' => $user_id,
        'product_id' => $product_id,
        'report_type' => $report_type,
        'report_content' => $report_content,
        'report_url' => $report_url,
        'report_ip' => $user_ip,
        'status' => 'pending',
        'operation_time' => current_time('mysql')
    );
    
    $data_types = array(
        '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s'
    );
    
    $result = $wpdb->insert($table_name, $data, $data_types);
    
    if ($result !== false) {
        // 设置提交时间缓存
        wp_cache_set($cache_key, $current_time, 'xk_auth', 30);
        echo json_encode(array('error' => 0, 'ys' => 'success', 'msg' => '举报提交成功，我们将尽快处理', 'reload' => true));
    } else {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '举报提交失败，请重试'));
    }
    
    exit;
}
add_action('wp_ajax_submit_report', 'xk_auth_ajax_submit_report');
add_action('wp_ajax_nopriv_submit_report', 'xk_auth_ajax_submit_report');

// 获取举报列表AJAX处理
function xk_auth_ajax_get_reports_list()
{
    // 验证请求是否为AJAX请求
    if (!wp_doing_ajax()) {
        wp_send_json_error(array('error' => 1, 'msg' => '非法请求'));
    }
    
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');
    
    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('error' => 1, 'msg' => '权限不足'));
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_reports';
    
    // 获取请求参数
    $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = isset($_REQUEST['per_page']) ? intval($_REQUEST['per_page']) : 10;
    $offset = ($paged - 1) * $per_page;
    
    // 获取搜索参数
    $search_type = isset($_REQUEST['search_type']) ? sanitize_text_field($_REQUEST['search_type']) : '';
    $search_keyword = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';
    $status = isset($_REQUEST['status']) ? sanitize_text_field($_REQUEST['status']) : '';
    
    // 构建查询条件
    $where_clauses = array();
    $query_params = array();
    
    // 状态筛选
    if (!empty($status)) {
        $where_clauses[] = "status = %s";
        $query_params[] = $status;
    }
    
    // 搜索条件
    if (!empty($search_keyword)) {
        switch ($search_type) {
            case 'user':
                // 搜索用户
                $user_ids = array();
                $users = get_users(array('search' => '*' . esc_attr($search_keyword) . '*'));
                foreach ($users as $user) {
                    $user_ids[] = $user->ID;
                }
                if (!empty($user_ids)) {
                    $user_placeholders = implode(',', array_fill(0, count($user_ids), '%d'));
                    $where_clauses[] = "user_id IN ({$user_placeholders})";
                    $query_params = array_merge($query_params, $user_ids);
                }
                break;
            
            case 'product':
                // 搜索产品
                $product_settings = xk_auth('product_settings', array());
                $product_ids = array();
                foreach ($product_settings as $product) {
                    if (isset($product['product_id'], $product['product_name']) && stripos($product['product_name'], $search_keyword) !== false) {
                        $product_ids[] = $product['product_id'];
                    }
                }
                if (!empty($product_ids)) {
                    $product_placeholders = implode(',', array_fill(0, count($product_ids), '%d'));
                    $where_clauses[] = "product_id IN ({$product_placeholders})";
                    $query_params = array_merge($query_params, $product_ids);
                }
                break;
            
            case 'type':
                // 搜索举报类型
                // 从设置中获取举报类型
                $report_types = xk_auth('report_types', array(
                    array('key' => 'piracy', 'label' => '盗版使用'),
                    array('key' => 'unauthorized', 'label' => '未授权使用'),
                    array('key' => 'fake', 'label' => '假冒产品'),
                    array('key' => 'other', 'label' => '其他问题')
                ));
                
                // 查找匹配的类型key
                $matching_keys = array();
                foreach ($report_types as $type) {
                    if (isset($type['key']) && isset($type['label'])) {
                        // 同时匹配key和label
                        if (stripos($type['key'], $search_keyword) !== false || stripos($type['label'], $search_keyword) !== false) {
                            $matching_keys[] = $type['key'];
                        }
                    }
                }
                
                // 如果有匹配的key，使用IN查询
                if (!empty($matching_keys)) {
                    $placeholders = implode(',', array_fill(0, count($matching_keys), '%s'));
                    $where_clauses[] = "report_type IN ({$placeholders})";
                    $query_params = array_merge($query_params, $matching_keys);
                }
                break;
        }
    }
    
    // 构建WHERE子句
    $where_sql = '';
    if (!empty($where_clauses)) {
        $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
    }
    
    // 辅助函数：获取产品名
    function get_product_name_from_settings_report($product_id) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id_temp = intval($product['product_id']);
                    $product_list[$product_id_temp] = sanitize_text_field($product['product_name']);
                }
            }
        }
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
    
    // 辅助函数：获取用户名
    function get_username_by_id_report($user_id) {
        $user_data = get_userdata($user_id);
        return $user_data ? $user_data->display_name . " (ID:{$user_id})" : "用户ID:{$user_id}";
    }
    
    // 辅助函数：获取举报类型文本
    function get_report_type_text($type) {
        // 从设置中获取举报类型
        $report_types = xk_auth('report_types', array(
            array('key' => 'piracy', 'label' => '盗版使用'),
            array('key' => 'unauthorized', 'label' => '未授权使用'),
            array('key' => 'fake', 'label' => '假冒产品'),
            array('key' => 'other', 'label' => '其他问题')
        ));
        
        // 查找对应的类型名称
        foreach ($report_types as $report_type) {
            if (isset($report_type['key']) && $report_type['key'] == $type) {
                return isset($report_type['label']) ? $report_type['label'] : $type;
            }
        }
        
        return $type;
    }
    
    // 辅助函数：获取状态文本和样式
    function get_report_status_info($status) {
        $status_map = array(
            'pending' => array('text' => '待处理', 'class' => 'warning'),
            'processed' => array('text' => '已处理', 'class' => 'success'),
            'rejected' => array('text' => '已拒绝', 'class' => 'danger')
        );
        return isset($status_map[$status]) ? $status_map[$status] : array('text' => '未知状态', 'class' => 'info');
    }
    
    // 获取总记录数
    $count_query = "SELECT COUNT(*) FROM {$table_name} {$where_sql}";
    if (!empty($query_params)) {
        $all_count = intval($wpdb->get_var($wpdb->prepare($count_query, $query_params)));
    } else {
        $all_count = intval($wpdb->get_var($count_query));
    }
    $total_pages = ceil($all_count / $per_page);
    
    // 查询举报数据
    $query = "SELECT * FROM {$table_name} {$where_sql} ORDER BY id DESC LIMIT %d, %d";
    $query_params[] = $offset;
    $query_params[] = $per_page;
    
    $reports_list = $wpdb->get_results($wpdb->prepare($query, $query_params));
    
    // 格式化举报数据
    $formatted_reports = array();
    foreach ($reports_list as $report) {
        $status_info = get_report_status_info($report->status);
        $formatted_reports[] = array(
            'id' => $report->id,
            'userId' => $report->user_id,
            'userName' => get_username_by_id_report($report->user_id),
            'productId' => $report->product_id,
            'productName' => get_product_name_from_settings_report($report->product_id),
            'reportType' => get_report_type_text($report->report_type),
            'reportContent' => $report->report_content,
            'reportUrl' => $report->report_url,
            'reportIp' => $report->report_ip,
            'status' => $report->status,
            'statusText' => $status_info['text'],
            'statusClass' => $status_info['class'],
            'adminNote' => $report->admin_note,
            'operationTime' => date('Y-m-d H:i:s', strtotime($report->operation_time)),
            'processTime' => $report->process_time ? date('Y-m-d H:i:s', strtotime($report->process_time)) : ''
        );
    }
    
    // 返回JSON响应
    wp_send_json(array(
        'error' => 0,
        'reportsList' => $formatted_reports,
        'reportsTotal' => $all_count,
        'reportCurrentPage' => $paged,
        'reportTotalPages' => $total_pages
    ));
}
add_action('wp_ajax_xk_auth_ajax_get_reports_list', 'xk_auth_ajax_get_reports_list');

// 更新举报状态AJAX处理
function xk_auth_ajax_update_report_status()
{
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 请求频率限制
        $user_id = get_current_user_id();
        $user_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $cache_key = 'xk_auth_report_update_limit_' . md5($user_id . '_' . $user_ip);
        $last_update_time = wp_cache_get($cache_key, 'xk_auth');
        $current_time = time();
        
        // 限制10秒内只能更新一次
        if ($last_update_time && ($current_time - $last_update_time) < 10) {
            throw new Exception('操作过于频繁，请10秒后再试');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_reports';
        
        // 获取请求参数
        $report_id = isset($_POST['report_id']) ? intval($_POST['report_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        $admin_note = isset($_POST['admin_note']) ? sanitize_textarea_field($_POST['admin_note']) : '';
        
        // 验证参数
        if (!$report_id || !in_array($status, array('pending', 'processed', 'rejected'))) {
            throw new Exception('参数错误');
        }
        
        // 验证管理员备注长度
        if (strlen($admin_note) > 200) {
            throw new Exception('处理备注不能超过200字');
        }
        
        // 获取举报信息
        $report = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $report_id));
        if (!$report) {
            throw new Exception('举报记录不存在');
        }
        
        // 更新举报状态
        $data = array(
            'status' => $status,
            'admin_note' => $admin_note,
            'process_time' => current_time('mysql')
        );
        
        $where = array('id' => $report_id);
        $where_types = array('%d');
        
        $result = $wpdb->update($table_name, $data, $where, array('%s', '%s', '%s'), $where_types);
        
        if ($result !== false) {
            // 检查邮箱通知功能是否开启
            $email_notification = xk_auth('report_email_notification', true);
            if ($email_notification) {
                // 发送邮件通知
                $user = get_userdata($report->user_id);
                if ($user && $user->user_email) {
                    // 获取产品名称
                    $product_name = '';
                    $product_settings = xk_auth('product_settings', array());
                    if (!empty($product_settings) && is_array($product_settings)) {
                        foreach ($product_settings as $product) {
                            if (!empty($product['product_id']) && $product['product_id'] == $report->product_id && !empty($product['product_name'])) {
                                $product_name = sanitize_text_field($product['product_name']);
                                break;
                            }
                        }
                    }
                    if (!$product_name) {
                        $product_name = '产品ID: ' . $report->product_id;
                    }
                    
                    // 获取举报类型
                    $report_type = '';
                    $report_types = xk_auth('report_types', array(
                        array('key' => 'piracy', 'label' => '盗版使用'),
                        array('key' => 'unauthorized', 'label' => '未授权使用'),
                        array('key' => 'fake', 'label' => '假冒产品'),
                        array('key' => 'other', 'label' => '其他问题')
                    ));
                    foreach ($report_types as $type) {
                        if (isset($type['key']) && $type['key'] == $report->report_type && isset($type['label'])) {
                            $report_type = $type['label'];
                            break;
                        }
                    }
                    if (!$report_type) {
                        $report_type = $report->report_type;
                    }
                    
                    // 获取发送者名称
                    $sender_name = xk_auth('report_sender_name', '星空授权');
                    
                    // 生成邮件内容
                    $status_text = '';
                    switch ($status) {
                        case 'processed':
                            $status_text = '已处理';
                            break;
                        case 'rejected':
                            $status_text = '已拒绝';
                            break;
                        default:
                            $status_text = '待处理';
                    }
                    
                    $subject = '【' . $sender_name . '】您的举报已' . $status_text;
                    $message = "尊敬的用户 {$user->display_name}：\n\n";
                    $message .= "您提交的举报已更新状态为：{$status_text}\n\n";
                    $message .= "举报详情：\n";
                    $message .= "产品名称：{$product_name}\n";
                    $message .= "举报类型：{$report_type}\n";
                    $message .= "举报内容：{$report->report_content}\n";
                    if (!empty($report->report_url)) {
                        $message .= "举报链接：{$report->report_url}\n";
                    }
                    if (!empty($admin_note)) {
                        $message .= "处理备注：{$admin_note}\n\n";
                    }
                    $message .= "感谢您对{$sender_name}的支持！\n";
                    $message .= $sender_name . '团队';
                    
                    // 发送邮件
                    $headers = array('Content-Type: text/plain; charset=UTF-8');
                    wp_mail($user->user_email, $subject, $message, $headers);
                }
            }
            
            // 设置更新时间缓存
            wp_cache_set($cache_key, $current_time, 'xk_auth', 10);
            $response = array('error' => 0, 'msg' => '举报状态更新成功');
        } else {
            throw new Exception('更新失败: ' . $wpdb->last_error);
        }
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}
add_action('wp_ajax_xk_auth_ajax_update_report_status', 'xk_auth_ajax_update_report_status');

// 删除举报AJAX处理
function xk_auth_ajax_delete_report()
{
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 请求频率限制
        $user_id = get_current_user_id();
        $user_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $cache_key = 'xk_auth_report_delete_limit_' . md5($user_id . '_' . $user_ip);
        $last_delete_time = wp_cache_get($cache_key, 'xk_auth');
        $current_time = time();
        
        // 限制10秒内只能删除一次
        if ($last_delete_time && ($current_time - $last_delete_time) < 10) {
            throw new Exception('操作过于频繁，请10秒后再试');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_reports';
        
        // 获取请求参数
        $report_id = isset($_POST['report_id']) ? $_POST['report_id'] : 0;
        
        // 验证参数
        if (!$report_id) {
            throw new Exception('参数错误');
        }
        
        // 处理单个ID或ID数组
        $report_ids = is_array($report_id) ? $report_id : array($report_id);
        $report_ids = array_map('intval', $report_ids);
        $report_ids = array_filter($report_ids); // 过滤掉非数字值
        
        if (empty($report_ids)) {
            throw new Exception('参数错误');
        }
        
        // 开始事务
        $wpdb->query('START TRANSACTION');
        
        try {
            // 验证所有举报记录是否存在
            foreach ($report_ids as $id) {
                $report = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id));
                if (!$report) {
                    throw new Exception('举报记录不存在');
                }
            }
            
            // 删除所有举报记录
            $deleted_count = 0;
            foreach ($report_ids as $id) {
                $result = $wpdb->delete(
                    $table_name,
                    array('id' => $id),
                    array('%d')
                );
                if ($result !== false) {
                    $deleted_count++;
                }
            }
            
            // 提交事务
            $wpdb->query('COMMIT');
            
            if ($deleted_count > 0) {
                // 设置删除时间缓存
                wp_cache_set($cache_key, $current_time, 'xk_auth', 10);
                $response = array('error' => 0, 'msg' => '举报记录删除成功');
            } else {
                throw new Exception('删除失败: ' . $wpdb->last_error);
            }
        } catch (Exception $e) {
            // 回滚事务
            $wpdb->query('ROLLBACK');
            throw $e;
        }
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}
add_action('wp_ajax_xk_auth_ajax_delete_report', 'xk_auth_ajax_delete_report');

// 变更授权的模态框AJAX - 不再直接使用，功能已整合到验证码模态框中
// 保留此函数以确保兼容性，但建议使用xk_verify_before_change_auth_modal替代
function add_xk_auth_change_modal()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';
    
    // 直接返回变更授权模态框内容，不再进行单独的验证检查
    // 因为我们现在使用xk_verify_before_change_auth_modal函数进行整合处理
    $modal_content = xk_auth_change_modal($user_id, $product_id);
    echo $modal_content;
    exit;
}
// 保留这个action钩子以确保向后兼容性，但新代码应使用xk_verify_before_change_auth_modal
add_action('wp_ajax_change_auth_modal', 'add_xk_auth_change_modal');

// 显示变更授权前的验证模态框
function xk_verify_before_change_auth_modal()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';
    echo xk_auth_verify_before_change_modal($user_id, $product_id);
    exit;
}
add_action('wp_ajax_xk_verify_before_change_auth', 'xk_verify_before_change_auth_modal');

// 获取授权列表数据
function xk_auth_get_auth_list() {
    // 声明全局变量
    global $wpdb;
    
    // 彻底清除所有之前的输出缓冲区，确保只返回JSON
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // 设置JSON响应头
    header('Content-Type: application/json');
    
    // 验证请求是否为AJAX请求
    if (!wp_doing_ajax()) {
        echo json_encode(array('error' => 1, 'msg' => '非法请求'));
        exit;
    }
    
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');
    
    // 检查权限
    if (!current_user_can('manage_options')) {
        echo json_encode(array('error' => 1, 'msg' => '权限不足'));
        exit;
    }
    
    // 获取请求参数
    $status = isset($_REQUEST['status']) && in_array($_REQUEST['status'], array('0', '1')) ? intval($_REQUEST['status']) : '';
    $search_type = sanitize_text_field($_REQUEST['search_type'] ?? 'user');
    $search_keyword = sanitize_text_field($_REQUEST['s'] ?? '');
    $view_mode = in_array($_REQUEST['view_mode'] ?? '', array('user', 'product')) ? sanitize_text_field($_REQUEST['view_mode']) : 'user';
    $current_page = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 10;
    
    // 获取产品列表并缓存
    $product_list = get_transient('xk_auth_product_list');
    if (false === $product_list) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id = intval($product['product_id']);
                    $product_list[$product_id] = sanitize_text_field($product['product_name']);
                }
            }
        }
        // 设置1小时缓存
        set_transient('xk_auth_product_list', $product_list, 3600);
    }
    
    // 构建查询条件
    $where_clauses = array();
    
    // 状态条件
    if ($status !== '') {
        $where_clauses[] = $wpdb->prepare("status = %d", $status);
    }
    
    // 搜索条件
    if (!empty($search_keyword)) {
        switch ($search_type) {
            case 'user':
                // 搜索用户
                $user_ids = array();
                $users = get_users(array('search' => '*' . esc_attr($search_keyword) . '*'));
                foreach ($users as $user) {
                    $user_ids[] = $user->ID;
                }
                if (!empty($user_ids)) {
                    $where_clauses[] = "user_id IN (" . implode(',', $user_ids) . ")";
                }
                break;
            
            case 'domain':
                // 搜索域名
                $where_clauses[] = $wpdb->prepare('domain LIKE %s', '%' . $search_keyword . '%');
                break;
            
            case 'product':
                // 搜索产品
                $product_ids = array();
                foreach ($product_list as $id => $name) {
                    if (stripos($name, $search_keyword) !== false) {
                        $product_ids[] = $id;
                    }
                }
                if (!empty($product_ids)) {
                    $where_clauses[] = "product_id IN (" . implode(',', $product_ids) . ")";
                }
                break;
        }
    }
        
    $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
    // 初始化数据数组
    $user_groups = array();
    $product_groups = array();
    $all_users_count = 0;
    $all_products_count = 0;
    $total_pages = 0;
    
    // 辅助函数：获取产品名
    function get_product_name_from_settings($product_id, $product_list) {
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
    
    if ($view_mode === 'user') {
        // 按用户分组模式
        // 获取所有用户ID - 用于分页
        $user_ids_query = "
            SELECT DISTINCT user_id FROM {$wpdb->prefix}product_auths
            {$where_sql}
            ORDER BY user_id DESC
        ";
        $user_ids = $wpdb->get_col($user_ids_query);
        $all_users_count = count($user_ids);
    
        // 分页处理
        $total_pages = ceil($all_users_count / $per_page);
        $offset = ($current_page - 1) * $per_page;
    
        // 限制当前页显示的用户
        $current_page_user_ids = array_slice($user_ids, $offset, $per_page);
    
        // 获取每个用户的所有授权记录
        if (!empty($current_page_user_ids)) {
            // 批量获取用户数据，减少get_userdata调用
            $user_data_map = get_users(array('include' => $current_page_user_ids, 'fields' => array('ID', 'display_name')));
            $user_names = array();
            foreach ($user_data_map as $user) {
                $user_names[$user->ID] = $user->display_name;
            }
            
            $user_placeholders = implode(',', array_fill(0, count($current_page_user_ids), '%d'));
            $user_where = $wpdb->prepare("user_id IN ({$user_placeholders})", $current_page_user_ids);
            $all_where_clauses = $where_clauses;
            $all_where_clauses[] = $user_where;
            $final_where = 'WHERE ' . implode(' AND ', $all_where_clauses);
    
            // 查询授权记录
            $auth_list_query = "
                SELECT * FROM {$wpdb->prefix}product_auths
                {$final_where}
                ORDER BY user_id DESC, operation_time DESC
            ";
            $auth_list = $wpdb->get_results($auth_list_query);
    
            // 按用户分组并格式化数据
            $formatted_user_groups = array();
            
            // 获取该用户在各个产品上的授权数量信息
            $user_auth_info = array();
            foreach ($auth_list as $auth) {
                $product_id = $auth->product_id;
                $user_id = $auth->user_id;
                $key = $user_id . '_' . $product_id;
                if (!isset($user_auth_info[$key])) {
                    // 调用函数获取授权数量信息
                    $auth_info = xk_auth_change_transference($user_id, $product_id);
                    $user_auth_info[$key] = array(
                        'total_auths' => $auth_info['total_auths'],
                        'remaining_auths' => $auth_info['remaining_auths']
                    );
                }
            }
            
            foreach ($auth_list as $auth) {
                $user_name = isset($user_names[$auth->user_id]) ? $user_names[$auth->user_id] : '未知用户';
                $product_name = get_product_name_from_settings($auth->product_id, $product_list);
                $expire_time = isset($auth->expire_time) ? $auth->expire_time : '';
                $is_valid_date = $expire_time && $expire_time !== '0000-00-00 00:00:00' && strtotime($expire_time) !== false;
                $is_expired = $is_valid_date && strtotime($expire_time) < time();
                    
                $status_class = $is_expired ? 'warning' : ($auth->status ? 'success' : 'danger');
                $status_text = $is_expired ? '已过期' : ($auth->status ? '正常' : '封禁');
                
                $key = $auth->user_id . '_' . $auth->product_id;
                
                $formatted_auth = array(
                    'id' => $auth->id,
                    'userId' => $auth->user_id,
                    'userName' => $user_name,
                    'productId' => $auth->product_id,
                    'productName' => $product_name,
                    'domain' => $auth->domain,
                    'authKey' => $auth->auth_key,
                    'expireTime' => $is_valid_date ? date('Y-m-d H:i', strtotime($expire_time)) : '永久',
                    'status' => intval($auth->status),
                    'statusClass' => $status_class,
                    'statusText' => $status_text,
                    'operationTime' => date('Y-m-d H:i', strtotime($auth->operation_time)),
                    'totalAuths' => $user_auth_info[$key]['total_auths'],
                    'remainingAuths' => $user_auth_info[$key]['remaining_auths']
                );
                
                // 查找用户组
                $found = false;
                foreach ($formatted_user_groups as &$group) {
                    if ($group['userId'] == $auth->user_id) {
                        $group['auths'][] = $formatted_auth;
                        $found = true;
                        break;
                    }
                }
                
                // 如果没找到，创建新的用户组
                if (!$found) {
                    $formatted_user_groups[] = array(
                        'userId' => $auth->user_id,
                        'userName' => $user_name,
                        'auths' => array($formatted_auth)
                    );
                }
            }
        } else {
            $formatted_user_groups = array();
        }
    } else {
        // 按产品分组模式
        // 获取所有产品ID - 用于分页
        $product_ids_query = "
            SELECT DISTINCT product_id FROM {$wpdb->prefix}product_auths
            {$where_sql}
            ORDER BY product_id DESC
        ";
        $product_ids = $wpdb->get_col($product_ids_query);
        $all_products_count = count($product_ids);
    
        // 分页处理
        $total_pages = ceil($all_products_count / $per_page);
        $offset = ($current_page - 1) * $per_page;
    
        // 限制当前页显示的产品
        $current_page_product_ids = array_slice($product_ids, $offset, $per_page);
    
        // 获取每个产品的所有授权记录
        if (!empty($current_page_product_ids)) {
            $product_placeholders = implode(',', array_fill(0, count($current_page_product_ids), '%d'));
            $product_where = $wpdb->prepare("product_id IN ({$product_placeholders})", $current_page_product_ids);
            $all_where_clauses = $where_clauses;
            $all_where_clauses[] = $product_where;
            $final_where = 'WHERE ' . implode(' AND ', $all_where_clauses);
    
            // 查询授权记录
            $auth_list_query = "
                SELECT * FROM {$wpdb->prefix}product_auths
                {$final_where}
                ORDER BY product_id DESC, user_id DESC, operation_time DESC
            ";
            $auth_list = $wpdb->get_results($auth_list_query);
            
            // 批量获取用户数据，减少get_userdata调用
            $user_ids_in_auths = array();
            foreach ($auth_list as $auth) {
                $user_ids_in_auths[] = $auth->user_id;
            }
            $user_ids_in_auths = array_unique($user_ids_in_auths);
            
            $user_data_map = get_users(array('include' => $user_ids_in_auths, 'fields' => array('ID', 'display_name')));
            $user_names = array();
            foreach ($user_data_map as $user) {
                $user_names[$user->ID] = $user->display_name;
            }
    
            // 按产品分组并格式化数据
            $formatted_product_groups = array();
            
            // 获取该产品下各个用户的授权数量信息
            $user_auth_info = array();
            foreach ($auth_list as $auth) {
                $user_id = $auth->user_id;
                $product_id = $auth->product_id;
                $key = $user_id . '_' . $product_id;
                if (!isset($user_auth_info[$key])) {
                    // 调用函数获取授权数量信息
                    $auth_info = xk_auth_change_transference($user_id, $product_id);
                    $user_auth_info[$key] = array(
                        'total_auths' => $auth_info['total_auths'],
                        'remaining_auths' => $auth_info['remaining_auths']
                    );
                }
            }
            
            foreach ($auth_list as $auth) {
                $user_name = isset($user_names[$auth->user_id]) ? $user_names[$auth->user_id] : '未知用户';
                $product_name = get_product_name_from_settings($auth->product_id, $product_list);
                $expire_time = isset($auth->expire_time) ? $auth->expire_time : '';
                $is_valid_date = $expire_time && $expire_time !== '0000-00-00 00:00:00' && strtotime($expire_time) !== false;
                $is_expired = $is_valid_date && strtotime($expire_time) < time();
                    
                $status_class = $is_expired ? 'warning' : ($auth->status ? 'success' : 'danger');
                $status_text = $is_expired ? '已过期' : ($auth->status ? '正常' : '封禁');
                
                $key = $auth->user_id . '_' . $auth->product_id;
                
                $formatted_auth = array(
                    'id' => $auth->id,
                    'userId' => $auth->user_id,
                    'userName' => $user_name,
                    'productId' => $auth->product_id,
                    'productName' => $product_name,
                    'domain' => $auth->domain,
                    'authKey' => $auth->auth_key,
                    'expireTime' => $is_valid_date ? date('Y-m-d H:i', strtotime($expire_time)) : '永久',
                    'status' => intval($auth->status),
                    'statusClass' => $status_class,
                    'statusText' => $status_text,
                    'operationTime' => date('Y-m-d H:i', strtotime($auth->operation_time)),
                    'totalAuths' => $user_auth_info[$key]['total_auths'],
                    'remainingAuths' => $user_auth_info[$key]['remaining_auths']
                );
                
                // 查找产品组
                $found = false;
                foreach ($formatted_product_groups as &$group) {
                    if ($group['productId'] == $auth->product_id) {
                        $group['auths'][] = $formatted_auth;
                        $found = true;
                        break;
                    }
                }
                
                // 如果没找到，创建新的产品组
                if (!$found) {
                    $formatted_product_groups[] = array(
                        'productId' => $auth->product_id,
                        'productName' => $product_name,
                        'auths' => array($formatted_auth)
                    );
                }
            }
        } else {
            $formatted_product_groups = array();
        }
    }
        
    // 返回JSON响应
    echo json_encode(array(
        'authUserGroups' => isset($formatted_user_groups) ? $formatted_user_groups : array(),
        'authProductGroups' => isset($formatted_product_groups) ? $formatted_product_groups : array(),
        'authTotalCount' => $view_mode === 'user' ? $all_users_count : $all_products_count,
        'authCurrentPage' => $current_page,
        'authTotalPages' => $total_pages,
        'authViewMode' => $view_mode,
        'authSearchType' => $search_type,
        'authSearchKeyword' => $search_keyword,
        'authStatus' => $status
    ));
    exit;
}
add_action('wp_ajax_get_auth_list', 'xk_auth_get_auth_list');

// 发送验证验证码
function xk_send_verify_captcha()
{
    // 设置JSON响应头
    header('Content-Type: application/json');
    
    $user_id = get_current_user_id();
    if (!$user_id) {
        echo json_encode(array('error' => 1, 'msg' => '请先登录'));
        exit;
    }
    
    $contact_type = sanitize_text_field($_POST['contact_type']);
    $contact_value = sanitize_text_field($_POST['contact_value']);
    
    if (empty($contact_type) || empty($contact_value)) {
        echo json_encode(array('error' => 1, 'msg' => '参数错误'));
        exit;
    }
    
    try {
        // 确保session已启动
        if (!session_id()) {
            session_start();
        }
        
        // 清除旧的验证码数据
        unset($_SESSION['xk_verify_captcha']);
        unset($_SESSION['xk_verify_contact']);
        unset($_SESSION['xk_verify_time']);
        
        // 只使用子比主题的验证码系统
        if (function_exists('zib_send_captcha')) {
            // 调用子比主题的验证码发送函数，该函数会处理验证码的生成和发送
            $result = zib_send_captcha($contact_value, $contact_type);
            
            // 保存联系人信息到session，用于验证时使用
            $_SESSION['xk_verify_contact'] = $contact_value;
            $_SESSION['xk_verify_time'] = time();
            
            // 正确处理zib_send_captcha返回的数组
            if (is_array($result)) {
                // 如果子比主题返回的数组中有error字段，根据该字段判断是否成功
                if (isset($result['error']) && $result['error'] === 0) {
                    echo json_encode(array('error' => 0, 'msg' => $result['msg'] ? $result['msg'] : '验证码发送成功，请查收'));
                } else {
                    // 提取错误信息，如果没有则使用默认提示
                    $error_msg = $result['msg'] ? $result['msg'] : '验证码发送失败';
                    echo json_encode(array('error' => 1, 'msg' => $error_msg));
                }
            } else if ($result === true) {
                // 保持向后兼容性，以防函数在某些情况下返回true
                echo json_encode(array('error' => 0, 'msg' => '验证码发送成功，请查收'));
            } else {
                echo json_encode(array('error' => 1, 'msg' => '验证码发送失败'));
            }
        } else {
            // 如果无法调用子比主题的函数，使用自己的验证码发送逻辑
            $captcha = rand(100000, 999999);
            
            // 保存验证码到session
            $_SESSION['xk_verify_captcha'] = $captcha;
            $_SESSION['xk_verify_contact'] = $contact_value;
            $_SESSION['xk_verify_time'] = time();
            
            if ($contact_type == 'email') {
                $subject = '变更授权验证';
                $message = '您的验证码为：' . $captcha . '，有效期10分钟，请尽快使用。';
                $headers = array('Content-Type: text/html; charset=UTF-8');
                
                if (wp_mail($contact_value, $subject, $message, $headers)) {
                    echo json_encode(array('error' => 0, 'msg' => '验证码发送成功，请查收邮件'));
                } else {
                    echo json_encode(array('error' => 1, 'msg' => '邮件发送失败，请检查邮箱配置'));
                }
            } else {
                echo json_encode(array('error' => 1, 'msg' => '暂不支持该验证方式'));
            }
        }
    } catch (Exception $e) {
        error_log('XK Auth: 发送验证码时发生错误: ' . $e->getMessage());
        echo json_encode(array('error' => 1, 'msg' => '发送验证码时发生错误: ' . $e->getMessage()));
    }
    
    exit;
}
add_action('wp_ajax_xk_send_verify_captcha', 'xk_send_verify_captcha');

// 验证验证码
// 调试模式：设置验证通过标志
function xk_set_verify_passed() {
    // 设置JSON响应头
    header('Content-Type: application/json');
    
    $user_id = get_current_user_id();
    if (!$user_id) {
        echo json_encode(array('error' => 1, 'msg' => '请先登录'));
        exit;
    }
    
    // 设置验证通过标志到session
    if (!session_id()) {
        session_start();
    }
    $_SESSION['xk_verify_passed'] = true;
    
    echo json_encode(array('error' => 0, 'msg' => '验证通过标志已设置'));
    exit;
}
add_action('wp_ajax_xk_set_verify_passed', 'xk_set_verify_passed');

function xk_check_verify_captcha()
{
    // 设置JSON响应头
    header('Content-Type: application/json');
    
    $user_id = get_current_user_id();
    if (!$user_id) {
        echo json_encode(array('error' => 1, 'msg' => '请先登录'));
        exit;
    }
    
    $captcha = sanitize_text_field($_POST['captcha']);
    $contact_type = sanitize_text_field($_POST['contact_type']);
    $contact_value = sanitize_text_field($_POST['contact_value']);
    
    if (empty($captcha) || empty($contact_type) || empty($contact_value)) {
        echo json_encode(array('error' => 1, 'msg' => '参数错误'));
        exit;
    }
    
    // 添加调试日志
    // error_log('XK Auth: 验证验证码 - 用户输入的验证码: ' . $captcha);
    // error_log('XK Auth: 验证验证码 - 联系人: ' . $contact_value);
    // error_log('XK Auth: 验证验证码 - 联系人类型: ' . $contact_type);
    
    try {
        // 确保session已启动
        if (!session_id()) {
            session_start();
        }
        
        // 验证码系统
        if (function_exists('zib_is_captcha')) {
            $result = zib_is_captcha($contact_value, $captcha);
            
            // 正确处理zib_is_captcha返回的结果
            if (is_array($result)) {
                if (isset($result['error']) && $result['error'] === 0) {
                    // 验证成功
                    $_SESSION['xk_verify_passed'] = true;
                    
                    // 清除验证码数据
                    unset($_SESSION['xk_verify_contact']);
                    unset($_SESSION['xk_verify_time']);
                    
                    echo json_encode(array('error' => 0, 'msg' => $result['msg'] ? $result['msg'] : '验证成功'));
                    exit;
                } else {
                    // 验证失败
                    // error_log('XK Auth: 子比主题验证码验证失败: ' . ($result['msg'] ? $result['msg'] : '未知错误'));
                    echo json_encode(array('error' => 1, 'msg' => $result['msg'] ? $result['msg'] : '验证码错误或已过期'));
                    exit;
                }
            } else if ($result === true) {
                // 验证成功
                $_SESSION['xk_verify_passed'] = true;
                
                // 清除验证码数据
                unset($_SESSION['xk_verify_contact']);
                unset($_SESSION['xk_verify_time']);
                
                echo json_encode(array('error' => 0, 'msg' => '验证成功'));
                exit;
            } else {
                // 验证失败
                error_log('XK Auth: 子比主题验证码验证失败: 返回值为 ' . var_export($result, true));
                echo json_encode(array('error' => 1, 'msg' => '验证码错误或已过期'));
                exit;
            }
        } else {
            // 如果子比主题的验证码系统不可用，使用自己的session验证
            error_log('XK Auth: 子比主题验证码系统不可用，使用自己的session验证');
            
            if (isset($_SESSION['xk_verify_captcha']) && 
                isset($_SESSION['xk_verify_contact']) && 
                isset($_SESSION['xk_verify_time'])) {
                
                // 检查联系人是否匹配
                if ($_SESSION['xk_verify_contact'] != $contact_value) {
                    //error_log('XK Auth: 联系人不匹配: Session中的联系人是 ' . $_SESSION['xk_verify_contact'] . '，用户输入的是 ' . $contact_value);
                    echo json_encode(array('error' => 1, 'msg' => '验证码错误或已过期'));
                    exit;
                }
                
                // 检查验证码是否匹配
                if ($_SESSION['xk_verify_captcha'] == $captcha) {
                    //error_log('XK Auth: 验证码匹配: Session中的验证码是 ' . $_SESSION['xk_verify_captcha'] . '，用户输入的是 ' . $captcha);
                    
                    // 检查验证码是否过期（10分钟）
                    if (time() - $_SESSION['xk_verify_time'] <= 600) {
                        // 清除验证码
                        unset($_SESSION['xk_verify_captcha']);
                        unset($_SESSION['xk_verify_contact']);
                        unset($_SESSION['xk_verify_time']);
                        
                        // 设置验证通过状态
                        $_SESSION['xk_verify_passed'] = true;
                        
                        echo json_encode(array('error' => 0, 'msg' => '验证成功'));
                    } else {
                        //error_log('XK Auth: 验证码已过期');
                        echo json_encode(array('error' => 1, 'msg' => '验证码已过期，请重新获取'));
                    }
                } else {
                    //error_log('XK Auth: 验证码不匹配: Session中的验证码是 ' . $_SESSION['xk_verify_captcha'] . '，用户输入的是 ' . $captcha);
                    echo json_encode(array('error' => 1, 'msg' => '验证码错误'));
                }
            } else {
                //error_log('XK Auth: Session中没有验证码');
                echo json_encode(array('error' => 1, 'msg' => '请先获取验证码'));
            }
        }
    } catch (Exception $e) {
        //error_log('XK Auth: 验证验证码时发生错误: ' . $e->getMessage());
        echo json_encode(array('error' => 1, 'msg' => '验证时发生错误: ' . $e->getMessage()));
    }
    
    exit;
}
add_action('wp_ajax_xk_check_verify_captcha', 'xk_check_verify_captcha');


// 变更授权域名处理AJAX
function xk_auth_ajax_change()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';

    if (!$user_id) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '权限不足')));
        exit;
    }
    
    // 检查用户是否被限制更换授权
    if (function_exists('xk_auth_check_user_restriction') && xk_auth_check_user_restriction($user_id)) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '您的账号已被限制更换授权，请联系管理员')));
        exit;
    }
    
    // 检查是否开启了验证功能
    $enable_verify = xk_auth('enable_verify', false);
    if ($enable_verify) {
        // 检查验证状态
        if (!session_id()) {
            session_start();
        }
        
        if (!isset($_SESSION['xk_verify_passed']) || !$_SESSION['xk_verify_passed']) {
            echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请先完成安全验证')));
            exit;
        }
        
        // 清除验证状态，防止重复使用
        unset($_SESSION['xk_verify_passed']);
    }

    // 获取授权QQ
    $auth_qq = get_user_meta($user_id, 'auth_qq', true);

    // 初始化授权系统类型为默认值（本地数据库）
    $auth_system_type = '0';

    // 从设置项中获取所有产品配置
    $product_settings = xk_auth('product_settings', array());

    // 遍历产品配置，匹配产品ID并获取对应的授权系统类型
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            // 检查是否存在匹配的产品ID和授权系统类型配置
            if (isset($product['product_id'], $product['auth_system_type']) && $product['product_id'] == $product_id) {
                // 赋值并过滤授权系统类型
                $auth_system_type = (string) sanitize_text_field($product['auth_system_type']);
                break; // 找到匹配项后退出循环
            }
        }
    }

    if (empty($_POST['change_past_domain'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请选择要修改的授权域名')));
        exit();
    }

    if (empty($_POST['change_new_domain'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入新的授权域名')));
        exit();
    }

    // 检查域名或IP地址格式
    if (!preg_match("/^(?:([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}|((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))$/i", $_POST['change_new_domain'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入正确的域名或IP地址'));
        exit();
    }

    // 检查授权域名是否已经存在（修改授权时允许将旧域名替换为同一个新域名）
    if (xk_Auth::is_exists_domaint($user_id, $product_id, $_POST['change_new_domain']) && $_POST['change_past_domain'] != $_POST['change_new_domain']) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '此域名已存在授权')));
        exit();
    }

    if ($auth_system_type == '1') { // 南逸授权系统    
        $nanyi_site_domain = '';
        $nanyi_product_id = '';
        $nanyi_webkey = '';

        // 从设置项中获取所有产品配置
        $product_settings = xk_auth('product_settings', array());

        // 遍历产品配置，匹配产品ID并获取相关配置
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    $nanyi_site_domain = sanitize_text_field($product['nanyi_site_domain']);
                    $nanyi_webkey = sanitize_text_field($product['nanyi_webkey']);
                    $nanyi_product_id = sanitize_text_field($product['nanyi_product_id']);
                    break; // 找到匹配项后退出循环
                }
            }
        }

        // 构建API请求参数数组
        $api_url = add_query_arg([
            'appid' => $nanyi_product_id,
            'webkey' => $nanyi_webkey,
            'qq' => $auth_qq,
            'url' => $_POST['change_past_domain'],
            'new_url' => $_POST['change_new_domain'],
        ], $nanyi_site_domain . 'api/Index/replace_auth');

        // 使用wp_remote_post发起请求，增加超时设置
        $response = wp_remote_post($api_url, ['timeout' => 15]);
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
            $response_body = wp_remote_retrieve_body($response);
            $data = json_decode($response_body, true);

            // 获取响应体并解析为数组
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($data['code']) && $data['code'] === "0") {
                echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '授权更换失败，请联系客服处理'));
                exit();
            }
        }
    }

    // 使用变更授权函数来变更
    xk_auth_change_api($user_id, $product_id, $_POST['change_past_domain'], $_POST['change_new_domain']);

    // 获取当前授权日志信息
    $aut_logs = xk_auth_change_transference('', $product_id);
    
    // 获取用户当前已使用的授权数量
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';
    $used_auths = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE user_id = %d AND product_id = %d",
            $user_id,
            $product_id
        )
    );
    $used_auths = intval($used_auths);
    
    // 计算剩余授权数（总授权数减去已使用的数量）
    $total_auths = $aut_logs['total_auths'];
    $remaining_auths = $total_auths - $used_auths;
    if ($remaining_auths < 0) {
        $remaining_auths = 0;
    }
    
    // 获取当前产品的到期时间
    $auth_log_table = $wpdb->prefix . 'auth_logs';
    $auth_info = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT expire_time FROM $auth_log_table WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
            $user_id, $product_id
        )
    );
    $expire_time = NULL;
    if ($auth_info && $auth_info->expire_time !== NULL) {
        $expire_time = $auth_info->expire_time;
    }
    
    // 执行更新授权日志
    xk_auth_insert_authorization_log($user_id, $product_id, $total_auths, $remaining_auths, '变更域名授权(' . $_POST['change_past_domain'] . '变更为' . $_POST['change_new_domain'] . ')', $expire_time);
    
    // 检查是否启用了授权变更通知
    $auth_change_notify = xk_auth('auth_change_notify', true);
    
    if ($auth_change_notify) {
        // 发送邮箱通知 - 使用子比主题邮件模板
        $user_info = get_userdata($user_id);
        if ($user_info && !empty($user_info->user_email) && !stristr($user_info->user_email, '@no')) {
        $user_name = $user_info->display_name ? $user_info->display_name : $user_info->user_login;
        $site_url = home_url();
        
        // 构建邮件内容 - 符合子比主题邮件格式
        $mail_title = '授权域名变更通知';
        $mail_content = '您好！' . $user_name . '<br>';
        $mail_content .= '您的产品授权域名已成功变更<br>';
        $mail_content .= '<div class="muted-box" style="padding:10px 15px;border-radius:8px;background:rgba(141, 141, 141, 0.05);line-height:1.7;">';
        $mail_content .= '产品ID：' . $product_id . '<br>';
        $mail_content .= '原域名：' . $_POST['change_past_domain'] . '<br>';
        $mail_content .= '新域名：' . $_POST['change_new_domain'] . '<br>';
        $mail_content .= '变更时间：' . date('Y-m-d H:i:s') . '<br>';
        $mail_content .= '</div>';
        $mail_content .= '<br>';
        $mail_content .= '如非您本人操作，请立即联系网站管理员<br>';
        $mail_content .= '<a target="_blank" style="margin-top: 20px" href="' . esc_url($site_url) . '">' . get_bloginfo('name') . '</a><br>';
        
        // 优先使用子比主题的邮件发送函数
        if (function_exists('zib_send_email')) {
            zib_send_email($user_info->user_email, $mail_title, $mail_content);
        } else {
            // 备用方案
            $site_name = get_bloginfo('name');
            $full_title = '[' . $site_name . '] ' . $mail_title;
            @wp_mail($user_info->user_email, $full_title, $mail_content);
        }
        }
    }

    // 清除仪表盘数据缓存，确保下次访问时显示最新数据
    delete_transient('xk_auth_dashboard_data');
    
    // 添加成功后刷新网页
    echo (json_encode(array('error' => 0, 'ys' => '', 'msg' => '授权变更添加成功', 'reload' => true)));
    exit();
}
add_action('wp_ajax_change_auth', 'xk_auth_ajax_change');

// 处理管理员修改授权状态AJAX
function xk_auth_ajax_process()
{
    // 设置JSON响应头
    header('Content-Type: application/json');

    // 初始化响应数据
    $response = array(
        'error' => 1,
        'ys' => 'danger',
        'msg' => '未知错误',
        'reload' => false
    );

    try {
        // 验证权限
        $user_id = get_current_user_id();
        if (!$user_id || !current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }

        // 验证参数
        $auth_id = !empty($_POST['auth_id']) ? intval($_POST['auth_id']) : 0;
        $new_status = !empty($_POST['status']) ? intval($_POST['status']) : 0;
        $log = !empty($_POST['log']) ? sanitize_text_field($_POST['log']) : '';

        if (empty($auth_id)) {
            throw new Exception('授权记录ID不能为空');
        }

        if (empty($log)) {
            throw new Exception('请输入处理备注');
        }

        // 验证授权记录存在
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        $auth_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $auth_id
        ));

        if (empty($auth_data)) {
            throw new Exception('授权记录不存在');
        }

        $product_id = $auth_data->product_id;
        global $wpdb;
        $table_name_1 = $wpdb->prefix . 'auth_logs';
        $auth_data_1 = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name_1} WHERE product_id = %d 
         ORDER BY id DESC
         LIMIT 1",
                $product_id
            )
        );
        $total_auths = $auth_data_1->total_auths;
        $remaining_auths = $auth_data_1->remaining_auths;

        // 初始化授权系统类型为默认值（本地数据库）
        $auth_system_type = '0';

        // 从设置项中获取所有产品配置
        $product_settings = xk_auth('product_settings', array());

        // 遍历产品配置，匹配产品ID并获取对应的授权系统类型
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                // 检查是否存在匹配的产品ID和授权系统类型配置
                if (isset($product['product_id'], $product['auth_system_type']) && $product['product_id'] == $product_id) {
                    // 赋值并过滤授权系统类型
                    $auth_system_type = (string) sanitize_text_field($product['auth_system_type']);
                    break; // 找到匹配项后退出循环
                }
            }
        }
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';

        // 获取指定auth_id的记录并提取domain
        $domain = $wpdb->get_var($wpdb->prepare(
            "SELECT domain FROM {$table_name} WHERE id = %d",
            $auth_id
        ));

        if ($auth_system_type == '1') { // 南逸授权系统    
            $nanyi_site_domain = '';
            $nanyi_product_id = '';
            $nanyi_webkey = '';

            // 从设置项中获取所有产品配置
            $product_settings = xk_auth('product_settings', array());

            // 遍历产品配置，匹配产品ID并获取相关配置
            if (!empty($product_settings) && is_array($product_settings)) {
                foreach ($product_settings as $product) {
                    if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                        $nanyi_site_domain = sanitize_text_field($product['nanyi_site_domain']);
                        $nanyi_webkey = sanitize_text_field($product['nanyi_webkey']);
                        $nanyi_product_id = sanitize_text_field($product['nanyi_product_id']);
                        break; // 找到匹配项后退出循环
                    }
                }
            }

            if ($new_status == '0') {
                // 构建API请求参数数组
                $api_url = add_query_arg([
                    'appid' => $nanyi_product_id,
                    'url' => $domain,
                    'reason' => $log,
                    'webkey' => $nanyi_webkey,
                ], $nanyi_site_domain . 'api/Index/freeze_auth');

                // 使用wp_remote_post发起请求，增加超时设置
                $response = wp_remote_post($api_url, ['timeout' => 15]);
                if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);

                    // 获取响应体并解析为数组
                    $data = json_decode(wp_remote_retrieve_body($response), true);
                    if (isset($data['code']) && $data['code'] === "0") {
                        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '授权封禁失败'));
                        exit();
                    }
                }
            } else {
                // 构建API请求参数数组
                $api_url = add_query_arg([
                    'appid' => $nanyi_product_id,
                    'url' => $domain,
                    'webkey' => $nanyi_webkey,
                ], $nanyi_site_domain . 'api/Index/unseal_auth');

                // 使用wp_remote_post发起请求，增加超时设置
                $response = wp_remote_post($api_url, ['timeout' => 15]);
                if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);

                    // 获取响应体并解析为数组
                    $data = json_decode(wp_remote_retrieve_body($response), true);
                    if (isset($data['code']) && $data['code'] === "0") {
                        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '授权解禁失败'));
                        exit();
                    }
                }
            }
        }

        // 执行数据库更新
        xk_auth_insert_authorization_log($user_id, $product_id, $total_auths, $remaining_auths, $log);
        $result = $wpdb->update(
            $table_name,
            array(
                'status' => $new_status,
                'operation_time' => current_time('mysql'),
                'log' => $log
            ),
            array('id' => $auth_id),
            array('%d', '%s', '%s')
        );

        if ($result === false) {
            throw new Exception('数据库更新失败：' . $wpdb->last_error);
        }

        // 更新成功
        $response = array(
            'error' => 0,
            'ys' => 'success',
            'msg' => '授权状态更新成功',
            'reload' => true
        );
    } catch (Exception $e) {
        // 捕获异常并返回错误信息
        $response['msg'] = $e->getMessage();
    }

    // 返回JSON响应
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_process_auth', 'xk_auth_ajax_process');

// 获取授权信息AJAX
function defaultYmAuthAjaxGetAuthInfo()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');

    try {
        $user_id = get_current_user_id();
        if (!$user_id || !current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }

        $auth_id = !empty($_POST['auth_id']) ? intval($_POST['auth_id']) : 0;
        if (empty($auth_id))
            throw new Exception('授权记录ID不能为空');

        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        $auth_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $auth_id
        ));

        if (empty($auth_data))
            throw new Exception('授权记录不存在');

        // 获取产品信息
        $product_list = array();
        $product_settings = xk_auth('product_settings', array());
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_list[$product['product_id']] = $product['product_name'];
                }
            }
        }

        // 获取用户信息
        $user_info = get_userdata($auth_data->user_id);
        $user_name = $user_info ? $user_info->display_name : '未知用户';

        $response = array(
            'error' => 0,
            'msg' => '获取成功',
            'auth' => array(
                'user_name' => $user_name,
                'product_name' => isset($product_list[$auth_data->product_id]) ? $product_list[$auth_data->product_id] : '未知产品',
                'domain' => $auth_data->domain,
                'auth_key' => $auth_data->auth_key,
                'status' => $auth_data->status,
                'operation_time' => $auth_data->operation_time
            )
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_get_auth_info', 'defaultYmAuthAjaxGetAuthInfo');

// 删除授权域名AJAX
function defaultYmAuthAjaxDeleteAuthDomain()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'ys' => 'danger', 'msg' => '未知错误', 'reload' => false);

    try {
        $user_id = get_current_user_id();
        if (!$user_id || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法删除域名');
        }

        $auth_id = !empty($_POST['auth_id']) ? intval($_POST['auth_id']) : 0;
        if (empty($auth_id))
            throw new Exception('授权记录ID不能为空');

        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        $auth_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $auth_id
        ));

        if (empty($auth_data))
            throw new Exception('授权记录不存在');

        // 删除授权记录
        $result = $wpdb->delete(
            $table_name,
            array('id' => $auth_id),
            array('%d')
        );
        
        // 获取当前用户对该产品的总授权数
        $table_name_1 = $wpdb->prefix . 'auth_logs';
        $latest_log = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT total_auths FROM {$table_name_1} WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
                $auth_data->user_id, // 使用域名所属用户ID
                $auth_data->product_id
            )
        );
        
        // 获取用户当前已使用的授权数量
        $used_auths = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_name} WHERE user_id = %d AND product_id = %d",
                $auth_data->user_id, // 使用域名所属用户ID
                $auth_data->product_id
            )
        );
        $used_auths = intval($used_auths);
        
        // 计算剩余授权数（总授权数减去已使用的数量）
        $total_auths = $latest_log ? intval($latest_log->total_auths) : 0;
        $remaining_auths = $total_auths - $used_auths;
        if ($remaining_auths < 0) {
            $remaining_auths = 0;
        }
        
        // 记录删除日志并更新授权数量
        xk_auth_insert_authorization_log(
            $auth_data->user_id, // 使用域名所属用户ID
            $auth_data->product_id,
            $total_auths, // 保持总授权数不变
            $remaining_auths, // 更新剩余授权数
            '管理员删除域名授权(' . $auth_data->domain . ')'
        );

        if ($result === false)
            throw new Exception('数据库删除失败：' . $wpdb->last_error);

        delete_transient('xk_auth_dashboard_data');
        
        $response = array(
            'error' => 0,
            'ys' => 'success',
            'msg' => '授权域名删除成功',
            'reload' => true
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_delete_auth_domain', 'defaultYmAuthAjaxDeleteAuthDomain');

// 处理管理员修改授权域名AJAX
function xk_auth_ajax_update_domain()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'ys' => 'danger', 'msg' => '未知错误', 'reload' => false);

    try {
        $user_id = get_current_user_id();
        if (!$user_id || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法修改域名');
        }

        $auth_id = !empty($_POST['auth_id']) ? intval($_POST['auth_id']) : 0;
        $new_domain = !empty($_POST['new_domain']) ? sanitize_text_field($_POST['new_domain']) : '';

        if (empty($auth_id))
            throw new Exception('授权记录ID不能为空');
        if (empty($new_domain))
            throw new Exception('请输入新域名');

        // 支持域名和IP地址的正则表达式
        if (!preg_match("/^(?:([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}|((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))$/i", $new_domain)) {
            throw new Exception('请输入有效的域名或IP地址（不带http://或https://）');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        $auth_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $auth_id
        ));

        if (empty($auth_data))
            throw new Exception('授权记录不存在');

        // 检查域名是否已被同一产品下的其他授权使用
        $domain_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE domain = %s AND id != %d AND product_id = %d",
            $new_domain,
            $auth_id,
            $auth_data->product_id
        ));
        if ($domain_exists)
            throw new Exception('该域名已被同一产品下的其他授权使用，请更换域名');
        
        // 检查域名是否与当前授权的旧域名相同（允许将域名修改为自身）
        if ($new_domain == $auth_data->domain) {
            // 域名未改变，直接允许
            return true;
        }

        $product_id = $auth_data->product_id;
        global $wpdb;
        $table_name_1 = $wpdb->prefix . 'auth_logs';
        $auth_data_1 = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name_1} WHERE product_id = %d 
         ORDER BY id DESC
         LIMIT 1",
                $product_id
            )
        );

        $total_auths = $auth_data_1->total_auths;
        
        // 获取用户当前已使用的授权数量
        $used_auths = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_name} WHERE user_id = %d AND product_id = %d",
                $auth_data->user_id, // 使用域名所属用户ID
                $auth_data->product_id
            )
        );
        $used_auths = intval($used_auths);
        
        // 计算剩余授权数（总授权数减去已使用的数量）
        $remaining_auths = $total_auths - $used_auths;
        if ($remaining_auths < 0) {
            $remaining_auths = 0;
        }

        // 获取授权QQ
        $auth_qq = get_user_meta($auth_data->user_id, 'auth_qq', true);

        // 初始化授权系统类型为默认值（本地数据库）
        $auth_system_type = '0';

        // 从设置项中获取所有产品配置
        $product_settings = xk_auth('product_settings', array());

        // 遍历产品配置，匹配产品ID并获取对应的授权系统类型
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                // 检查是否存在匹配的产品ID和授权系统类型配置
                if (isset($product['product_id'], $product['auth_system_type']) && $product['product_id'] == $product_id) {
                    // 赋值并过滤授权系统类型
                    $auth_system_type = (string) sanitize_text_field($product['auth_system_type']);
                    break; // 找到匹配项后退出循环
                }
            }
        }

        if ($auth_system_type == '1') { // 南逸授权系统    
            $nanyi_site_domain = '';
            $nanyi_product_id = '';
            $nanyi_webkey = '';

            // 从设置项中获取所有产品配置
            $product_settings = xk_auth('product_settings', array());

            // 遍历产品配置，匹配产品ID并获取相关配置
            if (!empty($product_settings) && is_array($product_settings)) {
                foreach ($product_settings as $product) {
                    if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                        $nanyi_site_domain = sanitize_text_field($product['nanyi_site_domain']);
                        $nanyi_webkey = sanitize_text_field($product['nanyi_webkey']);
                        $nanyi_product_id = sanitize_text_field($product['nanyi_product_id']);
                        break; // 找到匹配项后退出循环
                    }
                }
            }

            // 构建API请求参数数组
            $api_url = add_query_arg([
                'appid' => $nanyi_product_id,
                'webkey' => $nanyi_webkey,
                'qq' => $auth_qq,
                'url' => $auth_data->domain,
                'new_url' => $new_domain,
            ], $nanyi_site_domain . 'api/Index/replace_auth');

            // 使用wp_remote_post发起请求，增加超时设置
            $response = wp_remote_post($api_url, ['timeout' => 15]);
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
                $response_body = wp_remote_retrieve_body($response);
                $data = json_decode($response_body, true);

                // 获取响应体并解析为数组
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['code']) && $data['code'] === "0") {
                    echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '授权更换失败'));
                    exit();
                }
            }
        }

        // 记录变更日志，使用域名所属用户的ID
        xk_auth_insert_authorization_log(
            $auth_data->user_id, // 使用域名所属用户ID
            $auth_data->product_id,
            $total_auths,
            $remaining_auths,
            '管理员变更域名授权(' . $auth_data->domain . '变更为' . $new_domain . ')'
        );

        $result = $wpdb->update(
            $table_name,
            array(
                'domain' => $new_domain,
                'operation_time' => current_time('mysql'),
                'log' => "管理员变更域名授权({$auth_data->domain}变更为{$new_domain})"
            ),
            array('id' => $auth_id),
            array('%s', '%s', '%s'),
            array('%d')
        );
        if ($result === false)
            throw new Exception('数据库更新失败：' . $wpdb->last_error);

        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        $response = array(
            'error' => 0,
            'ys' => 'success',
            'msg' => '授权域名修改成功',
            'reload' => true
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_update_auth_domain', 'xk_auth_ajax_update_domain');



// 用户导入产品订单AJAX
function xk_auth_ajax_import_order()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';

    if (!$user_id) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '权限不足')));
        exit;
    }

    if (!$product_id) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请选择产品管理')));
        exit;
    }

    if (empty($_POST['auth_exchange_key'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入授权码')));
        exit();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    $auth_key = $_POST['auth_exchange_key'];
    $auth_data = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table_name} 
         WHERE product_id = %d 
         AND user_id = %d 
         AND auth_key = %s",
            $product_id,
            $user_id,
            $auth_key
        )
    );

    if (empty($auth_data)) {
        echo wp_send_json(array('error_type' => 'error', 'ys' => 'danger', 'reload' => false, 'msg' => '授权信息导入失败'));
        exit;
    } else {
        $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);
        $post_id = $product_id; // 本地购买订单的页面ID
        $pay_price = $pay_mate['pay_price'];
        $pay_time = current_time('Y-m-d H:i:s');
        // 准备订单数据
        $order_obj = array(
            'id' => '',
            'user_id' => $user_id,
            'ip_address' => '',
            'product_id' => '',
            'post_id' => $post_id,
            'post_author' => '',
            'income_price' => 0.00,
            'income_status' => '',
            'income_detail' => '',
            'order_num' => '',
            'order_price' => $pay_price,
            'order_type' => 15,
            'create_time' => '',
            'pay_num' => '',
            'pay_type' => 'balance',
            'pay_price' => $pay_price,
            'pay_detail' => '',
            'pay_time' => $pay_time,
            'status' => 1,
            'other' => '',
            'referrer_id' => 0,
            'rebate_price' => 0.00,
            'rebate_status' => '',
            'rebate_detail' => '',
        );

        // 创建本地新订单
        $order = ZibPay::add_order($order_obj);

        if (empty($order['order_num'])) {
            echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '订单创建失败'));
            exit();
        }

        // 获取插件配置中的产品设置
        $product_settings = xk_auth('product_settings', array());
        $auth_count = null; // 初始化为空，用于判断是否找到配置

        // 遍历配置中的产品，匹配当前产品ID（页面ID）
        if (!empty($product_settings)) {
            foreach ($product_settings as $product) {
                // 产品ID与页面ID一致，匹配成功
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    // 从配置中获取授权个数（转为整数）
                    $auth_count = intval($product['auth_count']);
                    break;
                }
            }
        }
        $auth_counts = $auth_count - 1;
        // 插入授权日志
        xk_auth_insert_authorization_log(
            $user_id,
            $product_id,
            $auth_count, // 总授权数
            $auth_counts, // 剩余授权数
            "用户导入授权获得额度"
        );
        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        // 添加成功后刷新网页
        echo (json_encode(array('error' => 0, 'ys' => '', 'msg' => '授权信息导入成功', 'reload' => true)));
        exit();
    }
}
add_action('wp_ajax_import_order', 'xk_auth_ajax_import_order');

// 管理员搜索用户AJAX
function xk_auth_ajax_search_user()
{
    check_ajax_referer('add_auth_nonce', 'security');

    $username = sanitize_text_field($_POST['username']);
    if (empty($username)) {
        wp_send_json_error(['msg' => '请输入用户名']);
    }

    $user = get_user_by('login', $username);
    if (!$user) {
        $user = get_user_by('email', $username);
    }
}
add_action('wp_ajax_search_user', 'xk_auth_ajax_search_user');

// 获取优惠码列表AJAX处理
function xk_auth_ajax_get_promo_codes() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误', 'promoCodes' => array(), 'promoTotalCount' => 0);
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        check_ajax_referer('xk_auth_nonce', 'security');
        
        // 检查权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_promo_codes';
        
        // 分页与排序
        $per_page = isset($_REQUEST['per_page']) ? intval($_REQUEST['per_page']) : 10;
        $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;
        
        // 构建查询条件
        $where_clauses = array();
        $query_params = array();
        
        // 关键词搜索
        $code = isset($_REQUEST['code']) ? sanitize_text_field($_REQUEST['code']) : '';
        if (!empty($code)) {
            $where_clauses[] = "code LIKE %s";
            $query_params[] = '%' . $code . '%';
        }
        
        // 状态筛选
        $status = isset($_REQUEST['status']) ? sanitize_text_field($_REQUEST['status']) : '';
        if (!empty($status)) {
            $where_clauses[] = "status = %s";
            $query_params[] = $status;
        }
        
        // 构建WHERE子句
        $where_sql = '';
        if (!empty($where_clauses)) {
            $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);
        }
        
        // 获取总记录数
        $count_query = "SELECT COUNT(*) FROM {$table_name} {$where_sql}";
        if (!empty($query_params)) {
            $total_count = intval($wpdb->get_var($wpdb->prepare($count_query, $query_params)));
        } else {
            $total_count = intval($wpdb->get_var($count_query));
        }
        $total_pages = ceil($total_count / $per_page);
        
        // 查询优惠码数据
        $query_params[] = $offset;
        $query_params[] = $per_page;
        
        $promo_codes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} {$where_sql} ORDER BY id DESC LIMIT %d, %d",
            $query_params
        ));
        
        // 格式化优惠码数据
        $formatted_promo_codes = array();
        foreach ($promo_codes as $promo) {
            $formatted_promo_codes[] = array(
                'id' => $promo->id,
                'name' => sanitize_text_field($promo->name),
                'code' => sanitize_text_field($promo->code),
                'type' => sanitize_text_field($promo->type),
                'value' => floatval($promo->value),
                'min_amount' => floatval($promo->min_amount),
                'max_discount' => $promo->max_discount ? floatval($promo->max_discount) : null,
                'usage_limit' => $promo->usage_limit ? intval($promo->usage_limit) : null,
                'usage_count' => intval($promo->usage_count),
                'product_ids' => sanitize_text_field($promo->product_ids),
                'user_ids' => sanitize_text_field($promo->user_ids),
                'start_time' => $promo->start_time ? $promo->start_time : null,
                'end_time' => $promo->end_time ? $promo->end_time : null,
                'status' => sanitize_text_field($promo->status),
                'description' => sanitize_textarea_field($promo->description),
                'create_time' => $promo->create_time,
                'update_time' => $promo->update_time
            );
        }
        
        $response = array(
            'error' => 0,
            'msg' => '获取优惠码列表成功',
            'promoCodes' => $formatted_promo_codes,
            'promoTotalCount' => $total_count,
            'promoCurrentPage' => intval($paged),
            'promoTotalPages' => intval($total_pages)
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_get_promo_codes', 'xk_auth_ajax_get_promo_codes');

// 保存优惠码AJAX处理
function xk_auth_ajax_save_promo_code() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        check_ajax_referer('xk_auth_nonce', 'security');
        
        // 检查权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_promo_codes';
        
        // 获取表单数据
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $code = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';
        $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'fixed';
        $value = isset($_POST['value']) ? floatval($_POST['value']) : 0;
        $min_amount = isset($_POST['min_amount']) ? floatval($_POST['min_amount']) : 0;
        $max_discount = isset($_POST['max_discount']) ? (empty($_POST['max_discount']) ? 999 : floatval($_POST['max_discount'])) : 999;
        $usage_limit = isset($_POST['usage_limit']) ? (empty($_POST['usage_limit']) ? null : intval($_POST['usage_limit'])) : null;
        $product_ids = isset($_POST['product_ids']) ? sanitize_text_field($_POST['product_ids']) : '';
        $user_ids = isset($_POST['user_ids']) ? sanitize_text_field($_POST['user_ids']) : '';
        
        // 处理开始时间和结束时间
        $current_time = current_time('mysql');
        
        // 获取并清理开始时间
        $raw_start_time = isset($_POST['start_time']) ? $_POST['start_time'] : '';
        $start_time = (trim($raw_start_time) !== '' && $raw_start_time !== 'null') ? sanitize_text_field($raw_start_time) : $current_time;
        
        // 获取并清理结束时间
        $raw_end_time = isset($_POST['end_time']) ? $_POST['end_time'] : '';
        $end_time = (trim($raw_end_time) !== '' && $raw_end_time !== 'null') ? sanitize_text_field($raw_end_time) : date('Y-m-d H:i:s', strtotime('+10 years', strtotime($current_time)));
        
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'active';
        $description = isset($_POST['description']) ? sanitize_textarea_field($_POST['description']) : '';
        
        // 如果优惠码为空，则生成随机优惠码
        if (empty($code)) {
            // 生成8位随机字符串，仅包含大写字母和数字
            $code = strtoupper(wp_generate_password(8, false, false));
            
            // 确保生成的优惠码唯一
            $max_attempts = 10;
            $attempt = 0;
            while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_name} WHERE code = %s", $code)) && $attempt < $max_attempts) {
                $code = strtoupper(wp_generate_password(8, false, false));
                $attempt++;
            }
        }
        
        // 验证必填字段
        if (empty($name) || empty($code) || empty($type) || $value <= 0) {
            throw new Exception('请填写完整的优惠码信息');
        }
        
        // 验证优惠码名称
        if (mb_strlen($name) < 2 || mb_strlen($name) > 50) {
            throw new Exception('优惠码名称长度必须在2到50个字符之间');
        }
        
        // 验证优惠码
        if (mb_strlen($code) < 3 || mb_strlen($code) > 20) {
            throw new Exception('优惠码长度必须在3到20个字符之间');
        }
        if (!preg_match('/^[a-zA-Z0-9]+$/', $code)) {
            throw new Exception('优惠码只能包含英文和数字');
        }
        
        // 验证优惠类型
        if (!in_array($type, array('fixed', 'percentage'))) {
            throw new Exception('无效的优惠类型');
        }
        
        // 验证优惠值
        if ($value <= 0 || $value > 9999.99) {
            throw new Exception('优惠值必须在0.01到9999.99之间');
        }
        
        // 验证最低消费金额
        if ($min_amount < 0 || $min_amount > 99999.99) {
            throw new Exception('最低消费金额必须在0到99999.99之间');
        }
        
        // 验证最大优惠金额
        if ($max_discount < 0 || $max_discount > 9999.99) {
            throw new Exception('最大优惠金额必须在0到9999.99之间');
        }
        
        // 验证使用次数限制
        if ($usage_limit !== null && $usage_limit < 0) {
            throw new Exception('使用次数限制必须大于等于0');
        }
        
        // 验证状态
        if (!in_array($status, array('active', 'inactive'))) {
            throw new Exception('无效的状态');
        }
        
        // 验证产品ID和用户ID格式
        if (!empty($product_ids)) {
            $product_id_array = explode(',', $product_ids);
            foreach ($product_id_array as $pid) {
                if (!is_numeric($pid) || $pid <= 0) {
                    throw new Exception('产品ID必须为正整数');
                }
            }
        }
        if (!empty($user_ids)) {
            $user_id_array = explode(',', $user_ids);
            foreach ($user_id_array as $uid) {
                if (!is_numeric($uid) || $uid <= 0) {
                    throw new Exception('用户ID必须为正整数');
                }
            }
        }
        
        // 检查优惠码是否已存在（编辑时排除自身）
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE code = %s" . ($id ? " AND id != %d" : ""),
            $code, $id
        ));
        if ($existing) {
            throw new Exception('该优惠码已存在');
        }
        
        $current_time = current_time('mysql');
        
        if ($id > 0) {
            // 更新优惠码
            $result = $wpdb->update(
                $table_name,
                array(
                    'name' => $name,
                    'code' => $code,
                    'type' => $type,
                    'value' => $value,
                    'min_amount' => $min_amount,
                    'max_discount' => $max_discount,
                    'usage_limit' => $usage_limit,
                    'product_ids' => $product_ids,
                    'user_ids' => $user_ids,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'status' => $status,
                    'description' => $description,
                    'update_time' => $current_time
                ),
                array('id' => $id),
                array(
                    '%s', '%s', '%s', '%f', '%f', '%s', '%s',
                    '%s', '%s', '%s', '%s', '%s', '%s', '%s'
                ),
                array('%d')
            );
        } else {
            // 添加优惠码
            $result = $wpdb->insert(
                $table_name,
                array(
                    'name' => $name,
                    'code' => $code,
                    'type' => $type,
                    'value' => $value,
                    'min_amount' => $min_amount,
                    'max_discount' => $max_discount,
                    'usage_limit' => $usage_limit,
                    'product_ids' => $product_ids,
                    'user_ids' => $user_ids,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'status' => $status,
                    'description' => $description,
                    'create_time' => $current_time,
                    'update_time' => $current_time
                ),
                array(
                    '%s', '%s', '%s', '%f', '%f', '%s', '%s',
                    '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'
                )
            );
        }
        
        if ($result === false) {
            throw new Exception('保存失败：' . $wpdb->last_error);
        }
        
        $response = array('error' => 0, 'msg' => '保存成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_save_promo_code', 'xk_auth_ajax_save_promo_code');

// 删除优惠码AJAX处理
function xk_auth_ajax_delete_promo_code() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        check_ajax_referer('xk_auth_nonce', 'security');
        
        // 检查权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_promo_codes';
        
        // 获取ID
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) {
            throw new Exception('参数错误');
        }
        
        // 删除优惠码
        $result = $wpdb->delete(
            $table_name,
            array('id' => $id),
            array('%d')
        );
        
        if ($result === false) {
            throw new Exception('删除失败：' . $wpdb->last_error);
        }
        
        $response = array('error' => 0, 'msg' => '删除成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_delete_promo_code', 'xk_auth_ajax_delete_promo_code');

// 验证优惠码AJAX处理
function xk_auth_ajax_validate_promo_code() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 暂时移除nonce验证，以支持未登录用户使用优惠码功能
        // check_ajax_referer('xk_auth_nonce', 'security');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'auth_promo_codes';
        
        // 获取参数
        $code = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';
        $amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $user_id = get_current_user_id();
        
        if (empty($code)) {
            throw new Exception('请输入优惠码');
        }
        
        // 查询优惠码
        $promo_code = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE code = %s AND status = 'active'",
            $code
        ));
        
        if (!$promo_code) {
            throw new Exception('优惠码无效或已过期');
        }
        
        // 检查使用次数限制
        if ($promo_code->usage_limit && $promo_code->usage_count >= $promo_code->usage_limit) {
            throw new Exception('优惠码已达到使用次数限制');
        }
        
        // 检查时间限制
        $current_time = current_time('mysql');
        if ($promo_code->start_time && $promo_code->start_time > $current_time) {
            throw new Exception('优惠码尚未生效');
        }
        if ($promo_code->end_time && $promo_code->end_time < $current_time) {
            throw new Exception('优惠码已过期');
        }
        
        // 检查最低消费
        if ($amount < $promo_code->min_amount) {
            throw new Exception('消费金额未达到最低使用标准');
        }
        
        // 检查适用产品
        if (!empty($promo_code->product_ids)) {
            $product_ids = array_map('intval', explode(',', $promo_code->product_ids));
            if (!in_array($product_id, $product_ids)) {
                throw new Exception('该优惠码不适用于此产品');
            }
        }
        
        // 检查适用用户
        if (!empty($promo_code->user_ids)) {
            $user_ids = array_map('intval', explode(',', $promo_code->user_ids));
            if (!in_array($user_id, $user_ids)) {
                throw new Exception('该优惠码仅适用于特定用户');
            }
        }
        
        // 计算优惠金额
        $discount = 0;
        if ($promo_code->type == 'fixed') {
            $discount = $promo_code->value;
        } else {
            $discount = $amount * ($promo_code->value / 100);
        }
        
        // 应用最大优惠限制
        if ($promo_code->max_discount && $discount > $promo_code->max_discount) {
            $discount = $promo_code->max_discount;
        }
        
        // 确保优惠金额不超过订单金额
        // 只有当优惠码类型为百分比时，才需要这个限制
        // 对于固定金额优惠码，只要订单金额达到最低消费，就应该使用完整的优惠值
        if ($promo_code->type === 'percentage') {
            $discount = min($discount, $amount);
        }
        
        $response = array(
            'error' => 0,
            'msg' => '优惠码验证成功',
            'discount' => $discount,
            'type' => $promo_code->type,
            'value' => $promo_code->value
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_validate_promo_code', 'xk_auth_ajax_validate_promo_code');
add_action('wp_ajax_nopriv_validate_promo_code', 'xk_auth_ajax_validate_promo_code');



// 管理员添加授权域名AJAX
function xk_auth_ajax_add_authorization()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误', 'reload' => false);

    try {
        // 验证nonce（与前端保持一致的验证标识）
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (!wp_verify_nonce($nonce, 'add_auth_nonce')) {
            throw new Exception('请求验证失败，请刷新页面重试');
        }

        // 获取并验证参数
        $user_id = intval($_POST['user_id']);
        $product_id = intval($_POST['product_id']);
        $expire_time = isset($_POST['expire_time']) ? sanitize_text_field($_POST['expire_time']) : '';
        $permanent = isset($_POST['permanent']) ? intval($_POST['permanent']) : 0;

        if (!$user_id || $user_id <= 0) {
            throw new Exception('用户ID必须是正整数');
        }
        if (!$product_id) {
            throw new Exception('无效的产品ID');
        }

        // 检查用户权限（管理员才能添加授权）
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足，无法添加授权');
        }

        // 获取产品支付信息
        $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);
        if (empty($pay_mate) || empty($pay_mate['pay_price'])) {
            throw new Exception('产品支付信息配置不完整');
        }

        $post_id = $product_id; // 本地购买订单的页面ID
        $pay_price = $pay_mate['pay_price'];
        $pay_time = current_time('Y-m-d H:i:s');

        // 准备订单数据
        $order_obj = array(
            'id' => '',
            'user_id' => $user_id,
            'ip_address' => '',
            'product_id' => '',
            'post_id' => $post_id,
            'post_author' => '',
            'income_price' => 0.00,
            'income_status' => '',
            'income_detail' => '',
            'order_num' => '',
            'order_price' => $pay_price,
            'order_type' => 15,
            'create_time' => '',
            'pay_num' => '',
            'pay_type' => 'balance',
            'pay_price' => $pay_price,
            'pay_detail' => '',
            'pay_time' => $pay_time,
            'status' => 1,
            'other' => '',
            'referrer_id' => 0,
            'rebate_price' => 0.00,
            'rebate_status' => '',
            'rebate_detail' => '',
        );

        // 创建本地新订单
        $order = ZibPay::add_order($order_obj);
        if (empty($order['order_num'])) {
            throw new Exception('订单创建失败');
        }

        // 获取插件配置中的产品设置
        $product_settings = xk_auth('product_settings', array());
        $auth_count = null;

        if (!empty($product_settings)) {
            foreach ($product_settings as $product) {
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    $auth_count = intval($product['auth_count']);
                    break;
                }
            }
        }

        if ($auth_count === null) {
            throw new Exception('未找到产品授权配置');
        }

        // 处理到期时间
        $db_expire_time = null;
        if ($permanent) {
            // 永久授权，到期时间为null
            $db_expire_time = null;
        } elseif (!empty($expire_time)) {
            // 有指定到期时间
            $db_expire_time = date('Y-m-d H:i:s', strtotime($expire_time));
        } else {
            // 默认情况，从产品设置中获取或使用默认值
            $db_expire_time = null;
        }

        // 插入授权日志
        xk_auth_insert_authorization_log(
            $user_id,
            $product_id,
            $auth_count, // 总授权数
            $auth_count, // 剩余授权数
            "后台添加授权获得额度",
            $db_expire_time // 到期时间
        );

        // 生成动态Token（用于传递到被授权站）
        $dynamic_token = xk_auth_generate_dynamic_token($product_id, 'default', 'default_auth_key');

        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        // 成功响应，包含动态Token信息
        $response = array(
            'error' => 0,
            'msg' => '授权添加成功',
            'reload' => true,
            'dynamic_token' => $dynamic_token['token'],
            'token_expire' => $dynamic_token['expire_time'],
            'token_type' => 'triple_verification'
        );
        
        // 这里可以添加将动态Token传递到被授权站的逻辑
        // 例如：通过API请求将Token发送到被授权站的回调URL
        // $callback_url = get_post_meta($product_id, 'callback_url', true);
        // if (!empty($callback_url)) {
        //     wp_remote_post($callback_url, array(
        //         'body' => array(
        //             'action' => 'auth_token_generated',
        //             'product_id' => $product_id,
        //             'user_id' => $user_id,
        //             'dynamic_token' => $dynamic_token['token'],
        //             'expire_time' => $dynamic_token['expire_time']
        //         )
        //     ));
        // }
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_add_product_authorization', 'xk_auth_ajax_add_authorization');

// 设置授权到期时间AJAX
function xk_auth_ajax_update_expire() {
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误', 'reload' => false);

    try {
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (!wp_verify_nonce($nonce, 'add_auth_nonce')) {
            throw new Exception('请求验证失败，请刷新页面重试');
        }

        // 获取并验证参数
        $auth_id = intval($_POST['auth_id']);
        $expire_time = sanitize_text_field($_POST['expire_time']);
        $reason = sanitize_text_field($_POST['reason']);

        if (!$auth_id) {
            throw new Exception('无效的授权ID');
        }
        if (!$reason) {
            throw new Exception('请输入设置原因');
        }

        // 检查用户权限（管理员才能设置到期时间）
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足，无法设置到期时间');
        }

        // 处理到期时间
        $permanent = isset($_POST['permanent']) ? intval($_POST['permanent']) : 0;
        if ($permanent) {
            // 永久授权，到期时间为null
            $db_expire_time = null;
            $display_time = '永久';
        } elseif (!empty($expire_time)) {
            // 有指定到期时间
            $db_expire_time = date('Y-m-d H:i:s', strtotime($expire_time));
            $display_time = $db_expire_time;
        } else {
            // 默认情况，到期时间为null
            $db_expire_time = null;
            $display_time = '永久';
        }

        // 更新数据库
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        
        // 先检查授权记录是否存在
        $auth_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $auth_id));
        if (empty($auth_data)) {
            throw new Exception('授权记录不存在');
        }

        // 更新到期时间
        $result = $wpdb->update(
            $table_name,
            array(
                'expire_time' => $db_expire_time,
                'log' => "管理员设置授权到期时间为{$display_time}：{$reason}"
            ),
            array('id' => $auth_id),
            array($db_expire_time === null ? '%s' : '%s', '%s'),
            array('%d')
        );

        if ($result === false) {
            throw new Exception('更新到期时间失败：' . $wpdb->last_error);
        }

        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        // 成功响应
        $response = array(
            'error' => 0,
            'msg' => '授权到期时间设置成功',
            'reload' => true
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_update_auth_expire', 'xk_auth_ajax_update_expire');

// 更新授权数量AJAX
function xk_auth_ajax_update_auth_count() {
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误', 'reload' => false);

    try {

        // 获取并验证参数
        $user_id = intval($_POST['user_id']);
        $product_id = intval($_POST['product_id']);
        $new_count = intval($_POST['new_count']);
        $reason = sanitize_text_field($_POST['reason']);

        if (!$user_id || $user_id <= 0) {
            throw new Exception('用户ID必须是正整数');
        }
        if (!$product_id) {
            throw new Exception('无效的产品ID');
        }
        if ($new_count < 0) {
            throw new Exception('授权数量不能为负数');
        }
        if (!$reason) {
            throw new Exception('请输入修改原因');
        }

        // 检查用户权限（管理员才能修改授权数量）
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足，无法修改授权数量');
        }

        // 获取当前用户已使用的授权数量
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_auths';
        $used_auths = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND product_id = %d", $user_id, $product_id));
        $used_auths = intval($used_auths);

        // 计算剩余授权数（新的总数减去已使用的数量）
        $remaining_auths = $new_count - $used_auths;
        // 确保剩余授权数不为负数
        if ($remaining_auths < 0) {
            $remaining_auths = 0;
        }

        // 插入授权日志（记录新的授权数量）
        xk_auth_insert_authorization_log(
            $user_id,
            $product_id,
            $new_count, // 新的总授权数
            $remaining_auths, // 新的剩余授权数
            '修改授权数量：' . $reason
        );

        // 成功响应
        $response = array(
            'error' => 0,
            'msg' => '授权数量修改成功',
            'reload' => true
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_update_auth_count', 'xk_auth_ajax_update_auth_count');

// 正版查询AJAX
function xk_auth_query_ajax()
{
    zib_ajax_send_ajaxpager(admin_add_ajax_aut());
    exit;
}
add_action('wp_ajax_add_ajax_admin_auth', 'xk_auth_query_ajax');
add_action('wp_ajax_nopriv_add_ajax_admin_auth', 'xk_auth_query_ajax');

// 授权时间查询AJAX
function xk_auth_time_query_ajax()
{
    zib_ajax_send_ajaxpager(admin_add_ajax_time_auth());
    exit;
}
add_action('wp_ajax_add_ajax_admin_time_auth', 'xk_auth_time_query_ajax');
add_action('wp_ajax_nopriv_add_ajax_admin_time_auth', 'xk_auth_time_query_ajax');


// 管理员添加产品更新包AJAX
function xk_auth_ajax_add_update_package()
{
    global $wpdb;
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误', 'reload' => false);

    try {
        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (!wp_verify_nonce($nonce, 'add_update_nonce')) {
            throw new Exception('请求验证失败，请刷新页面重试');
        }

        // 验证权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足，无法添加更新包');
        }

        // 获取并验证参数
        $product_id = intval($_POST['product_id']);
        $version = sanitize_text_field($_POST['version']);
        $update_url = esc_url_raw($_POST['update_package_url']);
        $description = sanitize_textarea_field($_POST['update_description']);
        $original_versions = isset($_POST['original_versions']) ? sanitize_textarea_field($_POST['original_versions']) : '';
        $push_type = isset($_POST['push_type']) ? sanitize_text_field($_POST['push_type']) : 'all';
        $target_values = isset($_POST['target_values']) ? sanitize_textarea_field($_POST['target_values']) : '';
        $push_status = 1; // 推送状态固定为1（已推送）

        // 参数验证
        if ($product_id <= 0) {
            throw new Exception('无效的产品ID，请选择正确的产品');
        }
        if (empty($version)) {
            throw new Exception('版本号不能为空');
        }
        if (empty($update_url)) {
            throw new Exception('更新包URL不能为空');
        }
        if (!filter_var($update_url, FILTER_VALIDATE_URL)) {
            throw new Exception('更新包URL格式无效，请输入包含http://或https://的完整链接');
        }
        if (!in_array($push_type, array('all', 'user_id', 'domain'))) {
            throw new Exception('无效的推送类型');
        }
        if ($push_type !== 'all' && empty($target_values)) {
            throw new Exception('请输入目标ID或域名');
        }

        // 检查该产品的该版本是否已存在
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_update';
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE product_id = %d AND version = %s",
            $product_id,
            $version
        ));
        if ($exists) {
            throw new Exception('该产品已存在此版本的更新包，请更换版本号');
        }

        // 开始事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('START TRANSACTION');
        }

        // 插入数据库
        $result = $wpdb->insert(
            $table_name,
            array(
                'product_id' => $product_id,
                'version' => $version,
                'update_package_url' => $update_url,
                'update_description' => $description,
                'original_versions' => $original_versions,
                'push_status' => $push_status,
                'operation_time' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%d', '%s')
        );

        if ($result === false) {
            $last_error = $wpdb->last_error;
            
            // 检查是否是original_versions字段不存在导致的错误
            if (strpos($last_error, 'Unknown column') !== false && strpos($last_error, 'original_versions') !== false) {
                // 尝试添加缺失的字段
                $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN original_versions text COMMENT '适用的原始版本列表'");
                
                // 再次尝试插入数据
                $result = $wpdb->insert(
                    $table_name,
                    array(
                        'product_id' => $product_id,
                        'version' => $version,
                        'update_package_url' => $update_url,
                        'update_description' => $description,
                        'original_versions' => $original_versions,
                        'push_status' => $push_status,
                        'operation_time' => current_time('mysql')
                    ),
                    array('%d', '%s', '%s', '%s', '%s', '%d', '%s')
                );
                
                if ($result === false) {
                    if (method_exists($wpdb, 'query')) {
                        $wpdb->query('ROLLBACK');
                    }
                    throw new Exception('更新包添加失败（表结构已修复但插入仍失败）：' . $wpdb->last_error);
                }
            } else {
                if (method_exists($wpdb, 'query')) {
                    $wpdb->query('ROLLBACK');
                }
                throw new Exception('更新包添加失败：' . $last_error);
            }
        }

        // 获取新插入的更新包ID
        $update_id = $wpdb->insert_id;

        // 处理推送
        $success_count = 0;
        $failed_count = 0;
        $failed_values = array();
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';

        if ($push_type === 'all') {
            // 全部推送
            $result = $wpdb->replace(
                $targeted_push_table,
                array(
                    'update_id' => $update_id,
                    'target_type' => 'all',
                    'target_value' => 'all',
                    'push_time' => current_time('mysql')
                ),
                array('%d', '%s', '%s', '%s')
            );

            if ($result !== false) {
                $success_count++;
            } else {
                $failed_count++;
                $failed_values[] = '全部更新';
            }
        } else {
            // 处理目标值（支持多行输入，每行一个）
            $target_array = array_filter(array_map('trim', explode("\n", $target_values)));
            // 也支持逗号分隔
            if (!empty($target_array)) {
                $temp_array = array();
                foreach ($target_array as $target) {
                    $temp_array = array_merge($temp_array, array_filter(array_map('trim', explode(',', $target))));
                }
                $target_array = $temp_array;
            }
            
            if (empty($target_array)) {
                throw new Exception('请输入有效的目标值');
            }

            foreach ($target_array as $target_value) {
                // 验证目标值格式
                if ($push_type === 'user_id') {
                    // 用户ID必须是数字
                    if (!is_numeric($target_value) || intval($target_value) <= 0) {
                        $failed_count++;
                        $failed_values[] = $target_value;
                        continue;
                    }
                    $target_value = intval($target_value);

                    // 验证用户是否存在
                    $user = get_user_by('id', $target_value);
                    if (!$user) {
                        $failed_count++;
                        $failed_values[] = $target_value;
                        continue;
                    }
                } else if ($push_type === 'domain') {
                    // 域名格式验证
                    if (!preg_match('/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', $target_value)) {
                        $failed_count++;
                        $failed_values[] = $target_value;
                        continue;
                    }
                }

                // 插入或更新推送记录
                $result = $wpdb->replace(
                    $targeted_push_table,
                    array(
                        'update_id' => $update_id,
                        'target_type' => $push_type,
                        'target_value' => $target_value,
                        'push_time' => current_time('mysql')
                    ),
                    array('%d', '%s', '%s', '%s')
                );

                if ($result !== false) {
                    $success_count++;
                } else {
                    $failed_count++;
                    $failed_values[] = $target_value;
                }
            }
        }

        // 提交事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('COMMIT');
        }

        // 构建响应消息
        $message = "V {$version} 添加成功，成功推送 {$success_count} 个目标";
        if ($failed_count > 0) {
            $message .= "，失败 {$failed_count} 个目标（" . implode(', ', $failed_values) . "）";
        }

        // 成功响应
        $response = array(
            'error' => 0,
            'msg' => $message,
            'reload' => true
        );
    } catch (Exception $e) {
        // 回滚事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('ROLLBACK');
        }
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    exit;
}
add_action('wp_ajax_add_product_update', 'xk_auth_ajax_add_update_package');


// 管理员修改更新包AJAX
function xk_auth_ajax_update_package()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '更新失败');

    try {
        // 验证用户权限
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法执行此操作');
        }

        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'edit_update_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }

        // 获取并验证参数
        $update_id = intval($_POST['update_id']);
        $url = esc_url_raw($_POST['update_url']);
        $desc = sanitize_textarea_field($_POST['update_desc']);
        $original_versions = isset($_POST['original_versions']) ? sanitize_textarea_field($_POST['original_versions']) : '';
        $status = intval($_POST['push_status']);

        if ($update_id <= 0) {
            throw new Exception('无效的更新包ID');
        }
        if (empty($url)) {
            throw new Exception('请输入更新包URL');
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new Exception('更新包URL格式无效');
        }

        // 执行数据库更新
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_update';
        $result = $wpdb->update(
            $table_name,
            array(
                'update_package_url' => $url,
                'update_description' => $desc,
                'original_versions' => $original_versions,
                'push_status' => $status,
                'operation_time' => current_time('mysql')
            ),
            array('id' => $update_id),
            array('%s', '%s', '%s', '%d', '%s'),
            array('%d')
        );

        if ($result === false) {
            throw new Exception('数据库更新失败：' . $wpdb->last_error);
        }

        $response = array('error' => 0, 'msg' => '更新成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    wp_die(); // 确保正确终止AJAX请求
}
add_action('wp_ajax_update_product_package', 'xk_auth_ajax_update_package');

// 管理员删除更新包AJAX
function xk_auth_ajax_delete_package()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '删除失败');

    try {
        // 验证用户权限
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法执行此操作');
        }

        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'delete_update_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }

        // 获取并验证参数
        $update_id = intval($_POST['update_id']);

        if ($update_id <= 0) {
            throw new Exception('无效的更新包ID');
        }

        // 执行数据库删除
        global $wpdb;
        $table_name = $wpdb->prefix . 'product_update';
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';

        // 开始事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('START TRANSACTION');
        }

        // 获取产品信息用于日志
        $update_data = $wpdb->get_row($wpdb->prepare("SELECT product_id, version FROM {$table_name} WHERE id = %d", $update_id));
        if (!$update_data) {
            throw new Exception('更新包不存在');
        }

        // 删除指定ID推送记录
        $wpdb->delete(
            $targeted_push_table,
            array('update_id' => $update_id),
            array('%d')
        );

        // 删除更新包
        $result = $wpdb->delete(
            $table_name,
            array('id' => $update_id),
            array('%d')
        );

        if ($result === false) {
            throw new Exception('数据库删除失败：' . $wpdb->last_error);
        }

        // 提交事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('COMMIT');
        }

        $response = array('error' => 0, 'msg' => '删除成功');
    } catch (Exception $e) {
        // 回滚事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('ROLLBACK');
        }

        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    wp_die(); // 确保正确终止AJAX请求
}
add_action('wp_ajax_delete_product_package', 'xk_auth_ajax_delete_package');

// 管理员指定ID推送更新AJAX
function xk_auth_ajax_targeted_push()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '推送失败');

    try {
        // 验证用户权限
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法执行此操作');
        }

        // 验证nonce
        $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'targeted_push_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }

        // 获取并验证参数
        $update_id = intval($_POST['update_id']);
        $target_type = sanitize_text_field($_POST['target_type']);
        $target_values = sanitize_textarea_field($_POST['target_values']);

        if ($update_id <= 0) {
            throw new Exception('无效的更新包ID');
        }

        if (!in_array($target_type, array('user_id', 'domain', 'all'))) {
            throw new Exception('无效的目标类型');
        }

        // 对于全部更新，不需要检查目标值
        if ($target_type !== 'all' && empty($target_values)) {
            throw new Exception('请输入目标值');
        }

        // 执行数据库操作
        global $wpdb;
        $update_table = $wpdb->prefix . 'product_update';
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';

        // 检查并创建目标推送表（如果不存在）
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        if (!$wpdb->get_var("SHOW TABLES LIKE '{$targeted_push_table}'")) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE {$targeted_push_table} (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                update_id mediumint(9) NOT NULL COMMENT '更新包ID',
                target_type varchar(20) NOT NULL COMMENT '目标类型(user_id/domain/all)',
                target_value varchar(255) NOT NULL COMMENT '目标值',
                push_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL COMMENT '推送时间',
                PRIMARY KEY  (id),
                UNIQUE KEY unique_push (update_id, target_type, target_value(191))
            ) {$charset_collate};";
            dbDelta($sql);
        }

        // 验证更新包是否存在
        $update_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$update_table} WHERE id = %d", $update_id));
        if (!$update_data) {
            throw new Exception('更新包不存在');
        }

        // 开始事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('START TRANSACTION');
        }

        // 记录成功和失败的数量
        $success_count = 0;
        $failed_count = 0;
        $failed_values = array();

        // 处理全部更新
        if ($target_type === 'all') {
            // 直接插入全部更新记录
            $result = $wpdb->replace(
                $targeted_push_table,
                array(
                    'update_id' => $update_id,
                    'target_type' => 'all',
                    'target_value' => 'all',
                    'push_time' => current_time('mysql')
                ),
                array('%d', '%s', '%s', '%s')
            );

            if ($result !== false) {
                $success_count++;
            } else {
                $failed_count++;
                $failed_values[] = '全部更新';
            }
        } else {
            // 处理目标值（支持多行输入，每行一个）
            $target_array = array_filter(array_map('trim', explode("\n", $target_values)));
            if (empty($target_array)) {
                throw new Exception('请输入有效的目标值');
            }

            foreach ($target_array as $target_value) {
                // 验证目标值格式
                if ($target_type === 'user_id') {
                    // 用户ID必须是数字
                    if (!is_numeric($target_value) || intval($target_value) <= 0) {
                        $failed_count++;
                        $failed_values[] = $target_value;
                        continue;
                    }
                    $target_value = intval($target_value);

                    // 验证用户是否存在
                    $user = get_user_by('id', $target_value);
                    if (!$user) {
                        $failed_count++;
                        $failed_values[] = $target_value;
                        continue;
                    }
                } else if ($target_type === 'domain') {
                    // 域名格式验证
                    if (!preg_match('/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', $target_value)) {
                        $failed_count++;
                        $failed_values[] = $target_value;
                        continue;
                    }
                }

                // 插入或更新推送记录
                $result = $wpdb->replace(
                    $targeted_push_table,
                    array(
                        'update_id' => $update_id,
                        'target_type' => $target_type,
                        'target_value' => $target_value,
                        'push_time' => current_time('mysql')
                    ),
                    array('%d', '%s', '%s', '%s')
                );

                if ($result !== false) {
                    $success_count++;
                } else {
                    $failed_count++;
                    $failed_values[] = $target_value;
                }
            }
        }

        // 提交事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('COMMIT');
        }

        // 构建响应消息
        $message = "成功推送 {$success_count} 个目标";
        if ($failed_count > 0) {
            $message .= "，失败 {$failed_count} 个目标（" . implode(', ', $failed_values) . "）";
        }

        $response = array(
            'error' => 0,
            'msg' => $message,
            'success_count' => $success_count,
            'failed_count' => $failed_count,
            'failed_values' => $failed_values
        );
    } catch (Exception $e) {
        // 回滚事务
        if (method_exists($wpdb, 'query')) {
            $wpdb->query('ROLLBACK');
        }

        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    wp_die(); // 确保正确终止AJAX请求
}
add_action('wp_ajax_targeted_push', 'xk_auth_ajax_targeted_push');

// 检查指定ID更新
function xk_auth_check_targeted_update($product_id, $user_id = 0, $domain = '')
{
    global $wpdb;
    $update_table = $wpdb->prefix . 'product_update';
    $targeted_push_table = $wpdb->prefix . 'product_targeted_push';

    // 获取所有已推送的更新包（包括指定ID和全部更新）
    $query = "SELECT u.* 
              FROM {$update_table} u 
              JOIN {$targeted_push_table} tp ON u.id = tp.update_id 
              WHERE u.product_id = %d AND u.push_status = 1 
              AND ((tp.target_type = 'user_id' AND tp.target_value = %d) OR 
                   (tp.target_type = 'domain' AND tp.target_value = %s) OR 
                   (tp.target_type = 'all' AND tp.target_value = 'all')) 
              ORDER BY u.id DESC LIMIT 1";

    $update = $wpdb->get_row($wpdb->prepare($query, $product_id, $user_id, $domain));

    return $update;
}

// 检查用户权限的AJAX处理函数
function xk_auth_ajax_check_permission()
{
    header('Content-Type: application/json');

    $permission = isset($_POST['permission']) ? sanitize_key($_POST['permission']) : '';
    $hasPermission = false;

    if (!empty($permission) && is_user_logged_in()) {
        $hasPermission = current_user_can($permission);
    }

    echo json_encode(array('hasPermission' => $hasPermission));
    wp_die();
}
add_action('wp_ajax_check_user_permission', 'xk_auth_ajax_check_permission');

// 日志查询AJAX
function xk_auth_log_query_ajax()
{
    zib_ajax_send_ajaxpager(admin_add_ajax_log());
    exit;
}
add_action('wp_ajax_add_ajax_admin_log', 'xk_auth_log_query_ajax');

// 绑定QQ的模态框AJAX
function xk_auth_increase_qq_modal()
{
    $user_id = get_current_user_id();
    echo xk_auth_increase_qq_form($user_id);
    exit;
}
add_action('wp_ajax_auth_increase_qq_modal', 'xk_auth_increase_qq_modal');

function xk_auth_add_qq_ajax()
{
    $user_id = get_current_user_id();

    if (!$user_id) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '权限不足'));
        exit;
    }

    if (empty($_POST['auth_qq'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入授权QQ'));
        exit;
    }

    if (!preg_match('/^[1-9][0-9]{4,12}$/', $_POST['auth_qq'])) {
        echo json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '请输入正确的QQ'));
        exit;
    }

    update_user_meta($user_id, 'auth_qq', $_POST['auth_qq']);

    echo json_encode(array('error' => 0, 'ys' => '', 'msg' => '授权QQ绑定成功', 'reload' => true));
    exit;
}
add_action('wp_ajax_increase_auth_qq', 'xk_auth_add_qq_ajax');
    add_action('wp_ajax_xk_auth_select_time_package', 'xk_auth_ajax_select_time_package');
    add_action('wp_ajax_xk_auth_pay_modal', 'xk_auth_pay_modal_ajax');
    add_action('wp_ajax_nopriv_xk_auth_pay_modal', 'xk_auth_pay_modal_ajax');
    add_action('wp_ajax_xk_auth_pay_with_points', 'xk_auth_pay_with_points');

/**
 * 处理余额支付AJAX请求
 */
function xk_auth_pay_with_balance() {
    // 使用子比主题的支付处理函数
    xk_auth_process_payment('balance');
}
add_action('wp_ajax_xk_auth_pay_with_balance', 'xk_auth_pay_with_balance');


/**
 * 统一处理支付请求
 * @param string $pay_type 支付类型：balance（余额支付）或 points（积分支付）
 */
function xk_auth_process_payment($pay_type) {
    // 声明全局变量
    global $wpdb;
    
    // 彻底清除所有之前的输出缓冲区，确保只返回JSON
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // 设置JSON响应头
    header('Content-Type: application/json; charset=UTF-8');
    // 禁用缓存
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // 初始化响应数据
    $response = array(
        'msg' => -1,
        'name' => '未知错误'
    );
    
    try {
        // 获取用户ID
        $user_id = get_current_user_id();
        if (!$user_id) {
            throw new Exception('请先登录');
        }
        
        // 验证参数
        $product_id = !empty($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $package_index = !empty($_POST['package_index']) ? intval($_POST['package_index']) : 0;
        // 前端在AJAX请求中实际发送的是 selected_duration 参数
        $frontend_selected_duration = isset($_POST['selected_duration']) ? intval($_POST['selected_duration']) : 0;
        
        // // 添加调试日志
        // error_log('[XK Auth] 支付处理开始 - 参数检查:');
        // error_log('[XK Auth] product_id: ' . $product_id);
        // error_log('[XK Auth] package_index: ' . $package_index);
        // error_log('[XK Auth] frontend_selected_duration: ' . $frontend_selected_duration);
        
        if (!$product_id) {
            throw new Exception('参数错误');
        }
        
        // 获取时间套餐信息
        $time_packages = xk_auth_get_product_time_packages($product_id);
        // 保存前端传递的有效期，这是关键！
        $original_frontend_selected_duration = $frontend_selected_duration;
        $selected_duration = $frontend_selected_duration;
        $selected_price = 0;
        $points_price = 0;
        
        // 获取优惠码折扣信息
        $promo_code = isset($_POST['promo_code']) ? sanitize_text_field($_POST['promo_code']) : '';
        $promo_discount = isset($_POST['promo_discount']) ? floatval($_POST['promo_discount']) : 0;
        
        // 获取用户会员等级
        $user_vip_level = 0;
        if (function_exists('zib_get_user_vip_level')) {
            $user_vip_level = zib_get_user_vip_level($user_id);
        }
        
        // 直接使用get_post_meta获取文章的支付设置（子比主题实际使用的方式）
        $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);
        // 如果获取不到或不是数组，使用空数组作为默认值
        if (!is_array($pay_mate)) {
            $pay_mate = array();
        }
        
        // 定义计算会员价格的函数，与前端保持一致
        function calculate_vip_price($original_price, $user_vip_level, $pay_mate, $is_points = false, $package = null) {
            // 如果不是会员，返回原价
            if (!$user_vip_level) {
                return $original_price;
            }
            
            // 优先使用套餐自身的会员价格设置
            if (!empty($package)) {
                if ($is_points) {
                    // 积分支付套餐，检查是否有对应的会员积分价格设置
                    $vip_points_key = 'package_vip_' . $user_vip_level . '_points_price';
                    if (isset($package[$vip_points_key]) && $package[$vip_points_key] > 0) {
                        // 返回套餐中设置的会员积分价格
                        return $package[$vip_points_key];
                    }
                } else {
                    // 现金支付套餐，检查是否有对应的会员价格设置
                    $vip_price_key = 'package_vip_' . $user_vip_level . '_price';
                    if (isset($package[$vip_price_key]) && $package[$vip_price_key] > 0) {
                        // 返回套餐中设置的会员价格
                        return $package[$vip_price_key];
                    }
                }
            }
            
            // 如果套餐没有设置会员价格，尝试使用文章的会员价格设置
            if (is_array($pay_mate)) {
                // 会员积分价格处理
                if ($is_points) {
                    // 检查是否有对应的会员积分价格设置
                    $vip_points_key = 'vip_' . $user_vip_level . '_points';
                    if (isset($pay_mate[$vip_points_key]) && $pay_mate[$vip_points_key] > 0) {
                        // 返回会员积分价格
                        return $pay_mate[$vip_points_key];
                    }
                    
                    // 检查是否有会员积分折扣
                    if (isset($pay_mate['vip_points_discount']) && $pay_mate['vip_points_discount'] > 0) {
                        // 计算积分折扣价格
                        $discount = $pay_mate['vip_points_discount'] / 100;
                        return $original_price * $discount;
                    }
                    
                    // 检查是否有通用的会员折扣
                    if (isset($pay_mate['vip_discount']) && $pay_mate['vip_discount'] > 0) {
                        // 使用通用会员折扣计算积分价格
                        $discount = $pay_mate['vip_discount'] / 100;
                        return $original_price * $discount;
                    }
                } else {
                    // 现金价格处理
                    // 检查是否有对应的会员价格设置
                    $vip_price_key = 'vip_' . $user_vip_level . '_price';
                    if (isset($pay_mate[$vip_price_key]) && $pay_mate[$vip_price_key] > 0) {
                        // 返回会员价格
                        return $pay_mate[$vip_price_key];
                    }
                    
                    // 如果没有找到对应的会员价格，检查是否启用了会员折扣
                    if (isset($pay_mate['vip_discount']) && $pay_mate['vip_discount'] > 0) {
                        // 计算折扣价格
                        $discount = $pay_mate['vip_discount'] / 100;
                        return $original_price * $discount;
                    }
                }
            }
            
            // 默认返回原价
            return $original_price;
        }
        
        // 根据package_index获取对应的套餐信息
        // 先检查time_packages是否为空以及package_index是否有效
        $selected_package_found = false;
        
        // 确保time_packages是数组
        if (is_array($time_packages) && !empty($time_packages)) {
            // 处理关联数组的情况，使用array_values转换为索引数组
            $time_packages = array_values($time_packages);
            
            // 检查package_index是否在有效范围内
            if (isset($time_packages[$package_index])) {
                $selected_package = $time_packages[$package_index];
                $selected_package_found = true;
                
                // 获取套餐的原始价格
                $original_price = floatval($selected_package['package_price']);
                $original_points_price = intval($selected_package['package_points_price']);
                $package_payment_type = isset($selected_package['package_payment_type']) ? $selected_package['package_payment_type'] : 'money';
                
                // 计算会员价格
                if ($package_payment_type === 'money') {
                    // 现金支付，计算现金会员价格
                    $selected_price = calculate_vip_price($original_price, $user_vip_level, $pay_mate, false, $selected_package);
                    $points_price = $original_points_price;
                    
                    // 应用优惠码折扣
                    if ($promo_discount > 0) {
                        $selected_price = max(0, $selected_price - $promo_discount);
                    }
                } else {
                    // 积分支付，计算积分会员价格
                    $points_price = calculate_vip_price($original_points_price, $user_vip_level, $pay_mate, true, $selected_package);
                    $selected_price = $original_price;
                    
                    // 应用优惠码折扣
                    if ($promo_discount > 0) {
                        $points_price = max(0, $points_price - intval($promo_discount));
                    }
                }
            }
        }
        
        // 如果没有找到对应的套餐，使用前端传递的数据
        if (!$selected_package_found) {
            if ($pay_type === 'balance') {
                $selected_price = floatval($_POST['selected_price']);
                if ($selected_price <= 0) {
                    throw new Exception('参数错误');
                }
                
                // 应用优惠码折扣
                if ($promo_discount > 0) {
                    $selected_price = max(0, $selected_price - $promo_discount);
                }
            } else {
                // 积分支付时，前端传递的是points_price
                $points_price = intval($_POST['points_price']);
                if ($points_price <= 0) {
                    throw new Exception('参数错误');
                }
                
                // 应用优惠码折扣
                if ($promo_discount > 0) {
                    $points_price = max(0, $points_price - intval($promo_discount));
                }
            }
        }
        
        // 优先使用前端传递的selected_duration，确保有效期正确
        // 这是关键修复：无论后端套餐获取是否成功，都使用前端选择的有效期
        if (isset($_POST['selected_duration'])) {
            $selected_duration = intval($_POST['selected_duration']);
        } else {
            // 如果前端没有传递，尝试从后端套餐获取
            if ($selected_package_found && isset($selected_package['package_duration'])) {
                $selected_duration = intval($selected_package['package_duration']);
            } else {
                // 默认使用60天
                $selected_duration = 60;
            }
        }
        
        // 添加调试日志
        // error_log('[XK Auth] 重新设置后 selected_duration: ' . $selected_duration);
        
        // 确保selected_duration不为空字符串或null，但允许为0（表示永久授权）
        if ($selected_duration === null || $selected_duration === '') {
            $selected_duration = 60;
        }
        
        // 幂等性检查：创建唯一的请求锁键
        $request_lock_key = 'xk_auth_pay_lock_' . $user_id . '_' . $product_id . '_' . $package_index;
        
        // 检查是否已经有相同的支付请求正在处理中（5秒内）
        if (get_transient($request_lock_key)) {
            throw new Exception('支付请求正在处理中，请5秒后再试');
        }
        
        // 设置请求锁，有效期5秒
        set_transient($request_lock_key, 1, 5);
        
        // 获取产品信息
        $product = get_post($product_id);
        if (!$product) {
            throw new Exception('产品不存在');
        }
        
        // 生成订单号
        $order_no = ZibPay::generate_payment_order_num();
        
        // 处理不同类型的支付
        if ($pay_type === 'balance') {
            // 余额支付
            $user_balance = zibpay_get_user_balance($user_id);
            
            // 检查余额是否充足
            if ($user_balance < $selected_price) {
                throw new Exception('余额不足，请先充值');
            }
            
            // 准备扣除余额的数据
            $update_balance_data = array(
                'order_num' => $order_no, // 订单号
                'value'     => -$selected_price, // 值 整数为加，负数为减去
                'type'      => '余额支付', // 类型说明
                'desc'      => '购买授权：' . $product->post_title, // 说明
                'time'      => current_time('Y-m-d H:i'),
            );
            
            // 扣除余额
            zibpay_update_user_balance($user_id, $update_balance_data);
        } else {
            // 积分支付
            $user_points = zibpay_get_user_points($user_id);
            
            if ($user_points < $points_price) {
                throw new Exception('积分不足');
            }
            
            // 准备扣除积分的数据
            $update_points_data = array(
                'order_num' => $order_no, // 订单号
                'value' => -$points_price,
                'type' => '积分支付',
                'desc' => '购买授权产品 - ' . $product->post_title,
                'time' => current_time('Y-m-d H:i'),
            );
            
            // 扣除积分
            zibpay_update_user_points($user_id, $update_points_data);
        }
        
        // 创建订单记录前，检查是否已存在相同条件的已支付订单
        $order_table = $wpdb->prefix . 'zibpay_order';
        
        // 检查是否已存在相同用户、相同产品、相同套餐的已支付订单（1分钟内）
        $existing_order = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $order_table WHERE user_id = %d AND post_id = %d AND order_type = 15 AND status = 1 AND pay_type = %s AND UNIX_TIMESTAMP(pay_time) > UNIX_TIMESTAMP(NOW()) - 60",
                $user_id, $product_id, $pay_type
            )
        );
        
        if ($existing_order) {
            throw new Exception('您已经成功支付过该产品，无需重复支付');
        }
        
        // 获取插件配置中的产品设置，获取授权数量
        $product_settings = xk_auth('product_settings', array());
        $auth_count = 1; // 默认给1个授权
        
        // 遍历配置中的产品，匹配当前产品ID
        if (!empty($product_settings)) {
            foreach ($product_settings as $product_setting) {
                if (isset($product_setting['product_id']) && $product_setting['product_id'] == $product_id) {
                    // 从配置中获取授权个数（转为整数）
                    $auth_count = intval($product_setting['auth_count']);
                    break;
                }
            }
        }
        
        // 计算到期时间 - 关键修复：根据用户选择的套餐设置正确的到期时间
        $expire_time = NULL;
        // 添加调试日志
        // error_log('[XK Auth] 到期时间计算前:');
        // error_log('[XK Auth] original_frontend_selected_duration: ' . $original_frontend_selected_duration);
        // error_log('[XK Auth] selected_duration: ' . $selected_duration);
        
        // 只有当selected_duration大于0时，才计算到期时间
        // 如果selected_duration为0，表示永久授权
        if ($selected_duration > 0) {
            // 如果选择了时间套餐，计算到期时间
            $expire_time = date('Y-m-d H:i:s', strtotime("+{$selected_duration} days"));
        } else {
            // 永久授权，到期时间为NULL
            $expire_time = NULL;
        }
        
        // 添加调试日志
        // error_log('[XK Auth] 到期时间计算后:');
        // error_log('[XK Auth] expire_time: ' . ($expire_time ? $expire_time : 'NULL'));
        
        // 构建订单数据
        $order_data = array(
            'order_num' => $order_no,
            'user_id' => $user_id,
            'post_id' => $product_id,
            'order_price' => $pay_type === 'balance' ? $selected_price : ($points_price / 100),
            'order_type' => 15, // 授权产品类型
            'status' => 1, // 已支付状态
            'pay_time' => current_time('Y-m-d H:i:s'),
            'pay_type' => $pay_type,
            'pay_num' => $order_no, // 支付单号
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'pay_price' => $pay_type === 'balance' ? $selected_price : ($points_price / 100),
            'pay_detail' => array(
                'payment_method' => $pay_type,
                $pay_type => $pay_type === 'balance' ? $selected_price : $points_price
            ),
            'meta' => array(
                'order_data' => array(
                    'product_name' => $product->post_title,
                    'payment_method' => $pay_type === 'balance' ? '余额支付' : '积分支付',
                    'package_duration' => $selected_duration,
                    'auth_count' => $auth_count,
                    'promo_code' => $promo_code,
                    'promo_discount' => $promo_discount
                )
            )
        );
        
        // 直接使用ZibPay类的add_order方法创建订单
        $order_result = ZibPay::add_order($order_data);
        if (!$order_result) {
            throw new Exception('订单记录创建失败：' . $wpdb->last_error);
        }
        
        if (!isset($order_result['other'])) {
            $order_result['other'] = '';
        }
        if (!isset($order_result['order_type'])) {
            $order_result['order_type'] = '';
        }
        
        // 触发支付成功钩子，以便子比主题发送邮件通知
        // 将数组转换为对象，确保主题函数能正确处理
        do_action('payment_order_success', (object) $order_result);
        
        // 为积分支付添加邮件通知
        if ($pay_type === 'points') {
            xk_auth_send_points_payment_email($order_result, $user_id, $product);
        }
        
        // 插入授权记录
        $auth_log_table = $wpdb->prefix . 'auth_logs';
        
        // 检查是否已有授权记录
        $existing_auth = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $auth_log_table WHERE user_id = %d AND product_id = %d ORDER BY operation_time DESC LIMIT 1",
                $user_id, $product_id
            )
        );
        
        if ($existing_auth) {
            // 已有授权记录，更新记录
            $total_auths = $existing_auth->total_auths + $auth_count;
            $remaining_auths = $existing_auth->remaining_auths + $auth_count;
            
            // 构建操作描述
            $operation_desc = $pay_type === 'balance' ? '用户使用余额支付增加授权额度' : '用户使用积分支付增加授权额度';
            if ($expire_time) {
                $operation_desc .= "，有效期 {$selected_duration} 天";
            } else {
                $operation_desc .= "，永久授权";
            }
            
            // // 添加调试日志
            // error_log('[XK Auth] 已有授权记录，更新记录:');
            // error_log('[XK Auth] existing_auth: ' . print_r($existing_auth, true));
            // error_log('[XK Auth] total_auths: ' . $total_auths);
            // error_log('[XK Auth] remaining_auths: ' . $remaining_auths);
            // error_log('[XK Auth] operation_desc: ' . $operation_desc);
            // error_log('[XK Auth] expire_time: ' . $expire_time);
            
            // 使用xk_auth_insert_authorization_log函数处理授权记录
            xk_auth_insert_authorization_log($user_id, $product_id, $total_auths, $remaining_auths, $operation_desc, $expire_time);
        } else {
            // 初次购买，插入新记录
            // 构建操作描述
            $operation_desc = $pay_type === 'balance' ? '用户使用余额支付初次购买获得额度' : '用户使用积分支付初次购买获得额度';
            if ($expire_time) {
                $operation_desc .= "，有效期 {$selected_duration} 天";
            } else {
                $operation_desc .= "，永久授权";
            }
            
            // // 添加调试日志
            // error_log('[XK Auth] 初次购买，插入新记录:');
            // error_log('[XK Auth] auth_count: ' . $auth_count);
            // error_log('[XK Auth] operation_desc: ' . $operation_desc);
            // error_log('[XK Auth] expire_time: ' . $expire_time);
            
            // 使用xk_auth_insert_authorization_log函数处理授权记录
            xk_auth_insert_authorization_log($user_id, $product_id, $auth_count, $auth_count, $operation_desc, $expire_time);
        }
        
        // 更新优惠码使用次数
        if (!empty($promo_code) && $promo_discount > 0) {
            $promo_table = $wpdb->prefix . 'auth_promo_codes';
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$promo_table} SET usage_count = usage_count + 1 WHERE code = %s",
                    $promo_code
                )
            );
        }
        
        // 清除仪表盘数据缓存，确保下次访问时显示最新数据
        delete_transient('xk_auth_dashboard_data');
        
        // 更新响应数据
        $response = array(
            'msg' => 1,
            'name' => '支付成功',
            'order_no' => $order_no,
            'reload' => true
        );
    } catch (Exception $e) {
        // 更新错误响应
        $response['name'] = $e->getMessage();
    }
    
    // 输出纯JSON响应
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
    // 确保立即退出，不输出任何其他内容
    exit;
}

/**
 * 发送积分支付邮件通知
 * @param array $order_result 订单结果
 * @param int $user_id 用户ID
 * @param object $product 产品对象
 */
function xk_auth_send_points_payment_email($order_result, $user_id, $product) {
    // 获取用户信息
    $udata = get_userdata($user_id);
    if (!$user_id || !$udata) {
        return;
    }
    
    // 获取订单信息
    $pay_order = (array) $order_result;
    $user_name = $udata->display_name;
    
    // 计算支付积分
    $pay_points = isset($pay_order['pay_detail']['points']) ? $pay_order['pay_detail']['points'] : 0;
    $pay_points = $pay_points ? $pay_points . '积分' : '';
    $pay_price  = $pay_points ? '-积分：' . $pay_points : '';
    $pay_time   = $pay_order['pay_time'];
    $blog_name  = get_bloginfo('name');
    $_link      = zib_get_user_center_url('order');
    $order_name = zibpay_get_pay_type_name($pay_order['order_type']);
    
    // 构建邮件内容
    $m_title = '订单支付成功' . $pay_price . '，订单号[' . $pay_order['order_num'] . ']';
    $title   = $m_title;
    
    $message = '您好！ ' . $user_name . '<br>';
    $message .= '您在【' . $blog_name . '】购买的商品已支付成功' . '<br>';
    $message .= '类型：' . $order_name . '<br>';
    $message .= '商品：<a target="_blank" href="' . get_permalink($product->ID) . '">' . $product->post_title . '</a>' . '<br>';
    $message .= '订单号：' . $pay_order['order_num'] . '<br>';
    $message .= '付款明细：积分支付 - ' . $pay_points . '<br>';
    $message .= '付款时间：' . $pay_time . '<br>';
    $message .= '<br>';
    $message .= '您可以点击下方按钮查看订单详情' . '<br>';
    $message .= '<a class="but c-blue" target="_blank" style="margin-top: 20px" href="' . esc_url($_link) . '">查看订单</a>' . '<br>';
    
    // 发送邮件
    if (_pz('email_payment_order', true)) {
        /**获取用户邮箱 */
        $user_email = !empty($udata->user_email) ? $udata->user_email : '';
        /**如果没有 email或者email无效则终止*/
        if (!$user_email || stristr($user_email, '@no')) {
            return false;
        }
        /**发送邮件 */
        @wp_mail($user_email, $title, $message);
    }
}

/**
 * 处理时间套餐选择AJAX请求
 */
function xk_auth_ajax_select_time_package() {
    // 验证非空
    if (empty($_POST['product_id']) || empty($_POST['package_index'])) {
        $error_msg = '参数错误：缺少必要参数';
        wp_send_json_error(array('msg' => -1, 'name' => $error_msg, 'debug' => '缺少必要参数'));
    }
    
    $product_id = intval($_POST['product_id']);
    $package_index = intval($_POST['package_index']);
    
    // 获取时间套餐
    $time_packages = xk_auth_get_product_time_packages($product_id);
    
    // 处理没有时间套餐的情况
    if (empty($time_packages)) {
        // 如果没有设置时间套餐，使用默认套餐
        $selected_package = array(
            'package_name' => '默认套餐',
            'package_duration' => 365,
            'package_price' => 0.01,
            'package_points_price' => 0
        );
    } else if (!isset($time_packages[$package_index])) {
        // 如果选择的套餐不存在，使用第一个套餐
        $selected_package = reset($time_packages);
        $package_index = key($time_packages);
    } else {
        // 正常情况，使用选择的套餐
        $selected_package = $time_packages[$package_index];
    }
    
    // 保存选择的套餐到会话或其他存储方式
    if (!session_id()) {
        session_start();
    }
    
    $_SESSION['xk_auth_selected_package'] = array(
        'product_id' => $product_id,
        'package_index' => $package_index,
        'package_duration' => $selected_package['package_duration'],
        'package_price' => $selected_package['package_price'],
        'package_points_price' => $selected_package['package_points_price'],
    );
    
    // 返回支付URL
    $pay_url = get_permalink($product_id);
    
    wp_send_json_success(array(
        'msg' => 1,
        'name' => '套餐选择成功',
        'pay_url' => $pay_url,
        'package_info' => $selected_package
    ));
    
    exit;
}

/**
 * 处理支付模态框AJAX请求
 */
function xk_auth_pay_modal_ajax() {
    // 验证非空，同时检查GET和POST请求
    $product_id = intval(isset($_POST['id']) ? $_POST['id'] : (isset($_GET['id']) ? $_GET['id'] : 0));
    
    if (empty($product_id)) {
        // 直接输出错误信息HTML，而不是调用会exit的函数
        $html = '<div class="em12 text-center c-red" style="padding: 30px 0;">产品ID获取错误，请刷新后重试</div>';
        echo $html;
        exit;
    }
    
    $user_id = get_current_user_id();
    
    // 调用支付模态框函数
    $modal_content = xk_auth_pay_modal($user_id, $product_id);
    
    echo $modal_content;
    exit;
}

/**
 * 处理积分支付AJAX请求
 */
function xk_auth_pay_with_points() {
    // 使用子比主题的支付处理函数
    xk_auth_process_payment('points');
}


// 获取指定更新包的推送目标列表AJAX
function xk_auth_ajax_get_targeted_pushes()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '获取失败', 'data' => array());

    try {
        // 验证用户权限
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法执行此操作');
        }

        // 验证nonce
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'targeted_push_nonce')) {
            throw new Exception('验证失败，请刷新页面重试');
        }

        // 获取更新包ID
        $update_id = isset($_POST['update_id']) ? intval($_POST['update_id']) : 0;
        if ($update_id <= 0) {
            throw new Exception('无效的更新包ID');
        }

        // 查询推送目标列表
        global $wpdb;
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';
        $push_targets = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$targeted_push_table} WHERE update_id = %d ORDER BY id DESC",
            $update_id
        ));

        if ($wpdb->last_error) {
            throw new Exception('数据库查询失败：' . $wpdb->last_error);
        }

        // 处理结果
        $data = array();
        if (!empty($push_targets)) {
            foreach ($push_targets as $target) {
                $target_info = array(
                    'id' => $target->id,
                    'target_type' => $target->target_type,
                    'target_value' => $target->target_value,
                    'push_time' => date('Y-m-d H:i:s', strtotime($target->push_time))
                );
                $data[] = $target_info;
            }
        }

        $response = array(
            'error' => 0,
            'msg' => '获取成功',
            'data' => $data
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    wp_die(); // 确保正确终止AJAX请求
}
add_action('wp_ajax_get_targeted_pushes', 'xk_auth_ajax_get_targeted_pushes');

// 删除指定的推送目标AJAX
function xk_auth_ajax_delete_targeted_push()
{
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '删除失败');

    try {
        // 验证用户权限
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new Exception('权限不足，无法执行此操作');
        }

        // 验证nonce
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'targeted_push_nonce')) {
            throw new Exception('验证失败，请刷新页面重试');
        }

        // 获取推送ID
        $push_id = isset($_POST['push_id']) ? intval($_POST['push_id']) : 0;
        if ($push_id <= 0) {
            throw new Exception('无效的推送ID');
        }

        // 执行删除操作
        global $wpdb;
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';
        $result = $wpdb->delete(
            $targeted_push_table,
            array('id' => $push_id),
            array('%d')
        );

        if ($result === false) {
            throw new Exception('数据库删除失败：' . $wpdb->last_error);
        }

        $response = array('error' => 0, 'msg' => '删除成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }

    echo json_encode($response);
    wp_die(); // 确保正确终止AJAX请求
}
add_action('wp_ajax_delete_targeted_push', 'xk_auth_ajax_delete_targeted_push');

// 搜索用户AJAX处理函数
function xk_auth_search_user() {
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');

    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => '您没有权限执行此操作'));
    }

    // 获取搜索关键词
    $search_term = isset($_POST['search_term']) ? sanitize_text_field($_POST['search_term']) : '';
    
    if (empty($search_term)) {
        wp_send_json_error(array('message' => '搜索关键词不能为空'));
    }

    // 构建搜索参数
    $args = array(
        'search' => '*' . $search_term . '*',
        'search_columns' => array('user_login', 'user_nicename', 'user_email', 'ID'),
        'number' => 10, // 限制返回10条结果
        'fields' => array('ID', 'user_login', 'user_email')
    );

    // 执行用户搜索
    $user_query = new WP_User_Query($args);
    $users = $user_query->get_results();

    // 格式化结果
    $formatted_users = array();
    foreach ($users as $user) {
        $formatted_users[] = array(
            'ID' => $user->ID,
            'user_login' => $user->user_login,
            'user_email' => $user->user_email
        );
    }

    wp_send_json_success(array('users' => $formatted_users));
}
add_action('wp_ajax_xk_auth_search_user', 'xk_auth_search_user');

// 下载授权资源验证模态框AJAX处理
function xk_download_resource_verify_modal()
{
    $user_id = get_current_user_id();
    $product_id = !empty($_REQUEST['product_id']) ? $_REQUEST['product_id'] : '';
    $resource_id = !empty($_REQUEST['resource_id']) ? $_REQUEST['resource_id'] : '';
    echo xk_auth_download_resource_verify_modal($user_id, $product_id, $resource_id);
    exit;
}
add_action('wp_ajax_xk_download_resource_verify', 'xk_download_resource_verify_modal');

// 下载授权资源处理函数
function xk_download_resource()
{
    // 设置JSON响应头
    header('Content-Type: application/json');
    
    $response = array('error' => 1, 'msg' => '下载失败');
    
    try {
        $user_id = get_current_user_id();
        if (!$user_id) {
            $response['msg'] = '请先登录';
            echo json_encode($response);
            exit;
        }
        
        $product_id = !empty($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $resource_id = !empty($_POST['resource_id']) ? sanitize_text_field($_POST['resource_id']) : '';
        
        if (!$product_id || !$resource_id) {
            $response['msg'] = '参数错误';
            echo json_encode($response);
            exit;
        }
        
        // 验证用户是否有权限下载该资源
        // 检查用户是否已绑定域名
        $enable_domain_check = xk_auth('enable_domain_check_download', true);
        $has_domains = xk_Auth::has_bound_domains($user_id, $product_id);
        
        // 如果关闭了域名绑定检验，则认为用户已绑定域名
        if (!$enable_domain_check) {
            $has_domains = true;
        }
        
        if (!$has_domains) {
            $response['msg'] = '请先绑定至少一个域名才能下载资源';
            echo json_encode($response);
            exit;
        }
        
        // 获取资源下载链接
        // 从产品设置中获取下载链接
        $all_products = xk_auth('product_settings', array());
        $current_product = array();
        
        // 查找匹配的产品ID
        if (!empty($all_products)) {
            foreach ($all_products as $product) {
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    $current_product = $product;
                    break;
                }
            }
        }
        
        if (empty($current_product)) {
            $response['msg'] = '未找到该产品的下载资源';
            echo json_encode($response);
            exit;
        }
        
        // 根据resource_id获取对应的下载链接
        $download_url = '';
        if ($resource_id == 'main') {
            $download_url = isset($current_product['down_1']) ? $current_product['down_1'] : '';
        } elseif ($resource_id == 'backup') {
            $download_url = isset($current_product['down_2']) ? $current_product['down_2'] : '';
        }
        
        if (empty($download_url)) {
            $response['msg'] = '资源不存在或已下架';
            echo json_encode($response);
            exit;
        }
        
        // 记录下载日志（可选）
        // 这里可以添加下载日志记录逻辑
        
        // 返回下载链接
        $response['error'] = 0;
        $response['msg'] = '下载成功';
        $response['download_url'] = $download_url;
        
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}
add_action('wp_ajax_xk_download_resource', 'xk_download_resource');

/**
 * @description: 获取用户列表
 */
function xk_auth_get_users() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_REQUEST['security']) ? sanitize_text_field($_REQUEST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取所有用户
        $users = get_users(array(
            'fields' => array('ID', 'user_login', 'user_email', 'display_name'),
            'orderby' => 'display_name',
            'order' => 'ASC'
        ));
        
        // 格式化用户数据
        $formatted_users = array();
        foreach ($users as $user) {
            $formatted_users[] = array(
                'id' => $user->ID,
                'name' => $user->display_name . ' (' . $user->user_login . ')',
                'email' => $user->user_email
            );
        }
        
        $response = array('error' => 0, 'users' => $formatted_users);
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}

/**
 * @description: 获取授权用户列表
 */
function xk_auth_get_authorized_users() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_REQUEST['security']) ? sanitize_text_field($_REQUEST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取分页参数
        $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
        $per_page = isset($_REQUEST['per_page']) ? max(1, intval($_REQUEST['per_page'])) : 10;
        $offset = ($paged - 1) * $per_page;
        
        // 获取授权用户列表
        $options = get_option('xk_auth_setting', array());
        $authorized_users = isset($options['authorized_users']) ? $options['authorized_users'] : array();
        
        // 计算总数量
        $total = count($authorized_users);
        
        // 分页处理
        $paged_users = array_slice($authorized_users, $offset, $per_page);
        
        // 格式化用户数据
        $formatted_users = array();
        foreach ($paged_users as $user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                $formatted_users[] = array(
                    'id' => $user->ID,
                    'name' => $user->display_name,
                    'email' => $user->user_email
                );
            }
        }
        
        $response = array(
            'error' => 0,
            'authorizedUsers' => $formatted_users,
            'total' => $total,
            'currentPage' => $paged
        );
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}

/**
 * @description: 添加授权用户
 */
function xk_auth_add_authorized_user() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_REQUEST['security']) ? sanitize_text_field($_REQUEST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取用户ID
        $user_id = isset($_REQUEST['user_id']) ? intval($_REQUEST['user_id']) : 0;
        if (!$user_id) {
            throw new Exception('用户ID无效');
        }
        
        // 验证用户是否存在
        $user = get_userdata($user_id);
        if (!$user) {
            throw new Exception('用户不存在');
        }
        
        // 获取当前授权用户列表
        $options = get_option('xk_auth_setting', array());
        $authorized_users = isset($options['authorized_users']) ? $options['authorized_users'] : array();
        
        // 检查用户是否已经在授权列表中
        if (in_array($user_id, $authorized_users)) {
            throw new Exception('用户已经在授权列表中');
        }
        
        // 添加用户到授权列表
        $authorized_users[] = $user_id;
        
        // 保存授权用户列表
        $options['authorized_users'] = $authorized_users;
        update_option('xk_auth_setting', $options);
        
        $response = array('error' => 0, 'msg' => '授权用户添加成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}

/**
 * @description: 移除授权用户
 */
function xk_auth_remove_authorized_user() {
    // 确保只返回JSON
    header('Content-Type: application/json');
    $response = array('error' => 1, 'msg' => '未知错误');
    
    try {
        // 验证请求是否为AJAX请求
        if (!wp_doing_ajax()) {
            throw new Exception('非法请求');
        }
        
        // 验证nonce
        $nonce = isset($_REQUEST['security']) ? sanitize_text_field($_REQUEST['security']) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
            throw new Exception('请求已过期，请刷新页面重试');
        }
        
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            throw new Exception('权限不足');
        }
        
        // 获取用户ID
        $user_id = isset($_REQUEST['user_id']) ? intval($_REQUEST['user_id']) : 0;
        if (!$user_id) {
            throw new Exception('用户ID无效');
        }
        
        // 获取当前授权用户列表
        $options = get_option('xk_auth_setting', array());
        $authorized_users = isset($options['authorized_users']) ? $options['authorized_users'] : array();
        
        // 检查用户是否在授权列表中
        if (!in_array($user_id, $authorized_users)) {
            throw new Exception('用户不在授权列表中');
        }
        
        // 从授权列表中移除用户
        $authorized_users = array_diff($authorized_users, array($user_id));
        
        // 保存授权用户列表
        $options['authorized_users'] = $authorized_users;
        update_option('xk_auth_setting', $options);
        
        $response = array('error' => 0, 'msg' => '授权用户移除成功');
    } catch (Exception $e) {
        $response['msg'] = $e->getMessage();
    }
    
    echo json_encode($response);
    wp_die();
}

// 注册AJAX处理函数
add_action('wp_ajax_xk_auth_get_users', 'xk_auth_get_users');
add_action('wp_ajax_xk_auth_get_authorized_users', 'xk_auth_get_authorized_users');
add_action('wp_ajax_xk_auth_add_authorized_user', 'xk_auth_add_authorized_user');
add_action('wp_ajax_xk_auth_remove_authorized_user', 'xk_auth_remove_authorized_user');

// 获取前端管理操作日志AJAX处理
function xk_auth_ajax_get_frontend_admin_logs() {
    // 验证请求是否为AJAX请求
    if (!wp_doing_ajax()) {
        wp_send_json_error(array('error' => 1, 'msg' => '非法请求'));
    }
    
    // 验证nonce
    check_ajax_referer('xk_auth_nonce', 'security');
    
    // 验证用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('error' => 1, 'msg' => '权限不足'));
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'auth_frontend_admin_logs';
    
    // 获取请求参数
    $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;
    
    // 获取总记录数
    $all_count = intval($wpdb->get_var("SELECT COUNT(*) FROM {$table_name}"));
    $total_pages = ceil($all_count / $per_page);
    
    // 查询日志数据
    $logs_list = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT %d, %d",
        $offset, $per_page
    ));
    
    // 格式化日志数据
    $formatted_frontend_admin_logs = array();
    foreach ($logs_list as $log) {
        // 格式化操作类型显示
        $action_type_map = array(
            'user_search' => array('text' => '用户搜索', 'class' => 'primary'),
            'view_authorization' => array('text' => '查看授权', 'class' => 'info'),
            'edit_authorization' => array('text' => '编辑授权', 'class' => 'warning'),
            'delete_authorization' => array('text' => '删除授权', 'class' => 'danger'),
            'add_authorization' => array('text' => '添加授权', 'class' => 'success')
        );
        
        $action_type_info = isset($action_type_map[$log->action_type]) ? $action_type_map[$log->action_type] : array('text' => ucfirst(str_replace('_', ' ', $log->action_type)), 'class' => 'default');
        
        $formatted_frontend_admin_logs[] = array(
            'id' => $log->id,
            'operator' => $log->operator,
            'actionType' => $log->action_type,
            'actionTypeText' => $action_type_info['text'],
            'actionTypeClass' => $action_type_info['class'],
            'targetUser' => $log->target_user ?: '无',
            'targetProduct' => $log->target_product ?: '无',
            'actionDetail' => $log->action_detail,
            'actionTime' => date('Y-m-d H:i:s', strtotime($log->action_time))
        );
    }
    
    // 返回JSON响应
    wp_send_json(array(
        'error' => 0,
        'frontendAdminLogs' => $formatted_frontend_admin_logs,
        'frontendAdminTotal' => $all_count,
        'frontendAdminCurrentPage' => $paged,
        'frontendAdminTotalPages' => $total_pages
    ));
}
