<?php
/*
Plugin Name: 授权插件
Plugin URI: https://www.xkzhi.cn
Description: 开发的子比主题授权插件，为子比主题提授权供扩展功能。非代码开源，只有授权部分和核心代码是加密的(这是给原作者的权益保障)
Author: 空白(二改)
Version: 1.0.3
Author URI: https://www.xkzhi.cn
*/

/**
 * 获取添加授权按钮
 *
 * 该函数用于生成一个包含添加产品授权的链接按钮，以便用户进行购买操作。
 *
 * @param string $class CSS类名（默认为空）
 * @param string $con 链接文本内容（默认为'添加授权'）
 * @return string 返回包含添加产品授权的链接按钮
 */
function xk_auth_get_increase_link($class = '', $con = '<i class="fa fa-plus" aria-hidden="true"></i> 绑定授权')
{
    // 获取用户ID
    $user_id = get_current_user_id();

    // 获取product_id，优先从GET参数获取，其次是POST参数，最后使用默认值
    $product_id = '';
    if (isset($_GET['product_id']) && !empty($_GET['product_id'])) {
        $product_id = intval($_GET['product_id']);
    } elseif (isset($_POST['product_id']) && !empty($_POST['product_id'])) {
        $product_id = intval($_POST['product_id']);
    } else {
        $default_product_id = xk_auth('default_product_id', 0);
        if (!empty($default_product_id)) {
            $product_id = intval($default_product_id);
        }
    }

    $args = array(
        'tag' => 'a',
        'data_class' => 'modal-dialog full-sm',
        'class' => $class,
        'mobile_bottom' => true,
        'height' => 400,
        'text' => $con,
        'query_arg' => array(
            'action' => 'increase_auth_modal',
            'product_id' => $product_id,
        ),
    );

    // 每次都刷新的modal
    return zib_get_refresh_modal_link($args);
}

/**
 * 获取变更授权按钮
 *
 * 该函数用于生成一个包含变更产品授权的链接按钮，以便用户进行购买操作。
 *
 * @param string $class CSS类名（默认为空）
 * @param string $con 链接文本内容（默认为'<i class="fa fa-refresh" aria-hidden="true"></i> 变更授权'）
 * @return string 返回包含变更产品授权的链接按钮
 */
function xk_auth_get_change_link($class = '', $con = '<i class="fa fa-refresh" aria-hidden="true"></i> 变更授权')
{
    // 获取用户ID
    $user_id = get_current_user_id();
    // 获取product_id，优先从GET参数获取，其次是POST参数，最后使用默认值
    $product_id = '';
    if (isset($_GET['product_id']) && !empty($_GET['product_id'])) {
        $product_id = intval($_GET['product_id']);
    } elseif (isset($_POST['product_id']) && !empty($_POST['product_id'])) {
        $product_id = intval($_POST['product_id']);
    } else {
        $default_product_id = xk_auth('default_product_id', 0);
        if (!empty($default_product_id)) {
            $product_id = intval($default_product_id);
        }
    }

    $args = array(
        'tag' => 'a',
        'data_class' => 'modal-dialog full-sm',
        'class' => $class,
        'mobile_bottom' => true,
        'height' => 400,
        'text' => $con,
        'query_arg' => array(
            'action' => 'change_auth_modal',
            'product_id' => $product_id,
        ),
    );

    //每次都刷新的modal
    return zib_get_refresh_modal_link($args);
}

/**
 * 获取绑定授权QQ按钮
 *
 * 该函数用于生成一个包含添加产品授权的链接按钮，以便用户进行购买操作。
 *
 * @param string $class CSS类名（默认为空）
 * @param string $con 链接文本内容（默认为'绑定QQ'）
 * @return string 返回包含添加产品授权的链接按钮
 */
function xk_auth_increase_qq_link($class = '', $con = '<i class="fa fa-plus" aria-hidden="true"></i> 绑定QQ')
{

    $args = array(
        'tag' => 'a',
        'data_class' => 'modal-dialog full-sm',
        'class' => $class,
        'mobile_bottom' => true,
        'height' => 400,
        'text' => $con,
        'query_arg' => array(
            'action' => 'auth_increase_qq_modal',
        ),
    );

    //每次都刷新的modal
    return zib_get_refresh_modal_link($args);
}