<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 防止直接访问文件
if (!defined('ABSPATH')) {
    die('Access denied!');
}

// 安全启动检查
function xk_auth_rewrites_secure_boot() {
    // 检查PHP版本
    if (version_compare(PHP_VERSION, '7.0.0', '<')) {
        die('授权系统要求PHP 7.0或更高版本。');
    }
    
    // 检查必要的PHP扩展
    $required_extensions = array('openssl', 'json');
    foreach ($required_extensions as $ext) {
        if (!extension_loaded($ext)) {
            die('授权系统需要PHP扩展：' . $ext);
        }
    }
    
    // 检查WordPress常量
    if (!defined('AUTH_KEY') || !defined('AUTH_SALT')) {
        die('WordPress安全常量未设置，请重新配置wp-config.php。');
    }
}
xk_auth_rewrites_secure_boot();

// 防过滤器绕过措施
function xk_auth_rewrites_prevent_filter_bypass() {
    // 移除可能的恶意过滤器
    remove_all_filters('pre_http_request');
    remove_all_filters('pre_transient');
    remove_all_filters('pre_option_Xk_Auth_License_Auth_Key');
    remove_all_filters('pre_option_Xk_Auth_License_Dynamic_Token');
    remove_all_filters('pre_option_Xk_Auth_License_Signature');
}

// 增强的过滤器清理，在关键操作前调用
function xk_auth_rewrites_ensure_clean_filters() {
    // 立即清理过滤器
    xk_auth_rewrites_prevent_filter_bypass();
    
    // 验证过滤器是否真的被清理
    $http_request_filters = has_filter('pre_http_request');
    $transient_filters = has_filter('pre_transient');
    $option_filters = has_filter('pre_option_Xk_Auth_License_Auth_Key');
    
    if ($http_request_filters || $transient_filters || $option_filters) {
        // 过滤器清理失败，可能存在深层注入
        die('授权系统检测到安全异常：无法清理可疑过滤器。请检查系统环境后重新安装插件。');
    }
    
    // 检查是否有可疑的钩子添加
    global $wp_filter;
    if (isset($wp_filter['pre_http_request']) || isset($wp_filter['pre_transient'])) {
        die('授权系统检测到安全异常：发现可疑的过滤器注册。');
    }
}

// 在plugins_loaded钩子上运行，更早清理过滤器
add_action('plugins_loaded', 'xk_auth_rewrites_prevent_filter_bypass', 1);

// 定期清理机制
function xk_auth_rewrites_schedule_filter_cleanup() {
    if (!wp_next_scheduled('xk_auth_rewrites_filter_cleanup')) {
        wp_schedule_event(time(), 'twicedaily', 'xk_auth_rewrites_filter_cleanup');
    }
}
add_action('wp', 'xk_auth_rewrites_schedule_filter_cleanup');

function xk_auth_rewrites_filter_cleanup_callback() {
    xk_auth_rewrites_prevent_filter_bypass();
}
add_action('xk_auth_rewrites_filter_cleanup', 'xk_auth_rewrites_filter_cleanup_callback');

/** 
 * 此文件为授权验证API文件，请勿泄露此文件！
 */

/**
 * 注册定时任务，定期向被授权站推送动态Token
 */
add_action('wp', 'xk_auth_schedule_push_token_cron');
function xk_auth_schedule_push_token_cron() {
    if (!wp_next_scheduled('xk_auth_push_dynamic_token')) {
        wp_schedule_event(time(), 'hourly', 'xk_auth_push_dynamic_token');
        error_log('[星空授权] 已注册定时任务：xk_auth_push_dynamic_token，每小时执行一次');
    }
}

/**
 * 定时任务回调函数：向超过12小时未通讯的站点推送动态Token
 */
add_action('xk_auth_push_dynamic_token', 'xk_auth_push_dynamic_token_callback');
function xk_auth_push_dynamic_token_callback() {
    global $wpdb;
    
    // 检查是否需要执行推送任务（可通过设置控制）
    $enable_push = xk_auth('enable_token_push', true);
    if (!$enable_push) {
        return;
    }
    
    $table_name = $wpdb->prefix . 'product_auths';
    $current_time = time();
    $two_hours_ago = $current_time - 7200;
    
    // 获取所有超过2小时未通讯的有效授权站点，限制每次最多处理10个站点
    $auth_sites = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE status = 1 AND (last_communication_time IS NULL OR UNIX_TIMESTAMP(last_communication_time) < %d) LIMIT 10",
        $two_hours_ago
    ));
    
    $site_count = count($auth_sites);
    
    if (empty($auth_sites)) {
        return;
    }
    
    foreach ($auth_sites as $site) {
        // 生成新的动态Token
        $dynamic_token = xk_auth_generate_dynamic_token($site->product_id, $site->domain, $site->auth_key);
        
        // 加密存储授权码+动态token
        $encrypted_auth_data = xk_auth_encrypt_auth_data($site->auth_key, $dynamic_token['token'], $dynamic_token['timestamp']);
        xk_auth_store_encrypted_auth_data($site->product_id, $site->domain, $encrypted_auth_data);
        
        // 尝试向被授权站推送Token，超时时间设置为5秒
        $push_result = xk_auth_push_token_to_site($site, $dynamic_token, $encrypted_auth_data);
    }
}

/**
 * 向被授权站推送动态Token
 * @param object $site 授权站点信息
 * @param array $dynamic_token 动态Token数据
 * @param string $encrypted_auth_data 加密的授权数据
 * @return bool 推送是否成功
 */
function xk_auth_push_token_to_site($site, $dynamic_token, $encrypted_auth_data) {
    global $wpdb;
    
    // 确保域名包含正确的协议
    $domain = $site->domain;
    if (!preg_match('/^https?:\/\//i', $domain)) {
        // 如果没有协议，添加默认协议http
        $domain = 'http://' . $domain;
    }
    
    // 构建推送URL（假设被授权站有接收Token的API接口）
    // 注意：这里需要被授权站配合实现接收Token的API
    $push_url = rtrim($domain, '/') . '/wp-json/xk-auth/v1/receive-token';
    
    // 构建推送数据
    $push_data = array(
        'product_id' => $site->product_id,
        'domain' => $site->domain,
        'auth_key' => $site->auth_key,
        'dynamic_token' => $dynamic_token['token'],
        'expire_time' => $dynamic_token['expire_time'],
        'timestamp' => $dynamic_token['timestamp'],
        'encrypted_auth_data' => $encrypted_auth_data
    );
    
    // 发送推送请求
    $response = wp_remote_post($push_url, array(
        'timeout' => 15,
        'headers' => array(
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($push_data),
    ));
    
    
    if (is_wp_error($response)) {
        // 推送失败，记录详细错误信息
        $error_message = $response->get_error_message();

        
        // 获取服务器真实IP地址
        $server_ip = $_SERVER['SERVER_ADDR'] ?? 'unknown';
        xk_auth_insert_request_log(
            $site->product_id,
            $server_ip,
            $site->domain,
            $site->auth_key,
            'failed_push_token',
            array('error_message' => $error_message, 'push_url' => $push_url)
        );
        return false;
    } else {
        // 检查HTTP响应码
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        
        // 检查响应是否成功
        if ($response_code == 200) {
            $response_data = json_decode($response_body, true);
            if (isset($response_data['status']) && $response_data['status'] == 1) {
                // 推送成功
                // 获取服务器真实IP地址
                $server_ip = $_SERVER['SERVER_ADDR'] ?? 'unknown';
                xk_auth_insert_request_log(
                    $site->product_id,
                    $server_ip,
                    $site->domain,
                    $site->auth_key,
                    'success_push_token',
                    array('response_code' => $response_code, 'response_body' => $response_body)
                );
                return true;
            } else {
                // 响应内容表示失败
                $error_message = isset($response_data['message']) ? $response_data['message'] : '响应内容无效';
                
                // 获取服务器真实IP地址
                $server_ip = $_SERVER['SERVER_ADDR'] ?? 'unknown';
                xk_auth_insert_request_log(
                    $site->product_id,
                    $server_ip,
                    $site->domain,
                    $site->auth_key,
                    'failed_push_token_response',
                    array('response_code' => $response_code, 'response_body' => $response_body, 'error_message' => $error_message)
                );
                return false;
            }
        } else {
            
            // 获取服务器真实IP地址
            $server_ip = $_SERVER['SERVER_ADDR'] ?? 'unknown';
            xk_auth_insert_request_log(
                $site->product_id,
                $server_ip,
                $site->domain,
                $site->auth_key,
                'failed_push_token_http',
                array('response_code' => $response_code, 'response_body' => $response_body)
            );
            return false;
        }
    }
}

/**
 * 检查请求冷却时间
 * @param string $request_type 请求类型（auth, update, notice, token）
 * @param string $identifier 标识符（IP或域名）
 * @param int $cool_down_time 冷却时间（秒）
 * @param array $rate_limit 速率限制配置（可选），格式：array('max_requests' => 5, 'time_window' => 60)
 * @return bool|array 成功返回true，失败返回包含错误信息的数组
 */
function xk_auth_check_request_cooldown($request_type, $identifier, $cool_down_time = 60, $rate_limit = array()) {
    // 检查是否开启了API请求限制
    $enable_limit = xk_auth('enable_api_rate_limit', false);
    if (!$enable_limit) {
        return true;
    }
    
    // 获取全局API速率限制设置
    $global_max_requests = xk_auth('api_rate_limit_count', 5);
    $global_time_window = xk_auth('api_rate_limit_time', 60);
    $global_limit_message = xk_auth('api_rate_limit_message', '请求过于频繁，请稍后重试');
    
    // 冷却时间和时间窗口使用相同的值，这样用户设置的时间就是冷却时间
    $global_cool_down_time = $global_time_window;
    
    // 特殊处理token请求，设置默认速率限制
    if ($request_type === 'token' && empty($rate_limit)) {
        $rate_limit = array(
            'max_requests' => $global_max_requests,
            'time_window' => $global_time_window,
            'cool_down_time' => $global_cool_down_time
        );
    } elseif (empty($rate_limit)) {
        // 使用全局设置
        $rate_limit = array(
            'max_requests' => $global_max_requests,
            'time_window' => $global_time_window,
            'cool_down_time' => $global_cool_down_time
        );
    }
    
    // 如果有速率限制配置，检查请求次数
    if (!empty($rate_limit) && isset($rate_limit['max_requests'], $rate_limit['time_window'])) {
        $max_requests = $rate_limit['max_requests'];
        $time_window = $rate_limit['time_window'];
        $cool_down_time = isset($rate_limit['cool_down_time']) ? $rate_limit['cool_down_time'] : $cool_down_time;
        
        $requests_key = 'xk_auth_' . $request_type . '_requests_' . md5($identifier);
        $cooldown_key = 'xk_auth_' . $request_type . '_cooldown_' . md5($identifier);
        
        // 检查是否在冷却期
        $cooling_down = get_transient($cooldown_key);
        if ($cooling_down) {
            $remaining_time = $cool_down_time - (time() - $cooling_down);
            return array(
                'status' => 0,
                'message' => $global_limit_message,
                'cooldown_remaining' => $remaining_time
            );
        }
        
        // 获取请求次数和时间戳数组
        $requests = get_transient($requests_key);
        if (!is_array($requests)) {
            $requests = array();
        }
        
        // 清理过期的请求记录
        $current_time = time();
        $valid_requests = array_filter($requests, function($timestamp) use ($current_time, $time_window) {
            return ($current_time - $timestamp) < $time_window;
        });
        
        // 检查请求次数是否超过限制
        if (count($valid_requests) >= $max_requests) {
            // 设置冷却期
            set_transient($cooldown_key, $current_time, $cool_down_time);
            return array(
                'status' => 0,
                'message' => $global_limit_message,
                'cooldown_remaining' => $cool_down_time
            );
        }
        
        // 添加当前请求记录
        $valid_requests[] = $current_time;
        set_transient($requests_key, $valid_requests, $time_window);
        
        return true;
    }
    
    // 原有逻辑：只检查冷却时间
    $cache_key = 'xk_auth_' . $request_type . '_cooldown_' . md5($identifier);
    $last_request_time = get_transient($cache_key);
    
    if ($last_request_time && (time() - $last_request_time) < $cool_down_time) {
        $remaining_time = $cool_down_time - (time() - $last_request_time);
        return array(
            'status' => 0,
            'message' => '请求过于频繁，请等待' . $remaining_time . '秒后重试',
            'cooldown_remaining' => $remaining_time
        );
    }
    
    set_transient($cache_key, time(), $cool_down_time);
    return true;
}

/**
 * 注册接收Token推送的API路由（供被授权站使用）
 */
add_action('rest_api_init', function () {
    register_rest_route(
        'xk-auth/v1',
        '/receive-token',
        array(
            'methods' => 'POST',
            'callback' => 'xk_auth_receive_token_callback',
            'permission_callback' => '__return_true'
        )
    );
});

/**
 * 处理接收Token推送的回调函数（供被授权站使用）
 */
function xk_auth_receive_token_callback($request)
{
    // 确保过滤器被清理
    xk_auth_rewrites_ensure_clean_filters();
    
    // 检查请求频率限制
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $cooldown_check = xk_auth_check_request_cooldown('token_receive', $ip);
    if ($cooldown_check !== true) {
        return new WP_REST_Response($cooldown_check, 429);
    }
    
    // 支持GET和POST请求，正确处理JSON格式的POST请求
    if (is_array($request)) {
        $data = $request;
    } else {
        // 检查请求方法
        $method = $request->get_method();
        
        if ($method === 'POST') {
            // 对于POST请求，先尝试获取JSON请求体
            $json_body = $request->get_json_params();
            if (!empty($json_body)) {
                $data = $json_body;
            } else {
                // 如果没有JSON请求体，再尝试获取普通参数
                $data = $request->get_params();
            }
        } else {
            // 对于GET请求，直接获取参数
            $data = $request->get_params();
        }
    }
    
    
    // 验证必要参数
    $required_params = ['product_id', 'domain', 'auth_key', 'dynamic_token'];
    $missing_params = [];
    
    foreach ($required_params as $param) {
        if (!isset($data[$param]) || empty(trim($data[$param]))) {
            $missing_params[] = $param;
        }
    }
    
    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }
    
    // 存储接收到的Token（被授权站需要实现此函数）
    // 注意：被授权站需要根据自己的需求实现Token存储逻辑
    do_action('xk_auth_store_received_token', $data);
    
    error_log('[星空授权] Token接收成功: product_id=' . $data['product_id'] . ', domain=' . $data['domain']);
    
    return new WP_REST_Response(
        ['status' => 1, 'message' => 'Token接收成功'],
        200
    );
}

// 注册插件需要的路由 - 支持三重验证（域名+授权码+动态token）
add_action('rest_api_init', function () {
    // 确保获取到的是字符串，避免trim()函数接收数组参数
    $authorization = (string)xk_auth('auth_api', '', 'authorization');
    $authorization_key = (string)xk_auth('auth_api', '', 'authorization_key');
    
    // 只在authorization和authorization_key都有值时注册路由
    if (!empty($authorization) && !empty($authorization_key)) {
        $namespace = ltrim(rtrim(trim($authorization), '/'), '/');
        $route = '/' . ltrim(trim($authorization_key), '/');

        register_rest_route(
            $namespace,
            $route,
            array(
                'methods' => array('GET', 'POST'),
                'callback' => 'xk_auth_product_api',
                'permission_callback' => '__return_true'
            )
        );
    }
});

/**
 * 处理授权验证的回调函数 - 实现三重验证（域名+授权码+动态token）
 */
function xk_auth_product_api($data)
{
    // 确保过滤器被清理
    xk_auth_rewrites_ensure_clean_filters();
    
    global $wpdb;

    // 检查是否是授权请求（生成动态Token）
    $is_auth_request = isset($data['action']) && ($data['action'] == 'auth_request' || $data['action'] == 'get_dynamic_token');
    
    // 检查请求冷却时间
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!$is_auth_request) {
        $cooldown_check = xk_auth_check_request_cooldown('auth', $ip); // 使用全局设置的冷却时间
        if ($cooldown_check !== true) {
            return new WP_REST_Response($cooldown_check, 429);
        }
    } else {
        // 对于获取动态Token的请求，应用相同的频率限制：1分钟内最多5次请求，超过冷却120秒
        $cooldown_check = xk_auth_check_request_cooldown('token', $ip);
        if ($cooldown_check !== true) {
            return new WP_REST_Response($cooldown_check, 429);
        }
    }
    
    // 增强API请求验证，防止模拟主站API服务器攻击
    $api_timestamp = isset($data['api_timestamp']) ? intval($data['api_timestamp']) : 0;
    
    // 验证时间戳是否在合理范围内（前后5分钟）
    $current_time = time();
    if ($api_timestamp && abs($current_time - $api_timestamp) > 300) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => 'API请求时间戳无效'],
            401
        );
    }
    
    // 如果是授权请求，只需要基本参数
    if ($is_auth_request) {
        $required_params = ['product_id', 'domain', 'auth_key'];
    } else {
        // 普通验证请求需要完整的三重验证参数
        $required_params = ['product_id', 'domain', 'auth_key', 'dynamic_token'];
    }
    
    $missing_params = [];

    foreach ($required_params as $param) {
        if (!isset($data[$param]) || empty(trim($data[$param]))) {
            $missing_params[] = $param;
        }
    }

    // 初始化变量，防止未定义错误
    $product_id = 0;
    $domain = '';
    $auth_key = '';
    $error_reason = '授权验证失败，未知错误'; // 初始化错误原因变量
    
    // 尝试从请求中获取参数，用于日志记录
    if (isset($data['product_id'])) {
        $product_id = intval($data['product_id']);
    }
    if (isset($data['domain'])) {
        $domain = sanitize_text_field(trim($data['domain']));
    }
    if (isset($data['auth_key'])) {
        $auth_key = sanitize_text_field(trim($data['auth_key']));
    }
    
    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        
        // 记录日志
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_missing_params'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }

    // 重新获取并验证参数
    $product_id = intval($data['product_id']);
    $domain = sanitize_text_field(trim($data['domain']));
    $auth_key = sanitize_text_field(trim($data['auth_key']));

    // 1. 验证product_id
    if ($product_id <= 0) {
        // 记录日志
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_invalid_product_id'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => 'product_id必须为有效的正整数'],
            400
        );
    }
    
    // 2. 验证域名格式
    $domain = strtolower($domain);
    if (!filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        // 尝试处理IP地址格式
        if (!filter_var($domain, FILTER_VALIDATE_IP)) {
            // 记录日志
            xk_auth_insert_request_log(
                $product_id,
                $ip,
                $domain,
                $auth_key,
                'failed_invalid_domain'
            );
            
            return new WP_REST_Response(
                ['status' => 0, 'message' => '域名格式无效'],
                400
            );
        }
    }
    
    // 3. 验证授权码格式（假设授权码为32位或64位字符串）
    $auth_key_length = strlen($auth_key);
    if (!preg_match('/^[a-zA-Z0-9]{32,64}$/', $auth_key)) {
        // 记录日志
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_invalid_auth_key'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权码格式无效'],
            400
        );
    }
    
    // 4. 验证IP地址格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = 'unknown';
    }
    

    $table_name = $wpdb->prefix . 'product_auths';
    // 获取当前时间用于到期时间检查
    $current_time = current_time('mysql');
    $current_timestamp = time();
    
    // 检查数据库中的授权记录
    $auth_record = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE product_id = %d AND domain = %s AND auth_key = %s",
        $product_id,
        $domain,
        $auth_key
    ));
    
    // 如果是授权请求（生成动态Token）
    if ($is_auth_request) {
        // 检查授权记录是否存在且有效
        if (!$auth_record || $auth_record->status != 1) {
            // 记录日志
            xk_auth_insert_request_log(
                $product_id,
                $ip,
                $domain,
                $auth_key,
                'failed_auth_record_invalid'
            );
            
            return new WP_REST_Response(
                ['status' => 0, 'message' => '授权记录不存在或无效'],
                401
            );
        }
        
        // 如果存在记录但已过期且状态仍为有效，则自动更新状态为无效
        if ($auth_record->expire_time && strtotime($auth_record->expire_time) < $current_timestamp) {
            $wpdb->update(
                $table_name,
                array('status' => 0),
                array('id' => $auth_record->id),
                array('%d'),
                array('%d')
            );
            
            // 记录日志
            xk_auth_insert_request_log(
                $product_id,
                $ip,
                $domain,
                $auth_key,
                'failed_auth_expired'
            );
            
            return new WP_REST_Response(
                ['status' => 0, 'message' => '授权已过期'],
                401
            );
        }
        
        // 生成动态Token
        $dynamic_token = xk_auth_generate_dynamic_token($product_id, $domain, $auth_key);
        
        // 加密存储授权码+动态token
        $encrypted_auth_data = xk_auth_encrypt_auth_data($auth_key, $dynamic_token['token'], $dynamic_token['timestamp']);
        xk_auth_store_encrypted_auth_data($product_id, $domain, $encrypted_auth_data);
        
        // 记录token生成日志
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'token_generated_for_auth'
        );
        
        // 更新最后通讯时间
        update_option('xk_auth_last_communication_' . $product_id . '_' . $domain, $current_timestamp);
        
        // 获取产品名称
        $product_name = '未知产品';
        $product_settings = xk_auth('product_settings', array());
        
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (is_array($product) && isset($product['product_id']) && strval($product['product_id']) === strval($product_id)) {
                    $product_name = isset($product['product_name']) && !empty($product['product_name'])
                        ? sanitize_text_field($product['product_name'])
                        : '未命名产品';
                    break;
                }
            }
        }
        
        // 返回动态Token到被授权站
        return new WP_REST_Response(
            [
                'status' => 1,
                'message' => '授权请求成功，动态Token已生成',
                'dynamic_token' => $dynamic_token['token'],
                'expire_time' => $dynamic_token['expire_time'],
                'timestamp' => $dynamic_token['timestamp'],
                'token_type' => 'triple_verification',
                'product_name' => $product_name,
                'encrypted_auth_data' => $encrypted_auth_data,
                'expire_in' => 1800 // 30分钟过期
            ],
            200
        );
    }
    
    // 普通验证请求，继续执行完整的三重验证逻辑
    // 注意：动态Token是Base64编码的，不能使用sanitize_text_field()处理，否则会破坏Token
    $dynamic_token = trim($data['dynamic_token']);
    // 修复URL传输问题：将空格替换回+字符（因为Base64中的+在URL中会被替换为空格）
    $dynamic_token = str_replace(' ', '+', $dynamic_token);
    
    // 1. 验证动态token（第一重验证：动态token有效性）
    $token_verify_result = xk_auth_validate_dynamic_token($dynamic_token);
    if (!$token_verify_result['valid']) {
        // 记录验证结果到日志表
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_token_invalid'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '动态Token无效或已过期'],
            401
        );
    }
    
    // 提取验证成功后的token数据
    $token_data = $token_verify_result['token_data'];
    
    // 2. 验证token中的授权信息是否匹配（第二重验证：域名+授权码）
    if ($token_data['product_id'] != $product_id || $token_data['domain'] != $domain || $token_data['auth_key'] != $auth_key) {
        // 记录验证结果到日志表
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_token_mismatch'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '动态Token与授权信息不匹配'],
            401
        );
    }
    
    // 3. 检查7200秒（2小时）离线授权（第三重验证：通讯时效性）
    // 优先检查数据库中的last_communication_time（主站主动推送会更新此字段）
    $last_communication_time = $auth_record->last_communication_time ? strtotime($auth_record->last_communication_time) : 0;
    
    // 同时检查WordPress选项中的记录（兼容旧版本）
    $wp_option_time = get_option('xk_auth_last_communication_' . $product_id . '_' . $domain, 0);
    
    $last_communication_time = max($last_communication_time, $wp_option_time);
    
    if ($last_communication_time > 0 && ($current_timestamp - $last_communication_time) > 7200) {
        // 记录验证结果到日志表
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_offline_expired'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '超过10800秒未与主站通讯，授权已失效'],
            401
        );
    }
    
    // 4. 检查授权记录是否存在且有效（第四重验证：基础授权有效性）
    if (!$auth_record || $auth_record->status != 1) {
        // 记录验证结果到日志表
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_auth_invalid'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权记录不存在或无效'],
            401
        );
    }
    
    // 5. 检查授权是否过期（第五重验证：授权时效性）
    if ($auth_record->expire_time && strtotime($auth_record->expire_time) < $current_timestamp) {
        // 自动更新状态为无效
        $wpdb->update(
            $table_name,
            array('status' => 0),
            array('id' => $auth_record->id),
            array('%d'),
            array('%d')
        );
        
        // 记录验证结果到日志表
        xk_auth_insert_request_log(
            $product_id,
            $ip,
            $domain,
            $auth_key,
            'failed_auth_expired'
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权已过期'],
            401
        );
    }
    
    // 所有验证通过，更新最后通讯时间
    update_option('xk_auth_last_communication_' . $product_id . '_' . $domain, $current_timestamp);
    
    // 更新数据库中的最后通讯时间
    $wpdb->update(
        $table_name,
        array('last_communication_time' => $current_time),
        array('id' => $auth_record->id),
        array('%s'),
        array('%d')
    );
    
    // 使用已验证的授权记录作为结果
    $result = $auth_record;

    // 记录验证结果到日志表
    $final_status = $result ? 'success_triple_verified' : 'failed_unknown';
    
    // 使用统一日志函数插入日志
    xk_auth_insert_request_log(
        $product_id,
        $ip,
        $domain,
        $auth_key,
        $final_status
    );

    if ($result) {
        
        // 获取用户信息
        $user_info = get_userdata($result->user_id);
        $username = $user_info ? $user_info->user_login : '未知用户';

        // 获取产品名称
        $product_name = '未知产品'; // 默认值
        $product_settings = xk_auth('product_settings', array());

        // 确保产品设置存在且为数组
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                // 确保product数组包含必要的字段
                if (is_array($product) && isset($product['product_id'])) {
                    // 使用字符串比较，避免类型转换问题
                    if (strval($product['product_id']) === strval($result->product_id)) {
                        $product_name = isset($product['product_name']) && !empty($product['product_name'])
                            ? sanitize_text_field($product['product_name'])
                            : '未命名产品';
                        break;
                    }
                }
            }
        }

        // 格式化授权有效期
        $expire_time = $result->expire_time;
        $expire_time_text = $expire_time ? date('Y-m-d H:i:s', strtotime($expire_time)) : '永久';

        return new WP_REST_Response(
            [
                'status' => 1,
                'message' => '恭喜您，授权验证成功',
                'username' => $username,
                'product_name' => $product_name,
                'expire_time' => $expire_time_text,
                'last_communication' => $current_timestamp,
                'verification_type' => 'triple_verification',
                'token_expire' => $token_data['expire_time']
            ],
            200
        );
    } else {
        // 确保有明确的错误消息
        $error_reason = '授权验证失败，未找到有效的授权记录';
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_reason],
            401
        );
    }
}

/**
 * 注册产品更新API路由
 */
add_action('rest_api_init', function () {
    $update_api_settings = xk_auth('update_api', array());
    $update_namespace = !empty($update_api_settings['pdate']) ? trim($update_api_settings['pdate']) : 'Update/v1';
    $update_route_key = !empty($update_api_settings['update_key']) ? trim($update_api_settings['update_key']) : 'key';

    $namespace = ltrim(rtrim($update_namespace, '/'), '/');
    $route = '/' . ltrim($update_route_key, '/');

    register_rest_route(
        $namespace,
        $route,
        array(
            'methods' => 'GET',
            'callback' => 'xk_auth_update_check_api',
            'permission_callback' => '__return_true'
        )
    );
});

/**
 * 处理更新检查的回调函数 - 添加动态Token验证
 */
function xk_auth_update_check_api($data)
{
    // 确保过滤器被清理
    xk_auth_rewrites_ensure_clean_filters();
    
    global $wpdb;

    // 检查请求冷却时间
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $cooldown_check = xk_auth_check_request_cooldown('update', $ip); // 使用全局设置的冷却时间
    if ($cooldown_check !== true) {
        return new WP_REST_Response($cooldown_check, 429);
    }

    // 检查是否是授权请求（生成动态Token）
    $is_auth_request = isset($data['action']) && ($data['action'] == 'auth_request' || $data['action'] == 'get_dynamic_token');
    
    // 如果是授权请求，只需要基本参数
    if ($is_auth_request) {
        $required_params = ['product_id', 'domain', 'auth_key', 'current_version'];
    } else {
        // 普通验证请求需要完整的三重验证参数
        $required_params = ['product_id', 'domain', 'auth_key', 'current_version', 'dynamic_token'];
    }
    
    $missing_params = [];

    foreach ($required_params as $param) {
        if (!isset($data[$param]) || empty(trim($data[$param]))) {
            $missing_params[] = $param;
        }
    }

    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }

    $product_id = intval($data['product_id']);
    $domain = sanitize_text_field(trim($data['domain']));
    $auth_key = sanitize_text_field(trim($data['auth_key']));
    $current_version = sanitize_text_field(trim($data['current_version']));

    if ($product_id <= 0) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => 'product_id必须为有效的正整数'],
            400
        );
    }

    // 验证域名格式
    $domain = strtolower($domain);
    if (!filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        // 尝试处理IP地址格式
        if (!filter_var($domain, FILTER_VALIDATE_IP)) {
            return new WP_REST_Response(
                ['status' => 0, 'message' => '域名格式无效'],
                400
            );
        }
    }

    // 验证授权码格式（假设授权码为32位或64位字符串）
    $auth_key_length = strlen($auth_key);
    if (!preg_match('/^[a-zA-Z0-9]{32,64}$/', $auth_key)) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权码格式无效'],
            400
        );
    }

    // 如果是普通验证请求，验证动态Token格式和有效性
        if (!$is_auth_request) {
            // 注意：动态Token是Base64编码的，不能使用sanitize_text_field()处理，否则会破坏Token
            $dynamic_token = trim($data['dynamic_token']);
            // 修复URL传输问题：将空格替换回+字符（因为Base64中的+在URL中会被替换为空格）
            $dynamic_token = str_replace(' ', '+', $dynamic_token);
            
            // 1. 验证动态Token格式
            if (!preg_match('/^[a-zA-Z0-9+\/=]+$/', $dynamic_token)) {
                return new WP_REST_Response(
                    ['status' => 0, 'message' => '动态Token格式无效'],
                    400
                );
            }
            
            // 2. 验证动态Token有效性
            $token_verify_result = xk_auth_validate_dynamic_token($dynamic_token);
            if (!$token_verify_result['valid']) {
                return new WP_REST_Response(
                    ['status' => 0, 'message' => $token_verify_result['message']],
                    401
                );
            }
            
            // 3. 提取验证成功后的token数据
            $token_data = $token_verify_result['token_data'];
        }

    $auth_table = $wpdb->prefix . 'product_auths';
    $auth_result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $auth_table WHERE product_id = %d AND domain = %s AND auth_key = %s AND status = 1",
        $product_id,
        $domain,
        $auth_key
    ));

    $table_name = $wpdb->prefix . 'product_auths';
    // 获取当前时间用于到期时间检查
    $current_time = current_time('mysql');

    $result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE product_id = %d AND domain = %s AND auth_key = %s AND status = 1 AND (expire_time IS NULL OR expire_time > %s)",
        $product_id,
        $domain,
        $auth_key,
        $current_time
    ));

    // 记录验证结果到日志表
    $log_table = $wpdb->prefix . 'auth_request_logs';
    $status = $result ? 'success' : 'failed';
    $current_time = current_time('mysql'); // 获取当前时间

    $wpdb->insert(
        $log_table,
        array(
            'product_id' => $product_id,
            'ip' => $ip,
            'domain' => $domain,
            'auth_key' => $auth_key,
            'status' => $status,
            'operation_time' => $current_time
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s') // 修复：添加第六个占位符对应operation_time
    );

    if (!$auth_result) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权验证失败，无法检查更新'],
            401
        );
    }

    // 获取用户ID
    $user_id = 0;
    if ($auth_result) {
        $user_id = intval($auth_result->user_id);
    }

    // 首先检查是否有指定ID推送的更新，包括全部更新
    $update_table = $wpdb->prefix . 'product_update';
    $targeted_push_table = $wpdb->prefix . 'product_targeted_push';

    // 检查指定ID推送的更新（包括全部更新）
    $targeted_update = $wpdb->get_row($wpdb->prepare(
        "SELECT u.* 
         FROM {$update_table} u 
         JOIN {$targeted_push_table} tp ON u.id = tp.update_id 
         WHERE u.product_id = %d AND u.push_status = 1 
         AND ((tp.target_type = 'user_id' AND tp.target_value = %d) OR 
              (tp.target_type = 'domain' AND tp.target_value = %s) OR 
              (tp.target_type = 'all' AND tp.target_value = 'all')) 
         ORDER BY u.id DESC LIMIT 1",
        $product_id,
        $user_id,
        $domain
    ));

    // 如果没有找到指定ID推送的更新，再检查普通更新
    $latest_update = null;
    if (!$targeted_update) {
        $latest_update = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $update_table 
             WHERE product_id = %d 
               AND push_status = 1 
               AND NOT EXISTS (SELECT 1 FROM {$targeted_push_table} tp WHERE tp.update_id = $update_table.id) 
             ORDER BY version DESC 
             LIMIT 1",
            $product_id
        ));
    } else {
        // 使用指定ID推送的更新
        $latest_update = $targeted_update;
    }

    // 记录验证结果到日志表
    $log_table = $wpdb->prefix . 'product_update_log';
    $status = 'success';
    $current_time = current_time('mysql'); // 获取当前时间

    // 检查并删除超过500条的日志
    xk_auth_manage_logs($log_table);

    $wpdb->insert(
        $log_table,
        array(
            'product_id' => $product_id,
            'ip' => $ip,
            'domain' => $domain,
            'current_version' => $current_version,
            'status' => $status,
            'operation_time' => $current_time
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s') // 修复：添加第六个占位符对应operation_time
    );

    if (!$latest_update) {
        return new WP_REST_Response(
            [
                'status' => 1,
                'message' => '当前已是最新版本',
                'has_update' => false,
                'current_version' => $current_version
            ],
            200
        );
    }

    // 检查当前版本是否在original_versions列表中
    $original_versions = !empty($latest_update->original_versions) ? $latest_update->original_versions : '';
    $is_version_allowed = true;
    
    if (!empty($original_versions)) {
        try {
            // 解析版本列表
            $version_array = array_filter(array_map('trim', explode("\n", $original_versions)));
            $temp_array = array();
            foreach ($version_array as $version) {
                if (!empty($version)) {
                    $temp_array = array_merge($temp_array, array_filter(array_map('trim', explode(',', $version))));
                }
            }
            $allowed_versions = array_values(array_unique($temp_array)); // 去重并重新索引
            
            // 标准化当前版本号（移除空格等）
            $current_version_clean = preg_replace('/[^0-9a-zA-Z.-]/', '', $current_version);
            
            // 检查当前版本是否在允许列表中
            if (!empty($allowed_versions)) {
                $is_version_allowed = false;
                
                foreach ($allowed_versions as $allowed_version) {
                    // 标准化允许版本号
                    $allowed_version_clean = preg_replace('/[^0-9a-zA-Z.-]/', '', $allowed_version);
                    
                    // 1. 精确匹配
                    if ($current_version_clean === $allowed_version_clean) {
                        $is_version_allowed = true;
                        break;
                    }
                    
                    // 2. 通配符支持（如 1.2.* 匹配 1.2.1, 1.2.2 等）
                    if (strpos($allowed_version_clean, '*') !== false) {
                        // 将通配符转换为正则表达式
                        $pattern = str_replace('*', '[0-9a-zA-Z.-]*', preg_quote($allowed_version_clean, '/'));
                        if (preg_match('/^' . $pattern . '$/', $current_version_clean)) {
                            $is_version_allowed = true;
                            break;
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // 记录错误但不阻止更新（容错处理）
            error_log('版本判断逻辑异常: ' . $e->getMessage());
        }
    } else {
        // 没有指定允许的版本列表，默认允许所有版本
        $is_version_allowed = true;
    }
    
    // 如果当前版本不在允许列表中，不返回更新
    if (!$is_version_allowed) {
        return new WP_REST_Response(
            [
                'status' => 1,
                'message' => '当前已是最新版本',
                'has_update' => false,
                'current_version' => $current_version,
                'latest_version' => $latest_update->version
            ],
            200
        );
    }

    $version_compare = version_compare($current_version, $latest_update->version);
    if ($version_compare >= 0) {
        return new WP_REST_Response(
            [
                'status' => 1,
                'message' => '当前已是最新版本',
                'has_update' => false,
                'current_version' => $current_version,
                'latest_version' => $latest_update->version
            ],
            200
        );
    }

    return new WP_REST_Response(
        [
            'status' => 1,
            'message' => '检测到可用更新',
            'has_update' => true,
            'current_version' => $current_version,
            'latest_version' => $latest_update->version,
            'update_url' => $latest_update->update_package_url,
            'update_description' => $latest_update->update_description,
            'release_time' => $latest_update->operation_time
        ],
        200
    );
}

/**
 * 注册公告API路由
 */
add_action('rest_api_init', function () {
    $notice_api_settings = xk_auth('notice_api', array());
    $notice_namespace = !empty($notice_api_settings['notice']) ? trim($notice_api_settings['notice']) : 'Notice/v1';
    $notice_route_key = !empty($notice_api_settings['notice_key']) ? trim($notice_api_settings['notice_key']) : 'key';

    $namespace = ltrim(rtrim($notice_namespace, '/'), '/');
    $route = '/' . ltrim($notice_route_key, '/');

    register_rest_route(
        $namespace,
        $route,
        array(
            'methods' => 'GET',
            'callback' => 'xk_auth_notice_api',
            'permission_callback' => '__return_true'
        )
    );
});

/**
 * 注册动态Token API路由 - 支持三重验证
 */
add_action('rest_api_init', function () {
    $dynamic_token_settings = xk_auth('dynamic_token_api', array());
    $dynamic_namespace = !empty($dynamic_token_settings['namespace']) ? trim($dynamic_token_settings['namespace']) : 'DynamicToken/v1';
    $dynamic_route_key = !empty($dynamic_token_settings['route_key']) ? trim($dynamic_token_settings['route_key']) : 'token';

    $namespace = ltrim(rtrim($dynamic_namespace, '/'), '/');
    $route = '/' . ltrim($dynamic_route_key, '/');

    register_rest_route(
        $namespace,
        $route,
        array(
            'methods' => array('GET', 'POST'),
            'callback' => 'xk_auth_get_dynamic_token',
            'permission_callback' => '__return_true'
        )
    );
});

/**
 * 注册动态Token验证API路由 - 支持三重验证
 */
add_action('rest_api_init', function () {
    $dynamic_token_settings = xk_auth('dynamic_token_api', array());
    $dynamic_namespace = !empty($dynamic_token_settings['namespace']) ? trim($dynamic_token_settings['namespace']) : 'DynamicToken/v1';
    $dynamic_verify_route = '/verify';

    $namespace = ltrim(rtrim($dynamic_namespace, '/'), '/');

    register_rest_route(
        $namespace,
        $dynamic_verify_route,
        array(
            'methods' => array('GET', 'POST'),
            'callback' => 'xk_auth_verify_dynamic_token',
            'permission_callback' => '__return_true'
        )
    );
});

/**
 * 处理公告请求的回调函数 - 添加动态Token验证
 */
function xk_auth_notice_api($data)
{
    // 确保过滤器被清理
    xk_auth_rewrites_ensure_clean_filters();
    
    global $wpdb;

    // 检查请求冷却时间
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $cooldown_check = xk_auth_check_request_cooldown('notice', $ip); // 使用全局设置的冷却时间
    if ($cooldown_check !== true) {
        return new WP_REST_Response($cooldown_check, 429);
    }

    // 检查是否是授权请求（生成动态Token）
    $is_auth_request = isset($data['action']) && ($data['action'] == 'auth_request' || $data['action'] == 'get_dynamic_token');
    
    // 如果是授权请求，只需要基本参数
    if ($is_auth_request) {
        $required_params = ['product_id', 'domain', 'auth_key'];
    } else {
        // 普通验证请求需要完整的三重验证参数
        $required_params = ['product_id', 'domain', 'auth_key', 'dynamic_token'];
    }
    
    $missing_params = [];

    foreach ($required_params as $param) {
        if (!isset($data[$param]) || empty(trim($data[$param]))) {
            $missing_params[] = $param;
        }
    }

    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }

    $product_id = intval($data['product_id']);
    $domain = sanitize_text_field(trim($data['domain']));
    $auth_key = sanitize_text_field(trim($data['auth_key']));
    $current_time = current_time('timestamp');

    if ($product_id <= 0) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => 'product_id必须为有效的正整数'],
            400
        );
    }

    // 验证域名格式
    $domain = strtolower($domain);
    if (!filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        // 尝试处理IP地址格式
        if (!filter_var($domain, FILTER_VALIDATE_IP)) {
            return new WP_REST_Response(
                ['status' => 0, 'message' => '域名格式无效'],
                400
            );
        }
    }

    // 验证授权码格式（假设授权码为32位或64位字符串）
    $auth_key_length = strlen($auth_key);
    if (!preg_match('/^[a-zA-Z0-9]{32,64}$/', $auth_key)) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权码格式无效'],
            400
        );
    }

    // 如果是普通验证请求，验证动态Token格式和有效性
        if (!$is_auth_request) {
            // 注意：动态Token是Base64编码的，不能使用sanitize_text_field()处理，否则会破坏Token
            $dynamic_token = trim($data['dynamic_token']);
            // 修复URL传输问题：将空格替换回+字符（因为Base64中的+在URL中会被替换为空格）
            $dynamic_token = str_replace(' ', '+', $dynamic_token);
            
            // 1. 验证动态Token格式
            if (!preg_match('/^[a-zA-Z0-9+\/=]+$/', $dynamic_token)) {
                return new WP_REST_Response(
                    ['status' => 0, 'message' => '动态Token格式无效'],
                    400
                );
            }
            
            // 2. 验证动态Token有效性
            $token_verify_result = xk_auth_validate_dynamic_token($dynamic_token);
            if (!$token_verify_result['valid']) {
                return new WP_REST_Response(
                    ['status' => 0, 'message' => $token_verify_result['message']],
                    401
                );
            }
            
            // 3. 验证token中的授权信息是否匹配
            $token_data = $token_verify_result['token_data'];
            if ($token_data['product_id'] != $product_id || $token_data['domain'] != $domain || $token_data['auth_key'] != $auth_key) {
                return new WP_REST_Response(
                    ['status' => 0, 'message' => '动态Token授权信息不匹配'],
                    401
                );
            }
        }

    // 验证授权
    $auth_table = $wpdb->prefix . 'product_auths';
    $auth_result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $auth_table WHERE product_id = %d AND domain = %s AND auth_key = %s AND status = 1",
        $product_id,
        $domain,
        $auth_key
    ));

    if (!$auth_result) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权验证失败，无法获取公告'],
            401
        );
    }

    // 获取用户ID
    $user_id = 0;
    if ($auth_result) {
        $user_id = intval($auth_result->user_id);
    }

    // 获取公告设置
    $notice_settings = xk_auth('notice_settings', array());
    $notices = array();

    // 过滤并整理公告数据
    if (!empty($notice_settings) && is_array($notice_settings)) {
        foreach ($notice_settings as $notice) {
            // 基本条件：对应产品且启用的公告
            if (
                isset($notice['product_id']) && $notice['product_id'] == $product_id &&
                isset($notice['status']) && $notice['status']
            ) {

                // 检查时间有效性
                $is_valid_time = true;
                if (isset($notice['start_time']) && !empty($notice['start_time'])) {
                    $start_time = strtotime($notice['start_time']);
                    if ($current_time < $start_time) {
                        $is_valid_time = false;
                    }
                }

                if (isset($notice['end_time']) && !empty($notice['end_time'])) {
                    $end_time = strtotime($notice['end_time']);
                    if ($current_time > $end_time) {
                        $is_valid_time = false;
                    }
                }

                if (!$is_valid_time) {
                    continue;
                }

                // 检查推送目标
                $is_valid_target = false;
                $push_type = isset($notice['push_type']) ? $notice['push_type'] : 'all';

                switch ($push_type) {
                    case 'all':
                        $is_valid_target = true;
                        break;
                    case 'specific':
                        if (isset($notice['push_target']) && !empty($notice['push_target']) && $user_id > 0) {
                            $targets = array_map('trim', explode("\n", $notice['push_target']));
                            if (in_array($user_id, $targets)) {
                                $is_valid_target = true;
                            }
                        }
                        break;
                    case 'domain':
                        if (isset($notice['push_target']) && !empty($notice['push_target'])) {
                            $targets = array_map('trim', explode("\n", $notice['push_target']));
                            if (in_array($domain, $targets)) {
                                $is_valid_target = true;
                            }
                        }
                        break;
                }

                if (!$is_valid_target) {
                    continue;
                }

                // 构建公告数据
                $notice_data = array(
                    'id' => md5($notice['title'] . $notice['created_at']),
                    'title' => isset($notice['title']) ? $notice['title'] : '',
                    'content' => isset($notice['content']) ? $notice['content'] : '',
                    'type' => isset($notice['type']) ? $notice['type'] : 'info',
                    'category' => isset($notice['category']) ? $notice['category'] : 'system',
                    'priority' => isset($notice['priority']) ? intval($notice['priority']) : 0,
                    'created_at' => isset($notice['created_at']) ? $notice['created_at'] : '',
                    'require_login' => isset($notice['require_login']) ? $notice['require_login'] : false
                );

                $notices[] = $notice_data;
            }
        }
    }

    // 按优先级和发布时间排序（优先级高的在前，相同优先级按时间降序）
    usort($notices, function ($a, $b) {
        if ($a['priority'] != $b['priority']) {
            return $b['priority'] - $a['priority'];
        }
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    });

    // 如果有请求分类参数，进行分类过滤
    if (isset($data['category']) && !empty($data['category'])) {
        $category = sanitize_text_field(trim($data['category']));
        $notices = array_filter($notices, function ($notice) use ($category) {
            return $notice['category'] == $category;
        });
    }

    return new WP_REST_Response(
        [
            'status' => 1,
            'message' => '获取公告成功',
            'total' => count($notices),
            'notices' => $notices
        ],
        200
    );
}

/**
 * 生成动态Token - 用于三重验证
 */
function xk_auth_generate_dynamic_token($product_id, $domain, $auth_key) {
    // 生成更强的随机字符串，包含更多字符类型
    $random_string = bin2hex(random_bytes(32)); // 64位随机字符串
    
    $timestamp = time();
    $expire_time = $timestamp + 10800; // 30分钟过期时间，提高安全性
    $day = date('Ymd');
    
    // 生成固定的加密密钥
    $encryption_key = hash('sha256', AUTH_KEY . AUTH_SALT);
    
    // 构建更完整的token数据，包含更多验证信息
    $token_data = array(
        'product_id' => $product_id,
        'domain' => $domain,
        'auth_key' => $auth_key,
        'random' => $random_string,
        'timestamp' => $timestamp,
        'expire_time' => $expire_time,
        'day' => $day,
        'signature' => hash('sha256', $product_id . $domain . $auth_key . $random_string . $timestamp . $day . AUTH_KEY) // 使用AUTH_KEY进行签名验证
    );
    
    // 序列化并加密token，使用更强的加密参数
    $serialized_data = serialize($token_data);
    $encrypted_token = openssl_encrypt($serialized_data, 'AES-256-CBC', $encryption_key, OPENSSL_RAW_DATA, substr(AUTH_SALT, 0, 16));
    $encrypted_token = base64_encode($encrypted_token); // 转换为base64格式，便于传输
    
    return array(
        'token' => $encrypted_token,
        'expire_time' => $expire_time,
        'timestamp' => $timestamp,
        'token_type' => 'triple_verification'
    );
}

/**
 * 验证动态Token - 用于三重验证
 */
function xk_auth_validate_dynamic_token($token) {
    try {
        // 先解码base64
        $decoded_token = base64_decode($token);
        if (!$decoded_token) {
            return array('valid' => false, 'message' => 'Base64解码失败');
        }
        
        // 生成固定的加密密钥
        $encryption_key = hash('sha256', AUTH_KEY . AUTH_SALT);
        
        // 解密token
        $decrypted_data = openssl_decrypt($decoded_token, 'AES-256-CBC', $encryption_key, OPENSSL_RAW_DATA, substr(AUTH_SALT, 0, 16));
        if (!$decrypted_data) {
            return array('valid' => false, 'message' => 'AES解密失败');
        }
        
        // 反序列化数据
        $token_data = unserialize($decrypted_data);
        if (!is_array($token_data)) {
            return array('valid' => false, 'message' => '反序列化失败 - 数据不是数组');
        }
        
        // 检查必要字段是否存在
        $required_fields = ['timestamp', 'expire_time', 'signature', 'product_id', 'domain', 'auth_key', 'random', 'day'];
        $missing_fields = [];
        foreach ($required_fields as $field) {
            if (!isset($token_data[$field])) {
                $missing_fields[] = $field;
            }
        }
        if (!empty($missing_fields)) {
            return array('valid' => false, 'message' => '缺少必要字段: ' . implode(', ', $missing_fields));
        }
        
        // 先验证签名，防止token被篡改
        $expected_signature = hash('sha256', $token_data['product_id'] . $token_data['domain'] . $token_data['auth_key'] . $token_data['random'] . $token_data['timestamp'] . $token_data['day'] . AUTH_KEY);
        if ($token_data['signature'] !== $expected_signature) {
            return array('valid' => false, 'message' => '签名验证失败');
        }
        
        // 验证签名通过后，再检查token是否过期
        $current_time = time();
        if ($current_time > $token_data['expire_time']) {
            return array('valid' => false, 'message' => 'Token已过期');
        }
        
        // 检查是否是当天生成的token（防止跨天攻击）
        if ($token_data['day'] !== date('Ymd')) {
            return array('valid' => false, 'message' => 'Token已过期');
        }
        
        // 验证成功，返回token数据
        return array(
            'valid' => true,
            'message' => '动态Token验证成功',
            'token_data' => $token_data
        );
    } catch (Exception $e) {
        return array('valid' => false, 'message' => '动态Token验证异常: ' . $e->getMessage());
    }
}

/**
 * 加密存储授权码+动态token
 */
function xk_auth_encrypt_auth_data($auth_key, $dynamic_token, $timestamp = null) {
    if (is_null($timestamp)) {
        $timestamp = time();
    }
    
    // 构建要加密的数据
    $auth_data = array(
        'auth_key' => $auth_key,
        'dynamic_token' => $dynamic_token,
        'timestamp' => $timestamp,
        'encrypted_at' => time()
    );
    
    // 序列化并加密
    $serialized_data = serialize($auth_data);
    $encrypted_data = openssl_encrypt($serialized_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
    
    return $encrypted_data;
}

/**
 * 解密授权数据
 */
function xk_auth_decrypt_auth_data($encrypted_data) {
    try {
        // 解密数据
        $decrypted_data = openssl_decrypt($encrypted_data, 'AES-256-CBC', AUTH_KEY, 0, substr(AUTH_SALT, 0, 16));
        if (!$decrypted_data) {
            return false;
        }
        
        // 反序列化
        $auth_data = unserialize($decrypted_data);
        if (!is_array($auth_data)) {
            return false;
        }
        
        // 检查必要字段
        if (!isset($auth_data['auth_key'], $auth_data['dynamic_token'], $auth_data['timestamp'])) {
            return false;
        }
        
        return $auth_data;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * 手动推送Token的AJAX处理函数
 */
function xk_auth_push_token_manual() {
    // 检查用户权限
    if (!current_user_can('manage_options')) {
        wp_send_json(array('error' => 1, 'msg' => '权限不足'));
        exit;
    }
    
    // 获取请求参数
    $auth_id = intval($_POST['auth_id']);
    $domain = sanitize_text_field($_POST['domain']);
    $product_id = intval($_POST['product_id']);
    $auth_key = sanitize_text_field($_POST['auth_key']);
    
    // 验证参数
    if (empty($auth_id) || empty($domain) || empty($product_id) || empty($auth_key)) {
        wp_send_json(array('error' => 1, 'msg' => '参数不完整'));
        exit;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';
    
    // 获取授权记录
    $auth_record = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id = %d AND product_id = %d AND domain = %s AND auth_key = %s",
        $auth_id, $product_id, $domain, $auth_key
    ));
    
    if (!$auth_record) {
        wp_send_json(array('error' => 1, 'msg' => '授权记录不存在'));
        exit;
    }
    
    // 生成新的动态Token
    $dynamic_token = xk_auth_generate_dynamic_token($product_id, $domain, $auth_key);
    
    // 加密存储授权码+动态token
    $encrypted_auth_data = xk_auth_encrypt_auth_data($auth_key, $dynamic_token['token'], $dynamic_token['timestamp']);
    xk_auth_store_encrypted_auth_data($product_id, $domain, $encrypted_auth_data);
    
    // 尝试向被授权站推送Token，超时时间设置为15秒
    $push_result = xk_auth_push_token_to_site($auth_record, $dynamic_token, $encrypted_auth_data);
    
    // 记录日志
    $log_data = array(
        'auth_id' => $auth_id,
        'domain' => $domain,
        'product_id' => $product_id,
        'push_result' => $push_result,
        'timestamp' => time()
    );
    
    error_log('[星空授权] 手动推送Token结果: ' . json_encode($log_data));
    
    // 返回结果
    if ($push_result) {
        $response = array(
            'error' => 0,
            'msg' => 'Token推送成功',
            'result' => array(
                'token' => $dynamic_token['token'],
                'expire_time' => $dynamic_token['expire_time'],
                'timestamp' => $dynamic_token['timestamp'],
                'domain' => $domain,
                'product_id' => $product_id
            )
        );
        wp_send_json($response);
    } else {
        $response = array(
            'error' => 1,
            'msg' => 'Token推送失败，请检查日志获取详细信息',
            'result' => array(
                'token' => $dynamic_token['token'],
                'expire_time' => $dynamic_token['expire_time'],
                'timestamp' => $dynamic_token['timestamp'],
                'domain' => $domain,
                'product_id' => $product_id
            )
        );
        wp_send_json($response);
    }
}

// 注册AJAX处理函数
add_action('wp_ajax_xk_auth_push_token_manual', 'xk_auth_push_token_manual');

/**
 * 存储加密的授权数据到数据库
 */
function xk_auth_store_encrypted_auth_data($product_id, $domain, $encrypted_data) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'product_auths';
    
    // 更新或插入加密数据
    $result = $wpdb->update(
        $table_name,
        array(
            'encrypted_auth_data' => $encrypted_data,
            'last_communication_time' => current_time('mysql')
        ),
        array(
            'product_id' => $product_id,
            'domain' => $domain
        ),
        array('%s', '%s'),
        array('%d', '%s')
    );
    
    // 如果没有更新到记录，则插入新记录
    if ($result === 0) {
        $wpdb->insert(
            $table_name,
            array(
                'product_id' => $product_id,
                'domain' => $domain,
                'encrypted_auth_data' => $encrypted_data,
                'last_communication_time' => current_time('mysql'),
                'status' => 1
            ),
            array('%d', '%s', '%s', '%s', '%d')
        );
    }
    
    return true;
}

/**
 * 从数据库获取加密的授权数据
 */
function xk_auth_get_encrypted_auth_data($product_id, $domain) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'product_auths';
    
    $result = $wpdb->get_row($wpdb->prepare(
        "SELECT encrypted_auth_data, last_communication_time FROM $table_name WHERE product_id = %d AND domain = %s AND status = 1",
        $product_id,
        $domain
    ));
    
    if (!$result) {
        return false;
    }
    
    return array(
        'encrypted_data' => $result->encrypted_auth_data,
        'last_communication_time' => $result->last_communication_time
    );
}

/**
 * 处理获取动态Token的API请求 - 用于三重验证
 */
function xk_auth_get_dynamic_token($request) {
    // 确保过滤器被清理
    xk_auth_rewrites_ensure_clean_filters();
    
    global $wpdb;
    
    // 支持GET和POST请求
    if (is_array($request)) {
        $data = $request;
    } else {
        $data = $request->get_params();
    }
    
    // 检查请求频率限制：1分钟内最多5次请求，超过冷却120秒
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $cooldown_check = xk_auth_check_request_cooldown('token', $ip);
    if ($cooldown_check !== true) {
        return new WP_REST_Response($cooldown_check, 429);
    }
    
    $required_params = ['product_id', 'domain', 'auth_key'];
    $missing_params = [];
    
    foreach ($required_params as $param) {
        if (!isset($data[$param]) || empty(trim($data[$param]))) {
            $missing_params[] = $param;
        }
    }
    
    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }
    
    $product_id = intval($data['product_id']);
    $domain = sanitize_text_field(trim($data['domain']));
    $auth_key = sanitize_text_field(trim($data['auth_key']));
    
    // 验证IP地址格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = 'unknown';
    }
    
    // 1. 验证product_id
    if ($product_id <= 0) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => 'product_id必须为有效的正整数'],
            400
        );
    }
    
    // 2. 验证域名格式
    $domain = strtolower($domain);
    if (!filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        // 尝试处理IP地址格式
        if (!filter_var($domain, FILTER_VALIDATE_IP)) {
            return new WP_REST_Response(
                ['status' => 0, 'message' => '域名格式无效'],
                400
            );
        }
    }
    
    // 3. 验证授权码格式（假设授权码为32位或64位字符串）
    $auth_key_length = strlen($auth_key);
    if (!preg_match('/^[a-zA-Z0-9]{32,64}$/', $auth_key)) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权码格式无效'],
            400
        );
    }
    
    // 4. 验证IP地址格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = 'unknown';
    }
    
    // 1. 验证基础授权信息（预验证，确保只有合法授权才能获取动态token）
    $auth_table = $wpdb->prefix . 'product_auths';
    $auth_result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $auth_table WHERE product_id = %d AND domain = %s AND auth_key = %s AND status = 1",
        $product_id,
        $domain,
        $auth_key
    ));
    
    if (!$auth_result) {
        // 记录失败日志
        $log_table = $wpdb->prefix . 'auth_request_logs';
        $current_time = current_time('mysql');
        
        $wpdb->insert(
            $log_table,
            array(
                'product_id' => $product_id,
                'ip' => $ip,
                'domain' => $domain,
                'auth_key' => $auth_key,
                'status' => 'failed_pre_auth',
                'operation_time' => $current_time
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '基础授权验证失败，无法获取动态Token'],
            401
        );
    }
    
    // 2. 生成动态token（用于三重验证）
    $dynamic_token = xk_auth_generate_dynamic_token($product_id, $domain, $auth_key);
    
    // 3. 加密存储授权码+动态token
    $encrypted_auth_data = xk_auth_encrypt_auth_data($auth_key, $dynamic_token['token'], $dynamic_token['timestamp']);
    xk_auth_store_encrypted_auth_data($product_id, $domain, $encrypted_auth_data);
    
    // 4. 记录token生成日志
    $log_table = $wpdb->prefix . 'auth_request_logs';
    $current_time = current_time('mysql');
    
    $wpdb->insert(
        $log_table,
        array(
            'product_id' => $product_id,
            'ip' => $ip,
            'domain' => $domain,
            'auth_key' => $auth_key,
            'status' => 'token_generated_triple',
            'operation_time' => $current_time
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s')
    );
    
    // 5. 更新最后通讯时间
    update_option('xk_auth_last_communication_' . $product_id . '_' . $domain, time());
    
    return new WP_REST_Response(
        [
            'status' => 1,
            'message' => '三重验证动态Token生成成功',
            'dynamic_token' => $dynamic_token['token'],
            'expire_time' => $dynamic_token['expire_time'],
            'timestamp' => $dynamic_token['timestamp'],
            'token_type' => 'triple_verification',
            'encrypted_auth_data' => $encrypted_auth_data,
            'expire_in' => 1800 // 30分钟过期
        ],
        200
    );
}

/**
 * 处理动态Token验证的API请求 - 用于三重验证
 */
function xk_auth_verify_dynamic_token($request) {
    // 确保过滤器被清理
    xk_auth_rewrites_ensure_clean_filters();
    
    global $wpdb;
    
    // 支持GET和POST请求
    if (is_array($request)) {
        $params = $request;
    } else {
        $params = $request->get_params();
    }
    
    // 检查请求冷却时间
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $cooldown_check = xk_auth_check_request_cooldown('token_verify', $ip); // 使用全局设置的冷却时间
    if ($cooldown_check !== true) {
        return new WP_REST_Response($cooldown_check, 429);
    }
    
    $required_params = ['product_id', 'domain', 'auth_key', 'dynamic_token'];
    $missing_params = [];
    
    foreach ($required_params as $param) {
        if (!isset($params[$param]) || empty(trim($params[$param]))) {
            $missing_params[] = $param;
        }
    }
    
    if (!empty($missing_params)) {
        $error_msg = '请求参数不完整，缺少：' . implode('、', $missing_params);
        return new WP_REST_Response(
            ['status' => 0, 'message' => $error_msg],
            400
        );
    }
    
    $product_id = intval($params['product_id']);
    $domain = sanitize_text_field(trim($params['domain']));
    $auth_key = sanitize_text_field(trim($params['auth_key']));
    // 注意：动态Token是Base64编码的，不能使用sanitize_text_field()处理，否则会破坏Token
    $dynamic_token = trim($params['dynamic_token']);
    // 修复URL传输问题：将空格替换回+字符（因为Base64中的+在URL中会被替换为空格）
    $dynamic_token = str_replace(' ', '+', $dynamic_token);
    
    // 1. 验证product_id
    if ($product_id <= 0) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => 'product_id必须为有效的正整数'],
            400
        );
    }
    
    // 2. 验证域名格式
    $domain = strtolower($domain);
    if (!filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        // 尝试处理IP地址格式
        if (!filter_var($domain, FILTER_VALIDATE_IP)) {
            return new WP_REST_Response(
                ['status' => 0, 'message' => '域名格式无效'],
                400
            );
        }
    }
    
    // 3. 验证授权码格式（假设授权码为32位或64位字符串）
    $auth_key_length = strlen($auth_key);
    if (!preg_match('/^[a-zA-Z0-9]{32,64}$/', $auth_key)) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权码格式无效'],
            400
        );
    }
    
    // 4. 验证动态Token格式
    if (!preg_match('/^[a-zA-Z0-9+\/=]+$/', $dynamic_token)) {
        return new WP_REST_Response(
            ['status' => 0, 'message' => '动态Token格式无效'],
            400
        );
    }
    
    // 5. 验证IP地址格式
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = 'unknown';
    }
    
    $current_time = time();
    $current_time_db = current_time('mysql');
    
    // 1. 验证动态token（第一重验证）
    $token_verify_result = xk_auth_validate_dynamic_token($dynamic_token);
    if (!$token_verify_result['valid']) {
        // 记录验证结果到日志表
        $log_table = $wpdb->prefix . 'auth_request_logs';
        $wpdb->insert(
            $log_table,
            array(
                'product_id' => $product_id,
                'ip' => $ip,
                'domain' => $domain,
                'auth_key' => $auth_key,
                'status' => 'failed_token_verify_invalid',
                'operation_time' => $current_time_db
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '动态Token无效或已过期'],
            401
        );
    }
    
    // 提取验证成功后的token数据
    $token_data = $token_verify_result['token_data'];
    
    // 2. 验证token中的授权信息是否匹配（第二重验证：域名+授权码）
    if ($token_data['product_id'] != $product_id || $token_data['domain'] != $domain || $token_data['auth_key'] != $auth_key) {
        // 记录验证结果到日志表
        $log_table = $wpdb->prefix . 'auth_request_logs';
        $wpdb->insert(
            $log_table,
            array(
                'product_id' => $product_id,
                'ip' => $ip,
                'domain' => $domain,
                'auth_key' => $auth_key,
                'status' => 'failed_token_verify_mismatch',
                'operation_time' => $current_time_db
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '动态Token与授权信息不匹配'],
            401
        );
    }
    
    // 3. 检查数据库中的授权记录（第三重验证：完整授权信息）
    $auth_table = $wpdb->prefix . 'product_auths';
    $auth_result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $auth_table WHERE product_id = %d AND domain = %s AND auth_key = %s AND status = 1",
        $product_id,
        $domain,
        $auth_key
    ));
    
    if (!$auth_result) {
        // 记录验证结果到日志表
        $log_table = $wpdb->prefix . 'auth_request_logs';
        $wpdb->insert(
            $log_table,
            array(
                'product_id' => $product_id,
                'ip' => $ip,
                'domain' => $domain,
                'auth_key' => $auth_key,
                'status' => 'failed_token_verify_auth_not_found',
                'operation_time' => $current_time_db
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '授权信息无效'],
            401
        );
    }
    
    // 4. 检查是否超过2小时未通讯
    $last_communication_time = get_option('xk_auth_last_communication_' . $product_id . '_' . $domain, 0);
    if ($last_communication_time > 0 && ($current_time - $last_communication_time) > 7200) { // 2小时 = 7200秒
        // 记录验证结果到日志表
        $log_table = $wpdb->prefix . 'auth_request_logs';
        $wpdb->insert(
            $log_table,
            array(
                'product_id' => $product_id,
                'ip' => $ip,
                'domain' => $domain,
                'auth_key' => $auth_key,
                'status' => 'failed_token_verify_offline_expired',
                'operation_time' => $current_time_db
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        return new WP_REST_Response(
            ['status' => 0, 'message' => '超过12小时未与主站通讯，授权已失效'],
            401
        );
    }
    
    // 5. 更新最后通讯时间
    update_option('xk_auth_last_communication_' . $product_id . '_' . $domain, $current_time);
    
    // 6. 记录验证日志
    $log_table = $wpdb->prefix . 'auth_request_logs';
    $wpdb->insert(
        $log_table,
        array(
            'product_id' => $product_id,
            'ip' => $ip,
            'domain' => $domain,
            'auth_key' => $auth_key,
            'status' => 'success_token_verified_triple',
            'operation_time' => $current_time_db
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s')
    );
    
    // 7. 获取产品名称
    $product_name = '未知产品';
    $product_settings = xk_auth('product_settings', array());
    
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            if (is_array($product) && isset($product['product_id']) && strval($product['product_id']) === strval($product_id)) {
                $product_name = isset($product['product_name']) && !empty($product['product_name']) 
                    ? sanitize_text_field($product['product_name']) 
                    : '未命名产品';
                break;
            }
        }
    }
    
    return new WP_REST_Response(
        [
            'status' => 1,
            'message' => '三重验证动态Token验证成功',
            'product_id' => $product_id,
            'domain' => $domain,
            'product_name' => $product_name,
            'last_communication' => $last_communication_time,
            'current_communication' => $current_time,
            'token_expire' => $token_data['expire_time'],
            'verification_type' => 'triple_verification',
            'token_signature' => $token_data['signature']
        ],
        200
    );
}
