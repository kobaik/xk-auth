<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2026-01-24 15:00:00
 * @Project      : 星空授权插件
 * @Description  : 优惠码管理页面
 * Copyright (c) 2026 by 星空授权, All Rights Reserved.
 */
?>
<el-row :gutter="20">
    <!-- 优惠码管理 -->
    <el-col :xs="24" :sm="24" :md="24" :lg="24">
        <div class="card-box">
            <div class="card-header">
                <el-button type="primary" @click="is_authorized ? addPromo() : handleUnauthorizedClick()">添加优惠码</el-button>
            </div>
            
            <!-- 筛选条件 -->
            <div class="filter-bar">
                <el-form :inline="true" :model="promoFilter" class="demo-form-inline">
                    <el-form-item label="优惠码">
                        <el-input v-model="promoFilter.code" placeholder="请输入优惠码"></el-input>
                    </el-form-item>
                    <el-form-item label="状态">
                        <el-select 
                        v-model="promoFilter.status"
                        placeholder="请选择状态"
                        style="width:250px;"
                        >
                            <el-option label="全部" value=""></el-option>
                            <el-option label="有效" value="active"></el-option>
                            <el-option label="无效" value="inactive"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="is_authorized ? getPromoCodes : handleUnauthorizedClick()">查询</el-button>
                        <el-button @click="is_authorized ? resetFilter : handleUnauthorizedClick()">重置</el-button>
                    </el-form-item>
                </el-form>
            </div>
            
            <!-- 优惠码列表 -->
            <el-table :data="promoCodes" stripe style="width: 100%" v-loading="loading.promoTable">
                <el-table-column prop="id" label="ID" width="80"></el-table-column>
                <el-table-column prop="code" label="优惠码" min-width="150"></el-table-column>
                <el-table-column prop="name" label="名称" min-width="150"></el-table-column>
                <el-table-column prop="type" label="类型" width="100">
                    <template #default="scope">
                        <el-tag type="primary" v-if="scope.row.type == 'fixed'">固定金额</el-tag>
                        <el-tag type="success" v-else>百分比</el-tag>
                    </template>
                </el-table-column>
                <el-table-column prop="value" label="优惠值" width="100">
                    <template #default="scope">
                        {{ scope.row.type == 'fixed' ? '¥' + scope.row.value : scope.row.value + '%' }}
                    </template>
                </el-table-column>
                <el-table-column prop="min_amount" label="最低消费" width="120">
                    <template #default="scope">
                        ¥{{ scope.row.min_amount }}
                    </template>
                </el-table-column>
                <el-table-column prop="usage_count" label="已使用" width="100"></el-table-column>
                <el-table-column prop="usage_limit" label="使用限制" width="100">
                    <template #default="scope">
                        {{ scope.row.usage_limit || '无限制' }}
                    </template>
                </el-table-column>
                <el-table-column prop="status" label="状态" width="100">
                    <template #default="scope">
                        <el-tag type="success" v-if="scope.row.status == 'active'">有效</el-tag>
                        <el-tag type="danger" v-else>无效</el-tag>
                    </template>
                </el-table-column>
                <el-table-column prop="start_time" label="开始时间" min-width="180"></el-table-column>
                <el-table-column prop="end_time" label="结束时间" min-width="180"></el-table-column>
                <el-table-column label="操作" width="150" fixed="right">
                    <template #default="scope">
                        <el-button type="primary" size="small" @click="is_authorized ? editPromo(scope.row) : handleUnauthorizedClick()">编辑</el-button>
                        <el-button type="danger" size="small" @click="is_authorized ? deletePromo(scope.row) : handleUnauthorizedClick()">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            
            <!-- 分页 -->
            <div class="pagination-container">
                <el-pagination
                    background
                    layout="prev, pager, next, jumper, ->, total"
                    :total="promoTotalCount"
                    :current-page="promoCurrentPage"
                    :page-size="promoPageSize"
                    @current-change="handlePromoPageChange"
                ></el-pagination>
            </div>
        </div>
    </el-col>
</el-row>

<!-- 添加/编辑优惠码对话框 -->
<el-dialog
    v-model="dialogVisible.addPromo"
    :title="promoForm.id ? '编辑优惠码' : '添加优惠码'"
    width="600px"
>
    <el-form :model="promoForm" :rules="promoRules" ref="promoFormRef" label-width="120px">
        <el-form-item label="优惠码名称" prop="name">
            <el-input v-model="promoForm.name" placeholder="请输入优惠码名称"></el-input>
        </el-form-item>
        <el-form-item label="优惠码" prop="code">
            <el-input v-model="promoForm.code" placeholder="请输入优惠码(留空随机)"></el-input>
        </el-form-item>
        <el-form-item label="优惠类型" prop="type">
            <el-select v-model="promoForm.type" placeholder="请选择优惠类型">
                <el-option label="固定金额" value="fixed"></el-option>
                <el-option label="百分比" value="percentage"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="优惠值" prop="value">
            <el-input v-model.number="promoForm.value" placeholder="请输入优惠值"></el-input>
        </el-form-item>
        <el-form-item label="最低消费金额">
            <el-input v-model.number="promoForm.min_amount" placeholder="请输入最低消费金额"></el-input>
        </el-form-item>
        <el-form-item label="最大优惠金额">
            <el-input v-model.number="promoForm.max_discount" placeholder="请输入最大优惠金额"></el-input>
        </el-form-item>
        <el-form-item label="使用次数限制">
            <el-input v-model.number="promoForm.usage_limit" placeholder="请输入使用次数限制，0或空表示无限制"></el-input>
        </el-form-item>
        <el-form-item label="适用产品ID">
            <el-input v-model="promoForm.product_ids" placeholder="请输入适用产品ID，多个用逗号分隔，空表示全部产品"></el-input>
        </el-form-item>
        <el-form-item label="适用用户ID">
            <el-input v-model="promoForm.user_ids" placeholder="请输入适用用户ID，多个用逗号分隔，空表示全部用户"></el-input>
        </el-form-item>
        <el-form-item label="开始时间">
            <el-date-picker
                v-model="promoForm.start_time"
                type="datetime"
                placeholder="选择开始时间"
                format="YYYY-MM-DD HH:mm:ss"
                value-format="YYYY-MM-DD HH:mm:ss"
                style="width:220px;"
            ></el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间">
            <el-date-picker
                v-model="promoForm.end_time"
                type="datetime"
                placeholder="选择结束时间"
                format="YYYY-MM-DD HH:mm:ss"
                value-format="YYYY-MM-DD HH:mm:ss"
                style="width:220px;"
            ></el-date-picker>
        </el-form-item>
        <el-form-item label="状态">
            <el-radio-group v-model="promoForm.status">
                <el-radio label="active">有效</el-radio>
                <el-radio label="inactive">无效</el-radio>
            </el-radio-group>
        </el-form-item>
        <el-form-item label="优惠码描述">
            <el-input type="textarea" v-model="promoForm.description" placeholder="请输入优惠码描述"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <span class="dialog-footer">
            <el-button @click="dialogVisible.addPromo = false">取消</el-button>
            <el-button type="primary" @click="savePromo">保存</el-button>
        </span>
    </template>
</el-dialog>