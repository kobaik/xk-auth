<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-17 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 统计页面模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 */
?>
<el-row :gutter="20" class="dashboard-cards">
    <!-- 关键数据统计 -->
    <el-col :xs="24" :sm="24" :md="24" :lg="24">
        <div class="card-box">
            <div class="card-header">
                <div class="box-title">关键数据统计(不计积分)</div>
            </div>
            <div class="stats-grid">
                <el-row :gutter="100">
                    <!-- 授权统计 -->
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">总授权数</div>
                                <div class="stat-value">{{ total_auths }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">活跃授权</div>
                                <div class="stat-value">{{ active_auths }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">过期授权</div>
                                <div class="stat-value">{{ expired_auths }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">今日新增</div>
                                <div class="stat-value">{{ today_auths }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <!-- 请求统计 -->
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">请求总数</div>
                                <div class="stat-value">{{ total_requests }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">成功请求</div>
                                <div class="stat-value">{{ success_requests }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <!-- 产品统计 -->
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">产品总数</div>
                                <div class="stat-value">{{ total_products }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <!-- 卡密统计 -->
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">卡密总数</div>
                                <div class="stat-value">{{ total_cards }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">已用卡密</div>
                                <div class="stat-value">{{ used_cards }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">未用卡密</div>
                                <div class="stat-value">{{ unused_cards }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <!-- 订单统计 -->
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">总订单数</div>
                                <div class="stat-value">{{ total_orders }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">总销售额</div>
                                <div class="stat-value">¥{{ total_sales.toFixed(2) }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">今日销售额</div>
                                <div class="stat-value">¥{{ today_sales.toFixed(2) }}</div>
                            </div>
                        </el-card>
                    </el-col>
                    
                    <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="3">
                        <el-card class="stat-card" shadow="hover">
                            <div class="stat-content">
                                <div class="stat-label">平均订单金额</div>
                                <div class="stat-value">¥{{ avg_order_price.toFixed(2) }}</div>
                            </div>
                        </el-card>
                    </el-col>
                </el-row>
            </div>
        </div>
    </el-col>
    
    <!-- 图表展示 -->
    <el-col :xs="24" :sm="12" :md="12" :lg="12">
        <div class="card-box">
            <div class="card-header">
                <div class="box-title">月度销售额趋势（不计积分）</div>
            </div>
            <div class="chart-container">
                <canvas id="salesTrendChart" width="100%" height="300"></canvas>
            </div>
        </div>
    </el-col>
    
    <el-col :xs="24" :sm="12" :md="12" :lg="12">
        <div class="card-box">
            <div class="card-header">
                <div class="box-title">产品销售排行（Top 5）（不计积分）</div>
            </div>
            <div class="chart-container">
                <canvas id="productSalesChart" width="100%" height="300"></canvas>
            </div>
        </div>
    </el-col>
    
    <!-- 最近授权记录 -->
    <el-col :xs="24" :sm="24" :md="24" :lg="24">
        <div class="card-box">
            <div class="card-header">
                <div class="box-title">最近授权记录</div>
            </div>
            <el-table :data="recentAuths" stripe style="width: 100%">
                <el-table-column prop="domain" label="域名" min-width="200"></el-table-column>
                <el-table-column prop="product_id" label="产品ID"></el-table-column>
                <el-table-column prop="operation_time" label="授权时间" min-width="180"></el-table-column>
                <el-table-column prop="expire_time" label="到期时间" min-width="180"></el-table-column>
                <el-table-column prop="status" label="状态">
                    <template #default="scope">
                        <el-tag v-if="scope.row.status == '1'" type="success">正常</el-tag>
                        <el-tag v-else type="danger">禁用</el-tag>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </el-col>
</el-row>
