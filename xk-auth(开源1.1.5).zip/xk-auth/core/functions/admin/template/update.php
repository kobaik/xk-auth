<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-19 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 更新管理页面模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 */
?>

<div class="update-manage-container">
    <el-card shadow="hover">
        <template #header>
            <div class="card-header">
                <span>更新包管理</span>
            </div>
        </template>
        
        <!-- 搜索和筛选区域 -->

            <div class="flex mb6 hh">
                <el-select v-model="updatesFilter.productId" class="mr6 mb6" placeholder="选择产品" style="width: 150px;">
                    <el-option 
                        v-for="(name, id) in productList" 
                        :key="id" 
                        :label="name" 
                        :value="id"
                    ></el-option>
                </el-select>
                <el-select v-model="updatesFilter.pushStatus" class="mr6 mb6" placeholder="推送状态" style="width: 120px;">
                    <el-option label="全部" :value="'all'"></el-option>
                    <el-option label="已推送" :value="1"></el-option>
                    <el-option label="未推送" :value="0"></el-option>
                </el-select>
                <div style="width: 420px" class="mr6 mb6 flex">
                    <el-date-picker v-model="updatesTimeFilter.operationTime" format="YYYY-MM-DD" type="daterange" range-separator="至" start-placeholder="开始时间" end-placeholder="结束时间" unlink-panels style="width: 100%"></el-date-picker>
                </div>
                <div class="shrink0 table-right-but mb6 flex">
                    <el-button @click="is_authorized ? filterUpdates() : handleUnauthorizedClick()" type="primary" style="margin-right: 8px;">查询</el-button>
                    <el-button @click="is_authorized ? resetUpdatesFilter() : handleUnauthorizedClick()">重置</el-button>
                </div>
                 <div style="margin-bottom: 10px; padding-left: 20px;">
                    <el-button type="primary" plain @click="is_authorized ? (dialogVisible.addUpdate = true) : handleUnauthorizedClick()">添加更新包</el-button>
                 </div>
        </div>
        
        <!-- 添加更新包按钮 -->

        
        <!-- 更新包列表 -->
        <div class="update-list">
            <el-skeleton :rows="5" animated v-if="loading.updates_table"></el-skeleton>
            <el-collapse v-else v-model="activeUpdateGroups" accordion>
                <el-collapse-item 
                    v-for="update in updatesList" 
                    :key="update.id" 
                    :title="`产品: ${update.productName} (ID: ${update.productId}) - 版本: ${update.version} - ${update.pushStatusText}`"
                    style="margin-top: 5px;"
                >
                    <el-table :data="[update]" stripe border style="width: 100%">
                        <el-table-column prop="id" label="ID" min-width="80"></el-table-column>
                        <el-table-column prop="updatePackageUrl" label="更新包URL" min-width="250">
                            <template #default="scope">
                                <div style="word-break: break-all;">{{ scope.row.updatePackageUrl }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="updateDescription" label="更新说明" min-width="200">
                            <template #default="scope">
                                <div style="max-height: 80px; overflow-y: auto;">{{ scope.row.updateDescription || '无' }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="originalVersions" label="适用版本" min-width="150">
                            <template #default="scope">
                                <div style="max-height: 60px; overflow-y: auto; font-size: 13px;">{{ scope.row.originalVersions }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="pushedTargets" label="已推送ID" min-width="150">
                            <template #default="scope">
                                <el-button 
                                    type="primary" 
                                    size="small" 
                                    plain
                                    @click="is_authorized ? viewPushTargets(scope.row) : handleUnauthorizedClick()"
                                >
                                    {{ scope.row.pushedTargets ? '管理推送ID' : '暂无指定推送' }}
                                </el-button>
                            </template>
                        </el-table-column>
                        <el-table-column prop="operationTime" label="添加时间" min-width="160"></el-table-column>
                        <el-table-column label="操作" min-width="120" fixed="right">
                            <template #default="scope">
                                <el-button 
                                    type="primary" 
                                    size="small" 
                                    plain
                                    @click="is_authorized ? openUpdateActionDialog(scope.row) : handleUnauthorizedClick()"
                                >
                                    编辑更新
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-collapse-item>
            </el-collapse>
            
            <!-- 空状态 -->
            <el-empty v-if="!loading.updates_table && updatesList.length === 0" description="暂无更新包记录"></el-empty>
        </div>
        
        <!-- 分页 -->
        <div class="pagination-container">
            <el-pagination
                background
                layout="prev, pager, next, jumper"
                :total="updatesTotal"
                :current-page="updatesCurrentPage"
                :page-size="updatesPerPage"
                @current-change="handleCurrentChange"
                @size-change="handleSizeChange"
                style="margin-top: 20px;"
            ></el-pagination>
        </div>
    </el-card>
    
    <!-- 编辑更新包弹窗 -->
    <el-dialog
        v-model="dialogVisible.editUpdate"
        title="编辑更新包"
        width="600px"
        center
    >
        <el-form :model="updateForm" label-width="120px">
            <el-form-item label="产品ID">
                <el-input v-model="updateForm.productId" disabled></el-input>
            </el-form-item>
            <el-form-item label="版本号">
                <el-input v-model="updateForm.version" disabled></el-input>
            </el-form-item>
            <el-form-item label="更新包URL">
                <el-input v-model="updateForm.updatePackageUrl" placeholder="请输入包含http://或https://的完整URL"></el-input>
            </el-form-item>
            <el-form-item label="更新说明">
                <el-input
                    v-model="updateForm.updateDescription"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入更新说明"
                ></el-input>
            </el-form-item>
            <el-form-item label="推送状态">
                <el-radio-group v-model="updateForm.pushStatus">
                    <el-radio :label="1">已推送</el-radio>
                    <el-radio :label="0">未推送</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="适用原版本">
                <el-input
                    v-model="updateForm.originalVersions"
                    type="textarea"
                    :rows="3"
                    placeholder="指定哪些版本可以接收此更新。多个版本用逗号或换行分隔，留空表示适用于所有版本"
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.editUpdate = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? submitUpdate() : handleUnauthorizedClick()">保存更改</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 指定ID推送弹窗 -->
    <el-dialog
        v-model="dialogVisible.targetedPush"
        title="指定ID推送更新"
        width="600px"
        center
    >
        <el-form :model="targetedPushForm" label-width="120px">
            <el-form-item label="推送类型">
                <el-radio-group v-model="targetedPushForm.targetType">
                    <el-radio :label="'all'">全部推送</el-radio>
                    <el-radio :label="'user_id'">用户ID</el-radio>
                    <el-radio :label="'domain'">域名</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item 
                v-if="targetedPushForm.targetType !== 'all'" 
                label="目标值"
            >
                <el-input
                    v-model="targetedPushForm.targetValues"
                    type="textarea"
                    :rows="3"
                    placeholder="多个值用逗号或换行分隔"
                ></el-input>
            </el-form-item>
            <div style="max-width: 600px; margin: 10px auto 0;">
                <el-alert v-if="targetedPushForm.targetType === 'all'" title="全部推送，将把此更新包推送给所有用户" type="success" center show-icon :closable="false" />
            </div>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.targetedPush = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? submitTargetedPush() : handleUnauthorizedClick()">确认推送</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 推送目标管理弹窗 -->
    <el-dialog
        v-model="dialogVisible.pushTargets"
        title="推送ID管理"
        width="700px"
        center
    >
        <div v-if="currentUpdate.pushedTargets" style="max-height: 500px; overflow-y: auto;">
            <el-tag
                v-for="target in currentUpdate.pushedTargets.split(', ')"
                :key="target"
                type="info"
                closable
                @close="removePushTarget(target)"
                style="margin-right: 5px; margin-bottom: 10px;"
            >
                {{ target }}
            </el-tag>
        </div>
        <div v-else style="text-align: center; padding: 40px 0; color: #909399;">
            暂无推送记录
        </div>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.pushTargets = false) : handleUnauthorizedClick()">关闭</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 编辑更新弹窗 -->
    <el-dialog
        v-model="dialogVisible.updateAction"
        :title="'操作：' + currentUpdate.version"
        width="400px"
        center
    >
        <div class="update-actions" style="padding: 20px; box-sizing: border-box;">
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <div>
                    <el-button 
                        type="primary" 
                        plain
                        @click="is_authorized ? handleUpdateAction('edit') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        编辑更新包
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="success" 
                        plain
                        @click="is_authorized ? handleUpdateAction('targetedPush') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        指定ID推送
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="info" 
                        plain
                        @click="is_authorized ? handleUpdateAction('allPush') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        全部推送
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="danger" 
                        plain
                        @click="is_authorized ? handleUpdateAction('delete') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        删除更新包
                    </el-button>
                </div>
            </div>
        </div>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.updateAction = false) : handleUnauthorizedClick()">关闭</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 添加更新包弹窗 -->
    <el-dialog
        v-model="dialogVisible.addUpdate"
        title="添加更新包"
        width="600px"
        center
    >
        <el-form :model="addUpdateForm" label-width="120px">
            <el-form-item label="选择产品" required>
                <el-select v-model="addUpdateForm.productId" placeholder="请选择产品" style="width: 100%;">
                    <el-option 
                        v-for="(name, id) in productList" 
                        :key="id" 
                        :label="name" 
                        :value="id"
                    ></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="版本号" required>
                <el-input v-model="addUpdateForm.version" placeholder="请输入版本号"></el-input>
            </el-form-item>
            <el-form-item label="更新包URL" required>
                <el-input v-model="addUpdateForm.updatePackageUrl" placeholder="请输入包含http://或https://的完整URL"></el-input>
            </el-form-item>
            <el-form-item label="更新说明">
                <el-input
                    v-model="addUpdateForm.updateDescription"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入更新说明"
                ></el-input>
            </el-form-item>
            <el-form-item label="适用原版本">
                <el-input
                    v-model="addUpdateForm.originalVersions"
                    type="textarea"
                    :rows="3"
                    placeholder="指定哪些版本可以接收此更新。多个版本用逗号或换行分隔，留空表示适用于所有版本"
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.addUpdate = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? confirmAddUpdate() : handleUnauthorizedClick()">添加更新包</el-button>
            </span>
        </template>
    </el-dialog>
</div>