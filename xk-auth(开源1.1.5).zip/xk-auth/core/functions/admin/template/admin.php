<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2026-01-24 15:00:00
 * @Project      : 星空授权插件
 * @Description  : 前端授权管理功能设置
 * Copyright (c) 2026 by 星空授权, All Rights Reserved.
 */
?>
<el-row :gutter="20">
    <!-- 前端授权管理功能设置 -->
    <el-col :xs="24" :sm="24" :md="24" :lg="24">
        <div class="card-box">
            <el-tabs v-model="activeTab">
                <!-- 前端授权管理设置 TAB -->
                <el-tab-pane label="前端授权管理设置" name="frontendAuth">

                    <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 20px;">
                        <el-button 
                        type="primary" 
                        @click="is_authorized ? saveFrontendAuthSetting() : handleUnauthorizedClick()"
                        >保存设置</el-button>
                    </div>
                    
                    <!-- 筛选条件 -->
                    <div class="filter-bar">
                        <el-form :inline="true" class="demo-form-inline">
                            <el-form-item label="前端授权管理">
                                <el-switch 
                                    v-model="frontendAuthEnabled" 
                                    active-text="开启" 
                                    inactive-text="关闭"
                                ></el-switch>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-tab-pane>
                
                <!-- 授权用户管理 TAB -->
                <el-tab-pane label="授权用户管理" name="authorizedUsers">
                    <div class="filter-bar">
                        <el-form :inline="true" class="demo-form-inline">
                            <el-form-item label="添加授权用户">
                                <el-autocomplete 
                                    v-model="userSearchText" 
                                    :fetch-suggestions="querySearch" 
                                    clearable 
                                    style="width: 200px;" 
                                    placeholder="搜索用户"
                                    @select="handleSelect"
                                    value-key="name"
                                >
                                    <template #default="{ item }">
                                        <div>
                                            {{ item.name }}
                                        </div>
                                    </template>
                                </el-autocomplete>
                            </el-form-item>
                            <el-form-item>
                                <el-button type="primary" @click="is_authorized ? addAuthorizedUser() : handleUnauthorizedClick()">添加授权</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                    
                    <!-- 授权用户列表 -->
                    <el-table :data="authorizedUsers" stripe style="width: 100%" v-loading="loading.authorizedUsers">
                        <el-table-column prop="id" label="ID" width="80"></el-table-column>
                        <el-table-column prop="name" label="用户名" min-width="150"></el-table-column>
                        <el-table-column prop="email" label="邮箱" min-width="150"></el-table-column>
                        <el-table-column label="操作" width="150" fixed="right">
                            <template #default="scope">
                                <el-button 
                                    type="danger" 
                                    size="small" 
                                    @click="is_authorized ? removeAuthorizedUser(scope.row.id) : handleUnauthorizedClick()"
                                >
                                    移除授权
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    
                    <!-- 分页 -->
                    <div class="pagination-container">
                        <el-pagination
                            background
                            layout="prev, pager, next, jumper, ->, total"
                            :total="authorizedUsersTotal"
                            :current-page="authorizedUsersCurrentPage"
                            :page-size="authorizedUsersPageSize"
                            @current-change="handleAuthorizedUsersPageChange"
                            style="margin-top: 15px;"
                        ></el-pagination>
                    </div>
                </el-tab-pane>
            </el-tabs>
        </div>
    </el-col>
</el-row>