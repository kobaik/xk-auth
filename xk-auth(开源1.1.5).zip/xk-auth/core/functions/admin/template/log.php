<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-18 18:30:00
 * @Project      : 星空授权插件
 * @Description  : 日志管理页面模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 */
?>
<div class="log-manage-container">
    <el-card shadow="hover">
        <template #header>
            <div class="card-header">
                <span>日志管理</span>
            <el-button 
            type="danger" 
            size="small" 
            @click="is_authorized ? clearLogs() : handleUnauthorizedClick()" 
            :loading="clearingLogs"
            style="position: absolute; right: 30px;"
            >
            <i class="el-icon-delete"></i> 清理当前标签页日志
            </el-button>
            </div>

        </template>
        <!-- 标签页切换 -->
        <el-tabs v-model="activeTab" type="card">
            <!-- 授权请求日志 -->
            <el-tab-pane label="授权请求日志" name="authRequest">
                <!-- 日志列表 -->
                <el-skeleton :rows="5" animated v-if="loading.auth_request_log"></el-skeleton>
                <el-table v-else :data="authRequestLogs" stripe border style="width: 100%">
                    <el-table-column prop="id" label="ID" min-width="50"></el-table-column>
                    <el-table-column prop="productName" label="产品名称" min-width="110"></el-table-column>
                    <el-table-column prop="requestIp" label="请求IP" min-width="110"></el-table-column>
                    <el-table-column prop="domain" label="请求域名" min-width="90"></el-table-column>
                    <el-table-column prop="authKey" label="授权密钥" min-width="200"></el-table-column>
                    <el-table-column prop="status" label="状态" min-width="120">
                        <template #default="scope">
                            <el-tag :type="scope.row.statusClass">
                                {{ scope.row.statusText }}
                            </el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="requestTime" label="请求时间" min-width="180"></el-table-column>
                    <!-- 空状态 -->
                </el-table>
                
                <!-- 空状态 -->
                <el-empty v-if="!loading.auth_request_log && authRequestLogs.length === 0" description="暂无授权请求日志"></el-empty>
                
                <!-- 分页 -->
                <div class="pagination-container">
                    <el-pagination
                        background
                        layout="prev, pager, next, jumper"
                        :total="authRequestTotal"
                        :current-page="authRequestCurrentPage"
                        :page-size="authRequestPageSize"
                        @current-change="handleAuthRequestPageChange"
                        style="margin-top: 20px;"
                    ></el-pagination>
                </div>
            </el-tab-pane>
            
            <!-- 授权操作日志 -->
            <el-tab-pane label="授权操作日志" name="authOperation">
                <!-- 日志列表 -->
                <el-skeleton :rows="5" animated v-if="loading.auth_operation_log"></el-skeleton>
                <el-table v-else :data="authOperationLogs" stripe border style="width: 100%">
                    <el-table-column prop="id" label="ID" min-width="80"></el-table-column>
                    <el-table-column prop="operator" label="操作人" min-width="100"></el-table-column>
                    <el-table-column prop="targetUser" label="目标用户" min-width="100"></el-table-column>
                    <el-table-column prop="targetProduct" label="目标产品" min-width="120"></el-table-column>
                    <el-table-column prop="detail" label="操作详情" min-width="200"></el-table-column>
                    <el-table-column prop="operationTime" label="操作时间" min-width="180"></el-table-column>
                </el-table>
                
                <!-- 空状态 -->
                <el-empty v-if="!loading.auth_operation_log && authOperationLogs.length === 0" description="暂无授权操作日志"></el-empty>
                
                <!-- 分页 -->
                <div class="pagination-container">
                    <el-pagination
                        background
                        layout="prev, pager, next, jumper"
                        :total="authOperationTotal"
                        :current-page="authOperationCurrentPage"
                        :page-size="authOperationPageSize"
                        @current-change="handleAuthOperationPageChange"
                        style="margin-top: 20px;"
                    ></el-pagination>
                </div>
            </el-tab-pane>
            
            <!-- 更新请求日志 -->
            <el-tab-pane label="更新请求日志" name="updateRequest">
                <!-- 日志列表 -->
                <el-skeleton :rows="5" animated v-if="loading.update_request_log"></el-skeleton>
                <el-table v-else :data="updateRequestLogs" stripe border style="width: 100%">
                    <el-table-column prop="id" label="ID" min-width="80"></el-table-column>
                    <el-table-column prop="productName" label="产品名称" min-width="120"></el-table-column>
                    <el-table-column prop="currentVersion" label="当前版本" min-width="100"></el-table-column>
                    <el-table-column prop="domain" label="请求域名" min-width="150"></el-table-column>
                    <el-table-column prop="requestIp" label="请求IP" min-width="120"></el-table-column>
                    <el-table-column prop="status" label="状态" min-width="80">
                        <template #default="scope">
                            <el-tag :type="scope.row.statusClass">
                                {{ scope.row.statusText }}
                            </el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="requestTime" label="请求时间" min-width="180"></el-table-column>
                </el-table>
                
                <!-- 空状态 -->
                <el-empty v-if="!loading.update_request_log && updateRequestLogs.length === 0" description="暂无更新请求日志"></el-empty>
                
                <!-- 分页 -->
                <div class="pagination-container">
                    <el-pagination
                        background
                        layout="prev, pager, next, jumper"
                        :total="updateRequestTotal"
                        :current-page="updateRequestCurrentPage"
                        :page-size="updateRequestPageSize"
                        @current-change="handleUpdateRequestPageChange"
                        style="margin-top: 20px;"
                    ></el-pagination>
                </div>
            </el-tab-pane>
            
            <!-- 前端管理操作日志 -->
            <el-tab-pane label="前端管理操作日志" name="frontendAdmin">
                <!-- 日志列表 -->
                <el-skeleton :rows="5" animated v-if="loading.frontend_admin_log"></el-skeleton>
                <el-table v-else :data="frontendAdminLogs" stripe border style="width: 100%">
                    <el-table-column prop="id" label="ID" min-width="80"></el-table-column>
                    <el-table-column prop="operator" label="操作人" min-width="120"></el-table-column>
                    <el-table-column prop="actionType" label="操作类型" min-width="120">
                        <template #default="scope">
                            <el-tag :type="scope.row.actionTypeClass">
                                {{ scope.row.actionTypeText }}
                            </el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="targetUser" label="目标用户" min-width="120"></el-table-column>
                    <el-table-column prop="targetProduct" label="目标产品" min-width="150"></el-table-column>
                    <el-table-column prop="actionDetail" label="操作详情" min-width="200"></el-table-column>
                    <el-table-column prop="actionTime" label="操作时间" min-width="180"></el-table-column>
                </el-table>
                
                <!-- 空状态 -->
                <el-empty v-if="!loading.frontend_admin_log && frontendAdminLogs.length === 0" description="暂无前端管理操作日志"></el-empty>
                
                <!-- 分页 -->
                <div class="pagination-container">
                    <el-pagination
                        background
                        layout="prev, pager, next, jumper"
                        :total="frontendAdminTotal"
                        :current-page="frontendAdminCurrentPage"
                        :page-size="frontendAdminPageSize"
                        @current-change="handleFrontendAdminPageChange"
                        style="margin-top: 20px;"
                    ></el-pagination>
                </div>
            </el-tab-pane>
        </el-tabs>
    </el-card>
</div>