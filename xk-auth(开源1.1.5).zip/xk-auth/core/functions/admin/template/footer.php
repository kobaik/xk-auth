<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-17 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 管理页面底部模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 */
?>
