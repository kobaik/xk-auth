<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-17 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 管理页面头部模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 * @Email        : admin@xkzhi.com
 * @Read me      : 感谢您使用星空授权插件，插件源码有详细的注释，支持二次开发
 * @Remind       : 使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
?>
<div class="mb10">
    <el-menu
        :default-active="$route.path"
        class="menu-tabs"
        mode="horizontal"
        @select="menuGo">
        <el-menu-item index="/">统计</el-menu-item>
        <el-menu-item index="/auth">授权</el-menu-item>
        <el-menu-item index="/log">日志</el-menu-item>
        <el-menu-item index="/update">更新</el-menu-item>
        <el-menu-item index="/promo">优惠码</el-menu-item>
        <el-menu-item index="/report">举报</el-menu-item>
        <el-menu-item index="/admin">前端授权管理</el-menu-item>
    </el-menu>
</div>