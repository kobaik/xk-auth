<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-17 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 举报管理页面模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 */
?>

<div class="reports-manage-container">
    <el-card shadow="hover">
        <template #header>
            <div class="card-header">
                <span>举报管理</span>
            </div>
        </template>
        <!-- 标签页切换 -->
        <el-tabs v-model="activeTab" type="card">
            <!-- 举报管理标签页 -->
            <el-tab-pane label="举报管理" name="manage">
                <!-- 搜索和视图模式区域 -->
                <el-form :inline="true" class="search-form">
                    <el-form-item label="搜索类型">
                        <el-select v-model="reportSearchType" placeholder="请选择搜索类型" style="width: 120px;">
                            <el-option key="user" label="用户" value="user"></el-option>
                            <el-option key="product" label="产品" value="product"></el-option>
                            <el-option key="type" label="举报类型" value="type"></el-option>
                        </el-select>
                    </el-form-item>
                    
                    <el-form-item>
                        <el-input v-model="reportSearchKeyword" placeholder="请输入搜索内容" style="width: 200px;"></el-input>
                    </el-form-item>
                    
                    <el-form-item>
                        <el-button type="primary" @click="is_authorized ? reportHandleSearch() : handleUnauthorizedClick()">搜索</el-button>
                        <el-button @click="is_authorized ? reportResetSearch() : handleUnauthorizedClick()">重置</el-button>
                    </el-form-item>
                     <el-button 
                        type="danger" 
                        @click="is_authorized ? batchDeleteReports() : handleUnauthorizedClick()"
                        :disabled="selectedReports.length === 0"
                        style="margin:0px 0px 18px -18px;"
                    >
                        <i class="el-icon-delete"></i> 批量删除
                    </el-button>
                </el-form>
            
                
                <!-- 状态筛选 -->
                <div class="status-filter">
                    <el-radio-group 
                    v-model="reportStatusFilter" 
                    @change="is_authorized ? reportHandleStatusChange() : handleUnauthorizedClick()"
                    style="margin:0px 0px 14px;"
                    >
                        <el-radio-button label="">全部</el-radio-button>
                        <el-radio-button label="pending">待处理</el-radio-button>
                        <el-radio-button label="processed">已处理</el-radio-button>
                        <el-radio-button label="rejected">已拒绝</el-radio-button>
                    </el-radio-group>
                </div>
                
                <!-- 搜索结果提示 -->
                <div v-if="reportSearchKeyword" class="search-result-info">
                    搜索类型：{{ reportSearchTypeText[reportSearchType] }}，关键词："{{ reportSearchKeyword }}" 的搜索结果
                </div>
                
                <!-- 举报列表 -->
                <div class="report-list">
                    <el-skeleton :rows="5" animated v-if="loading.report_table"></el-skeleton>
                    <el-table v-else :data="reportsList" stripe border style="width: 100%" @selection-change="handleReportSelectionChange">
                        <el-table-column type="selection" width="55"></el-table-column>
                        <el-table-column prop="id" label="举报ID" min-width="80"></el-table-column>
                        <el-table-column prop="userName" label="举报用户" min-width="120">
                            <template #default="scope">
                                <div>{{ scope.row.userName }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="productName" label="产品" min-width="100">
                            <template #default="scope">
                                <div>{{ scope.row.productName }}</div>
                                <div class="row-actions">ID: {{ scope.row.productId }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="reportType" label="举报类型" min-width="100"></el-table-column>
                        <el-table-column prop="reportContent" label="举报内容" min-width="100">
                            <template #default="scope">
                                <el-button 
                                    type="primary" 
                                    size="small"
                                    @click="is_authorized ? showReportContent(scope.row) : handleUnauthorizedClick()"
                                >
                                    查看内容
                                </el-button>
                            </template>
                        </el-table-column>
                        <el-table-column prop="reportUrl" label="举报域名" min-width="150">
                            <template #default="scope">
                                <a 
                                v-if="scope.row.reportUrl" 
                                :href="'http://' + scope.row.reportUrl.replace(/^https?:\/\//, '')" 
                                style="text-decoration: none;"
                                target="_blank" 
                                class="report-url">{{ scope.row.reportUrl.replace(/^https?:\/\//, '') }}
                            </a>
                                <span v-else>无</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="reportIp" label="举报IP" min-width="100"></el-table-column>
                        <el-table-column prop="status" label="状态" min-width="80">
                            <template #default="scope">
                                <el-tag :type="scope.row.statusClass">{{ scope.row.statusText }}</el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="operationTime" label="举报时间" min-width="150"></el-table-column>
                        <el-table-column prop="processTime" label="处理时间" min-width="150">
                            <template #default="scope">
                                <span>{{ scope.row.processTime || '未处理' }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="操作" min-width="150" fixed="right">
                            <template #default="scope">
                                <el-button 
                                    type="primary" 
                                    size="small" 
                                    plain
                                    @click="is_authorized ? openReportActionDialog(scope.row) : handleUnauthorizedClick()"
                                >
                                    处理举报
                                </el-button>
                                <el-button 
                                    type="danger" 
                                    size="small" 
                                    plain
                                    @click="is_authorized ? deleteReport(scope.row) : handleUnauthorizedClick()"
                                    style="margin-left: 5px;"
                                >
                                    删除
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    
                    <!-- 空状态 -->
                    <el-empty v-if="!loading.report_table && reportsList.length === 0" description="暂无举报记录"></el-empty>
                </div>
                
                <!-- 分页 -->
                <div class="pagination-container">
                    <el-pagination
                        background
                        layout="prev, pager, next, jumper"
                        :total="reportsTotal"
                        :current-page="reportCurrentPage"
                        :page-size="reportPageSize"
                        @current-change="is_authorized ? reportHandleCurrentChange($event) : handleUnauthorizedClick()"
                        style="margin-top: 20px;"
                    ></el-pagination>
                </div>
            </el-tab-pane>
            
            <!-- 举报设置标签页 -->
            <el-tab-pane label="举报设置" name="settings">
                <div class="report-settings">
                    <el-form :model="reportSettingsForm" label-width="120px">
                        <el-form-item label="举报功能开关">
                            <el-switch 
                                v-model="reportSettingsForm.enabled" 
                                active-text="开启" 
                                inactive-text="关闭"
                            ></el-switch>
                        </el-form-item>
                        
                        <el-form-item label="邮箱通知开关">
                            <el-switch 
                                v-model="reportSettingsForm.emailNotification" 
                                active-text="开启" 
                                inactive-text="关闭"
                            ></el-switch>
                        </el-form-item>
                        
                        <el-form-item label="发送者名称设置">
                            <el-input 
                                v-model="reportSettingsForm.senderName" 
                                placeholder="请输入邮件通知的发送者名称" 
                                style="width: 300px;"
                            ></el-input>
                            <el-alert title="用于在发送举报处理通知邮件时显示的发送者名称(需在子比设置STMP)" style="margin-left: 10px;max-width: 600px;" type="success" :closable="false" />
                        </el-form-item>
                        
                        <el-form-item label="举报类型设置">
                            <div class="report-types-container">
                                <div v-for="(type, index) in reportSettingsForm.reportTypes" :key="index" class="report-type-item">
                                    <el-input 
                                        v-model="type.key" 
                                        placeholder="类型标识" 
                                        style="width: 150px; margin-right: 10px;"
                                    ></el-input>
                                    <el-input 
                                        v-model="type.label" 
                                        placeholder="类型名称" 
                                        style="width: 200px; margin-right: 10px;"
                                    ></el-input>
                                    <el-button 
                                        type="danger" 
                                        size="small"
                                        @click="removeReportType(index)"
                                    >
                                        删除
                                    </el-button>
                                </div>
                                <el-button 
                                    type="primary" 
                                    size="small"
                                    @click="addReportType"
                                    style="margin-top: 10px;"
                                >
                                    添加举报类型
                                </el-button>
                            </div>
                        </el-form-item>
                    </el-form>
                    
                    <div class="settings-actions">
                        <el-button type="primary" @click="saveReportSettings">保存设置</el-button>
                    </div>
                </div>
            </el-tab-pane>
        </el-tabs>
    </el-card>
    
    <!-- 处理举报弹窗 -->
    <el-dialog
        v-model="dialogVisible.reportAction"
        :title="'处理举报: ID ' + (currentReport ? currentReport.id : '')"
        width="600px"
        center
    >
        <el-form :model="reportActionForm" label-width="80px">
            <el-form-item label="举报用户">
                <el-input v-model="reportActionForm.userName" disabled></el-input>
            </el-form-item>
            <el-form-item label="产品名称">
                <el-input v-model="reportActionForm.productName" disabled></el-input>
            </el-form-item>
            <el-form-item label="举报类型">
                <el-input v-model="reportActionForm.reportType" style="text-decoration: none;" disabled></el-input>
            </el-form-item>
            <el-form-item label="举报域名">
                <a v-if="reportActionForm.reportUrl" style="text-decoration: none;":href="'http://' + reportActionForm.reportUrl.replace(/^https?:\/\//, '')" target="_blank">{{ reportActionForm.reportUrl.replace(/^https?:\/\//, '') }}</a>
                <span v-else>无</span>
            </el-form-item>
            <el-form-item label="举报内容">
                <el-input
                    v-model="reportActionForm.reportContent"
                    type="textarea"
                    :rows="4"
                    disabled
                ></el-input>
            </el-form-item>
            <el-form-item label="举报时间">
                <el-input v-model="reportActionForm.operationTime" disabled></el-input>
            </el-form-item>
            <el-form-item label="当前状态">
                <el-tag :type="reportActionForm.statusClass">{{ reportActionForm.statusText }}</el-tag>
            </el-form-item>
            <el-form-item label="处理状态" required>
                <el-radio-group v-model="reportActionForm.status">
                    <el-radio :label="'pending'">待处理</el-radio>
                    <el-radio :label="'processed'">已处理</el-radio>
                    <el-radio :label="'rejected'">已拒绝</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="处理备注" required>
                <el-input
                    v-model="reportActionForm.adminNote"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入处理备注"
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.reportAction = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? confirmReportAction() : handleUnauthorizedClick()">确定处理</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 举报内容弹窗 -->
    <el-dialog
        v-model="dialogVisible.reportContent"
        :title="'举报内容: ID ' + (currentReport ? currentReport.id : '')"
        width="500px"
        center
    >
        <div class="report-content-dialog">
            <el-form :model="reportActionForm" label-width="80px">
                <el-form-item label="举报内容">
                    <el-input
                        v-model="reportActionForm.reportContent"
                        type="textarea"
                        :rows="6"
                        disabled
                    ></el-input>
                </el-form-item>
            </el-form>
        </div>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.reportContent = false) : handleUnauthorizedClick()">关闭</el-button>
            </span>
        </template>
    </el-dialog>
</div>