<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-17 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 授权管理页面模板
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 */
?>

<div class="auth-manage-container">
    <el-card shadow="hover">
        <template #header>
            <div class="card-header">
                <span>授权管理</span>
            </div>
        </template>
        <!-- 搜索和视图模式区域 -->
        <el-form :inline="true" class="search-form">
            <el-form-item label="视图模式">
                <el-select v-model="authViewMode" placeholder="请选择视图模式" style="width: 180px;" @change="authHandleViewModeChange">
                    <el-option key="user" label="按用户分组" value="user"></el-option>
                    <el-option key="product" label="按产品分类" value="product"></el-option>
                </el-select>
            </el-form-item>
            
            <el-form-item label="搜索类型">
                <el-select v-model="authSearchType" placeholder="请选择搜索类型" style="width: 120px;">
                    <el-option key="user" label="用户" value="user"></el-option>
                    <el-option key="domain" label="域名" value="domain"></el-option>
                    <el-option key="product" label="产品" value="product"></el-option>
                </el-select>
            </el-form-item>
            
            <el-form-item>
                <el-input v-model="authSearchKeyword" placeholder="请输入搜索内容" style="width: 200px;"></el-input>
            </el-form-item>
            
            <el-form-item>
                <el-button type="primary" @click="is_authorized ? authHandleSearch() : handleUnauthorizedClick()">搜索</el-button>
                <el-button @click="is_authorized ? authResetSearch() : handleUnauthorizedClick()">重置</el-button>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="is_authorized ? (dialogVisible.addAuth = true) : handleUnauthorizedClick()">添加授权</el-button>
            </el-form-item>
        </el-form>
        
        
        <!-- 状态筛选 -->
        <div class="status-filter">
            <el-radio-group v-model="authStatusFilter" @change="authHandleStatusChange">
                <el-radio-button label="">全部</el-radio-button>
                <el-radio-button label="1">正常</el-radio-button>
                <el-radio-button label="0">封禁</el-radio-button>
            </el-radio-group>
        </div>
        
        <!-- 搜索结果提示 -->
        <div v-if="authSearchKeyword" class="search-result-info">
            搜索类型：{{ authSearchTypeText[authSearchType] }}，关键词："{{ authSearchKeyword }}" 的搜索结果
        </div>
        
        <!-- 授权列表 -->
        <div v-if="authViewMode === 'user'" class="auth-list">
            <el-skeleton :rows="5" animated v-if="loading.auth_table"></el-skeleton>
            <el-collapse v-else v-model="authActiveUserNames" accordion>
                <el-collapse-item 
                    v-for="user in authUserGroups" 
                    :key="user.userId" 
                    :title="`用户: ${user.userName} (ID: ${user.userId}) - 域名数量: ${user.auths.length}`"
                    style="margin-top: 5px;"
                >
                    <el-table :data="user.auths" stripe border style="width: 100%">
                        <el-table-column prop="productName" label="产品" min-width="100">
                            <template #default="scope">
                                <div>{{ scope.row.productName }}</div>
                                <div class="row-actions">ID: {{ scope.row.productId }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column label="授权数量" min-width="150">
                            <template #default="scope">
                                <div>当前授权: {{ scope.row.totalAuths }}</div>
                                <div class="row-actions">剩余授权: {{ scope.row.remainingAuths }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="domain" label="授权域名" min-width="80"></el-table-column>
                        <el-table-column prop="authKey" label="授权密钥" min-width="200">
                            <template #default="scope">
                                <div class="auth-key">{{ scope.row.authKey }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="expireTime" label="到期时间" min-width="150"></el-table-column>
                        <el-table-column prop="status" label="状态" min-width="50">
                            <template #default="scope">
                                <el-tag :type="scope.row.statusClass">{{ scope.row.statusText }}</el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="operationTime" label="操作时间" min-width="120"></el-table-column>
                        <el-table-column label="操作" min-width="120" fixed="right">
                            <template #default="scope">
                                <el-button 
                                    type="primary" 
                                    size="small" 
                                    plain
                                    @click="is_authorized ? openAuthActionDialog(scope.row) : handleUnauthorizedClick()"
                                >
                                    管理授权
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-collapse-item>
            </el-collapse>
            
            <!-- 空状态 -->
            <el-empty v-if="!loading.auth_table && authUserGroups.length === 0" description="暂无授权记录"></el-empty>
        </div>
        
        <!-- 产品分组视图 -->
        <div v-else class="auth-list">
            <el-skeleton :rows="5" animated v-if="loading.auth_table"></el-skeleton>
            <el-collapse v-else v-model="authActiveProductNames" accordion>
                <el-collapse-item 
                    v-for="product in authProductGroups" 
                    :key="product.productId" 
                    :title="`产品: ${product.productName} (ID: ${product.productId}) - 授权数量: ${product.auths.length}`"
                >
                    <el-table :data="product.auths" stripe border style="width: 100%">
                        <el-table-column prop="userName" label="用户名/ID" min-width="100">
                            <template #default="scope">
                                <div>{{ scope.row.userName }}</div>
                                <div class="row-actions">ID: {{ scope.row.userId }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column label="授权数量" min-width="150">
                            <template #default="scope">
                                <div>当前授权: {{ scope.row.totalAuths }}</div>
                                <div class="row-actions">剩余授权: {{ scope.row.remainingAuths }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="domain" label="授权域名" min-width="120"></el-table-column>
                        <el-table-column prop="authKey" label="授权密钥" min-width="200">
                            <template #default="scope">
                                <div class="auth-key">{{ scope.row.authKey }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="expireTime" label="到期时间" min-width="150"></el-table-column>
                        <el-table-column prop="status" label="状态" min-width="50">
                            <template #default="scope">
                                <el-tag :type="scope.row.statusClass">{{ scope.row.statusText }}</el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="operationTime" label="操作时间" min-width="150"></el-table-column>
                        <el-table-column label="操作" min-width="200" fixed="right">
                            <template #default="scope">
                                <el-button 
                                    type="primary" 
                                    size="small" 
                                    plain
                                    @click="is_authorized ? openAuthActionDialog(scope.row) : handleUnauthorizedClick()"
                                >
                                    操作
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-collapse-item>
            </el-collapse>
            
            <!-- 空状态 -->
            <el-empty v-if="!loading.auth_table && authProductGroups.length === 0" description="暂无授权记录"></el-empty>
        </div>
        
        <!-- 分页 -->
        <div class="pagination-container">
            <el-pagination
                background
                layout="prev, pager, next, jumper"
                :total="authTotalCount"
                :current-page="authCurrentPage"
                :page-size="authPageSize"
                @current-change="authHandleCurrentChange"
                style="margin-top: 20px;"
            ></el-pagination>
        </div>
    </el-card>
    

    
    <!-- 修改状态弹窗 -->
    <el-dialog
        v-model="dialogVisible.statusUpdate"
        title="修改授权状态"
        width="500px"
        center
    >
        <el-form :model="statusUpdateForm" label-width="80px">
            <el-form-item label="当前状态">
                <el-tag :type="statusUpdateForm.status === 1 ? 'success' : 'danger'">
                    {{ statusUpdateForm.status === 1 ? '正常' : '封禁' }}
                </el-tag>
            </el-form-item>
            <el-form-item label="新状态">
                <el-radio-group v-model="statusUpdateForm.status">
                    <el-radio :label="1">正常</el-radio>
                    <el-radio :label="0">封禁</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="处理备注">
                <el-input
                    v-model="statusUpdateForm.log"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入处理备注"
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.statusUpdate = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? confirmStatusUpdate() : handleUnauthorizedClick()">确定</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 管理域名弹窗 -->
    <el-dialog
        v-model="dialogVisible.domainManage"
        title="管理授权域名"
        width="500px"
        center
    >
        <el-form :model="domainManageForm" label-width="80px">
            <el-form-item label="当前域名">
                <el-input v-model="domainManageForm.currentDomain" disabled></el-input>
            </el-form-item>
            <el-form-item label="产品名称">
                <el-input v-model="domainManageForm.productName" disabled></el-input>
            </el-form-item>
            <el-form-item label="用户名称">
                <el-input v-model="domainManageForm.userName" disabled></el-input>
            </el-form-item>
            <el-form-item label="新域名">
                <el-input
                    v-model="domainManageForm.newDomain"
                    placeholder="请输入新域名或IP地址（不带http://）"
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.domainManage = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="danger" @click="is_authorized ? deleteDomain() : handleUnauthorizedClick()">删除域名</el-button>
                <el-button type="primary" @click="is_authorized ? confirmDomainUpdate() : handleUnauthorizedClick()">修改域名</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 修改总授权数量弹窗 -->
    <el-dialog
        v-model="dialogVisible.authCountUpdate"
        title="修改总授权数量"
        width="500px"
        center
    >
        <el-form :model="authCountUpdateForm" label-width="120px">
            <el-form-item label="产品ID">
                <el-input v-model="authCountUpdateForm.productId" disabled></el-input>
            </el-form-item>
            <el-form-item label="用户ID">
                <el-input v-model="authCountUpdateForm.userId" disabled></el-input>
            </el-form-item>
            <el-form-item label="授权总数量">
                <el-input-number
                    v-model="authCountUpdateForm.authCount"
                    :min="0"
                    :step="1"
                    placeholder="请输入授权总数量"
                    style="width: 100%"
                ></el-input-number>
            </el-form-item>
            <el-form-item label="修改原因">
                <el-input
                    v-model="authCountUpdateForm.reason"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入修改原因"
                    style="width: 100%"
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.authCountUpdate = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? confirmAuthCountUpdate() : handleUnauthorizedClick()">确定</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 设置到期时间弹窗 -->
    <el-dialog
        v-model="dialogVisible.expireTimeSet"
        title="设置到期时间"
        width="500px"
        center
    >
        <el-form :model="expireTimeSetForm" label-width="80px">
            <el-form-item label="到期时间">
                <el-date-picker
                    v-model="expireTimeSetForm.expireTime"
                    type="datetime"
                    placeholder="选择到期时间"
                    format="YYYY-MM-DD HH:mm"
                    value-format="YYYY-MM-DD HH:mm"
                    clearable
                    :disabled="expireTimeSetForm.permanent"
                    style="width: 100%"
                ></el-date-picker>
            </el-form-item>
            <el-form-item label="设置原因" required>
                <el-input
                    v-model="expireTimeSetForm.reason"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入设置原因"
                ></el-input>
            </el-form-item>
            <div style="text-align: center; margin-top: 10px; color: rgb(144, 147, 153);">
            <el-checkbox v-model="expireTimeSetForm.permanent" @change="handlePermanentChange">永久授权</el-checkbox>
            </div>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.expireTimeSet = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? confirmExpireTimeSet() : handleUnauthorizedClick()">确定</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 推送Token弹窗 -->
    <el-dialog
        v-model="dialogVisible.pushToken"
        title="推送Token"
        width="600px"
        center
    >
        <div v-if="pushTokenForm.result" class="push-token-result" style="margin-bottom: 20px; padding: 15px; background-color: #f0f0f0; border-radius: 4px;">
            <h4 style="margin-bottom: 10px;">推送结果</h4>
            <p>{{ pushTokenForm.result }}</p>
        </div>
        
        <div v-if="pushTokenForm.detailResult" class="push-token-detail-result" style="margin-bottom: 20px; padding: 15px; background-color: #f9f9f9; border-radius: 4px; border: 1px solid #e0e0e0;">
            <h4 style="margin-bottom: 10px;">详细结果</h4>
            <div class="result-json" style="background-color: #fff; padding: 15px; border-radius: 4px; border: 1px solid #e0e0e0; overflow-x: auto; font-family: monospace; font-size: 13px; line-height: 1.5;">
                <pre>{{ JSON.stringify(pushTokenForm.detailResult, null, 2) }}</pre>
            </div>
        </div>
        
        <el-form :model="pushTokenForm" label-width="80px">
            <el-form-item label="域名">
                <el-input v-model="pushTokenForm.domain" disabled></el-input>
            </el-form-item>
            <el-form-item label="产品ID">
                <el-input v-model="pushTokenForm.productId" disabled></el-input>
            </el-form-item>
            <el-form-item label="授权密钥">
                <el-input v-model="pushTokenForm.authKey" disabled></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.pushToken = false) : handleUnauthorizedClick()">关闭</el-button>
                <el-button type="primary" @click="is_authorized ? confirmPushToken() : handleUnauthorizedClick()">确认推送</el-button>
            </span>
        </template>
    </el-dialog>
    
    <!-- 授权操作弹窗 -->
    <el-dialog
        v-model="dialogVisible.authAction"
        :title="'操作：' + (currentAuth ? currentAuth.domain : '')"
        width="400px"
        center
    >
        <div class="auth-actions" style="padding: 20px; box-sizing: border-box;">
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <div>
                    <el-button 
                        type="primary" 
                        plain
                        @click="is_authorized ? handleAuthAction('status') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        {{ currentAuth && currentAuth.status === 1 ? '封禁授权' : '启用授权' }}
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="success" 
                        plain
                        @click="is_authorized ? handleAuthAction('domain') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        管理域名
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="info" 
                        plain
                        @click="is_authorized ? handleAuthAction('count') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        修改授权数量
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="warning" 
                        plain
                        @click="is_authorized ? handleAuthAction('expire') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        设置到期时间
                    </el-button>
                </div>
                <div>
                    <el-button 
                        type="danger" 
                        plain
                        @click="is_authorized ? handleAuthAction('token') : handleUnauthorizedClick()"
                        style="width: 100%;"
                    >
                        推送Token
                    </el-button>
                </div>
            </div>
        </div>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.authAction = false) : handleUnauthorizedClick()">关闭</el-button>
            </span>
        </template>
    </el-dialog>

    <!-- 添加授权弹窗 -->
    <el-dialog
        v-model="dialogVisible.addAuth"
        title="添加授权"
        width="500px"
        center
    >
        <el-form :model="addAuthForm" label-width="80px">
            <el-form-item label="用户ID" required>
                <el-input v-model="addAuthForm.user_id" placeholder="输入用户ID" style="width: 100%;"></el-input>
                <div style="margin-top: 5px; color: #606266; font-size: 12px;">请勿输入用户名或用户昵称</div>
                <div id="add-auth-user-info" style="margin-top: 5px;"></div>
            </el-form-item>
            <el-form-item label="选择产品" required>
                <el-select v-model="addAuthForm.product_id" placeholder="请选择产品" style="width: 100%;">
                    <el-option v-for="product in products" :key="product.id" :label="product.name" :value="product.id"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="到期时间">
                <el-date-picker
                    v-model="addAuthForm.expire_time"
                    type="datetime"
                    placeholder="选择到期时间"
                    format="YYYY-MM-DD HH:mm"
                    value-format="YYYY-MM-DD HH:mm"
                    clearable
                    style="width: 100%;"
                    :disabled="addAuthForm.permanent"
                ></el-date-picker>
            </el-form-item>
            <el-form-item>
                <div style="text-align: center; margin-top: 10px; color: #606266;">
                    <el-checkbox 
                    v-model="addAuthForm.permanent"
                    style="padding-left: 110px;"
                    >永久授权</el-checkbox>
                </div>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="is_authorized ? (dialogVisible.addAuth = false) : handleUnauthorizedClick()">取消</el-button>
                <el-button type="primary" @click="is_authorized ? confirmAddAuth() : handleUnauthorizedClick()">添加授权</el-button>
            </span>
        </template>
    </el-dialog>
</div>

