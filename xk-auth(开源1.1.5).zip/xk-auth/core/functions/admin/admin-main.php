<?php
/*
 * @Author       : 星空授权
 * @Url          : https://www.xkzhi.cn/
 * @Date         : 2025-07-18 22:12:17
 * @LastEditTime : 2026-01-17 16:00:00
 * @Project      : 星空授权插件
 * @Description  : 更优雅的Wordpress授权管理插件
 * Copyright (c) 2025 by 星空授权, All Rights Reserved.
 * @Email        : admin@xkzhi.com
 * @Read me      : 感谢您使用星空授权插件，插件源码有详细的注释，支持二次开发
 * @Remind       : 使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!is_super_admin()) {
    wp_die('您不能访问此页面', '权限不足');
    exit;
}

// 检查授权状态
$is_authorized = class_exists('xk_auth_Core_license') && xk_auth_Core_license::is_aut();

$vue_data = array(
    'menu_data' => array(
        'order_id' => '',
    ),
    'config' => array(
        'shop_s' => true,
    ),
    'is_authorized' => $is_authorized,
);

// 统计图标dashboard.php使用
// 获取仪表盘数据
// 生成唯一缓存键
$dashboard_cache_key = 'xk_auth_dashboard_data';

// 尝试从缓存获取所有仪表盘数据
$dashboard_data = get_transient($dashboard_cache_key);
if (false === $dashboard_data) {
    global $wpdb;
    
    // 一次性查询所有仪表盘数据
    $dashboard_data = array();
    
    // 获取最近授权记录
    $recent_auths = $wpdb->get_results("SELECT domain, product_id, operation_time, expire_time, status FROM {$wpdb->prefix}product_auths ORDER BY operation_time DESC LIMIT 10");
    $recentAuths = array();
    foreach ($recent_auths as $auth) {
        $expire_time = $auth->expire_time;
        $is_valid_date = $expire_time && $expire_time !== '0000-00-00 00:00:00' && strtotime($expire_time) !== false;
        $formatted_expire_time = $is_valid_date ? $expire_time : '永久';
        $recentAuths[] = array(
            'domain' => $auth->domain,
            'product_id' => $auth->product_id,
            'operation_time' => $auth->operation_time,
            'expire_time' => $formatted_expire_time,
            'status' => $auth->status
        );
    }
    $dashboard_data['recentAuths'] = $recentAuths;
    
    // 关键数据统计
    //总授权数
    $dashboard_data['total_auths'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}product_auths");

    //活跃授权数
    $dashboard_data['active_auths'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}product_auths WHERE status = '1' AND (last_communication_time IS NOT NULL AND last_communication_time >= DATE_SUB(NOW(), INTERVAL 2 HOUR))");

    //过期授权数
    $dashboard_data['expired_auths'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}product_auths WHERE expire_time IS NOT NULL AND expire_time < NOW()");

    //今日新增授权数
    $today = date('Y-m-d');
    $dashboard_data['today_auths'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}product_auths WHERE DATE(operation_time) = %s", $today));

    //授权请求总数
    $dashboard_data['total_requests'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}auth_request_logs");
    //成功授权请求数
    $dashboard_data['success_requests'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}auth_request_logs WHERE status LIKE '%success%'");

    //产品总数
    $dashboard_data['total_products'] = $wpdb->get_var("SELECT COUNT(DISTINCT product_id) FROM {$wpdb->prefix}product_auths");

    //卡密总数
    $dashboard_data['total_cards'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}auth_cards");

    //已使用卡密数
    $dashboard_data['used_cards'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}auth_cards WHERE status = 'used'");

    //未使用卡密数 
    $dashboard_data['unused_cards'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}auth_cards WHERE status = 'unused'");

    //订单统计 - 总订单数
    $dashboard_data['total_orders'] = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}zibpay_order WHERE (order_type = 15 OR order_type = 13) AND status = 1 AND pay_type != 'points'");

    //订单统计 - 总销售额
    $total_sales = $wpdb->get_var("SELECT SUM(order_price) FROM {$wpdb->prefix}zibpay_order WHERE (order_type = 15 OR order_type = 13) AND status = 1 AND pay_type != 'points'");
    $dashboard_data['total_sales'] = $total_sales ? floatval($total_sales) : 0.00;

    //订单统计 - 今日销售额
    $today_sales = $wpdb->get_var($wpdb->prepare("SELECT SUM(order_price) FROM {$wpdb->prefix}zibpay_order WHERE (order_type = 15 OR order_type = 13) AND status = 1 AND pay_type != 'points' AND DATE(pay_time) = %s", $today));
    $dashboard_data['today_sales'] = $today_sales ? floatval($today_sales) : 0.00;

    //订单统计 - 平均订单金额
    $dashboard_data['avg_order_price'] = $dashboard_data['total_orders'] > 0 ? $dashboard_data['total_sales'] / $dashboard_data['total_orders'] : 0.00;
    
    // 获取月度销售额数据（最近6个月）
    $months = array();
    
    // 预生成最近6个月的月份数组
    for ($i = 5; $i >= 0; $i--) {
        $months[] = date('Y-m', strtotime("-$i month"));
    }
    
    // 使用单次查询获取所有月份数据
    $start_month = $months[0];
    $end_month = end($months);
    $sql = $wpdb->prepare("SELECT DATE_FORMAT(pay_time, '%%Y-%%m') as month, SUM(order_price) as sales FROM {$wpdb->prefix}zibpay_order WHERE (order_type = 15 OR order_type = 13) AND status = 1 AND pay_type != 'points' AND DATE_FORMAT(pay_time, '%%Y-%%m') BETWEEN %s AND %s GROUP BY DATE_FORMAT(pay_time, '%%Y-%%m') ORDER BY month", $start_month, $end_month);
    $sales_data = $wpdb->get_results($sql);
    
    // 将查询结果转换为关联数组，便于快速查找
    $sales_map = array();
    foreach ($sales_data as $data) {
        $sales_map[$data->month] = floatval($data->sales);
    }
    
    // 确保每个月份都有数据，没有则填充0
    $monthly_sales = array();
    foreach ($months as $month) {
        $monthly_sales[] = array(
            'month' => $month,
            'sales' => isset($sales_map[$month]) ? $sales_map[$month] : 0.00
        );
    }
    $dashboard_data['monthlySalesData'] = $monthly_sales;
    
    // 获取产品销售排行（Top 5）
    $product_sales = $wpdb->get_results("SELECT post_id as product_id, SUM(order_price) as total_sales, COUNT(*) as order_count FROM {$wpdb->prefix}zibpay_order WHERE (order_type = 15 OR order_type = 13) AND status = 1 AND pay_type != 'points' GROUP BY post_id ORDER BY total_sales DESC LIMIT 5");
    $productSalesData = array();
    foreach ($product_sales as $product) {
        $productSalesData[] = array(
            'product_id' => $product->product_id,
            'total_sales' => floatval($product->total_sales),
            'order_count' => $product->order_count
        );
    }
    $dashboard_data['productSalesData'] = $productSalesData;
    
    // 设置30分钟缓存，平衡数据实时性和性能
    set_transient($dashboard_cache_key, $dashboard_data, 1800);
}

// 使用缓存数据
$vue_data['recentAuths'] = $dashboard_data['recentAuths'];
$vue_data['monthlySalesData'] = $dashboard_data['monthlySalesData'];
$vue_data['productSalesData'] = $dashboard_data['productSalesData'];

// 关键数据统计
$vue_data['total_auths'] = $dashboard_data['total_auths'];
$vue_data['active_auths'] = $dashboard_data['active_auths'];
$vue_data['expired_auths'] = $dashboard_data['expired_auths'];
$vue_data['today_auths'] = $dashboard_data['today_auths'];
$vue_data['total_requests'] = $dashboard_data['total_requests'];
$vue_data['success_requests'] = $dashboard_data['success_requests'];
$vue_data['total_products'] = $dashboard_data['total_products'];
$vue_data['total_cards'] = $dashboard_data['total_cards'];
$vue_data['used_cards'] = $dashboard_data['used_cards'];
$vue_data['unused_cards'] = $dashboard_data['unused_cards'];
$vue_data['total_orders'] = $dashboard_data['total_orders'];
$vue_data['total_sales'] = $dashboard_data['total_sales'];
$vue_data['today_sales'] = $dashboard_data['today_sales'];
$vue_data['avg_order_price'] = $dashboard_data['avg_order_price'];
    


// 处理授权管理页面数据
if (isset($_GET['page']) && ($_GET['page'] === 'product_auth_manage' || $_GET['page'] === 'admin')) {
    // 直接获取WordPress数据库连接
    global $wpdb;
    
    // 定义表名
    $table_name = $wpdb->prefix . 'product_auths';
    
    // 获取请求参数
    $status = isset($_REQUEST['status']) && in_array($_REQUEST['status'], array('0', '1')) ? intval($_REQUEST['status']) : '';
    $search_type = sanitize_text_field($_GET['search_type'] ?? 'user');
    $search_keyword = sanitize_text_field($_GET['s'] ?? '');
    $view_mode = in_array($_GET['view_mode'] ?? '', array('user', 'product')) ? sanitize_text_field($_GET['view_mode']) : 'user';
    $current_page = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 10;
    
    // 获取产品列表并缓存
    $product_list = get_transient('xk_auth_product_list');
    if (false === $product_list) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id = intval($product['product_id']);
                    $product_list[$product_id] = sanitize_text_field($product['product_name']);
                }
            }
        }
        // 设置1小时缓存
        set_transient('xk_auth_product_list', $product_list, 3600);
    }
    
    // 构建查询条件
    $where_clauses = array();
    
    // 状态条件
    if ($status !== '') {
        $where_clauses[] = $wpdb->prepare("status = %d", $status);
    }
    
    // 搜索条件
    if (!empty($search_keyword)) {
        switch ($search_type) {
            case 'user':
                // 搜索用户
                $user_ids = array();
                $users = get_users(array('search' => '*' . esc_attr($search_keyword) . '*'));
                foreach ($users as $user) {
                    $user_ids[] = $user->ID;
                }
                if (!empty($user_ids)) {
                    $where_clauses[] = "user_id IN (" . implode(',', $user_ids) . ")";
                }
                break;
            
            case 'domain':
                // 搜索域名
                $where_clauses[] = $wpdb->prepare('domain LIKE %s', '%' . $search_keyword . '%');
                break;
            
            case 'product':
                // 搜索产品
                $product_ids = array();
                foreach ($product_list as $id => $name) {
                    if (stripos($name, $search_keyword) !== false) {
                        $product_ids[] = $id;
                    }
                }
                if (!empty($product_ids)) {
                    $where_clauses[] = "product_id IN (" . implode(',', $product_ids) . ")";
                }
                break;
        }
    }
        
    $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
    // 初始化数据数组
    $user_groups = array();
    $product_groups = array();
    $all_users_count = 0;
    $all_products_count = 0;
    $total_pages = 0;
    
    if ($view_mode === 'user') {
        // 按用户分组模式
        // 获取所有用户ID - 用于分页
        $user_ids_query = "
            SELECT DISTINCT user_id FROM {$table_name}
            {$where_sql}
            ORDER BY user_id DESC
        ";
        $user_ids = $wpdb->get_col($user_ids_query);
        $all_users_count = count($user_ids);
    
        // 分页处理
        $total_pages = ceil($all_users_count / $per_page);
        $offset = ($current_page - 1) * $per_page;
    
        // 限制当前页显示的用户
        $current_page_user_ids = array_slice($user_ids, $offset, $per_page);
    
        // 获取每个用户的所有授权记录
        if (!empty($current_page_user_ids)) {
            // 批量获取用户数据，减少get_userdata调用
            $user_data_map = get_users(array('include' => $current_page_user_ids, 'fields' => array('ID', 'display_name')));
            $user_names = array();
            foreach ($user_data_map as $user) {
                $user_names[$user->ID] = $user->display_name;
            }
            
            $user_placeholders = implode(',', array_fill(0, count($current_page_user_ids), '%d'));
            $user_where = $wpdb->prepare("user_id IN ({$user_placeholders})", $current_page_user_ids);
            $all_where_clauses = $where_clauses;
            $all_where_clauses[] = $user_where;
            $final_where = 'WHERE ' . implode(' AND ', $all_where_clauses);
    
            // 查询授权记录
            $auth_list_query = "
                SELECT * FROM {$table_name}
                {$final_where}
                ORDER BY user_id DESC, operation_time DESC
            ";
            $auth_list = $wpdb->get_results($auth_list_query);
    
            // 按用户分组
            foreach ($auth_list as $auth) {
                $user_groups[$auth->user_id][] = $auth;
            }
        }
    } else {
        // 按产品分组模式
        // 获取所有产品ID - 用于分页
        $product_ids_query = "
            SELECT DISTINCT product_id FROM {$table_name}
            {$where_sql}
            ORDER BY product_id DESC
        ";
        $product_ids = $wpdb->get_col($product_ids_query);
        $all_products_count = count($product_ids);
    
        // 分页处理
        $total_pages = ceil($all_products_count / $per_page);
        $offset = ($current_page - 1) * $per_page;
    
        // 限制当前页显示的产品
        $current_page_product_ids = array_slice($product_ids, $offset, $per_page);
    
        // 获取每个产品的所有授权记录
        if (!empty($current_page_product_ids)) {
            $product_placeholders = implode(',', array_fill(0, count($current_page_product_ids), '%d'));
            $product_where = $wpdb->prepare("product_id IN ({$product_placeholders})", $current_page_product_ids);
            $all_where_clauses = $where_clauses;
            $all_where_clauses[] = $product_where;
            $final_where = 'WHERE ' . implode(' AND ', $all_where_clauses);
    
            // 查询授权记录
            $auth_list_query = "
                SELECT * FROM {$table_name}
                {$final_where}
                ORDER BY product_id DESC, user_id DESC, operation_time DESC
            ";
            $auth_list = $wpdb->get_results($auth_list_query);
            
            // 批量获取用户数据，减少get_userdata调用
            $user_ids_in_auths = array();
            foreach ($auth_list as $auth) {
                $user_ids_in_auths[] = $auth->user_id;
            }
            $user_ids_in_auths = array_unique($user_ids_in_auths);
            
            $user_data_map = get_users(array('include' => $user_ids_in_auths, 'fields' => array('ID', 'display_name')));
            $user_names = array();
            foreach ($user_data_map as $user) {
                $user_names[$user->ID] = $user->display_name;
            }
    
            // 按产品分组
            foreach ($auth_list as $auth) {
                $product_groups[$auth->product_id][] = $auth;
            }
        }
    }
        
    // 辅助函数：获取产品名
    function get_product_name_from_settings($product_id, $product_list) {
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
        
    // 转换用户组数据为Vue可用格式
        $formatted_user_groups = array();
        foreach ($user_groups as $user_id => $auths) {
            $user_name = isset($user_names[$user_id]) ? $user_names[$user_id] : '未知用户';
            
            // 获取该用户在各个产品上的授权数量信息
            $user_auth_info = array();
            foreach ($auths as $auth) {
                $product_id = $auth->product_id;
                if (!isset($user_auth_info[$product_id])) {
                    // 调用函数获取授权数量信息
                    $auth_info = xk_auth_change_transference($user_id, $product_id);
                    $user_auth_info[$product_id] = array(
                        'total_auths' => $auth_info['total_auths'],
                        'remaining_auths' => $auth_info['remaining_auths']
                    );
                }
            }
            
            $formatted_auths = array();
            foreach ($auths as $auth) {
                $product_id = $auth->product_id;
                $product_name = get_product_name_from_settings($product_id, $product_list);
                $expire_time = isset($auth->expire_time) ? $auth->expire_time : '';
                $is_valid_date = $expire_time && $expire_time !== '0000-00-00 00:00:00' && strtotime($expire_time) !== false;
                $is_expired = $is_valid_date && strtotime($expire_time) < time();
                     
                $status_class = $is_expired ? 'warning' : ($auth->status ? 'success' : 'danger');
                $status_text = $is_expired ? '已过期' : ($auth->status ? '正常' : '封禁');
                     
                $formatted_auths[] = array(
                    'id' => $auth->id,
                    'userId' => $user_id,
                    'productId' => $product_id,
                    'productName' => $product_name,
                    'domain' => $auth->domain,
                    'authKey' => $auth->auth_key,
                    'expireTime' => $is_valid_date ? date('Y-m-d H:i', strtotime($expire_time)) : '永久',
                    'status' => intval($auth->status),
                    'statusClass' => $status_class,
                    'statusText' => $status_text,
                    'operationTime' => date('Y-m-d H:i', strtotime($auth->operation_time)),
                    'totalAuths' => $user_auth_info[$product_id]['total_auths'],
                    'remainingAuths' => $user_auth_info[$product_id]['remaining_auths']
                );
                }
            
            $formatted_user_groups[] = array(
                'userId' => $user_id,
                'userName' => $user_name,
                'auths' => $formatted_auths
            );
            }
        
        // 转换产品组数据为Vue可用格式
        $formatted_product_groups = array();
        foreach ($product_groups as $product_id => $auths) {
            $product_name = get_product_name_from_settings($product_id, $product_list);
            
            // 获取该产品下各个用户的授权数量信息
            $user_auth_info = array();
            foreach ($auths as $auth) {
                $user_id = $auth->user_id;
                if (!isset($user_auth_info[$user_id])) {
                    // 调用函数获取授权数量信息
                    $auth_info = xk_auth_change_transference($user_id, $product_id);
                    $user_auth_info[$user_id] = array(
                        'total_auths' => $auth_info['total_auths'],
                        'remaining_auths' => $auth_info['remaining_auths']
                    );
                }
            }
            
            $formatted_auths = array();
            foreach ($auths as $auth) {
                $user_id = $auth->user_id;
                $user_name = isset($user_names[$user_id]) ? $user_names[$user_id] : '未知用户';
                $expire_time = isset($auth->expire_time) ? $auth->expire_time : '';
                $is_valid_date = $expire_time && $expire_time !== '0000-00-00 00:00:00' && strtotime($expire_time) !== false;
                $is_expired = $is_valid_date && strtotime($expire_time) < time();
                
                $status_class = $is_expired ? 'warning' : ($auth->status ? 'success' : 'danger');
                $status_text = $is_expired ? '已过期' : ($auth->status ? '正常' : '封禁');
                
                $formatted_auths[] = array(
                    'id' => $auth->id,
                    'userId' => $user_id,
                    'productId' => $product_id,
                    'userName' => $user_name,
                    'domain' => $auth->domain,
                    'authKey' => $auth->auth_key,
                    'expireTime' => $is_valid_date ? date('Y-m-d H:i', strtotime($expire_time)) : '永久',
                    'status' => intval($auth->status),
                    'statusClass' => $status_class,
                    'statusText' => $status_text,
                    'operationTime' => date('Y-m-d H:i', strtotime($auth->operation_time)),
                    'totalAuths' => $user_auth_info[$user_id]['total_auths'],
                    'remainingAuths' => $user_auth_info[$user_id]['remaining_auths']
                );
            }
            
            $formatted_product_groups[] = array(
            'productId' => $product_id,
            'productName' => $product_name,
            'auths' => $formatted_auths
        );
    }
        
        // 添加授权管理数据到vue_data
        $vue_data['authUserGroups'] = $formatted_user_groups;
        $vue_data['authProductGroups'] = $formatted_product_groups;
        $vue_data['authTotalCount'] = $view_mode === 'user' ? $all_users_count : $all_products_count;
        $vue_data['authCurrentPage'] = $current_page;
        $vue_data['authTotalPages'] = $total_pages;
        $vue_data['authViewMode'] = $view_mode;
        $vue_data['authSearchType'] = $search_type;
        $vue_data['authSearchKeyword'] = $search_keyword;
        $vue_data['authStatus'] = $status;
        $vue_data['nonce'] = wp_create_nonce('add_auth_nonce');
        $vue_data['clear_logs_nonce'] = wp_create_nonce('xk_auth_clear_logs');
        $vue_data['xk_auth_nonce'] = wp_create_nonce('xk_auth_nonce');
    }

    // 处理日志管理页面数据
    if (isset($_GET['page']) && $_GET['page'] === 'admin') {
        global $wpdb;
        
        // 辅助函数：获取产品名
        function get_product_name_from_settings_log($product_id) {
            $product_settings = xk_auth('product_settings', array());
            $product_list = array();
            if (!empty($product_settings) && is_array($product_settings)) {
                foreach ($product_settings as $product) {
                    if (!empty($product['product_id']) && !empty($product['product_name'])) {
                        $product_id_temp = intval($product['product_id']);
                        $product_list[$product_id_temp] = sanitize_text_field($product['product_name']);
                    }
                }
            }
            $product_id = intval($product_id);
            return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
        }
        
        // 辅助函数：获取用户名
        function get_username_by_id($user_id) {
            $user_data = get_userdata($user_id);
            return $user_data ? $user_data->display_name . " (ID:{$user_id})" : "用户ID:{$user_id}";
        }
        
        // 辅助函数：格式化请求状态显示
        function format_request_status_log($status) {
            $status = strtolower($status);
            
            $status_map = array(
                'success' => array('text' => '验证成功', 'class' => 'success'),
                'token_generated_for_auth' => array('text' => 'Token生成成功', 'class' => 'success'),
                'token_generated_triple' => array('text' => '三重验证Token生成', 'class' => 'success'),
                'success_triple_verified' => array('text' => '三重验证成功', 'class' => 'success'),
                'success_push_token' => array('text' => 'Token推送成功', 'class' => 'success'),
                'failed_missing_params' => array('text' => '参数不完整', 'class' => 'danger'),
                'failed_invalid_product_id' => array('text' => '无效产品ID', 'class' => 'danger'),
                'failed_invalid_domain' => array('text' => '无效域名', 'class' => 'danger'),
                'failed_invalid_auth_key' => array('text' => '无效授权码', 'class' => 'danger'),
                'failed_invalid_token_format' => array('text' => '无效Token格式', 'class' => 'danger'),
                'failed' => array('text' => '验证失败', 'class' => 'danger'),
                'failed_pre_auth' => array('text' => '预验证失败', 'class' => 'danger'),
                'failed_token_invalid' => array('text' => 'Token无效', 'class' => 'danger'),
                'failed_token_mismatch' => array('text' => 'Token不匹配', 'class' => 'danger'),
                'failed_offline_expired' => array('text' => '离线授权过期', 'class' => 'danger'),
                'failed_auth_expired' => array('text' => '授权已过期', 'class' => 'danger'),
                'failed_auth_invalid' => array('text' => '授权无效', 'class' => 'danger'),
                'failed_auth_record_invalid' => array('text' => '授权记录无效', 'class' => 'danger'),
                'failed_token_verify_invalid' => array('text' => 'Token验证无效', 'class' => 'danger'),
                'failed_push_token' => array('text' => 'Token推送失败', 'class' => 'danger')
            );
            
            $default = array('text' => '未知状态', 'class' => 'warning');
            
            if (isset($status_map[$status])) {
                return $status_map[$status];
            } elseif (strpos($status, 'success') === 0) {
                return array('text' => '验证成功', 'class' => 'success');
            } elseif (strpos($status, 'failed') === 0) {
                $reason = str_replace('failed_', '', $status);
                $reason_text = str_replace('_', ' ', $reason);
                return array('text' => '验证失败: ' . ucfirst($reason_text), 'class' => 'danger');
            } else {
                return $default;
            }
        }
        
        // 获取授权请求日志
        $table_name = $wpdb->prefix . 'auth_request_logs';
        
        // 状态筛选
        $status_filter = isset($_REQUEST['auth_request_status']) ? sanitize_text_field($_REQUEST['auth_request_status']) : '';
        $where_clause = '';
        if (!empty($status_filter)) {
            $where_clause = $wpdb->prepare("WHERE status LIKE %s", '%' . $status_filter . '%');
        }
        
        $all_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} {$where_clause}");
        $per_page = 20;
        $total_pages = ceil($all_count / $per_page);
        $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;
        
        $orderby = !empty($_REQUEST['orderby']) ? sanitize_text_field($_REQUEST['orderby']) : 'id';
        $order = !empty($_REQUEST['order']) ? sanitize_text_field($_REQUEST['order']) : 'DESC';
        $valid_orderby = array('id', 'product_id', 'operation_time', 'status', 'domain');
        $orderby = in_array($orderby, $valid_orderby) ? $orderby : 'id';
        $order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';
        
        $logs_list = $wpdb->get_results("SELECT * FROM {$table_name} {$where_clause} ORDER BY {$orderby} {$order} LIMIT {$offset}, {$per_page}");
        
        $formatted_auth_request_logs = array();
        foreach ($logs_list as $log) {
            $status_info = format_request_status_log($log->status);
            $formatted_auth_request_logs[] = array(
                'id' => $log->id,
                'productId' => $log->product_id,
                'productName' => get_product_name_from_settings_log($log->product_id),
                'requestIp' => $log->ip,
                'domain' => $log->domain,
                'authKey' => $log->auth_key,
                'status' => $log->status,
                'statusText' => $status_info['text'],
                'statusClass' => $status_info['class'],
                'requestTime' => date('Y-m-d H:i:s', strtotime($log->operation_time))
            );
        }
        
        // 获取授权操作日志
        $operation_log_table = $wpdb->prefix . 'auth_logs';
        $operation_all_count = $wpdb->get_var("SELECT COUNT(*) FROM {$operation_log_table}");
        $operation_total_pages = ceil($operation_all_count / $per_page);
        $operation_logs_list = $wpdb->get_results("SELECT * FROM {$operation_log_table} ORDER BY id DESC LIMIT {$offset}, {$per_page}");
        
        $formatted_auth_operation_logs = array();
        foreach ($operation_logs_list as $log) {
            $formatted_auth_operation_logs[] = array(
                'id' => $log->id,
                'operator' => get_username_by_id($log->user_id),
                'targetUser' => get_username_by_id($log->user_id),
                'targetProduct' => get_product_name_from_settings_log($log->product_id),
                'detail' => $log->other_operations,
                'operationTime' => date('Y-m-d H:i:s', strtotime($log->operation_time)),
            );
        }
        
        // 获取更新请求日志
        $update_log_table = $wpdb->prefix . 'product_update_log';
        $update_all_count = $wpdb->get_var("SELECT COUNT(*) FROM {$update_log_table}");
        $update_total_pages = ceil($update_all_count / $per_page);
        $update_logs_list = $wpdb->get_results("SELECT * FROM {$update_log_table} ORDER BY id DESC LIMIT {$offset}, {$per_page}");
        
        $formatted_update_request_logs = array();
        foreach ($update_logs_list as $log) {
            $status_info = format_request_status_log($log->status);
            $formatted_update_request_logs[] = array(
                'id' => $log->id,
                'productName' => get_product_name_from_settings_log($log->product_id),
                'currentVersion' => $log->current_version,
                'domain' => $log->domain,
                'requestIp' => $log->ip,
                'status' => $log->status,
                'statusText' => $status_info['text'],
                'statusClass' => $status_info['class'],
                'message' => '',
                'requestTime' => $log->operation_time && $log->operation_time !== '0000-00-00 00:00:00' ? date('Y-m-d H:i:s', strtotime($log->operation_time)) : '时间未知'
            );
        }
        
        // 获取前端管理操作日志
        $frontend_admin_log_table = $wpdb->prefix . 'auth_frontend_admin_logs';
        $frontend_admin_all_count = $wpdb->get_var("SELECT COUNT(*) FROM {$frontend_admin_log_table}");
        $frontend_admin_total_pages = ceil($frontend_admin_all_count / $per_page);
        $frontend_admin_logs_list = $wpdb->get_results("SELECT * FROM {$frontend_admin_log_table} ORDER BY id DESC LIMIT {$offset}, {$per_page}");
        
        $formatted_frontend_admin_logs = array();
        foreach ($frontend_admin_logs_list as $log) {
            // 格式化操作类型显示
            $action_type_map = array(
                'user_search' => array('text' => '用户搜索', 'class' => 'primary'),
                'view_authorization' => array('text' => '查看授权', 'class' => 'info'),
                'edit_authorization' => array('text' => '编辑授权', 'class' => 'warning'),
                'delete_authorization' => array('text' => '删除授权', 'class' => 'danger'),
                'add_authorization' => array('text' => '添加授权', 'class' => 'success')
            );
            
            $action_type_info = isset($action_type_map[$log->action_type]) ? $action_type_map[$log->action_type] : array('text' => ucfirst(str_replace('_', ' ', $log->action_type)), 'class' => 'default');
            
            $formatted_frontend_admin_logs[] = array(
                'id' => $log->id,
                'operator' => $log->operator,
                'actionType' => $log->action_type,
                'actionTypeText' => $action_type_info['text'],
                'actionTypeClass' => $action_type_info['class'],
                'targetUser' => $log->target_user ?: '无',
                'targetProduct' => $log->target_product ?: '无',
                'actionDetail' => $log->action_detail,
                'actionTime' => date('Y-m-d H:i:s', strtotime($log->action_time))
            );
        }
        
        // 添加日志数据到vue_data
        $vue_data['authRequestLogs'] = $formatted_auth_request_logs;
        $vue_data['authRequestTotal'] = $all_count;
        $vue_data['authRequestCurrentPage'] = $paged;
        $vue_data['authRequestTotalPages'] = $total_pages;
        
        $vue_data['authOperationLogs'] = $formatted_auth_operation_logs;
        $vue_data['authOperationTotal'] = $operation_all_count;
        $vue_data['authOperationCurrentPage'] = $paged;
        $vue_data['authOperationTotalPages'] = $operation_total_pages;
        
        $vue_data['updateRequestLogs'] = $formatted_update_request_logs;
        $vue_data['updateRequestTotal'] = $update_all_count;
        $vue_data['updateRequestCurrentPage'] = $paged;
        $vue_data['updateRequestTotalPages'] = $update_total_pages;
        
        $vue_data['frontendAdminLogs'] = $formatted_frontend_admin_logs;
        $vue_data['frontendAdminTotal'] = $frontend_admin_all_count;
        $vue_data['frontendAdminCurrentPage'] = $paged;
        $vue_data['frontendAdminTotalPages'] = $frontend_admin_total_pages;
    }
    
    // 处理更新管理页面数据
    if (isset($_GET['page']) && ($_GET['page'] === 'admin' || $_GET['page'] === 'product_manage_update')) {
        global $wpdb;
        
        // 获取产品列表
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id = intval($product['product_id']);
                    $product_list[$product_id] = sanitize_text_field($product['product_name']);
                }
            }
        }
        $vue_data['productList'] = $product_list;
        
        // 分页与排序
        $per_page = 20;
        $paged = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
        $offset = ($paged - 1) * $per_page;
        
        // 排序处理
        $orderby = !empty($_REQUEST['orderby']) ? sanitize_text_field($_REQUEST['orderby']) : 'id';
        $order = !empty($_REQUEST['order']) ? sanitize_text_field($_REQUEST['order']) : 'DESC';
        $valid_orderby = array('id', 'product_id', 'version', 'operation_time', 'push_status');
        $orderby = in_array($orderby, $valid_orderby) ? $orderby : 'id';
        $order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';
        
        // 获取更新包列表
        $table_name = $wpdb->prefix . 'product_update';
        $targeted_push_table = $wpdb->prefix . 'product_targeted_push';
        
        $total_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
        $total_pages = ceil($total_count / $per_page);
        
        $updates_list = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                u.*, 
                GROUP_CONCAT(CASE WHEN tp.target_type = 'all' THEN '全部' 
                                 WHEN tp.target_type = 'user_id' THEN CONCAT('ID:', tp.target_value) 
                                 WHEN tp.target_type = 'domain' THEN CONCAT('域名:', tp.target_value) 
                                 ELSE tp.target_value END SEPARATOR ', ') as pushed_targets
             FROM {$table_name} u 
             LEFT JOIN {$targeted_push_table} tp ON u.id = tp.update_id 
             GROUP BY u.id 
             ORDER BY {$orderby} {$order} 
             LIMIT %d, %d",
            $offset,
            $per_page
        ));
        
        // 格式化更新包数据
        $formatted_updates = array();
        foreach ($updates_list as $update) {
            $formatted_updates[] = array(
                'id' => $update->id,
                'productId' => $update->product_id,
                'productName' => isset($product_list[$update->product_id]) ? $product_list[$update->product_id] : "产品ID:{$update->product_id}",
                'version' => $update->version,
                'updatePackageUrl' => $update->update_package_url,
                'updateDescription' => $update->update_description ?: '',
                'pushStatus' => intval($update->push_status),
                'pushStatusText' => $update->push_status ? '已推送' : '未推送',
                'originalVersions' => $update->original_versions ?: '全版本',
                'pushedTargets' => $update->pushed_targets ?: '',
                'operationTime' => date('Y-m-d H:i', strtotime($update->operation_time))
            );
        }
        
        // 添加更新包数据到vue_data
    $vue_data['updatesList'] = $formatted_updates;
    $vue_data['updatesTotal'] = $total_count;
    $vue_data['updatesCurrentPage'] = $paged;
    $vue_data['updatesTotalPages'] = $total_pages;
    $vue_data['updatesPerPage'] = $per_page;
    $vue_data['updatesOrderBy'] = $orderby;
    $vue_data['updatesOrder'] = $order;
    $vue_data['edit_update_nonce'] = wp_create_nonce('edit_update_nonce');
    $vue_data['delete_update_nonce'] = wp_create_nonce('delete_update_nonce');
    $vue_data['targeted_push_nonce'] = wp_create_nonce('targeted_push_nonce');
    $vue_data['add_update_nonce'] = wp_create_nonce('add_update_nonce');
}

// 处理举报管理页面数据
if (isset($_GET['page']) && ($_GET['page'] === 'product_auth_manage' || $_GET['page'] === 'admin')) {
    // 直接获取WordPress数据库连接
    global $wpdb;
    
    // 定义表名
    $table_name = $wpdb->prefix . 'auth_reports';
    
    // 获取请求参数
    $status = isset($_REQUEST['status']) && in_array($_REQUEST['status'], array('pending', 'processed', 'rejected')) ? sanitize_text_field($_REQUEST['status']) : '';
    $search_type = sanitize_text_field($_GET['search_type'] ?? 'user');
    $search_keyword = sanitize_text_field($_GET['s'] ?? '');
    $current_page = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;
    $per_page = 10;
    
    // 构建查询条件
    $where_clauses = array();
    
    // 状态条件
    if (!empty($status)) {
        $where_clauses[] = $wpdb->prepare("status = %s", $status);
    }
    
    // 搜索条件
    if (!empty($search_keyword)) {
        switch ($search_type) {
            case 'user':
                // 搜索用户
                $user_ids = array();
                $users = get_users(array('search' => '*' . esc_attr($search_keyword) . '*'));
                foreach ($users as $user) {
                    $user_ids[] = $user->ID;
                }
                if (!empty($user_ids)) {
                    $where_clauses[] = "user_id IN (" . implode(',', $user_ids) . ")";
                }
                break;
            
            case 'product':
                // 搜索产品
                $product_settings = xk_auth('product_settings', array());
                $product_ids = array();
                foreach ($product_settings as $product) {
                    if (isset($product['product_id'], $product['product_name']) && stripos($product['product_name'], $search_keyword) !== false) {
                        $product_ids[] = $product['product_id'];
                    }
                }
                if (!empty($product_ids)) {
                    $where_clauses[] = "product_id IN (" . implode(',', $product_ids) . ")";
                }
                break;
            
            case 'type':
                // 搜索举报类型
                $where_clauses[] = $wpdb->prepare('report_type LIKE %s', '%' . $search_keyword . '%');
                break;
        }
    }
        
    $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
    // 获取总记录数
    $total_count = intval($wpdb->get_var("SELECT COUNT(*) FROM {$table_name} {$where_sql}"));
    $total_pages = ceil($total_count / $per_page);
    $offset = ($current_page - 1) * $per_page;
    
    // 辅助函数：获取产品名
    function get_product_name_from_settings_report($product_id) {
        $product_settings = xk_auth('product_settings', array());
        $product_list = array();
        if (!empty($product_settings) && is_array($product_settings)) {
            foreach ($product_settings as $product) {
                if (!empty($product['product_id']) && !empty($product['product_name'])) {
                    $product_id_temp = intval($product['product_id']);
                    $product_list[$product_id_temp] = sanitize_text_field($product['product_name']);
                }
            }
        }
        $product_id = intval($product_id);
        return isset($product_list[$product_id]) ? $product_list[$product_id] : "产品ID:{$product_id}";
    }
    
    // 辅助函数：获取用户名
    function get_username_by_id_report($user_id) {
        $user_data = get_userdata($user_id);
        return $user_data ? $user_data->display_name . " (ID:{$user_id})" : "用户ID:{$user_id}";
    }
    
    // 辅助函数：获取举报类型文本
    function get_report_type_text($type) {
        $type_map = array(
            'piracy' => '盗版使用',
            'unauthorized' => '未授权使用',
            'fake' => '假冒产品',
            'other' => '其他问题'
        );
        return isset($type_map[$type]) ? $type_map[$type] : $type;
    }
    
    // 辅助函数：获取状态文本和样式
    function get_report_status_info($status) {
        $status_map = array(
            'pending' => array('text' => '待处理', 'class' => 'warning'),
            'processed' => array('text' => '已处理', 'class' => 'success'),
            'rejected' => array('text' => '已拒绝', 'class' => 'danger')
        );
        return isset($status_map[$status]) ? $status_map[$status] : array('text' => '未知状态', 'class' => 'info');
    }
    
    // 查询举报数据
    $reports_list = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_name} {$where_sql} ORDER BY id DESC LIMIT %d, %d",
        $offset, $per_page
    ));
    
    // 格式化举报数据
    $formatted_reports = array();
    foreach ($reports_list as $report) {
        $status_info = get_report_status_info($report->status);
        $formatted_reports[] = array(
            'id' => $report->id,
            'userId' => $report->user_id,
            'userName' => get_username_by_id_report($report->user_id),
            'productId' => $report->product_id,
            'productName' => get_product_name_from_settings_report($report->product_id),
            'reportType' => get_report_type_text($report->report_type),
            'reportContent' => $report->report_content,
            'reportUrl' => $report->report_url,
            'reportIp' => $report->report_ip,
            'status' => $report->status,
            'statusText' => $status_info['text'],
            'statusClass' => $status_info['class'],
            'adminNote' => $report->admin_note,
            'operationTime' => date('Y-m-d H:i:s', strtotime($report->operation_time)),
            'processTime' => $report->process_time ? date('Y-m-d H:i:s', strtotime($report->process_time)) : ''
        );
    }
    
    // 添加举报数据到vue_data
    $vue_data['reportsList'] = $formatted_reports;
    $vue_data['reportsTotal'] = $total_count;
    $vue_data['reportCurrentPage'] = $current_page;
    $vue_data['reportTotalPages'] = $total_pages;
    $vue_data['reportPageSize'] = $per_page;
    $vue_data['reportSearchType'] = $search_type;
    $vue_data['reportSearchKeyword'] = $search_keyword;
    $vue_data['reportStatusFilter'] = $status;
    $vue_data['reportSearchTypeText'] = array(
        'user' => '用户',
        'product' => '产品',
        'type' => '举报类型'
    );
}

?>

<!--加载Vue 3 -->
<script src="<?php echo XK_AUTH_DIR_URL; ?>/js/vue.global.js"></script>
<!--加载Vue Router -->
<script src="<?php echo XK_AUTH_DIR_URL; ?>/js/vue-router.global.js"></script>
<!--加载Element Plus CSS -->
<link rel="stylesheet" href="<?php echo XK_AUTH_DIR_URL; ?>/css/element-plus.css">
<!--加载Element Plus JS -->
<script src="<?php echo XK_AUTH_DIR_URL; ?>/js/element-plus.js"></script>
<!--加载Element Plus中文语言包 -->
<script src="<?php echo XK_AUTH_DIR_URL; ?>/js/zh-cn.min.js"></script>
<!--加载Main CSS -->
<link rel="stylesheet" href="<?php echo XK_AUTH_DIR_URL; ?>/css/admin-main.css">
<!--加载Pay Page CSS -->
<link rel="stylesheet" href="<?php echo XK_AUTH_DIR_URL; ?>/css/pay-page.css">

<!-- 自定义样式 -->
<style>
    /* 调整消息弹窗位置，避免被WordPress导航栏遮挡 */
    .xk-auth-message {
        margin-top: 45px !important;
    }
</style>

<script>
    window.ElementPlusLocaleZhCn = ElementPlusLocaleZhCn;
    window._vue_data = <?php echo json_encode($vue_data); ?>;
</script>

<div class="loading-mask shop-page-loading"><div class="loading"></div></div>
<div class="demo" id="xk_auth_app">
    <?php require_once dirname(__FILE__) . '/template/header.php'; ?>
    
    <div class="zibpay-shop-content">
        <transition name="slide-down" mode="out-in" tag="div">
            <div v-if="$route.path == '/'" key="dashboard">
                <?php require_once dirname(__FILE__) . '/template/dashboard.php'; ?>
            </div>
            <div v-else-if="$route.path == '/auth'" key="auth">
                <?php require_once dirname(__FILE__) . '/template/auth.php'; ?>
            </div>
            <div v-else-if="$route.path == '/log'" key="log">
                <?php require_once dirname(__FILE__) . '/template/log.php'; ?>
            </div>
            <div v-else-if="$route.path == '/update'" key="update">
                <?php require_once dirname(__FILE__) . '/template/update.php'; ?>
            </div>
            <div v-else-if="$route.path == '/promo'" key="promo">
                <?php require_once dirname(__FILE__) . '/template/promo.php'; ?>
            </div>
            <div v-else-if="$route.path == '/report'" key="report">
                <?php require_once dirname(__FILE__) . '/template/report.php'; ?>
            </div>
            <div v-else-if="$route.path == '/admin'" key="admin">
                <?php require_once dirname(__FILE__) . '/template/admin.php'; ?>
            </div>
        </transition>
    </div>
    
    <?php require_once dirname(__FILE__) . '/template/footer.php'; ?>
</div>

<!-- 初始化图表 -->
<script src="<?php echo XK_AUTH_DIR_URL; ?>/js/chart.umd.min.js"></script>
<script>
// 图表初始化函数
function initCharts() {
    // 检查当前路由，只有在仪表盘页面才初始化图表
    const currentPath = window.location.hash;
    if (currentPath !== '' && currentPath !== '#/') {
        // 不是仪表盘页面，不初始化图表
        return;
    }
    
    // 确保DOM已渲染，添加重试机制
    const checkAndInitCharts = () => {
        // 销毁旧图表实例（如果存在且有destroy方法）
        if (window.salesTrendChart && typeof window.salesTrendChart.destroy === 'function') {
            try {
                window.salesTrendChart.destroy();
            } catch (e) {
                console.error('销毁销售额趋势图失败:', e);
            }
        }
        if (window.productSalesChart && typeof window.productSalesChart.destroy === 'function') {
            try {
                window.productSalesChart.destroy();
            } catch (e) {
                console.error('销毁产品销售排行图失败:', e);
            }
        }
        
        // 检查canvas元素是否存在
        const ctx1 = document.getElementById('salesTrendChart');
        const ctx2 = document.getElementById('productSalesChart');
        
        if (!ctx1 || !ctx2) {
            // 如果canvas元素不存在，尝试重试
            console.log('图表canvas元素不存在，重试初始化...');
            setTimeout(checkAndInitCharts, 100);
            return;
        }
        
        // 月度销售额趋势图 - 处理单数据点情况
        let months = window._vue_data.monthlySalesData.map(item => item.month);
        let sales = window._vue_data.monthlySalesData.map(item => item.sales);
        
        // 如果只有一个数据点，添加空标签和null数据来调整显示
        if (months.length === 1) {
            months = ['', months[0], ''];
            sales = [null, sales[0], null];
        }
        
        // 产品销售排行数据 - 处理单数据点情况
        let productIds = window._vue_data.productSalesData.map(item => '产品 ' + item.product_id);
        let productSales = window._vue_data.productSalesData.map(item => item.total_sales);
        
        // 如果只有一个数据点，添加空标签和null数据来调整显示
        if (productIds.length === 1) {
            productIds = ['', productIds[0], ''];
            productSales = [null, productSales[0], null];
        }
        
        // 初始化月度销售额趋势图
        try {
            const ctx1Context = ctx1.getContext('2d');
            window.salesTrendChart = new Chart(ctx1Context, {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [{
                        label: '销售额（元）',
                        data: sales,
                        backgroundColor: 'rgba(64, 158, 255, 0.2)',
                        borderColor: 'rgba(64, 158, 255, 1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: '销售额（元）'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: '月份'
                            },
                            // 确保只有一个数据点时图表不会过宽
                            ticks: {
                                autoSkip: true,
                                maxRotation: 0,
                                minRotation: 0
                            },
                            // 对于分类轴，控制显示范围
                            bounds: 'data'
                        }
                    }
                }
            });
        } catch (e) {
            console.error('初始化销售额趋势图失败:', e);
        }
        
        // 初始化产品销售排行柱状图
        try {
            const ctx2Context = ctx2.getContext('2d');
            window.productSalesChart = new Chart(ctx2Context, {
                type: 'bar',
                data: {
                    labels: productIds,
                    datasets: [{
                        label: '销售金额（元）',
                        data: productSales,
                        backgroundColor: 'rgba(118, 198, 230, 0.8)',
                        borderColor: 'rgba(118, 198, 230, 0.8)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: '销售金额（元）'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: '产品ID'
                            },
                            // 确保只有一个数据点时图表不会过宽
                            ticks: {
                                autoSkip: true,
                                maxRotation: 0,
                                minRotation: 0
                            },
                            // 对于分类轴，控制显示范围
                            bounds: 'data'
                        }
                    }
                }
            });
        } catch (e) {
            console.error('初始化产品销售排行图失败:', e);
        }
    };
    
    // 初始调用，添加延迟确保DOM已渲染
    setTimeout(checkAndInitCharts, 200);
}
</script>

<script>
    // 简化的Vue应用初始化
    const { createApp } = Vue;
    const { createRouter, createWebHashHistory } = VueRouter;
    
    // 定义主组件
    const App = {
        data() {
            return {
                ...window._vue_data,
                loading: {
                    order_table_list: true,
                    auth_table: false,
                    auth_request_log: false,
                    auth_operation_log: false,
                    update_request_log: false,
                    updates_table: false,
                    promoTable: false,
                    report_table: false,
                    authorizedUsers: false
                },
                
                // 日志清理相关
                clearingLogs: false,
                
                // 授权管理相关数据
                authStatusFilter: '',
                authPageSize: 10,
                authSearchTypeText: {
                    'user': '用户',
                    'domain': '域名',
                    'product': '产品'
                },
                authActiveUserNames: [],
                authActiveProductNames: [],
                
                // 初始化数据
                authUserGroups: window._vue_data.authUserGroups || [],
                authProductGroups: window._vue_data.authProductGroups || [],
                authTotalCount: window._vue_data.authTotalCount || 0,
                authCurrentPage: window._vue_data.authCurrentPage || 1,
                authTotalPages: window._vue_data.authTotalPages || 1,
                authViewMode: window._vue_data.authViewMode || 'user',
                authSearchType: window._vue_data.authSearchType || 'user',
                authSearchKeyword: window._vue_data.authSearchKeyword || '',
                authStatus: window._vue_data.authStatus || '',
                
                // 更新包筛选相关数据
                updatesFilter: {
                    productId: '',
                    pushStatus: ''
                },
                updatesTimeFilter: {
                    operationTime: []
                },
                
                // 日志管理相关数据
                activeTab: 'authRequest',
                
                // 授权请求日志
                authRequestLogs: window._vue_data.authRequestLogs || [],
                authRequestTotal: parseInt(window._vue_data.authRequestTotal) || 0,
                authRequestCurrentPage: parseInt(window._vue_data.authRequestCurrentPage) || 1,
                authRequestPageSize: 20,
                
                // 授权操作日志
                authOperationLogs: window._vue_data.authOperationLogs || [],
                authOperationTotal: parseInt(window._vue_data.authOperationTotal) || 0,
                authOperationCurrentPage: parseInt(window._vue_data.authOperationCurrentPage) || 1,
                authOperationPageSize: 20,
                
                // 更新请求日志
                updateRequestLogs: window._vue_data.updateRequestLogs || [],
                updateRequestTotal: parseInt(window._vue_data.updateRequestTotal) || 0,
                updateRequestCurrentPage: parseInt(window._vue_data.updateRequestCurrentPage) || 1,
                updateRequestPageSize: 20,
                
                // 前端管理操作日志
                frontendAdminLogs: window._vue_data.frontendAdminLogs || [],
                frontendAdminTotal: parseInt(window._vue_data.frontendAdminTotal) || 0,
                frontendAdminCurrentPage: parseInt(window._vue_data.frontendAdminCurrentPage) || 1,
                frontendAdminPageSize: 20,
                
                // 更新管理相关数据
                productList: window._vue_data.productList || {},
                updatesList: window._vue_data.updatesList || [],
                updatesTotal: parseInt(window._vue_data.updatesTotal) || 0,
                updatesCurrentPage: parseInt(window._vue_data.updatesCurrentPage) || 1,
                updatesTotalPages: parseInt(window._vue_data.updatesTotalPages) || 1,
                updatesPerPage: parseInt(window._vue_data.updatesPerPage) || 20,
                updatesOrderBy: window._vue_data.updatesOrderBy || 'id',
                updatesOrder: window._vue_data.updatesOrder || 'DESC',
                
                // 优惠码管理相关数据
                promoCodes: [],
                promoTotalCount: 0,
                promoCurrentPage: 1,
                promoPageSize: 10,
                promoFilter: {
                    code: '',
                    status: ''
                },
                
                // 优惠码表单数据
                promoForm: {
                    id: '',
                    name: '',
                    code: '',
                    type: 'fixed',
                    value: 0,
                    min_amount: 0,
                    max_discount: null,
                    usage_limit: null,
                    product_ids: '',
                    user_ids: '',
                    start_time: null,
                    end_time: null,
                    status: 'active',
                    description: ''
                },
                
                // 授权状态
                is_authorized: window._vue_data.is_authorized || false,
                
                // 前端授权管理功能开关
                frontendAuthEnabled: true,
                
                // 授权用户管理相关数据
                selectedUser: '',
                userSearchText: '',
                users: [],
                authorizedUsers: [],
                authorizedUsersTotal: 0,
                authorizedUsersCurrentPage: 1,
                authorizedUsersPageSize: 10,
                
                // 优惠码表单验证规则
                promoRules: {
                    name: [
                        { required: true, message: '请输入优惠码名称', trigger: 'blur' },
                        { type: 'string', max: 50, message: '优惠码名称不能超过50个字符', trigger: 'blur' },
                        { pattern: /^[\u4e00-\u9fa5a-zA-Z0-9_-]+$/, message: '优惠码名称只能包含中文、英文、数字、下划线和短横线', trigger: 'blur' }
                    ],
                    code: [
                        { type: 'string', max: 30, message: '优惠码不能超过30个字符', trigger: 'blur' },
                        { pattern: /^[a-zA-Z0-9_-]+$/, message: '优惠码只能包含英文、数字、下划线和短横线', trigger: 'blur' }
                    ],
                    type: [{ required: true, message: '请选择优惠类型', trigger: 'change' }],
                    value: [
                        { required: true, message: '请输入优惠值', trigger: 'blur' },
                        { type: 'number', min: 0.01, message: '优惠值必须大于0', trigger: 'blur' },
                        { validator: (rule, value, callback) => {
                            if (this.promoForm.type === 'percentage' && value > 100) {
                                callback(new Error('百分比优惠不能超过100%'));
                            } else if (this.promoForm.type === 'percentage' && value <= 0) {
                                callback(new Error('百分比优惠必须大于0%'));
                            } else {
                                callback();
                            }
                        }, trigger: 'blur' }
                    ],
                    min_amount: [
                        { type: 'number', min: 0, message: '最低消费金额不能小于0', trigger: 'blur' },
                        { validator: (rule, value, callback) => {
                            if (value < 0) {
                                callback(new Error('最低消费金额不能小于0'));
                            } else {
                                callback();
                            }
                        }, trigger: 'blur' }
                    ],
                    max_discount: [
                        { type: 'number', min: 0, message: '最大优惠金额不能小于0', trigger: 'blur' }
                    ],
                    usage_limit: [
                        { type: 'number', min: 0, message: '使用次数限制不能小于0', trigger: 'blur' }
                    ],
                    product_ids: [
                        { pattern: /^(\d+(,\d+)*)?$/, message: '产品ID必须是数字，多个ID用逗号分隔', trigger: 'blur' }
                    ],
                    user_ids: [
                        { pattern: /^(\d+(,\d+)*)?$/, message: '用户ID必须是数字，多个ID用逗号分隔', trigger: 'blur' }
                    ],
                    description: [
                        { type: 'string', max: 200, message: '优惠码描述不能超过200个字符', trigger: 'blur' }
                    ]
                },
                
                // 弹窗相关状态
                dialogVisible: {
                    statusUpdate: false,
                    domainManage: false,
                    authCountUpdate: false,
                    expireTimeSet: false,
                    pushToken: false,
                    addAuth: false,
                    editUpdate: false,
                    targetedPush: false,
                    pushTargets: false,
                    updateAction: false,
                    addPromo: false,
                    authAction: false,
                    reportAction: false,
                    reportContent: false
                },
                
                // 更新包表单数据
                updateForm: {
                    id: '',
                    productId: '',
                    version: '',
                    updatePackageUrl: '',
                    updateDescription: '',
                    pushStatus: 0,
                    originalVersions: ''
                },
                
                // 优惠码表单引用
                promoFormRef: null,
                
                // 当前操作的更新包数据
                currentUpdate: {
                    id: '',
                    productId: '',
                    version: '',
                    updatePackageUrl: '',
                    updateDescription: '',
                    pushStatus: 0,
                    originalVersions: '',
                    pushedTargets: ''
                },
                
                // 指定ID推送表单数据
                targetedPushForm: {
                    updateId: '',
                    targetType: 'all',
                    targetValues: ''
                },
                
                // 添加更新包表单数据
                addUpdateForm: {
                    productId: '',
                    version: '',
                    updatePackageUrl: '',
                    updateDescription: '',
                    originalVersions: ''
                },
                
                // 折叠面板激活组
                activeUpdateGroups: [],
                
                // 日志清理nonce
                clear_logs_nonce: window._vue_data.clear_logs_nonce || '',
                
                // 当前操作的授权数据
                currentAuth: {
                    id: '',
                    productId: '',
                    domain: '',
                    authKey: '',
                    expireTime: '',
                    status: 1,
                    productName: '',
                    userName: ''
                },
                
                // 举报管理相关数据
                reportStatusFilter: '',
                reportPageSize: 10,
                reportSearchTypeText: {
                    'user': '用户',
                    'product': '产品',
                    'type': '举报类型'
                },
                
                // 选中的举报记录
                selectedReports: [],
                
                // 初始化举报数据
                reportsList: window._vue_data.reportsList || [],
                reportsTotal: window._vue_data.reportsTotal || 0,
                reportCurrentPage: window._vue_data.reportCurrentPage || 1,
                reportTotalPages: window._vue_data.reportTotalPages || 1,
                reportPageSize: window._vue_data.reportPageSize || 10,
                reportSearchType: window._vue_data.reportSearchType || 'user',
                reportSearchKeyword: window._vue_data.reportSearchKeyword || '',
                reportStatusFilter: window._vue_data.reportStatusFilter || '',
                
                // 标签页状态
                activeTab: 'manage',
                
                // 举报设置表单数据
                reportSettingsForm: {
                    enabled: true,
                    emailNotification: true,
                    senderName: '星空授权',
                    reportTypes: [
                        { key: 'piracy', label: '盗版使用' },
                        { key: 'unauthorized', label: '未授权使用' },
                        { key: 'fake', label: '假冒产品' },
                        { key: 'other', label: '其他问题' }
                    ]
                },
                
                // 当前操作的举报数据
                currentReport: {
                    id: '',
                    userId: '',
                    userName: '',
                    productId: '',
                    productName: '',
                    reportType: '',
                    reportContent: '',
                    reportUrl: '',
                    reportIp: '',
                    status: 'pending',
                    statusText: '待处理',
                    statusClass: 'warning',
                    adminNote: '',
                    operationTime: '',
                    processTime: ''
                },
                
                // 举报处理表单数据
                reportActionForm: {
                    id: '',
                    userName: '',
                    productName: '',
                    reportType: '',
                    reportContent: '',
                    reportUrl: '',
                    operationTime: '',
                    status: 'pending',
                    statusText: '待处理',
                    statusClass: 'warning',
                    adminNote: ''
                },
                
                // 状态更新表单数据
                statusUpdateForm: {
                    id: '',
                    status: 1,
                    log: ''
                },
                
                // 域名管理表单数据
                domainManageForm: {
                    id: '',
                    currentDomain: '',
                    newDomain: '',
                    productName: '',
                    userName: ''
                },
                
                // 修改授权数量表单数据
                authCountUpdateForm: {
                    id: '',
                    userId: '',
                    productId: '',
                    authCount: null,
                    reason: ''
                },
                
                // 设置到期时间表单数据
                expireTimeSetForm: {
                    id: '',
                    expireTime: '',
                    permanent: false,
                    reason: ''
                },
                
                // 推送Token表单数据
                pushTokenForm: {
                    id: '',
                    domain: '',
                    productId: '',
                    authKey: '',
                    result: '',
                    detailResult: null
                },
                
                // 添加授权表单数据
                addAuthForm: {
                    user_id: '',
                    product_id: '',
                    expire_time: '',
                    permanent: false
                },
                
                // 产品列表数据
                products: [],
                
                // Nonce验证
                nonce: window._vue_data.nonce || '',
                xk_auth_nonce: window._vue_data.xk_auth_nonce || ''
            };
        },
        methods: {
            // 处理未授权点击事件
            handleUnauthorizedClick() {
                this.$message.error({
                    message: '未授权，请先完成插件授权',
                    offset: 50 // 调整偏移量，避免被顶部导航栏挡住
                });
            },
            
            menuGo(path) {
                this.$router.push(path);
            },
            
            // 授权管理相关方法
            authHandleSearch() {
                // 重置页码为1
                this.authCurrentPage = 1;
                // 刷新授权列表
                this.refreshAuthList();
            },
            
            authResetSearch() {
                // 重置所有搜索参数
                this.authSearchType = 'user';
                this.authSearchKeyword = '';
                this.authStatusFilter = '';
                this.authCurrentPage = 1;
                // 刷新授权列表
                this.refreshAuthList();
            },
            
            authHandleStatusChange() {
                // 状态筛选变化时重置页码并刷新授权列表
                this.authCurrentPage = 1;
                this.refreshAuthList();
            },
            
            authHandleViewModeChange() {
                // 视图模式变化时重置页码并刷新授权列表
                this.authCurrentPage = 1;
                this.refreshAuthList();
            },
            
            authHandleCurrentChange(val) {
                // 页码变化时刷新授权列表
                this.authCurrentPage = val;
                this.refreshAuthList();
            },
            
            // 打开授权操作弹窗
            openAuthActionDialog(auth) {
                // 保存当前授权数据
                this.currentAuth = {
                    id: auth.id,
                    userId: auth.userId,
                    productId: auth.productId,
                    domain: auth.domain,
                    authKey: auth.authKey,
                    expireTime: auth.expireTime,
                    status: auth.status,
                    productName: auth.productName,
                    userName: auth.userName
                };
                // 打开操作弹窗
                this.dialogVisible.authAction = true;
            },
            
            // 处理授权操作
            handleAuthAction(action) {
                // 关闭操作弹窗
                this.dialogVisible.authAction = false;
                
                // 根据操作类型打开相应的弹窗
                switch (action) {
                    case 'status':
                        // 打开修改状态弹窗
                        this.statusUpdateForm = {
                            id: this.currentAuth.id,
                            status: this.currentAuth.status,
                            log: ''
                        };
                        this.dialogVisible.statusUpdate = true;
                        break;
                    case 'domain':
                        // 打开管理域名弹窗
                        this.domainManageForm = {
                            id: this.currentAuth.id,
                            currentDomain: this.currentAuth.domain,
                            newDomain: '',
                            productName: this.currentAuth.productName,
                            userName: this.currentAuth.userName
                        };
                        this.dialogVisible.domainManage = true;
                        break;
                    case 'count':
                        // 打开修改授权数量弹窗
                        this.authCountUpdateForm = {
                            id: this.currentAuth.id,
                            userId: this.currentAuth.userId,
                            productId: this.currentAuth.productId,
                            authCount: null,
                            reason: ''
                        };
                        this.dialogVisible.authCountUpdate = true;
                        break;
                    case 'expire':
                        // 打开设置到期时间弹窗
                        this.expireTimeSetForm = {
                            id: this.currentAuth.id,
                            expireTime: this.currentAuth.expireTime,
                            permanent: this.currentAuth.expireTime === '永久',
                            reason: ''
                        };
                        this.dialogVisible.expireTimeSet = true;
                        break;
                    case 'token':
                        // 打开推送Token弹窗
                        this.pushTokenForm = {
                            id: this.currentAuth.id,
                            domain: this.currentAuth.domain,
                            productId: this.currentAuth.productId,
                            authKey: this.currentAuth.authKey,
                            result: '',
                            detailResult: null
                        };
                        this.dialogVisible.pushToken = true;
                        break;
                }
            },
            
            // 日志管理相关方法
            
            // 授权请求日志
            handleAuthRequestPageChange(val) {
                this.authRequestCurrentPage = val;
                this.refreshAuthRequestLogs();
            },
            
            // 刷新授权请求日志数据
            async refreshAuthRequestLogs() {
                try {
                    // 设置加载状态
                    this.loading.auth_request_log = true;
                    
                    // 构建请求数据
                    const data = {
                        action: 'get_auth_request_logs',
                        paged: this.authRequestCurrentPage
                    };
                    
                    // 发送请求到AJAX端点
                    const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                    
                    if (!result.error) {
                        // 更新日志列表相关数据
                        this.authRequestLogs = result.authRequestLogs || [];
                        this.authRequestTotal = parseInt(result.authRequestTotal) || 0;
                        this.authRequestCurrentPage = parseInt(result.authRequestCurrentPage) || 1;
                        this.authRequestTotalPages = parseInt(result.authRequestTotalPages) || 1;
                        
                        // 更新URL而不刷新页面
                        const url = new URL(window.location.href);
                        url.searchParams.delete('auth_request_status');
                        url.searchParams.set('paged', this.authRequestCurrentPage);
                        window.history.replaceState({}, '', url.toString());
                    } else {
                        this.showMessage(result.msg || '刷新日志列表失败', 'error');
                    }
                } catch (error) {
                    this.showMessage('刷新日志列表失败: ' + error.message, 'error');
                } finally {
                    // 关闭加载状态
                    this.loading.auth_request_log = false;
                }
            },
            
            // 授权操作日志
            handleAuthOperationPageChange(val) {
                this.authOperationCurrentPage = val;
                this.refreshAuthOperationLogs();
            },
            
            // 刷新授权操作日志数据
            async refreshAuthOperationLogs() {
                try {
                    // 设置加载状态
                    this.loading.auth_operation_log = true;
                    
                    // 构建请求数据
                    const data = {
                        action: 'get_auth_operation_logs',
                        paged: this.authOperationCurrentPage
                    };
                    
                    // 发送请求到AJAX端点
                    const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                    
                    if (!result.error) {
                        // 更新日志列表相关数据
                        this.authOperationLogs = result.authOperationLogs || [];
                        this.authOperationTotal = parseInt(result.authOperationTotal) || 0;
                        this.authOperationCurrentPage = parseInt(result.authOperationCurrentPage) || 1;
                        this.authOperationTotalPages = parseInt(result.authOperationTotalPages) || 1;
                    } else {
                        this.showMessage(result.msg || '刷新操作日志失败', 'error');
                    }
                } catch (error) {
                    this.showMessage('刷新操作日志失败: ' + error.message, 'error');
                } finally {
                    // 关闭加载状态
                    this.loading.auth_operation_log = false;
                }
            },
            
            // 更新请求日志
            handleUpdateRequestPageChange(val) {
                this.updateRequestCurrentPage = val;
                this.refreshUpdateRequestLogs();
            },
            
            // 刷新更新请求日志数据
            async refreshUpdateRequestLogs() {
                try {
                    // 设置加载状态
                    this.loading.update_request_log = true;
                    
                    // 构建请求数据
                    const data = {
                        action: 'get_update_request_logs',
                        paged: this.updateRequestCurrentPage
                    };
                    
                    // 发送请求到AJAX端点
                    const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                    
                    if (!result.error) {
                        // 更新日志列表相关数据
                        this.updateRequestLogs = result.updateRequestLogs || [];
                        this.updateRequestTotal = parseInt(result.updateRequestTotal) || 0;
                        this.updateRequestCurrentPage = parseInt(result.updateRequestCurrentPage) || 1;
                        this.updateRequestTotalPages = parseInt(result.updateRequestTotalPages) || 1;
                    } else {
                        this.showMessage(result.msg || '刷新更新日志失败', 'error');
                    }
                } catch (error) {
                    this.showMessage('刷新更新日志失败: ' + error.message, 'error');
                } finally {
                    // 关闭加载状态
                    this.loading.update_request_log = false;
                }
            },
            
            // 前端管理操作日志
            handleFrontendAdminPageChange(val) {
                this.frontendAdminCurrentPage = val;
                this.refreshFrontendAdminLogs();
            },
            
            // 刷新前端管理操作日志数据
            async refreshFrontendAdminLogs() {
                try {
                    // 设置加载状态
                    this.loading.frontend_admin_log = true;
                    
                    // 构建请求数据
                    const data = {
                        action: 'get_frontend_admin_logs',
                        paged: this.frontendAdminCurrentPage
                    };
                    
                    // 发送请求到AJAX端点
                    const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                    
                    if (!result.error) {
                        // 更新日志列表相关数据
                        this.frontendAdminLogs = result.frontendAdminLogs || [];
                        this.frontendAdminTotal = parseInt(result.frontendAdminTotal) || 0;
                        this.frontendAdminCurrentPage = parseInt(result.frontendAdminCurrentPage) || 1;
                        this.frontendAdminTotalPages = parseInt(result.frontendAdminTotalPages) || 1;
                    } else {
                        this.showMessage(result.msg || '刷新前端管理操作日志失败', 'error');
                    }
                } catch (error) {
                    this.showMessage('刷新前端管理操作日志失败: ' + error.message, 'error');
                } finally {
                    // 关闭加载状态
                    this.loading.frontend_admin_log = false;
                }
            },
            
            // 刷新当前标签页的日志数据
            refreshCurrentTabLogs() {
                switch (this.activeTab) {
                    case 'authRequest':
                        this.refreshAuthRequestLogs();
                        break;
                    case 'authOperation':
                        this.refreshAuthOperationLogs();
                        break;
                    case 'updateRequest':
                        this.refreshUpdateRequestLogs();
                        break;
                    case 'frontendAdmin':
                        this.refreshFrontendAdminLogs();
                        break;
                }
            },
            
            // 刷新更新列表数据
            async refreshUpdatesList() {
                try {
                    // 设置加载状态
                    this.loading.updates_table = true;
                    
                    // 构建请求数据
                    // 将日期对象转换为YYYY-MM-DD格式的字符串
                    const formatDate = (date) => {
                        if (!date) return '';
                        const year = date.getFullYear();
                        const month = String(date.getMonth() + 1).padStart(2, '0');
                        const day = String(date.getDate()).padStart(2, '0');
                        return `${year}-${month}-${day}`;
                    };
                    
                    // 确保operationTime是数组
                    const operationTime = Array.isArray(this.updatesTimeFilter.operationTime) ? this.updatesTimeFilter.operationTime : [];
                    
                    const data = {
                        action: 'get_updates_list',
                        paged: this.updatesCurrentPage,
                        per_page: this.updatesPerPage,
                        orderby: this.updatesOrderBy,
                        order: this.updatesOrder,
                        product_id: this.updatesFilter.productId,
                        push_status: this.updatesFilter.pushStatus,
                        start_time: formatDate(operationTime[0]),
                        end_time: formatDate(operationTime[1])
                    };
                    
                    // 发送请求到AJAX端点
                    const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                    
                    // 检查结果格式是否正确
                    if (result && typeof result === 'object') {
                        if (!result.error) {
                            // 更新更新列表相关数据
                            this.updatesList = result.updatesList || [];
                            this.updatesTotal = parseInt(result.updatesTotal) || 0;
                            this.updatesCurrentPage = parseInt(result.updatesCurrentPage) || 1;
                            this.updatesTotalPages = parseInt(result.updatesTotalPages) || 1;
                        } else {
                            this.showMessage(result.msg || '刷新更新列表失败', 'error');
                        }
                    } else {
                        this.showMessage('服务器返回数据格式错误', 'error');
                    }
                } catch (error) {
                    this.showMessage('刷新更新列表失败: ' + error.message, 'error');
                    console.error('刷新更新列表失败:', error);
                } finally {
                    // 关闭加载状态
                    this.loading.updates_table = false;
                }
            },
            
            // 筛选更新包
            filterUpdates() {
                // 验证必须同时选择产品和推送状态
                if (!this.updatesFilter.productId) {
                    this.showMessage('请选择产品', 'error');
                    return;
                }
                if (this.updatesFilter.pushStatus === '') {
                    this.showMessage('请选择推送状态', 'error');
                    return;
                }
                this.updatesCurrentPage = 1;
                this.refreshUpdatesList();
            },
            
            // 重置更新包筛选条件
            resetUpdatesFilter() {
                this.updatesFilter = {
                    productId: '',
                    pushStatus: 'all'
                };
                // 确保updatesTimeFilter和operationTime都存在且为数组
                if (!this.updatesTimeFilter) {
                    this.updatesTimeFilter = {};
                }
                this.updatesTimeFilter.operationTime = [];
                this.updatesCurrentPage = 1;
                this.refreshUpdatesList();
            },
            
            // 处理更新列表页码变化
            handleCurrentChange(val) {
                this.updatesCurrentPage = val;
                this.refreshUpdatesList();
            },
            
            // 处理更新列表每页显示数量变化
            handleSizeChange(val) {
                this.updatesPerPage = val;
                this.updatesCurrentPage = 1;
                this.refreshUpdatesList();
            },
            
            // 编辑更新包
            editUpdate(update) {
                this.currentUpdate = { ...update };
                // 如果适用原版本为'全版本'，则在表单中显示为空
                const formData = { ...update };
                if (formData.originalVersions === '全版本') {
                    formData.originalVersions = '';
                }
                this.updateForm = formData;
                this.dialogVisible.editUpdate = true;
            },
            
            // 指定ID推送
            targetedPush(update) {
                this.currentUpdate = { ...update };
                this.targetedPushForm.updateId = update.id;
                this.targetedPushForm.targetType = 'all';
                this.targetedPushForm.targetValues = '';
                this.dialogVisible.targetedPush = true;
            },
            
            // 全部推送
            allPush(update) {
                this.$confirm(`确定要将版本为【${update.version}】的更新包推送给所有用户吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.targetedPushForm.updateId = update.id;
                    this.targetedPushForm.targetType = 'all';
                    this.targetedPushForm.targetValues = 'all';
                    this.submitTargetedPush();
                }).catch(() => {
                    // 用户取消操作，不做处理
                });
            },
            
            // 删除更新包
            deleteUpdate(update) {
                this.$confirm(`确定要删除版本为【${update.version}】的更新包吗？此操作不可恢复！`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'danger'
                }).then(() => {
                    this.handleDeleteUpdate(update.id, update.version);
                }).catch(() => {
                    // 用户取消操作，不做处理
                });
            },
            
            // 查看推送目标
            viewPushTargets(update) {
                this.currentUpdate = { ...update };
                this.dialogVisible.pushTargets = true;
            },
            
            // 打开添加更新包弹窗
            addUpdate() {
                // 重置表单
                this.addUpdateForm = {
                    productId: '',
                    version: '',
                    updatePackageUrl: '',
                    updateDescription: '',
                    originalVersions: ''
                };
                this.dialogVisible.addUpdate = true;
            },
            
            // 打开更新操作弹窗
            openUpdateActionDialog(update) {
                this.currentUpdate = { ...update };
                this.dialogVisible.updateAction = true;
            },
            
            // 处理更新操作
            handleUpdateAction(action) {
                this.dialogVisible.updateAction = false;
                
                switch (action) {
                    case 'edit':
                        this.editUpdate(this.currentUpdate);
                        break;
                    case 'targetedPush':
                        this.targetedPush(this.currentUpdate);
                        break;
                    case 'allPush':
                        this.allPush(this.currentUpdate);
                        break;
                    case 'delete':
                        this.deleteUpdate(this.currentUpdate);
                        break;
                }
            },
            
            // 删除推送目标
            async removePushTarget(target) {
                try {
                    // 构建请求数据
                    const requestData = {
                        action: 'remove_push_target',
                        update_id: this.currentUpdate.id,
                        target: target
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, requestData, 'POST');
                    
                    // 检查结果格式是否正确
                    if (result && typeof result === 'object') {
                        if (!result.error) {
                            this.showMessage('推送目标已成功删除', 'success');
                            // 更新当前显示的推送目标
                            const targets = this.currentUpdate.pushedTargets.split(', ');
                            const index = targets.indexOf(target);
                            if (index > -1) {
                                targets.splice(index, 1);
                                this.currentUpdate.pushedTargets = targets.join(', ');
                            }
                            // 刷新更新列表数据
                            this.refreshUpdatesList();
                        } else {
                            this.showMessage('删除推送目标失败：' + (result.msg || '未知错误'), 'error');
                        }
                    } else {
                        this.showMessage('服务器返回数据格式错误', 'error');
                    }
                } catch (error) {
                    this.showMessage('删除推送目标失败：' + error.message, 'error');
                }
            },
            
            // 提交更新包编辑
            async submitUpdate() {
                try {
                    const result = await this.handleAjaxRequest(ajaxurl, {
                        action: 'update_product_package',
                        update_id: this.updateForm.id,
                        update_url: this.updateForm.updatePackageUrl,
                        update_desc: this.updateForm.updateDescription,
                        original_versions: this.updateForm.originalVersions,
                        push_status: this.updateForm.pushStatus
                    }, 'POST');
                    
                    if (!result.error) {
                        this.dialogVisible.editUpdate = false;
                        this.showMessage('更新包信息已成功更新', 'success');
                        this.refreshUpdatesList();
                    } else {
                        this.showMessage('更新失败：' + result.msg, 'error');
                    }
                } catch (error) {
                    this.showMessage('更新失败：' + error.message, 'error');
                }
            },
            
            // 提交指定ID推送
            async submitTargetedPush() {
                try {
                    const result = await this.handleAjaxRequest(ajaxurl, {
                        action: 'targeted_push',
                        update_id: this.targetedPushForm.updateId,
                        target_type: this.targetedPushForm.targetType,
                        target_values: this.targetedPushForm.targetValues
                    }, 'POST');
                    
                    if (!result.error) {
                        this.dialogVisible.targetedPush = false;
                        this.showMessage('推送成功：' + result.msg, 'success');
                        this.refreshUpdatesList();
                    } else {
                        this.showMessage('推送失败：' + result.msg, 'error');
                    }
                } catch (error) {
                    this.showMessage('推送失败：' + error.message, 'error');
                }
            },
            
            // 删除更新包
            async handleDeleteUpdate(updateId, version) {
                try {
                    const result = await this.handleAjaxRequest(ajaxurl, {
                        action: 'delete_product_package',
                        update_id: updateId
                    }, 'POST');
                    
                    if (!result.error) {
                        this.showMessage('更新包已成功删除', 'success');
                        this.refreshUpdatesList();
                    } else {
                        this.showMessage('删除失败：' + result.msg, 'error');
                    }
                } catch (error) {
                    this.showMessage('删除失败：' + error.message, 'error');
                }
            },
            
            // 确认添加更新包
            async confirmAddUpdate() {
                try {
                    const result = await this.handleAjaxRequest(ajaxurl, {
                        action: 'add_product_update',
                        product_id: this.addUpdateForm.productId,
                        version: this.addUpdateForm.version,
                        update_package_url: this.addUpdateForm.updatePackageUrl,
                        update_description: this.addUpdateForm.updateDescription,
                        original_versions: this.addUpdateForm.originalVersions
                    }, 'POST');
                    
                    if (!result.error) {
                        this.dialogVisible.addUpdate = false;
                        this.showMessage('更新包已成功添加', 'success');
                        this.refreshUpdatesList();
                        // 重置表单
                        this.addUpdateForm = {
                            productId: '',
                            version: '',
                            updatePackageUrl: '',
                            updateDescription: '',
                            originalVersions: ''
                        };
                    } else {
                        this.showMessage('添加失败：' + result.msg, 'error');
                    }
                } catch (error) {
                    this.showMessage('添加失败：' + error.message, 'error');
                }
            },
            
            // 清理当前标签页的日志
            async clearLogs() {
                // 确认清理操作
                try {
                    await this.$confirm('确定要清理当前标签页的所有日志吗？此操作不可恢复！', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                        center: true
                    });
                    
                    // 设置清理中状态
                    this.clearingLogs = true;
                    
                    // 构建请求数据
                let action = '';
                switch (this.activeTab) {
                    case 'authRequest':
                        action = 'xk_auth_clear_request_logs';
                        break;
                    case 'authOperation':
                        action = 'xk_auth_clear_operate_logs';
                        break;
                    case 'updateRequest':
                        action = 'xk_auth_clear_update_logs';
                        break;
                    case 'frontendAdmin':
                        action = 'xk_auth_clear_frontend_admin_logs';
                        break;
                    default:
                        throw new Error('当前标签页不支持清理操作');
                }
                
                // 发送清理请求
                const data = {
                    action: action,
                    security: this.clear_logs_nonce
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data, 'POST');
                
                if (result.success) {
                    this.showMessage(result.data.message || '日志清理成功', 'success');
                    // 重新刷新当前标签页的日志数据
                    this.refreshCurrentTabLogs();
                } else {
                    this.showMessage(result.data.message || '日志清理失败', 'error');
                }
                } catch (error) {
                    // 用户取消操作，不做处理
                    if (error !== 'cancel') {
                        console.error('清理日志失败:', error);
                        this.showMessage('日志清理失败: ' + error.message, 'error');
                    }
                } finally {
                    // 关闭清理中状态
                    this.clearingLogs = false;
                }
            },
            
            // 显示消息
            showMessage(text, type = 'success') {
                // 使用Element Plus的全局$message方法，调整位置和样式
                this.$message({
                    message: text,
                    type: type,
                    duration: 3000,
                    position: 'top', // 设置消息弹窗位置为顶部中央
                    customClass: 'xk-auth-message' // 添加自定义CSS类，用于调整样式
                });
            },
            
            // 构建URL参数，支持数组
            buildUrlParams(data) {
                const params = [];
                
                function addParam(key, value) {
                    if (value === null || value === undefined) {
                        return;
                    }
                    
                    if (Array.isArray(value)) {
                        value.forEach(item => {
                            addParam(`${key}[]`, item);
                        });
                    } else if (typeof value === 'object') {
                        Object.keys(value).forEach(subKey => {
                            addParam(`${key}[${subKey}]`, value[subKey]);
                        });
                    } else {
                        params.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
                    }
                }
                
                Object.keys(data).forEach(key => {
                    addParam(key, data[key]);
                });
                
                return params.join('&');
            },
            
            // 处理AJAX请求
            async handleAjaxRequest(url, data, method = 'POST') {
                try {
                    // 添加nonce到请求数据，但不覆盖已有security字段
                    let securityToken = data.security;
                    
                    // 根据不同的action使用不同的nonce
                    if (['get_auth_list', 'get_auth_request_logs', 'get_auth_operation_logs', 'get_update_request_logs', 'get_frontend_admin_logs', 'xk_auth_get_products', 'get_updates_list', 'remove_push_target', 'get_promo_codes', 'save_promo_code', 'delete_promo_code', 'xk_auth_ajax_get_reports_list', 'xk_auth_ajax_update_report_status', 'xk_auth_ajax_delete_report', 'xk_auth_save_report_settings', 'xk_auth_load_report_settings', 'xk_auth_check_report_type_usage', 'xk_auth_get_users', 'xk_auth_get_authorized_users', 'xk_auth_add_authorized_user', 'xk_auth_remove_authorized_user'].includes(data.action)) {
                        securityToken = data.security || this.xk_auth_nonce || '';
                    } else if (data.action === 'update_product_package') {
                        securityToken = data.security || this.edit_update_nonce || '';
                    } else if (data.action === 'delete_product_package') {
                        securityToken = data.security || this.delete_update_nonce || '';
                    } else if (data.action === 'targeted_push') {
                        securityToken = data.security || this.targeted_push_nonce || '';
                    } else if (data.action === 'add_product_update') {
                        securityToken = data.security || this.add_update_nonce || '';
                    } else {
                        securityToken = data.security || this.nonce || '';
                    }
                    
                    const requestData = {
                        ...data,
                        security: securityToken
                    };
                    
                    let fetchOptions = {
                        method: method,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    };
                    
                    let fetchUrl = url;
                    
                    if (method === 'GET') {
                        // 对于GET请求，将数据转换为URL查询字符串
                        const params = this.buildUrlParams(requestData);
                        fetchUrl += (url.includes('?') ? '&' : '?') + params;
                    } else {
                        // 对于POST请求，设置body
                        fetchOptions.headers['Content-Type'] = 'application/x-www-form-urlencoded';
                        fetchOptions.body = this.buildUrlParams(requestData);
                    }
                    
                    const response = await fetch(fetchUrl, fetchOptions);
                    
                    const result = await response.json();
                    return result;
                } catch (error) {
                    return { error: 1, msg: '网络请求失败: ' + error.message };
                }
            },
            
            // 刷新授权列表数据
            async refreshAuthList(skipParamsUpdate = false) {
                try {
                    // 设置加载状态
                    this.loading.auth_table = true;
                    
                    // 立即返回，让点击处理程序尽快完成
                    Promise.resolve().then(async () => {
                        // 构建请求数据
                        const data = {
                            action: 'get_auth_list',
                            search_type: this.authSearchType,
                            s: this.authSearchKeyword,
                            status: this.authStatusFilter,
                            view_mode: this.authViewMode,
                            paged: this.authCurrentPage
                        };
                        
                        // 发送请求到AJAX端点
                        const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                        
                        if (!result.error) {
                            // 更新授权列表相关数据
                            this.authUserGroups = result.authUserGroups || [];
                            this.authProductGroups = result.authProductGroups || [];
                            this.authTotalCount = result.authTotalCount || 0;
                            this.authCurrentPage = result.authCurrentPage || 1;
                            this.authTotalPages = result.authTotalPages || 1;
                            
                            // 更新URL而不刷新页面
                            const url = new URL(window.location.href);
                            url.searchParams.set('search_type', this.authSearchType);
                            url.searchParams.set('s', this.authSearchKeyword);
                            url.searchParams.set('status', this.authStatusFilter);
                            url.searchParams.set('view_mode', this.authViewMode);
                            url.searchParams.set('paged', this.authCurrentPage);
                            window.history.replaceState({}, '', url.toString());
                            
                            // 重置折叠面板状态
                            this.authActiveUserNames = [];
                            this.authActiveProductNames = [];
                        } else {
                            this.showMessage(result.msg || '刷新授权列表失败', 'error');
                        }
                    }).catch(error => {
                        console.error('刷新授权列表失败:', error);
                        this.showMessage('刷新授权列表失败', 'error');
                    }).finally(() => {
                        // 无论请求成功还是失败，都关闭加载状态
                        this.loading.auth_table = false;
                    });
                } catch (error) {
                    console.error('刷新授权列表失败:', error);
                    this.showMessage('刷新授权列表失败', 'error');
                    // 关闭加载状态
                    this.loading.auth_table = false;
                }
            },
            
            // 修改状态
            authHandleStatusUpdate(row) {
                this.currentAuth = { ...row };
                this.statusUpdateForm.id = row.id;
                this.statusUpdateForm.status = row.status;
                this.statusUpdateForm.log = '';
                this.dialogVisible.statusUpdate = true;
            },
            
            // 确认修改状态
            async confirmStatusUpdate() {
                if (!this.statusUpdateForm.log.trim()) {
                    this.showMessage('请输入处理备注', 'error');
                    return;
                }
                
                const data = {
                    action: 'process_auth',
                    auth_id: this.statusUpdateForm.id,
                    status: this.statusUpdateForm.status,
                    log: this.statusUpdateForm.log
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.showMessage(result.msg, 'success');
                    this.dialogVisible.statusUpdate = false;
                    // 刷新授权列表
                    this.refreshAuthList();
                } else {
                    this.showMessage(result.msg, 'error');
                }
            },
            
            // 管理域名
            authHandleManageDomain(row) {
                this.currentAuth = { ...row };
                this.domainManageForm.id = row.id;
                this.domainManageForm.currentDomain = row.domain;
                this.domainManageForm.newDomain = '';
                this.domainManageForm.productName = '加载中...';
                this.domainManageForm.userName = '加载中...';
                
                // 先显示弹窗
                this.dialogVisible.domainManage = true;
                
                // 然后异步获取授权信息
                this.fetchAuthInfo(row.id);
            },
            
            // 获取授权信息
            async fetchAuthInfo(authId) {
                const data = {
                    action: 'get_auth_info',
                    auth_id: authId
                };
                
                try {
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error && result.auth) {
                        this.domainManageForm.productName = result.auth.product_name;
                        this.domainManageForm.userName = result.auth.user_name;
                    } else {
                        this.showMessage('获取授权信息失败', 'error');
                        this.domainManageForm.productName = '获取失败';
                        this.domainManageForm.userName = '获取失败';
                    }
                } catch (error) {
                    console.error('获取授权信息失败:', error);
                    this.showMessage('获取授权信息失败', 'error');
                    this.domainManageForm.productName = '获取失败';
                    this.domainManageForm.userName = '获取失败';
                }
            },
            
            // 确认修改域名
            async confirmDomainUpdate() {
                const newDomain = this.domainManageForm.newDomain.trim();
                if (!newDomain) {
                    this.showMessage('请输入新域名', 'error');
                    return;
                }
                
                // 支持域名和IP地址的正则表达式
                const domainRegex = /^(?:([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}|((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))$/i;
                if (!domainRegex.test(newDomain)) {
                    this.showMessage('请输入有效的域名或IP地址（不带http://）', 'error');
                    return;
                }
                
                const data = {
                    action: 'update_auth_domain',
                    auth_id: this.domainManageForm.id,
                    new_domain: newDomain
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.showMessage(result.msg, 'success');
                    this.dialogVisible.domainManage = false;
                    // 刷新授权列表
                    this.refreshAuthList();
                } else {
                    this.showMessage(result.msg, 'error');
                }
            },
            
            // 删除域名
            async deleteDomain() {
                try {
                    // 使用Element Plus的确认对话框
                    await this.$confirm('确定要删除这个授权域名吗？此操作不可恢复！', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                    });
                    
                    const data = {
                        action: 'delete_auth_domain',
                        auth_id: this.domainManageForm.id
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage(result.msg, 'success');
                        this.dialogVisible.domainManage = false;
                        // 刷新授权列表
                        this.refreshAuthList();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    // 用户取消了删除操作，不做任何处理
                    if (error !== 'cancel') {
                        console.error('删除域名失败:', error);
                        this.showMessage('删除域名失败', 'error');
                    }
                }
            },
            
            // 修改授权数量
            authHandleUpdateAuthCount(row) {
                this.currentAuth = { ...row };
                this.authCountUpdateForm.id = row.id;
                this.authCountUpdateForm.userId = row.userId || '';
                this.authCountUpdateForm.productId = row.productId;
                this.authCountUpdateForm.authCount = null;
                this.authCountUpdateForm.reason = '';
                this.dialogVisible.authCountUpdate = true;
            },
            
            // 确认修改授权数量
            async confirmAuthCountUpdate() {
                if (!this.authCountUpdateForm.authCount || isNaN(this.authCountUpdateForm.authCount)) {
                    this.showMessage('请输入有效的授权数量', 'error');
                    return;
                }
                
                if (!this.authCountUpdateForm.reason.trim()) {
                    this.showMessage('请输入修改原因', 'error');
                    return;
                }
                
                const data = {
                    action: 'update_auth_count',
                    auth_id: this.authCountUpdateForm.id,
                    user_id: this.authCountUpdateForm.userId,
                    product_id: this.authCountUpdateForm.productId,
                    new_count: this.authCountUpdateForm.authCount,
                    reason: this.authCountUpdateForm.reason
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.showMessage(result.msg, 'success');
                    this.dialogVisible.authCountUpdate = false;
                    // 刷新授权列表
                    this.refreshAuthList();
                } else {
                    this.showMessage(result.msg, 'error');
                }
            },
            
            // 设置到期时间
            authHandleSetExpireTime(row) {
                this.currentAuth = { ...row };
                this.expireTimeSetForm.id = row.id;
                this.expireTimeSetForm.expireTime = row.expireTime === '永久' ? '' : row.expireTime;
                this.expireTimeSetForm.permanent = row.expireTime === '永久';
                this.dialogVisible.expireTimeSet = true;
            },
            
            // 处理永久授权复选框变化
            handlePermanentChange(checked) {
                if (checked) {
                    this.expireTimeSetForm.expireTime = '';
                }
            },
            
            // 确认设置到期时间
            async confirmExpireTimeSet() {
                // 验证设置原因
                if (!this.expireTimeSetForm.reason.trim()) {
                    this.showMessage('请输入设置原因', 'error');
                    return;
                }
                
                const data = {
                    action: 'update_auth_expire',
                    auth_id: this.expireTimeSetForm.id,
                    expire_time: this.expireTimeSetForm.expireTime,
                    permanent: this.expireTimeSetForm.permanent ? 1 : 0,
                    reason: this.expireTimeSetForm.reason
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.showMessage(result.msg, 'success');
                    this.dialogVisible.expireTimeSet = false;
                    // 刷新授权列表
                    this.refreshAuthList();
                } else {
                    this.showMessage(result.msg, 'error');
                }
            },
            
            // 推送Token
            authHandlePushToken(row) {
                this.currentAuth = { ...row };
                this.pushTokenForm.id = row.id;
                this.pushTokenForm.domain = row.domain;
                this.pushTokenForm.productId = row.productId;
                this.pushTokenForm.authKey = row.authKey;
                this.pushTokenForm.result = '';
                this.pushTokenForm.detailResult = null;
                this.dialogVisible.pushToken = true;
            },
            
            // 确认推送Token
            async confirmPushToken() {
                const data = {
                    action: 'xk_auth_push_token_manual',
                    auth_id: this.pushTokenForm.id,
                    domain: this.pushTokenForm.domain,
                    product_id: this.pushTokenForm.productId,
                    auth_key: this.pushTokenForm.authKey
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.showMessage(result.msg, 'success');
                } else {
                    this.showMessage(result.msg, 'error');
                }
                
                // 设置结果信息
                this.pushTokenForm.result = result.msg;
                // 设置完整的详细结果
                this.pushTokenForm.detailResult = result;
                
                // 刷新授权列表
                this.refreshAuthList();
            },
            
            // 确认添加授权
            async confirmAddAuth() {
                // 表单验证
                if (!this.addAuthForm.user_id) {
                    this.showMessage('请输入用户ID', 'error');
                    return;
                }
                if (isNaN(this.addAuthForm.user_id) || parseInt(this.addAuthForm.user_id) <= 0) {
                    this.showMessage('用户ID必须是正整数', 'error');
                    return;
                }
                if (!this.addAuthForm.product_id) {
                    this.showMessage('请选择产品', 'error');
                    return;
                }
                
                const data = {
                    action: 'add_product_authorization',
                    user_id: this.addAuthForm.user_id,
                    product_id: this.addAuthForm.product_id,
                    expire_time: this.addAuthForm.permanent ? '' : this.addAuthForm.expire_time,
                    permanent: this.addAuthForm.permanent ? 1 : 0,
                    security: this.nonce
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.showMessage(result.msg, 'success');
                    this.dialogVisible.addAuth = false;
                    // 重置表单
                    this.addAuthForm.user_id = '';
                    this.addAuthForm.product_id = '';
                    this.addAuthForm.expire_time = '';
                    this.addAuthForm.permanent = false;
                    // 刷新授权列表
                    this.refreshAuthList();
                } else {
                    this.showMessage(result.msg, 'error');
                }
            },
            
            // 获取产品列表
            async getProducts() {
                const data = {
                    action: 'xk_auth_get_products'
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.products = result.data || [];
                } else {
                    this.showMessage(result.msg, 'error');
                }
            },
            
            // 获取优惠码列表
            async getPromoCodes() {
                this.loading.promoTable = true;
                const data = {
                    action: 'get_promo_codes',
                    paged: this.promoCurrentPage,
                    per_page: this.promoPageSize,
                    code: this.promoFilter.code,
                    status: this.promoFilter.status
                };
                
                const result = await this.handleAjaxRequest(ajaxurl, data);
                
                if (!result.error) {
                    this.promoCodes = result.promoCodes || [];
                    this.promoTotalCount = result.promoTotalCount || 0;
                    this.promoCurrentPage = result.promoCurrentPage || 1;
                } else {
                    this.showMessage(result.msg, 'error');
                }
                
                this.loading.promoTable = false;
            },
            
            // 保存优惠码
            async savePromo() {
                await this.$refs.promoFormRef.validate(async (valid) => {
                    if (valid) {
                        const data = {
                            action: 'save_promo_code',
                            ...this.promoForm
                        };
                        
                        const result = await this.handleAjaxRequest(ajaxurl, data);
                        
                        if (!result.error) {
                            this.showMessage(result.msg, 'success');
                            this.dialogVisible.addPromo = false;
                            this.getPromoCodes();
                            // 重置表单
                            this.promoForm = {
                                id: '',
                                name: '',
                                code: '',
                                type: 'fixed',
                                value: 0,
                                min_amount: 0,
                                max_discount: 999,
                                usage_limit: null,
                                product_ids: '',
                                user_ids: '',
                                start_time: null,
                                end_time: null,
                                status: 'active',
                                description: ''
                            };
                        } else {
                            this.showMessage(result.msg, 'error');
                        }
                    }
                });
            },
            
            // 添加优惠码
            addPromo() {
                // 重置表单
                this.promoForm = {
                    id: '',
                    name: '',
                    code: '',
                    type: 'fixed',
                    value: 0,
                    min_amount: 0,
                    max_discount: 999,
                    usage_limit: null,
                    product_ids: '',
                    user_ids: '',
                    start_time: null,
                    end_time: null,
                    status: 'active',
                    description: ''
                };
                this.dialogVisible.addPromo = true;
            },
            
            // 编辑优惠码
            editPromo(promo) {
                this.promoForm = { ...promo };
                this.dialogVisible.addPromo = true;
            },
            
            // 删除优惠码
            async deletePromo(promo) {
                try {
                    await this.$confirm('确定要删除这个优惠码吗？此操作不可恢复！', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    });
                    
                    const data = {
                        action: 'delete_promo_code',
                        id: promo.id
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage(result.msg, 'success');
                        this.getPromoCodes();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    // 用户取消操作，不做处理
                }
            },
            
            // 重置优惠码筛选条件
            resetFilter() {
                this.promoFilter = {
                    code: '',
                    status: ''
                };
                this.getPromoCodes();
            },
            
            // 处理优惠码分页变化
            handlePromoPageChange(val) {
                this.promoCurrentPage = val;
                this.getPromoCodes();
            },
            
            // 保存前端授权管理功能设置
            async saveFrontendAuthSetting() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                try {
                    // 构建请求数据，确保包含所有必要的参数
                    const data = {
                        action: 'xk_auth_save_report_settings',
                        report_types: JSON.stringify([
                            { key: 'piracy', label: '盗版使用' },
                            { key: 'unauthorized', label: '未授权使用' },
                            { key: 'fake', label: '假冒产品' },
                            { key: 'other', label: '其他问题' }
                        ]),
                        sender_name: '星空授权',
                        enabled: true,
                        email_notification: true,
                        frontend_auth_enabled: this.frontendAuthEnabled ? 1 : 0
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage('设置保存成功', 'success');
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    console.error('保存前端授权管理设置失败:', error);
                    this.showMessage('保存设置失败: ' + error.message, 'error');
                }
            },
            
            // 获取用户列表
            async getUsers() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                try {
                    const data = {
                        action: 'xk_auth_get_users'
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.users = result.users || [];
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    console.error('获取用户列表失败:', error);
                    this.showMessage('获取用户列表失败: ' + error.message, 'error');
                }
            },
            
            // 获取授权用户列表
            async getAuthorizedUsers() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                this.loading.authorizedUsers = true;
                
                try {
                    const data = {
                        action: 'xk_auth_get_authorized_users',
                        paged: this.authorizedUsersCurrentPage,
                        per_page: this.authorizedUsersPageSize
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.authorizedUsers = result.authorizedUsers || [];
                        this.authorizedUsersTotal = result.total || 0;
                        this.authorizedUsersCurrentPage = result.currentPage || 1;
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    console.error('获取授权用户列表失败:', error);
                    this.showMessage('获取授权用户列表失败: ' + error.message, 'error');
                } finally {
                    this.loading.authorizedUsers = false;
                }
            },
            
            // 添加授权用户
            async addAuthorizedUser() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                if (!this.selectedUser) {
                    this.showMessage('请选择用户', 'error');
                    return;
                }
                
                try {
                    const data = {
                        action: 'xk_auth_add_authorized_user',
                        user_id: this.selectedUser
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage('授权用户添加成功', 'success');
                        this.selectedUser = '';
                        this.userSearchText = '';
                        this.getAuthorizedUsers();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    console.error('添加授权用户失败:', error);
                    this.showMessage('添加授权用户失败: ' + error.message, 'error');
                }
            },
            
            // 移除授权用户
            async removeAuthorizedUser(user_id) {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                try {
                    await this.$confirm('确定要移除这个授权用户吗？', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    });
                    
                    const data = {
                        action: 'xk_auth_remove_authorized_user',
                        user_id: user_id
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage('授权用户移除成功', 'success');
                        this.getAuthorizedUsers();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    // 用户取消操作，不做处理
                }
            },
            
            // 处理授权用户分页变化
            handleAuthorizedUsersPageChange(val) {
                this.authorizedUsersCurrentPage = val;
                this.getAuthorizedUsers();
            },
            
            // 搜索用户
            querySearch(query, callback) {
                if (!query) {
                    callback([]);
                    return;
                }
                const results = this.users.filter(user => {
                    return user.name.toLowerCase().includes(query.toLowerCase());
                });
                callback(results);
            },
            
            // 处理用户选择
            handleSelect(item) {
                this.selectedUser = item.id;
                this.userSearchText = item.name;
            },
            
            // 举报管理相关方法
            // 打开举报处理弹窗
            openReportActionDialog(report) {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                this.currentReport = { ...report };
                this.reportActionForm = {
                    id: report.id,
                    userName: report.userName,
                    productName: report.productName,
                    reportType: report.reportType,
                    reportContent: report.reportContent,
                    reportUrl: report.reportUrl,
                    operationTime: report.operationTime,
                    status: report.status,
                    statusText: report.statusText,
                    statusClass: report.statusClass,
                    adminNote: report.adminNote || ''
                };
                this.dialogVisible.reportAction = true;
            },
            
            // 确认举报处理
            async confirmReportAction() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                if (!this.reportActionForm.adminNote.trim()) {
                    this.showMessage('请输入处理备注', 'error');
                    return;
                }
                
                const data = {
                    action: 'xk_auth_ajax_update_report_status',
                    report_id: this.reportActionForm.id,
                    status: this.reportActionForm.status,
                    admin_note: this.reportActionForm.adminNote
                };
                
                try {
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage(result.msg, 'success');
                        this.dialogVisible.reportAction = false;
                        // 刷新举报列表
                        this.refreshReportsList();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    this.showMessage('处理举报失败: ' + error.message, 'error');
                }
            },
            
            // 处理举报搜索
            reportHandleSearch() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                // 重置页码为1
                this.reportCurrentPage = 1;
                // 刷新举报列表
                this.refreshReportsList();
            },
            
            // 重置举报搜索
            reportResetSearch() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                // 重置所有搜索参数
                this.reportSearchType = 'user';
                this.reportSearchKeyword = '';
                this.reportStatusFilter = '';
                this.reportCurrentPage = 1;
                // 刷新举报列表
                this.refreshReportsList();
            },
            
            // 处理举报状态筛选变化
            reportHandleStatusChange() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                // 状态筛选变化时重置页码并刷新举报列表
                this.reportCurrentPage = 1;
                this.refreshReportsList();
            },
            
            // 处理举报分页变化
            reportHandleCurrentChange(val) {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                // 页码变化时刷新举报列表
                this.reportCurrentPage = val;
                this.refreshReportsList();
            },
            
            // 刷新举报列表数据
            async refreshReportsList() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                try {
                    // 设置加载状态
                    this.loading.report_table = true;
                    
                    // 构建请求数据
                    const data = {
                        action: 'xk_auth_ajax_get_reports_list',
                        search_type: this.reportSearchType,
                        s: this.reportSearchKeyword,
                        status: this.reportStatusFilter,
                        paged: this.reportCurrentPage,
                        per_page: this.reportPageSize
                    };
                    
                    // 发送请求到AJAX端点
                    const result = await this.handleAjaxRequest(ajaxurl, data, 'GET');
                    
                    if (!result.error) {
                        // 更新举报列表相关数据
                        this.reportsList = result.reportsList || [];
                        this.reportsTotal = result.reportsTotal || 0;
                        this.reportCurrentPage = result.reportCurrentPage || 1;
                        this.reportTotalPages = result.reportTotalPages || 1;
                        
                        // 更新URL而不刷新页面
                        const url = new URL(window.location.href);
                        url.searchParams.set('search_type', this.reportSearchType);
                        url.searchParams.set('s', this.reportSearchKeyword);
                        url.searchParams.set('status', this.reportStatusFilter);
                        url.searchParams.set('paged', this.reportCurrentPage);
                        window.history.replaceState({}, '', url.toString());
                    } else {
                        this.showMessage(result.msg || '刷新举报列表失败', 'error');
                    }
                } catch (error) {
                    this.showMessage('刷新举报列表失败: ' + error.message, 'error');
                    console.error('刷新举报列表失败:', error);
                } finally {
                    // 关闭加载状态
                    this.loading.report_table = false;
                }
            },
            
            // 处理举报选择变化
            handleReportSelectionChange(selection) {
                this.selectedReports = selection;
            },
            
            // 批量删除举报
            async batchDeleteReports() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                if (this.selectedReports.length === 0) {
                    this.showMessage('请先选择要删除的举报记录', 'warning');
                    return;
                }
                
                try {
                    await this.$confirm(`确定要删除选中的 ${this.selectedReports.length} 条举报记录吗？此操作不可恢复！`, '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'danger'
                    });
                    
                    // 提取选中的举报ID
                    const reportIds = this.selectedReports.map(report => report.id);
                    
                    const data = {
                        action: 'xk_auth_ajax_delete_report',
                        report_id: reportIds
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage('举报记录删除成功', 'success');
                        // 清空选择
                        this.selectedReports = [];
                        // 刷新举报列表
                        this.refreshReportsList();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    // 用户取消操作，不做处理
                    if (error !== 'cancel') {
                        console.error('批量删除举报失败:', error);
                        this.showMessage('批量删除举报失败: ' + error.message, 'error');
                    }
                }
            },
            
            // 删除举报
            async deleteReport(report) {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                try {
                    await this.$confirm(`确定要删除举报ID为 ${report.id} 的记录吗？此操作不可恢复！`, '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'danger'
                    });
                    
                    const data = {
                        action: 'xk_auth_ajax_delete_report',
                        report_id: report.id
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage('举报记录删除成功', 'success');
                        // 刷新举报列表
                        this.refreshReportsList();
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    // 用户取消操作，不做处理
                    if (error !== 'cancel') {
                        console.error('删除举报失败:', error);
                        this.showMessage('删除举报失败: ' + error.message, 'error');
                    }
                }
            },
            
            // 显示举报内容弹窗
            showReportContent(report) {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                this.currentReport = { ...report };
                this.reportActionForm = {
                    id: report.id,
                    reportContent: report.reportContent
                };
                this.dialogVisible.reportContent = true;
            },
            
            // 举报设置相关方法
            // 添加举报类型
            addReportType() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                this.reportSettingsForm.reportTypes.push({ key: '', label: '' });
            },
            
            // 删除举报类型
            async removeReportType(index) {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                if (this.reportSettingsForm.reportTypes.length <= 1) {
                    this.showMessage('至少需要保留一个举报类型', 'error');
                    return;
                }
                
                // 获取要删除的举报类型
                const reportType = this.reportSettingsForm.reportTypes[index];
                
                try {
                    // 检查该举报类型是否在数据库中被使用
                    const data = {
                        action: 'xk_auth_check_report_type_usage',
                        report_type_key: reportType.key,
                        security: this.xk_auth_nonce || this.nonce
                    };
                    
                    const response = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (response.error === 0 && response.data.is_used) {
                        // 如果该类型被使用，显示提示
                        this.$message.error({
                            message: `该举报类型已被使用(${response.data.count}条记录)，请先删除相关举报记录后再重试`,
                            offset: 50
                        });
                        return;
                    }
                    
                    // 确认删除
                    this.$confirm('确定要删除该举报类型吗？', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(() => {
                        // 执行删除操作
                        this.reportSettingsForm.reportTypes.splice(index, 1);
                }).catch(() => {
                        // 取消删除
                    });
                } catch (error) {
                    this.$message.error({
                        message: '检查举报类型使用情况失败，请刷新页面重试',
                        offset: 50
                    });
                }
            },
            
            // 保存举报设置
            async saveReportSettings() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                // 验证设置
                const validTypes = this.reportSettingsForm.reportTypes.filter(type => type.key && type.label);
                if (validTypes.length === 0) {
                    this.showMessage('请至少添加一个有效的举报类型', 'error');
                    return;
                }
                
                // 检查是否有重复的key
                const keys = validTypes.map(type => type.key);
                const uniqueKeys = [...new Set(keys)];
                if (keys.length !== uniqueKeys.length) {
                    this.showMessage('举报类型标识不能重复', 'error');
                    return;
                }
                
                try {
                    const data = {
                        action: 'xk_auth_save_report_settings',
                        report_types: JSON.stringify(validTypes),
                        sender_name: this.reportSettingsForm.senderName,
                        enabled: this.reportSettingsForm.enabled,
                        email_notification: this.reportSettingsForm.emailNotification
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        this.showMessage('举报设置保存成功', 'success');
                    } else {
                        this.showMessage(result.msg, 'error');
                    }
                } catch (error) {
                    console.error('保存举报设置失败:', error);
                    this.showMessage('保存举报设置失败: ' + error.message, 'error');
                }
            },
            
            // 加载举报设置
            async loadReportSettings() {
                if (!this.is_authorized) {
                    this.handleUnauthorizedClick();
                    return;
                }
                
                try {
                    const data = {
                        action: 'xk_auth_load_report_settings'
                    };
                    
                    const result = await this.handleAjaxRequest(ajaxurl, data);
                    
                    if (!result.error) {
                        if (typeof result.enabled !== 'undefined') {
                            this.reportSettingsForm.enabled = result.enabled;
                        }
                        if (typeof result.emailNotification !== 'undefined') {
                            this.reportSettingsForm.emailNotification = result.emailNotification;
                        }
                        if (result.reportTypes) {
                            this.reportSettingsForm.reportTypes = result.reportTypes;
                        }
                        if (result.senderName) {
                            this.reportSettingsForm.senderName = result.senderName;
                        }
                        if (typeof result.frontendAuthEnabled !== 'undefined') {
                            this.frontendAuthEnabled = result.frontendAuthEnabled;
                        }
                    } else {
                        // 使用默认设置
                        this.reportSettingsForm.enabled = true;
                        this.reportSettingsForm.emailNotification = true;
                        this.reportSettingsForm.senderName = '星空授权';
                        this.reportSettingsForm.reportTypes = [
                            { key: 'piracy', label: '盗版使用' },
                            { key: 'unauthorized', label: '未授权使用' },
                            { key: 'fake', label: '假冒产品' },
                            { key: 'other', label: '其他问题' }
                        ];
                        this.frontendAuthEnabled = true;
                    }
                } catch (error) {
                    console.error('加载举报设置失败:', error);
                    // 使用默认设置
                    this.reportSettingsForm.enabled = true;
                    this.reportSettingsForm.emailNotification = true;
                    this.reportSettingsForm.senderName = '星空授权';
                    this.reportSettingsForm.reportTypes = [
                        { key: 'piracy', label: '盗版使用' },
                        { key: 'unauthorized', label: '未授权使用' },
                        { key: 'fake', label: '假冒产品' },
                        { key: 'other', label: '其他问题' }
                    ];
                    this.frontendAuthEnabled = true;
                }
            },
        },
        mounted() {
            // 移除加载遮罩
            setTimeout(() => {
                document.querySelector('.shop-page-loading').style.display = 'none';
            }, 100);
            
            // 加载前端授权管理功能设置
            this.loadReportSettings();
            
            // 加载用户列表和授权用户列表
            this.getUsers();
            this.getAuthorizedUsers();
            
            // 初始加载时初始化图表
            if (this.$route.path === '/') {
                // 延迟执行，确保DOM已渲染
                setTimeout(() => {
                    initCharts();
                }, 100);
            } else if (this.$route.path === '/log') {
                // 如果初始路径是日志页面，自动刷新当前标签页的日志数据
                this.refreshCurrentTabLogs();
            } else if (this.$route.path === '/auth') {
                // 如果初始路径是授权管理页面，获取产品列表
                this.getProducts();
            } else if (this.$route.path === '/promo') {
                // 如果初始路径是优惠码页面，获取优惠码列表
                this.getPromoCodes();
            } else if (this.$route.path === '/report') {
                // 如果初始路径是举报管理页面，刷新举报列表和加载设置
                this.refreshReportsList();
                this.loadReportSettings();
            }
        },
        watch: {
            // 监听路由变化，当切换到仪表盘时重新初始化图表
            '$route.path'(newPath) {
                // 加载前端授权管理功能设置
                this.loadReportSettings();
                
                // 加载用户列表和授权用户列表
                this.getUsers();
                this.getAuthorizedUsers();
                
                if (newPath === '/') {
                    // 延迟执行，确保DOM已渲染
                    setTimeout(() => {
                        initCharts();
                    }, 100);
                } else if (newPath === '/log') {
                    // 切换到日志页面时，自动刷新当前标签页的日志数据
                    this.refreshCurrentTabLogs();
                } else if (newPath === '/auth') {
                    // 切换到授权管理页面时，获取产品列表
                    this.getProducts();
                } else if (newPath === '/promo') {
                    // 切换到优惠码页面时，获取优惠码列表
                    this.getPromoCodes();
                } else if (newPath === '/report') {
                    // 切换到举报管理页面时，刷新举报列表和加载设置
                    this.refreshReportsList();
                    this.loadReportSettings();
                }
            },
            // 监听标签页变化，自动刷新对应标签页的日志数据
            activeTab(newTab) {
                if (this.$route.path === '/log') {
                    this.refreshCurrentTabLogs();
                }
            }
        }
    };
    
    // 创建路由实例
    const router = createRouter({
        history: createWebHashHistory(),
        routes: [
            { path: '/', component: { template: '<div></div>' } },
            { path: '/auth', component: { template: '<div></div>' } },
            { path: '/log', component: { template: '<div></div>' } },
            { path: '/update', component: { template: '<div></div>' } },
            { path: '/promo', component: { template: '<div></div>' } },
            { path: '/report', component: { template: '<div></div>' } },
        ],
    });
    
    // 创建并挂载Vue应用
    const app = createApp(App);
    app.use(ElementPlus, {
        locale: ElementPlusLocaleZhCn,
    });
    app.use(router);
    
    // 将应用实例保存到window对象，方便外部访问
    window.xkAuthApp = app;
    
    app.mount('#xk_auth_app');
</script>
