<?php
/*
 * @Project Name: 允梦授权插件
 * @Project URI: https://www.mengdo.cn/
 * @Author: YunMen Net
 * @Author URI: https://www.mengdo.cn/
 * @Date: 2025-07-13 22:31:56
 * @LastEditors: YunMen Net
 * @LastEditTime: 2025-07-13 23:18:53
 * @Description: 感谢您使用允梦授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * 用户中心-产品管理页面
 * 显示产品选择、订单信息及下载/导入功能
 */
function xk_auth_main_user_tab_content_agent()
{
    // 获取当前用户ID，未登录则直接返回
    $user = wp_get_current_user();
    $user_id = isset($user->ID) ? (int) $user->ID : 0;
    if (!$user_id) {
        return;
    }
    // 获取产品ID
    $product_id = '';

    // 优先从GET参数获取（用于AJAX请求）
    if (isset($_GET['product_id'])) {
        $product_id = sanitize_text_field($_GET['product_id']);

        // 检查是否为数字
        if (!is_numeric($product_id)) {
            $product_id = '';
            $error_message = '选择的产品ID无效，请重新选择';
        }
    }
    // 其次从POST参数获取（保持兼容性）
    elseif (isset($_POST['product_id'])) {
        $product_id = sanitize_text_field($_POST['product_id']);

        // 检查是否为数字
        if (!is_numeric($product_id)) {
            $product_id = '';
            $error_message = '选择的产品ID无效，请重新选择';
        }
    }
    // 最后从默认设置获取
    elseif (!empty(xk_auth('default_product_id'))) {
        $product_id = xk_auth('default_product_id');
    }

    // 初始化页面HTML
    $html = '';

    // 产品选择区域 - 横向排列可点击切换
    $html .= '
        <style>
            .product-tabs {
                display: flex;
                overflow-x: auto;
                padding: 10px 0;
                margin-bottom: 20px;
                scrollbar-width: thin;
                scrollbar-color: var(--main-color) var(--main-bg-color);
                list-style: none;
                margin: 0;
                padding: 0;
            }
            .product-tabs::-webkit-scrollbar {
                height: 6px;
            }
            .product-tabs::-webkit-scrollbar-track {
                background: var(--main-bg-color);
            }
            .product-tabs::-webkit-scrollbar-thumb {
                background: var(--main-color);
                border-radius: 3px;
            }
            .product-tab {
                flex: 0 0 auto;
                padding: 10px 20px;
                margin-right: 10px;
                background: var(--light-bg-color);
                border: 1px solid var(--border-color);
                border-radius: var(--main-radius);
                cursor: pointer;
                transition: all 0.3s ease;
                white-space: nowrap;
            }
            .product-tab:hover {
                background: var(--main-color);
                color: white;
                border-color: var(--main-color);
            }
            .product-tab.active {
                background: var(--main-color);
                color: white;
                border-color: var(--main-color);
            }
            .men {
                height: auto;
                margin-right: 8px;
                width: 100%;
                display: block;
            }
            @media (max-width:640px) {
                .men {
                    height: auto;
                    width: 100%;
                    display: block;
                }
            }
            .mens {
                height: auto;
                margin-left: 0;
                margin-top: 20px;
                width: 100%;
                display: block;
            }
            @media (max-width:640px) {
                .mens {
                    height: auto;
                    width: 100%;
                    display: block;
                }
            }
        </style>
        <div class="zib-widget pay-box men">
            <div class="pay-tag abs-center" style="right: auto;left: 0;border-radius: var(--main-radius) 0 var(--main-radius) 0;">选择产品</div>
            <div class="mt20">
                <div class="product-tabs" id="product-tabs">
                    '; 
    // 获取所有产品
    $products = xk_auth('product_settings', array());
    foreach ($products as $product) {
        $current_product_id = isset($product['product_id']) ? $product['product_id'] : '';
        $product_name = isset($product['product_name']) ? $product['product_name'] : '未命名产品';
        $is_active = (!empty($product_id) && $current_product_id == $product_id) ? 'active' : '';
        $active_attr = $is_active ? ' href="javascript:;"' : ' ajax-replace="true" href="' . esc_url(add_query_arg('product_id', $current_product_id)) . '"';
        $html .= '<a' . $active_attr . ' class="product-tab ' . $is_active . '" data-product-id="' . esc_attr($current_product_id) . '">' . esc_html($product_name) . '</a>';
    }
    $html .= '                </div>
            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // 产品标签点击事件
                $("#product-tabs .product-tab").on("click", function(e) {
                    if (!$(this).hasClass("active")) {
                        // 首先移除所有标签的active类
                        $("#product-tabs .product-tab").removeClass("active");
                        // 立即为当前点击的标签添加active类，确保视觉反馈
                        $(this).addClass("active");
                    }
                });
            });
        </script>
    ';

    // 获取订单信息
    $order_info = xk_auth_product_order_date('', $product_id);

    // 显示订单信息或购买提示
    if (!empty($order_info)) {
        global $post;
        $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);
        $pay_price = $pay_mate['pay_original_price'];

        $html .= '
            <div class="zib-widget pay-box mens" win-ajax-replace="true">
                <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>
                <div>
                    <div class="mb10"><b><a target="_blank" href="' . get_permalink($product_id) . '">' . (!empty(men_get_product_title($product_id)) ? men_get_product_title($product_id) : '未知的产品') . '</a></b></div>
                    <div class="meta-time em09 muted-2-color mb6">付款时间：' . $order_info[0]['pay_time'] . '</div>
                    <div class="meta-time em09 muted-2-color" title="点击复制订单号" data-clipboard-text="' . $order_info[0]['order_num'] . '" data-clipboard-tag="订单号">订单号：<i class="fa fa-files-o mr3"></i>' . $order_info[0]['order_num'] . '</div>
                    <div class="meta-time em09 muted-2-color"><span class="em12"><span class="pay-mark">价格：￥</span>' . $pay_price . '<span class="pay-mark ml10">实付金额：</span><span class="pay-mark">￥</span>' . $order_info[0]['order_price'] . '</span></div>
                </div>
            </div>
        ';
    } else {
        // 用户未购买，显示购买提示
        $product_link = ($product_id > 0) ? esc_url(get_permalink($product_id)) : '';
        $product_target = ($product_id > 0) ? 'target="_blank"' : '';
        $product_name = ($product_id > 0) ? get_the_title($product_id) : '未知产品';
        $ajax_url = esc_js(admin_url('admin-ajax.php'));

        $html .= '
    <div class="zib-widget pay-box mens" win-ajax-replace="true">
        <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>
        <div>
            <div class="mb10">
                <b>
                    <a ' . $product_target . ' href="' . $product_link . '">
                        ' . esc_html($product_name) . '
                    </a>
                </b>
            </div>
            <p>
                <div class="meta-time em09 muted-2-color mb10">当前您还未购买此产品，请先购买后再来管理您的授权吧</div>
                <div class="text-center mb10">
                    <a class="but c-blue padding-lg" href="' . esc_url(get_permalink($product_id)) . '">
                        <i class="fa fa-cart-plus fa-fw" aria-hidden="true"></i> 购买授权
                    </a>
                </div>
                <div class="meta-time em09 muted-2-color mb10">或者使用卡密获取授权：</div>
                <div class="text-center">
                    <div class="zib-widget pay-box" style="max-width: 400px; margin: 0 auto;">
                        <div class="mt10 mb10">
                            <input type="text" id="card_code" placeholder="请输入卡密" class="form-control">
                        </div>
                        <div class="mt10 mb10">
                            <input type="text" id="auth_domain" placeholder="请输入要授权的域名" class="form-control">
                        </div>
                        <div class="text-center">
                            <button type="button" class="but c-green padding-lg" onclick="xk_auth_use_card()">
                                <i class="fa fa-key fa-fw" aria-hidden="true"></i> 使用卡密
                            </button>
                        </div>
                        <div id="card_result" class="mt10 text-center"></div>
                    </div>
                </div>
            </p>
            <script type="text/javascript">
            // 定义ajaxurl变量
            var ajaxurl = "' . $ajax_url . '";
            var currentProductId = ' . $product_id . ';
            
            function xk_auth_use_card() {
                var card_code = document.getElementById("card_code").value;
                var auth_domain = document.getElementById("auth_domain").value;
                
                if (!card_code) {
                    notyf("请输入卡密", "danger");
                    return;
                }
                
                if (!auth_domain) {
                    notyf("请输入要授权的域名", "danger");
                    return;
                }
                
                // 显示加载状态
                notyf("正在验证卡密，请稍候...", "info");
                
                fetch(ajaxurl, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: "action=xk_auth_use_card&card_code=" + encodeURIComponent(card_code) + "&product_id=" + currentProductId + "&auth_domain=" + encodeURIComponent(auth_domain)
                })
                .then(response => response.json())
                .then(data => {
                    // 处理Zibll主题的错误格式
                    if (data.error) {
                        notyf(data.msg || "操作失败", data.ys || "danger");
                    } 
                    // 处理WordPress的成功格式
                    else if (data.success) {
                        notyf(data.data.message || "操作成功", "success");
                        // 刷新页面
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } 
                    // 处理其他情况
                    else {
                        notyf(data.msg || data.data.message || "未知错误", "danger");
                    }
                })
                .catch(error => {
                    notyf("发生错误：" + error.message, "danger");
                });
            }
            </script>
        </div>
    </div>
';
    }
    return zib_get_ajax_ajaxpager_one_centent($html);
}
add_filter('main_user_tab_content_agent', 'xk_auth_main_user_tab_content_agent');