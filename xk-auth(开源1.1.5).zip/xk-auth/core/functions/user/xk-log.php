<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * 用户中心-产品管理页面
 * 显示产品选择、订单信息及下载/导入功能
 */
function xk_auth_main_user_tab_content_log()
{
    // 获取当前用户ID，未登录则直接返回
    $user = wp_get_current_user();
    $user_id = isset($user->ID) ? (int) $user->ID : 0;
    if (!$user_id) {
        return;
    }
    // 获取产品ID
    $product_id = '';

    // 优先从GET参数获取（用于AJAX请求）
    if (isset($_GET['product_id'])) {
        $product_id = sanitize_text_field($_GET['product_id']);

        // 检查是否为数字
        if (!is_numeric($product_id)) {
            $product_id = '';
            $error_message = '选择的产品ID无效，请重新选择';
        }
    }
    // 其次从POST参数获取（保持兼容性）
    elseif (isset($_POST['product_id'])) {
        $product_id = sanitize_text_field($_POST['product_id']);

        // 检查是否为数字
        if (!is_numeric($product_id)) {
            $product_id = '';
            $error_message = '选择的产品ID无效，请重新选择';
        }
    }
    // 最后从默认设置获取
    elseif (!empty(xk_auth('default_product_id'))) {
        $product_id = xk_auth('default_product_id');
    }

    // 初始化页面HTML
    $html = '';
    // 产品选择区域 - 横向排列可点击切换
    $html .= '
        <style>
            .product-tabs {
                list-style: none;
                margin-top: 20px;
                display: flex;
                overflow-x: auto;
                margin-bottom: -20px;
                scrollbar-width: thin;
                scrollbar-color: transparent transparent;
                -ms-overflow-style: none;
                position: relative;
                z-index: 1;
                padding: 10px;
                padding-left: 0px;
                flex-wrap: nowrap;
                border-radius: 8px;
                transition: scrollbar-color 0.3s ease;
                -webkit-overflow-scrolling: touch;
                touch-action: pan-x;
            }
            .product-tabs:hover {
                scrollbar-color: #adb5bd transparent;
            }
            .product-tabs::-webkit-scrollbar {
                height: 1px;
            }
            .product-tabs::-webkit-scrollbar-track {
                background: transparent;
                transition: background 0.3s ease;
            }
            .product-tabs:hover::-webkit-scrollbar-track {
                background: transparent;
            }
            .product-tabs::-webkit-scrollbar-thumb {
                background: transparent;
                border-radius: 0.5px;
                transition: background 0.3s ease;
            }
            .product-tabs:hover::-webkit-scrollbar-thumb {
                background: #adb5bd;
            }
            .product-tabs::-webkit-scrollbar-thumb:hover {
                background: #6c757d;
            }
            
            /* 移动端箭头导航 */
            .product-tabs-container {
                margin-top: -27px;
                margin-bottom: -20px;
            }
            .product-tabs-nav {
                display: none !important;
            }
            @media (max-width: 768px) {
                .product-tabs-container {
                    position: relative;
                }
                .product-tabs-nav {
                    display: flex !important;
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    width: 30px;
                    height: 30px;
                    background: white;
                    border: 1px solid #e9ecef;
                    border-radius: 50%;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    z-index: 10;
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
                    transition: all 0.2s ease;
                }
                .product-tabs-nav:hover {
                    background: #f8f9fa;
                    transform: translateY(-50%) scale(1.05);
                }
                .product-tabs-nav.prev {
                    left: 0;
                }
                .product-tabs-nav.next {
                    right: 0;
                }
                .product-tabs-nav i {
                    font-size: 14px;
                    color: #495057;
                }
                /* 暗模式适配 */
                .dark-theme .product-tabs-nav {
                    background: rgba(255, 255, 255, 0.1);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
                }
                .dark-theme .product-tabs-nav:hover {
                    background: rgba(255, 255, 255, 0.15);
                    border-color: rgba(255, 255, 255, 0.3);
                }
                .dark-theme .product-tabs-nav i {
                    color: var(--text-color, #ffffff);
                }
            }
            .product-tab {
                flex: 0 0 auto;
                padding: 4px 12px;
                margin-right: 8px;
                background: #f8f9fa;
                border: 1px solid #e9ecef;
                border-radius: 4px;
                cursor: pointer;
                transition: all 0.2s ease;
                white-space: nowrap;
                font-weight: 400;
                font-size: 14px;
                color: #495057;
                position: relative;
            }
            .product-tab:hover {
                background: #e9ecef;
                border-color: #dee2e6;
                color: #212529;
                transform: translateY(-1px);
            }
            .product-tab.active {
                background: var(--main-color);
                border-color: var(--main-color);
                color: white;
                font-weight: 500;
                transform: translateY(-1px);
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            }
            .dark-theme .product-tab {
                background: rgba(255, 255, 255, 0.1);
                color: var(--text-color, #ffffff);
                border-color: rgba(255, 255, 255, 0.2);
            }
            .dark-theme .product-tab:hover {
                background: rgba(255, 255, 255, 0.15);
                border-color: rgba(255, 255, 255, 0.3);
            }
            .dark-theme .product-tab.active {
                background: #5a6c7f;
                color: #ffffff;
                border-color: #5a6c7f;
            }
            /* 增强的点击动画 */
            .product-tab.click-animation {
                transform: scale(0.95);
                transition: transform 0.15s ease;
            }
            /* 响应式优化 */
            @media (max-width: 768px) {
                .product-tab {
                    padding: 6px 12px;
                    margin-right: 6px;
                    font-size: 13px;
                    border-radius: 4px;
                }
            }
            @media (max-width: 480px) {
                .product-tab {
                    padding: 5px 10px;
                    margin-right: 4px;
                    font-size: 12px;
                    border-radius: 4px;
                }
            }
            .men {
                height: auto;
                margin-right: 8px;
                width: 100%;
                display: block;
            }
            @media (max-width:640px) {
                .men {
                    height: auto;
                    width: 100%;
                    display: block;
                }
            }
            .mens {
                height: auto;
                margin-left: 0;
                margin-top: 20px;
                width: 100%;
                display: block;
            }
            @media (max-width:640px) {
                .mens {
                    height: auto;
                    width: 100%;
                    display: block;
                }
            }
            .log-table th {
                padding: 8px 10px;
                text-align: left;
                background: #f9f9f9;
            }
            .log-table td {
                padding: 8px 10px;
                border-top: 1px solid #eee;
            }
            .dark-theme .log-table th {
                background: #323335;
            }
        </style>
        <div class="product-tabs-container">
            <div class="product-tabs-nav prev" id="product-tabs-prev">
                <i class="fa fa-chevron-left"></i>
            </div>
            <div class="product-tabs-nav next" id="product-tabs-next">
                <i class="fa fa-chevron-right"></i>
            </div>
            <div class="product-tabs" id="product-tabs">
                    '; 
    // 获取所有产品
    $products = xk_auth('product_settings', array());
    if (!empty($products)) {
        foreach ($products as $product) {
            $current_product_id = isset($product['product_id']) ? $product['product_id'] : '';
            $product_name = isset($product['product_name']) ? $product['product_name'] : '未命名产品';
            $is_active = (!empty($product_id) && $current_product_id == $product_id) ? 'active' : '';
            $active_attr = $is_active ? ' href="javascript:;"' : ' ajax-replace="true" href="' . esc_url(add_query_arg('product_id', $current_product_id)) . '"';
            $html .= '<a' . $active_attr . ' class="product-tab ' . $is_active . '" data-product-id="' . esc_attr($current_product_id) . '" title="' . esc_html($product_name) . '">
                            ' . esc_html($product_name) . '
                        </a>';
        }
    } else {
        $html .= '<div class="text-center text-muted py4 px10 w-full">暂无可用产品</div>';
    }
$html .= '            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // 产品标签点击事件
                $("#product-tabs .product-tab").on("click", function(e) {
                    if (!$(this).hasClass("active")) {
                        // 添加点击动画效果
                        $(this).addClass("click-animation");
                        
                        // 首先移除所有标签的active类
                        $("#product-tabs .product-tab").removeClass("active");
                        
                        // 延迟添加active类以增强视觉效果
                        setTimeout(function() {
                            $(this).addClass("active");
                        }.bind(this), 150);
                        
                        // 移除点击动画
                        setTimeout(function() {
                            $(this).removeClass("click-animation");
                        }.bind(this), 300);
                    }
                });
                
                // 添加点击动画样式
                $("<style>", { text: ".product-tab.click-animation { transform: scale(0.95); transition: transform 0.15s ease; }" }).appendTo("head");
                
                // 产品标签导航功能
                $("#product-tabs-prev").on("click", function() {
                    $("#product-tabs").animate({ scrollLeft: "-=200" }, 300);
                });
                
                $("#product-tabs-next").on("click", function() {
                    $("#product-tabs").animate({ scrollLeft: "+=200" }, 300);
                });
                
                // 隐藏/显示导航按钮
                function toggleNavButtons() {
                    var tabs = $("#product-tabs");
                    var prevBtn = $("#product-tabs-prev");
                    var nextBtn = $("#product-tabs-next");
                    
                    if (tabs.scrollLeft() > 0) {
                        prevBtn.fadeIn();
                    } else {
                        prevBtn.fadeOut();
                    }
                    
                    if (tabs.scrollLeft() < (tabs[0].scrollWidth - tabs.innerWidth())) {
                        nextBtn.fadeIn();
                    } else {
                        nextBtn.fadeOut();
                    }
                }
                
                // 初始化导航按钮状态
                toggleNavButtons();
                
                // 滚动时更新导航按钮状态
                $("#product-tabs").on("scroll", toggleNavButtons);
            });
        </script>
    ';

    $html .= '            <div class="zib-widget pay-box mens" win-ajax-replace="true">
        <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>
        <div>
            <div class="mb10">
                <b>
                </b>
            </div>
            <p>
                <div class="meta-time em09 muted-2-color mb10">如果您未购买过此产品，请点击下方链接完成购买。若您购买后未绑定域名，请联系客服处理。</div>
                <div class="text-center">
                    <a class="but c-blue padding-lg" href="' . esc_url(get_permalink($product_id)) . '">
                        <i class="fa fa-cart-plus fa-fw" aria-hidden="true"></i> 购买授权
                    </a>
                </div>
            </p>
        </div>
    </div>
        ';


    // 初始化变量为false
    $has_auth = false;
    
    // 检查用户是否有该产品的授权记录
    if (!empty($product_id)) {
        global $wpdb;
        $auth_table = $wpdb->prefix . 'product_auths';

        $auths = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $auth_table 
                WHERE product_id = %d 
                AND user_id = %d 
                ORDER BY id DESC",
                $product_id,
                $user_id
            ),
            ARRAY_A
        );

        $has_auth = !empty($auths);
    }

    // 根据授权记录情况显示内容
    if ($has_auth) {
        $html .= '
        <div class="zib-widget pay-box">
                    <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">授权信息</div>
                <div class="box-body">
                    <div class="c-red mb10"><i class="fa fa-diamond em12 mr10"></i><b>授权信息</b></div>
                    <div class="muted-2-color em09">
                       下方会显示您拥有的此产品的授权信息，如授权日志丢失可在此处获取授权码导入授权
                    </div>
                </div>';

        $html .= '
                    <div class="mb10">
                        <div class="author-set-left">授权有效期</div>
                        <div class="author-set-right"><span class="badg">点击授权中心的时间查询查看</span></div>
                    </div>
                    <div class="mb10">
                        <div class="author-set-left">验证类型</div>
                        <div class="author-set-right"><span class="badg">授权码+域名验证</span></div>
                    </div>
                    <div class="mb10">
                        <div class="author-set-left">授权域名</div>
                    </div>
                    <div class="mb10 text-center">
                        ' . xk_auth_for_product_domain('', $product_id) . '
                    </div>
                                </div>
        </div>
                ';

        global $wpdb;
        $log_table = $wpdb->prefix . 'auth_logs';

        // 查询该产品的授权日志
        $logs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $log_table 
                WHERE product_id = %d 
                AND user_id = %d 
                ORDER BY operation_time DESC",
                $product_id,
                $user_id
            ),
            ARRAY_A
        );

        $html .= '
        <div class="zib-widget pay-box">
            <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">授权日志</div>
            <div class="box-body">
                <div class="c-red mb10"><i class="fa fa-history em12 mr10"></i><b>授权操作日志</b></div>
                <div class="muted-2-color em09 mb10">
                   以下是您对此产品授权操作的所有日志记录
                </div>';

        if (empty($logs)) {
            $html .= '
            <div class="text-center p-10 text-muted">
                <i class="fa fa-info-circle em2x mb5"></i>
                <p>暂无授权操作日志记录</p>
            </div>';
        } else {
            $html .= '
            <div class="overflow-x-auto">
                <table class="log-table w-full">
                    <thead>
                        <tr>
                            <th>操作时间</th>
                            <th>全部授权数</th>
                            <th>剩余授权数</th>
                            <th>操作详情</th>
                        </tr>
                    </thead>
                    <tbody>';

            foreach ($logs as $log) {
                $html .= '
                <tr>
                    <td>' . esc_html($log['operation_time']) . '</td>
                    <td>' . esc_html($log['total_auths']) . '</td>
                    <td>' . esc_html($log['remaining_auths']) . '</td>
                    <td>' . esc_html($log['other_operations']) . '</td>
                </tr>';
            }

            $html .= '
                    </tbody>
                </table>
            </div>
            <div class="mt10 text-sm text-muted">
                共 ' . count($logs) . ' 条记录
            </div>';
        }
    } else {
        $html .= '
        <div class="zib-widget pay-box">
            <div class="text-center p-10 text-muted">
                <i class="fa fa-info-circle em2x mb5"></i>
                <p>暂无授权操作日志记录</p>
            </div>
        </div>';
    }
    return zib_get_ajax_ajaxpager_one_centent($html);
}
add_filter('main_user_tab_content_log', 'xk_auth_main_user_tab_content_log');

/**
 * 日志查询表单函数 - 用于AJAX请求
 * 提供日志查询的模态框表单界面
 */
function admin_add_ajax_log()
{
    $header = zib_get_modal_colorful_header('modal-colorful-header colorful-bg c-blue', '<i class="csf-tab-icon fa fa-fw fa-history"></i>', '授权日志查询');

    $tab_content = '
    <form class="bbs-modal-form">' . $header . '<div>
    <span class="violations_name"></span>
        <ul class="muted-2-color theme-box">
            <li class="c-red"><i class="fa fa-info-circle mr6"></i>选择产品后查看授权操作日志</li>
        </ul>
        <div class="mb6">
            <div class="muted-color mb6">选择应用</div>
            <div class="flex ac">
                <select name="app_id" id="appIdSelect" class="form-control mr10">
                    ' . xk_auth_product_option() . '
                </select>
            </div>
        </div>
        <input type="hidden" name="action" value="add_auth_log">
        <div class="box-body text-center nobottom">
            <button class="but jb-red radius btn-block padding-lg wp-ajax-submit">
                <i class="fa fa-search" aria-hidden="true"></i>查询日志
            </button>
        </div>
    </form>';

    $tab = '<div class="padding-w10 nop-sm"><div class="tab-content">' . $tab_content . '</div></div>';
    return zib_get_ajax_ajaxpager_one_centent($tab);
}
