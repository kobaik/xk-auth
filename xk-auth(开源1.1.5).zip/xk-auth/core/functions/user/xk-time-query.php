<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * 生成授权时间查询按钮
 * 点击后弹出授权时间查询弹窗
 * 
 * @param array $args 按钮参数
 * @return string 按钮HTML代码
 */
function xk_auth_time_query_button($args = array()) {
    $defaults = array(
        'id' => 'xk-auth-time-query-btn',
        'class' => 'button button-primary',
        'text' => '查询授权时间',
        'style' => '',
    );
    
    $args = wp_parse_args($args, $defaults);
    
    ob_start();
    ?>
    <button 
        id="<?php echo esc_attr($args['id']); ?>"
        class="<?php echo esc_attr($args['class']); ?> xk-auth-time-query-button"
        style="<?php echo esc_attr($args['style']); ?>"
        data-action="xk_auth_time_query"
    >
        <?php echo esc_html($args['text']); ?>
    </button>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $(document).on('click', '.xk-auth-time-query-button', function(e) {
            e.preventDefault();
            
            // 使用现有的admin_add_ajax_time_auth函数获取弹窗内容
            $.ajax({
                url: ajaxurl,
                type: 'post',
                data: {
                    action: 'xk_get_time_auth_modal'
                },
                success: function(response) {
                    // 创建模态框
                    var modal = $(response);
                    $('body').append(modal);
                    
                    // 显示模态框
                    modal.show();
                    
                    // 添加关闭事件
                    modal.on('click', '.modal-close, .modal-backdrop', function() {
                        modal.remove();
                    });
                    
                    // 处理表单提交
                    modal.on('submit', 'form', function(e) {
                        e.preventDefault();
                        var form = $(this);
                        
                        $.ajax({
                            url: ajaxurl,
                            type: 'post',
                            data: form.serialize(),
                            beforeSend: function() {
                                form.find('button[type="submit"]').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> 查询中...');
                            },
                            success: function(response) {
                                if (response.success) {
                                    alert(response.data.msg);
                                    modal.remove();
                                } else {
                                    alert(response.data.msg);
                                }
                            },
                            complete: function() {
                                form.find('button[type="submit"]').prop('disabled', false).html('<i class="fa fa-check" aria-hidden="true"></i> 确认查询');
                            }
                        });
                    });
                }
            });
        });
    });
    </script>
    <?php
    
    return ob_get_clean();
}

/**
 * AJAX处理函数，用于获取授权时间查询弹窗内容
 */
function xk_get_time_auth_modal() {
    // 检查用户权限
    if (!current_user_can('manage_options')) {
        wp_die('没有权限访问此功能');
    }
    
    // 获取弹窗内容
    $modal_content = admin_add_ajax_time_auth();
    
    // 包装成完整的模态框
    $modal = '<div class="modal-backdrop in" style="display: none;">
        <div class="modal" style="display: none; width: 600px; max-width: 90%; margin: 10% auto;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <button type="button" class="modal-close" style="position: absolute; top: 10px; right: 10px; z-index: 1000; background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                    ' . $modal_content . '
                </div>
            </div>
        </div>
    </div>';
    
    echo $modal;
    wp_die();
}
add_action('wp_ajax_xk_get_time_auth_modal', 'xk_get_time_auth_modal');

function admin_add_ajax_time_auth()
{
    $header = zib_get_modal_colorful_header('modal-colorful-header colorful-bg c-blue', '<i class="csf-tab-icon fa fa-fw fa-clock-o"></i>', '授权时间查询');
    // 获取当前网站域名
    $site_domain = parse_url(home_url(), PHP_URL_HOST);

    $tab_content = '
    <form class="bbs-modal-form">' . $header . '<div>
    <span class="violations_name"></span>
        <ul class="muted-2-color theme-box">
            <li class="c-red"><i class="fa fa-info-circle mr6"></i>输入需要查询授权时间的完整域名</li>
        </ul>
        <div class="mb6">
            <div class="muted-color mb6">选择应用</div>
            <div class="flex ac">
                <select name="app_id" id="timeAppIdSelect" class="form-control mr10">
                    ' . xk_auth_product_option() . '
                </select>
            </div>
        </div>
        <div class="active" data-for="product" data-value="custom">
            <div class="mb6">
                <div class="muted-color mb6">查询域名:</div>
                <div class="flex ac">
                    <input type="text" tabindex="1" value="" id="timeDomainInput" name="domain" class="form-control mr10" placeholder="' . $site_domain . '">
                </div>
            </div>
        </div>
        <input type="hidden" name="action" value="add_time_auth">
        <div class="box-body text-center nobottom">
            <button class="but jb-red radius btn-block padding-lg wp-ajax-submit" style="overflow: hidden; position: relative;">
                <i class="fa fa-check" aria-hidden="true"></i>确认查询
                <div style="display: block; background: rgb(255, 255, 255); border-radius: 50%; position: absolute; transform: scale(1); opacity: 0; transition: all 1.5s cubic-bezier(0.22, 0.61, 0.36, 1) 0s; z-index: 1; overflow: hidden; pointer-events: none; width: 1040px; height: 1040px; top: -504.703px; left: -247.5px;"></div>
            </button>
        </div>
    </form>';

    $tab = '<div class="padding-w10 nop-sm"><div class="tab-content">' . $tab_content . '</div></div>';
    return zib_get_ajax_ajaxpager_one_centent($tab);
}

//处理授权时间查询
function add_ajax_time_admin()
{
    $domain = isset($_POST['domain']) ? sanitize_text_field($_POST['domain']) : '';
    $app_id = isset($_POST['app_id']) ? sanitize_text_field($_POST['app_id']) : '';

    if (!$domain) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请输入要查询的域名'));
    }

    if ($app_id == 'none' || !$app_id) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请选择要查询的应用'));
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    // 查询授权信息，包括过期时间和状态
    $sql = $wpdb->prepare(
        "SELECT * FROM $table_name WHERE product_id = %s AND domain = %s",
        $app_id, $domain
    );

    $results = $wpdb->get_results($sql);

    if ($results && isset($results[0])) {
        $auth_info = $results[0];
        $current_time = current_time('mysql');
        
        // 先检查是否已过期（与后台逻辑保持一致）
        $is_expired = false;
        if (!empty($auth_info->expire_time) && $auth_info->expire_time != '0000-00-00 00:00:00') {
            $is_expired = strtotime($auth_info->expire_time) < strtotime($current_time);
        }
        
        // 检查是否被封禁
        $is_banned = isset($auth_info->status) && $auth_info->status != 1;
        
        // 优先判断过期状态
        if ($is_expired) {
            // 已过期状态
            $expire_date = date('Y-m-d', strtotime($auth_info->expire_time));
            $msg = '您查询的 ' . esc_html($domain) . ' 到期时间：' . esc_html($expire_date) . ' 授权状态：已过期';
        } else if ($is_banned) {
            // 未过期但被封禁
            $msg = '您查询的 ' . esc_html($domain) . ' 授权状态：已封禁';
        } else {
            // 格式化授权时间信息
            if (!empty($auth_info->expire_time) && $auth_info->expire_time != '0000-00-00 00:00:00') {
                $expire_date = date('Y-m-d', strtotime($auth_info->expire_time));
                $msg = '您查询的 ' . esc_html($domain) . ' 到期时间：' . esc_html($expire_date) . ' 授权状态：有效';
            } else {
                // 永久授权
                $msg = '您查询的 ' . esc_html($domain) . ' 到期时间：永久有效';
            }
        }
        
        zib_send_json_success(array('msg' => $msg));
    } else {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '未找到该域名的授权信息'));
    }

    exit;
}
add_action('wp_ajax_add_time_auth', 'add_ajax_time_admin');
