<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

function admin_add_ajax_aut()
{
    $header = zib_get_modal_colorful_header('modal-colorful-header colorful-bg c-blue', '<i class="csf-tab-icon fa fa-fw fa-gitlab"></i>', '正版查询');
    // 获取当前网站域名
    $site_domain = parse_url(home_url(), PHP_URL_HOST);

    $tab_content = '
    <form class="bbs-modal-form">' . $header . '<div>
    <span class="violations_name"></span>
        <ul class="muted-2-color theme-box">
            <li class="c-red"><i class="fa fa-info-circle mr6"></i>输入需要查询正版的的完整域名</li>
        </ul>
        <div class="mb6">
            <div class="muted-color mb6">选择应用</div>
            <div class="flex ac">
                <select name="app_id" id="appIdSelect" class="form-control mr10">
                    ' . xk_auth_product_option() . '
                </select>
            </div>
        </div>
        <div class="active" data-for="product" data-value="custom">
            <div class="mb6">
                <div class="muted-color mb6">查询域名:</div>
                <div class="flex ac">
                    <input type="text" tabindex="1" value="" id="domainInput" name="domain" class="form-control mr10" placeholder="' . $site_domain . '">
                </div>
            </div>
        </div>
        <input type="hidden" name="action" value="add_auth">
        <div class="box-body text-center nobottom">
            <button class="but jb-red radius btn-block padding-lg wp-ajax-submit" style="overflow: hidden; position: relative;">
                <i class="fa fa-check" aria-hidden="true"></i>确认提交
                <div style="display: block; background: rgb(255, 255, 255); border-radius: 50%; position: absolute; transform: scale(1); opacity: 0; transition: all 1.5s cubic-bezier(0.22, 0.61, 0.36, 1) 0s; z-index: 1; overflow: hidden; pointer-events: none; width: 1040px; height: 1040px; top: -504.703px; left: -247.5px;"></div>
            </button>
        </div>
    </form>';

    $tab = '<div class="padding-w10 nop-sm"><div class="tab-content">' . $tab_content . '</div></div>';
    return zib_get_ajax_ajaxpager_one_centent($tab);
}

//处理查询
function add_ajax_admin()
{
    $domain = $_POST['domain'];
    $app_id = $_POST['app_id'];

    if (!$domain) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请输入要查询的域名'));
    }

    if ($app_id == 'none') {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请选择要查询的应用'));
    }

    if (!$app_id) {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '请选择要查询的应用'));
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE product_id = %d AND domain = %s",
        $app_id, $domain
    ));

    if ($results) {
        zib_send_json_success(array('msg' => '您查询的 ' . esc_html($domain) . ' 为正版授权'));
    } else {
        zib_send_json_error(array('ys' => 'danger', 'msg' => '您查询的' . esc_html($domain) . '为盗版授权'));
    }

    exit;
}
add_action('wp_ajax_add_auth', 'add_ajax_admin');
add_action('wp_ajax_nopriv_add_auth', 'add_ajax_admin');
