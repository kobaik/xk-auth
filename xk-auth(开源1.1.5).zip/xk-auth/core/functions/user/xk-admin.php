<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * @description: 检查API请求频率限制
 * @param string $action 操作类型
 * @param int $limit 限制次数
 * @param int $time_window 时间窗口（秒）
 * @return bool|array 如果请求被限制，返回包含错误信息的数组；否则返回true
 */
function xk_auth_check_admin_api_rate_limit($action = 'default', $limit = 5, $time_window = 60) {
    // 检查是否开启了API请求限制
    $enable_limit = xk_auth('enable_api_rate_limit', false);
    if (!$enable_limit) {
        return true;
    }
    
    // 获取当前用户ID
    $user_id = get_current_user_id();
    if (!$user_id) {
        return true;
    }
    
    // 生成缓存键
    $cache_key = "xk_auth_admin_rate_limit_{$action}_{$user_id}";
    
    // 获取当前请求次数
    $request_count = get_transient($cache_key);
    
    // 如果缓存不存在，初始化计数
    if (false === $request_count) {
        set_transient($cache_key, 1, $time_window);
        return true;
    }
    
    // 检查是否超过限制
    if ($request_count >= $limit) {
        return array('msg' => "请求过于频繁，请在{$time_window}秒后重试");
    }
    
    // 增加计数
    set_transient($cache_key, $request_count + 1, $time_window);
    return true;
}

/**
 * @description: 验证请求来源IP
 * @return bool 是否为有效IP
 */
function xk_auth_validate_request_ip() {
    // 获取客户端IP
    $client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // 检查IP是否有效
    if (empty($client_ip) || !filter_var($client_ip, FILTER_VALIDATE_IP)) {
        return false;
    }
    
    // 可以在这里添加IP白名单或黑名单逻辑
    
    return true;
}

/**
 * @description: 用户中心-管理中心页面
 * @return {*}
 */
function xk_auth_main_user_tab_content_admin() {
    $user_id = get_current_user_id();
    if (!$user_id) {
        return '<div class="zib-widget text-center py20"><p class="c-red">您没有权限访问此页面</p></div>';
    }

    // 检查用户是否有管理权限（管理员或授权用户）
    $is_admin = current_user_can('manage_options');
    $authorized_users = xk_auth('authorized_users', array());
    $is_authorized_user = in_array($user_id, $authorized_users);
    
    if (!$is_admin && !$is_authorized_user) {
        return '<div class="zib-widget text-center py20"><p class="c-red">您没有权限访问此页面</p></div>';
    }

    // 检查前端授权管理功能是否开启
    $frontend_auth_enabled = xk_auth('frontend_auth_enabled', true);
    if (!$frontend_auth_enabled) {
        return '<div class="zib-widget text-center py20"><p class="c-red">前端授权管理功能未开启</p></div>';
    }

    // 初始化页面HTML
    $html = '';

    // 用户搜索功能
    $html .= '    <div class="zib-widget mb10">
        <div class="box-body">
            <div class="mb10">
                <h4>搜索用户</h4>
                <p class="muted-2-color">通过用户名、邮箱或ID搜索用户，查看其授权情况</p>
            </div>
            <form id="user-search-form" class="mb10">
                <div class="flex flex-wrap gap10 items-end">
                    <div style="flex: 1; min-width: 200px;">
                        <input type="text" id="user-search-term" name="search_term" placeholder="请输入用户名、邮箱或ID" class="form-control">
                    </div>
                    <div>
                        <button type="button" id="search-user-btn" class="but jb-blue" style="padding: 7px 7px 7px 7px;margin-left: 10px;">搜索用户</button>
                    </div>
                </div>
            </form>
            <div id="user-search-result" class="mt10"></div>
        </div>
    </div>
    ';

    // 搜索结果和授权信息显示区域
    $html .= '    <div id="user-authorization-info" class="hidden">
        <div class="zib-widget mb10">
            <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);"></div>
            <div class="box-body" id="user-info-content">
            </div>
        </div>
        <div class="zib-widget mb10">
            <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);"></div>
            <div class="box-body" id="authorization-info-content">
            </div>
        </div>
    </div>';

    // 添加JavaScript代码
    $html .= '<script type="text/javascript">
        // 定义ajaxurl变量
        var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        var xk_auth_nonce = "' . wp_create_nonce('xk_auth_nonce') . '";
        jQuery(document).ready(function($) {
            // 搜索用户按钮点击事件
            $("#search-user-btn").on("click", function() {
                var searchTerm = $("#user-search-term").val().trim();
                if (!searchTerm) {
                    notyf("请输入搜索关键词", "danger");
                    return;
                }

                // 显示加载状态
                $("#user-search-result").html("<div class=\"text-center py20\"><i class=\"fa fa-spinner fa-spin em16 mr10\"></i> 正在搜索用户...</div>");
                $("#user-authorization-info").addClass("hidden");

                // 发送AJAX请求
                $.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: {
                        action: "xk_auth_admin_action",
                        sub_action: "search_user",
                        search_term: searchTerm,
                        security: xk_auth_nonce
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            // 处理成功响应
                            var data = response.data || response;
                            $("#user-search-result").html("<div class=\"text-center py10 c-green\"><i class=\"fa fa-check-circle mr10\"></i> " + data.msg + "</div>");
                            if (data.user_info) {
                                $("#user-info-content").html(data.user_info);
                                $("#authorization-info-content").html(data.authorization_info);
                                $("#user-authorization-info").removeClass("hidden");
                            }
                        } else {
                            // 处理错误响应
                            var errorMsg = response.data && response.data.msg ? response.data.msg : "搜索失败";
                            $("#user-search-result").html("<div class=\"text-center py10 c-red\"><i class=\"fa fa-exclamation-circle mr10\"></i> " + errorMsg + "</div>");
                            $("#user-authorization-info").addClass("hidden");
                        }
                    },
                    error: function() {
                        $("#user-search-result").html("<div class=\"text-center py10 c-red\"><i class=\"fa fa-exclamation-circle mr10\"></i> 搜索失败，请稍后重试</div>");
                    }
                });
            });

            // 回车键触发搜索
            $("#user-search-term").on("keypress", function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    $("#search-user-btn").click();
                }
            });
        });

        
    </script>';

    return zib_get_ajax_ajaxpager_one_centent($html);
}

// 注册管理中心内容过滤器
add_filter('main_user_tab_content_admin', 'xk_auth_main_user_tab_content_admin');

/**
 * @description: 管理中心AJAX处理函数
 */
function xk_auth_admin_ajax_handler() {
    // 验证请求来源IP
    if (!xk_auth_validate_request_ip()) {
        wp_send_json_error(array('msg' => '请求来源无效'));
    }

    // 验证nonce
    $nonce = isset($_POST['security']) ? sanitize_text_field($_POST['security']) : '';
    if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
        wp_send_json_error(array('msg' => '请求已过期，请刷新页面重试'));
    }

    // 验证用户是否登录
    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(array('msg' => '您没有权限执行此操作'));
    }

    // 检查用户是否有管理权限（管理员或授权用户）
    $is_admin = current_user_can('manage_options');
    $authorized_users = xk_auth('authorized_users', array());
    $is_authorized_user = in_array($user_id, $authorized_users);
    
    if (!$is_admin && !$is_authorized_user) {
        wp_send_json_error(array('msg' => '您没有权限执行此操作'));
    }

    // 检查前端授权管理功能是否开启
    $frontend_auth_enabled = xk_auth('frontend_auth_enabled', true);
    if (!$frontend_auth_enabled) {
        wp_send_json_error(array('msg' => '前端授权管理功能未开启'));
    }

    // 获取操作类型
    $action = isset($_POST['sub_action']) ? sanitize_text_field($_POST['sub_action']) : '';
    if (empty($action)) {
        wp_send_json_error(array('msg' => '操作类型无效'));
    }

    // 检查请求频率限制
    $rate_limit_check = xk_auth_check_admin_api_rate_limit($action, 5, 60);
    if (is_array($rate_limit_check)) {
        wp_send_json_error($rate_limit_check);
    }

    switch ($action) {
        case 'search_user':
            xk_auth_admin_search_user();
            break;
        default:
            wp_send_json_error(array('msg' => '未知操作'));
            break;
    }
}

/**
 * @description: 记录前端管理操作日志
 */
function xk_auth_log_frontend_admin_action($action_type, $target_user = '', $target_product = '', $action_detail = '') {
    // 使用新的数据库存储方式
    return xk_auth_insert_frontend_admin_log($action_type, $target_user, $target_product, $action_detail);
}

/**
 * @description: 搜索用户并显示其授权情况
 */
function xk_auth_admin_search_user() {
    // 严格验证和清理用户输入
    $search_term = isset($_POST['search_term']) ? sanitize_text_field($_POST['search_term']) : '';

    if (empty($search_term)) {
        wp_send_json_error(array('msg' => '请输入搜索关键词'));
    }

    // 限制搜索关键词长度
    if (strlen($search_term) > 100) {
        wp_send_json_error(array('msg' => '搜索关键词过长'));
    }

    try {
        // 搜索用户
        $user = null;
        
        // 尝试通过用户ID搜索
        if (is_numeric($search_term)) {
            $user_id = intval($search_term);
            $user = get_user_by('ID', $user_id);
        }
        
        // 尝试通过用户名搜索
        if (!$user) {
            $sanitized_login = sanitize_user($search_term);
            $user = get_user_by('login', $sanitized_login);
        }
        
        // 尝试通过邮箱搜索
        if (!$user) {
            $sanitized_email = sanitize_email($search_term);
            if (is_email($sanitized_email)) {
                $user = get_user_by('email', $sanitized_email);
            }
        }

        if (!$user) {
            wp_send_json_error(array('msg' => '未找到匹配的用户'));
        }
    } catch (Exception $e) {
        // 记录错误但不泄露详细信息给用户
        error_log('XK Auth Admin Search Error: ' . $e->getMessage());
        wp_send_json_error(array('msg' => '搜索过程中发生错误，请稍后重试'));
    }

    // 记录前端管理操作日志
    xk_auth_log_frontend_admin_action(
        'user_search',
        $user->display_name . ' (ID: ' . $user->ID . ')',
        '',
        '搜索用户并查看授权信息'
    );

    // 生成用户信息HTML
    $user_info_html = '    <div class="flex flex-wrap gap20 items-center">
        <div>
            <h4>' . esc_html($user->display_name) . '</h4>
            <p class="muted-2-color">用户ID: ' . esc_html($user->ID) . '</p>
            <p class="muted-2-color">邮箱: ' . esc_html($user->user_email) . '</p>
            <p class="muted-2-color">注册时间: ' . esc_html(date('Y-m-d H:i:s', strtotime($user->user_registered))) . '</p>
        </div>
    </div>';

    // 生成授权信息HTML
    $authorization_info_html = '';
    
    // 获取用户的所有产品授权
    $products = xk_auth('product_settings', array());
    if (!empty($products)) {
        $has_authorization = false;
        $authorization_info_html .= '    <div class="mb10">
        <h4>产品授权列表</h4>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>产品名称</th>
                        <th>授权状态</th>
                        <th>剩余授权数</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>';
        
        foreach ($products as $product) {
            $product_id = isset($product['product_id']) ? $product['product_id'] : '';
            $product_name = isset($product['product_name']) ? $product['product_name'] : '未命名产品';
            
            // 获取用户对该产品的授权信息
            $order_info = xk_auth_product_order_date($user->ID, $product_id);
            $aut_logs = xk_auth_change_transference($user->ID, $product_id);
            
            $remaining_auths = isset($aut_logs['remaining_auths']) ? $aut_logs['remaining_auths'] : 0;
            $total_auths = isset($aut_logs['total_auths']) ? $aut_logs['total_auths'] : 0;
            
            if (!empty($order_info) || $remaining_auths > 0) {
                $has_authorization = true;
                $status = !empty($order_info) ? '已购买' : '未购买';
                $status_class = !empty($order_info) ? 'c-green' : 'c-red';
                $remaining_text = !empty($order_info) ? esc_html($remaining_auths) . '/' . esc_html($total_auths) : '暂无';
                
                // 构建查看按钮的远程链接
                $view_remote_url = add_query_arg(array(
                    'action' => 'xk_auth_view_authorization',
                    'user_id' => $user->ID,
                    'product_id' => $product_id,
                    'security' => wp_create_nonce('xk_auth_nonce')
                ), admin_url('admin-ajax.php'));
                
                // 未购买产品时禁用按钮
                $is_purchased = !empty($order_info);
                $disabled_attr = $is_purchased ? '' : ' disabled title="产品未购买，无法操作"';
                
                // 查看按钮的属性
                $view_data_attrs = $is_purchased ? ' data-remote="' . esc_url($view_remote_url) . '" data-class="modal-mini full-sm modal-dialog" data-toggle="RefreshModal"' : '';
                
                // 编辑按钮的属性
                if ($is_purchased) {
                    $edit_remote_url = add_query_arg(array(
                        'action' => 'xk_auth_edit_authorization',
                        'user_id' => $user->ID,
                        'product_id' => $product_id,
                        'security' => wp_create_nonce('xk_auth_nonce')
                    ), admin_url('admin-ajax.php'));
                    $edit_data_attrs = ' data-remote="' . esc_url($edit_remote_url) . '" data-class="modal-mini full-sm modal-dialog" data-toggle="RefreshModal"';
                } else {
                    $edit_data_attrs = '';
                }
                
                $authorization_info_html .= '                    <tr>
                        <td>' . esc_html($product_name) . '</td>
                        <td><span class="' . $status_class . '">' . esc_html($status) . '</span></td>
                        <td>' . $remaining_text . '</td>
                        <td>
                            <button class="but but-sm jb-blue" style="padding: 4px 10px 4px 10px;" ' . $disabled_attr . $view_data_attrs . '>
                                查看
                            </button>
                            <button class="but but-sm jb-yellow" style="padding: 4px 10px 4px 10px;" ' . $disabled_attr . $edit_data_attrs . '>
                                编辑
                            </button>
                        </td>
                    </tr>';
            }
        }
        
        $authorization_info_html .= '                </tbody>
            </table>
        </div>';
        
        if (!$has_authorization) {
            $authorization_info_html .= '    <div class="text-center py20">
        <p class="muted-2-color">该用户暂无任何产品授权</p>
    </div>';
        }
        
        $authorization_info_html .= '    </div>';
    } else {
        $authorization_info_html = '    <div class="text-center py20">
        <p class="muted-2-color">暂无可用产品</p>
    </div>';
    }

    // 返回搜索结果
    wp_send_json_success(array(
        'msg' => '找到用户: ' . esc_html($user->display_name),
        'user_info' => $user_info_html,
        'authorization_info' => $authorization_info_html
    ));
}

// 注册AJAX处理函数
add_action('wp_ajax_xk_auth_admin_action', 'xk_auth_admin_ajax_handler');
