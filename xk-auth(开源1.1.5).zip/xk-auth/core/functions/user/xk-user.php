<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * 在页面头部添加刷新授权码的JavaScript函数
 * 确保函数在页面渲染早期就被定义，解决第一次进入页面时函数未定义的问题
 */
function xk_auth_add_refresh_auth_scripts()
{
    // 只在用户中心页面添加脚本
    if (is_user_logged_in()) {
        $admin_ajax_url = admin_url('admin-ajax.php');
        echo <<<EOF
        <script type="text/javascript">
        // 刷新整个产品的授权码
        function refreshAuthKey(productId) {
            if (confirm("确定要刷新此产品的授权码吗？刷新后旧的授权码将失效，请及时更新使用！")) {
                jQuery.ajax({
                    url: "{$admin_ajax_url}",
                    type: "POST",
                    data: {
                        action: "refresh_auth_key",
                        product_id: productId
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.error === 0) {
                            // 成功后刷新页面
                            location.reload();
                        } else {
                            alert(response.msg);
                        }
                    },
                    error: function() {
                        alert("刷新授权码失败，请稍后重试");
                    }
                });
            }
        }
        
        // 刷新单个域名的授权码
        function refreshDomainAuthKey(productId, domain, button) {
            if (confirm("确定要刷新此域名的授权码吗？刷新后旧的授权码将失效，请及时更新使用！")) {
                // 显示加载状态
                var originalText = button.innerHTML;
                button.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 刷新中...';
                button.disabled = true;
                
                jQuery.ajax({
                    url: "{$admin_ajax_url}",
                    type: "POST",
                    data: {
                        action: "refresh_domain_auth_key",
                        product_id: productId,
                        domain: domain
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.error === 0) {
                            // 成功后刷新当前页面
                            location.reload();
                        } else {
                            alert(response.msg);
                            // 恢复按钮状态
                            button.innerHTML = originalText;
                            button.disabled = false;
                        }
                    },
                    error: function() {
                        alert("刷新授权码失败，请稍后重试");
                        // 恢复按钮状态
                        button.innerHTML = originalText;
                        button.disabled = false;
                    }
                });
            }
        }
        </script>
        EOF;
    }
}
add_action('wp_head', 'xk_auth_add_refresh_auth_scripts');

/**
 * 用户中心-产品管理页面
 * 显示产品选择、订单信息及下载/导入功能
 */
function xk_auth_main_user_tab_content_product()
{

    // 获取当前用户ID，未登录则直接返回
    $user = wp_get_current_user();
    $user_id = isset($user->ID) ? (int) $user->ID : 0;
    if (!$user_id) {
        return;
    }
    // 获取产品ID
    $product_id = '';

    // 优先从GET参数获取（用于AJAX请求）
    if (isset($_GET['product_id'])) {
        $product_id = sanitize_text_field($_GET['product_id']);

        // 检查是否为数字
        if (!is_numeric($product_id)) {
            $product_id = '';
            $error_message = '选择的产品ID无效，请重新选择';
        }
    }
    // 其次从POST参数获取（保持兼容性）
    elseif (isset($_POST['product_id'])) {
        $product_id = sanitize_text_field($_POST['product_id']);

        // 检查是否为数字
        if (!is_numeric($product_id)) {
            $product_id = '';
            $error_message = '选择的产品ID无效，请重新选择';
        }
    }
    // 最后从默认设置获取
    elseif (!empty(xk_auth('default_product_id'))) {
        $product_id = xk_auth('default_product_id');
    }

    // 初始化页面HTML
    $html = '';

    // 产品选择区域 - 横向排列可点击切换
    $html .= '
        <style>
            .product-tabs {
                list-style: none;
                margin-top: 20px;
                display: flex;
                overflow-x: auto;
                margin-bottom: -20px;
                scrollbar-width: thin;
                scrollbar-color: transparent transparent;
                -ms-overflow-style: none;
                position: relative;
                z-index: 1;
                padding: 10px;
                padding-left: 0px;
                flex-wrap: nowrap;
                border-radius: 8px;
                transition: scrollbar-color 0.3s ease;
                -webkit-overflow-scrolling: touch;
                touch-action: pan-x;
            }
            .product-tabs:hover {
                scrollbar-color: #adb5bd transparent;
            }
            .product-tabs::-webkit-scrollbar {
                height: 1px;
            }
            .product-tabs::-webkit-scrollbar-track {
                background: transparent;
                transition: background 0.3s ease;
            }
            .product-tabs:hover::-webkit-scrollbar-track {
                background: transparent;
            }
            .product-tabs::-webkit-scrollbar-thumb {
                background: transparent;
                border-radius: 0.5px;
                transition: background 0.3s ease;
            }
            .product-tabs:hover::-webkit-scrollbar-thumb {
                background: #adb5bd;
            }
            .product-tabs::-webkit-scrollbar-thumb:hover {
                background: #6c757d;
            }
            
            /* 移动端箭头导航 */
            .product-tabs-container {
                margin-top: -27px;
                margin-bottom: -20px;
            }
            .product-tabs-nav {
                display: none !important;
            }
            @media (max-width: 768px) {
                .product-tabs-container {
                    position: relative;
                }
                .product-tabs-nav {
                    display: flex !important;
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    width: 30px;
                    height: 30px;
                    background: white;
                    border: 1px solid #e9ecef;
                    border-radius: 50%;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    z-index: 10;
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
                    transition: all 0.2s ease;
                }
                .product-tabs-nav:hover {
                    background: #f8f9fa;
                    transform: translateY(-50%) scale(1.05);
                }
                .product-tabs-nav.prev {
                    left: 0;
                }
                .product-tabs-nav.next {
                    right: 0;
                }
                .product-tabs-nav i {
                    font-size: 14px;
                    color: #495057;
                }
                /* 暗模式适配 */
                .dark-theme .product-tabs-nav {
                    background: rgba(255, 255, 255, 0.1);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
                }
                .dark-theme .product-tabs-nav:hover {
                    background: rgba(255, 255, 255, 0.15);
                    border-color: rgba(255, 255, 255, 0.3);
                }
                .dark-theme .product-tabs-nav i {
                    color: var(--text-color, #ffffff);
                }
            }
            .product-tab {
                flex: 0 0 auto;
                padding: 4px 12px;
                margin-right: 8px;
                background: #f8f9fa;
                border: 1px solid #e9ecef;
                border-radius: 4px;
                cursor: pointer;
                transition: all 0.2s ease;
                white-space: nowrap;
                font-weight: 400;
                font-size: 14px;
                color: #495057;
                position: relative;
            }
            .product-tab:hover {
                background: #e9ecef;
                border-color: #dee2e6;
                color: #212529;
                transform: translateY(-1px);
            }
            .product-tab.active {
                background: var(--main-color);
                border-color: var(--main-color);
                color: white;
                font-weight: 500;
                transform: translateY(-1px);
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            }
            .dark-theme .product-tab {
                background: rgba(255, 255, 255, 0.1);
                color: var(--text-color, #ffffff);
                border-color: rgba(255, 255, 255, 0.2);
            }
            .dark-theme .product-tab:hover {
                background: rgba(255, 255, 255, 0.15);
                border-color: rgba(255, 255, 255, 0.3);
            }
            .dark-theme .product-tab.active {
                background: #5a6c7f;
                color: #ffffff;
                border-color: #5a6c7f;
            }
            /* 增强的点击动画 */
            .product-tab.click-animation {
                transform: scale(0.95);
                transition: transform 0.15s ease;
            }
            /* 响应式优化 */
            @media (max-width: 768px) {
                .product-tab {
                    padding: 6px 12px;
                    margin-right: 6px;
                    font-size: 13px;
                    border-radius: 4px;
                }
            }
            @media (max-width: 480px) {
                .product-tab {
                    padding: 5px 10px;
                    margin-right: 4px;
                    font-size: 12px;
                    border-radius: 4px;
                }
            }
            .men {
                height: auto;
                margin-right: 8px;
                width: 100%;
                display: block;
            }
            @media (max-width:640px) {
                .men {
                    height: auto;
                    width: 100%;
                    display: block;
                }
            }
            .mens {
                height: auto;
                margin-left: 0;
                margin-top: 20px;
                width: 100%;
                display: block;
            }
            @media (max-width:640px) {
                .mens {
                    height: auto;
                    width: 100%;
                    display: block;
                }
            }
        </style>
        <div class="product-tabs-container">
            <div class="product-tabs-nav prev" id="product-tabs-prev">
                <i class="fa fa-chevron-left"></i>
            </div>
            <div class="product-tabs-nav next" id="product-tabs-next">
                <i class="fa fa-chevron-right"></i>
            </div>
            <div class="product-tabs" id="product-tabs">
                    '; 
    // 获取所有产品
    $products = xk_auth('product_settings', array());
    if (!empty($products)) {
        foreach ($products as $product) {
            $current_product_id = isset($product['product_id']) ? $product['product_id'] : '';
            $product_name = isset($product['product_name']) ? $product['product_name'] : '未命名产品';
            $is_active = (!empty($product_id) && $current_product_id == $product_id) ? 'active' : '';
            $active_attr = $is_active ? ' href="javascript:;"' : ' ajax-replace="true" href="' . esc_url(add_query_arg('product_id', $current_product_id)) . '"';
            $html .= '<a' . $active_attr . ' class="product-tab ' . $is_active . '" data-product-id="' . esc_attr($current_product_id) . '" title="' . esc_html($product_name) . '">
                        ' . esc_html($product_name) . '
                    </a>';
        }
    } else {
        $html .= '<div class="text-center text-muted py4 px10 w-full">暂无可用产品</div>';
    }
$html .= '            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // 产品标签点击事件
                $("#product-tabs .product-tab").on("click", function(e) {
                    if (!$(this).hasClass("active")) {
                        // 添加点击动画效果
                        $(this).addClass("click-animation");
                        
                        // 首先移除所有标签的active类
                        $("#product-tabs .product-tab").removeClass("active");
                        
                        // 延迟添加active类以增强视觉效果
                        setTimeout(function() {
                            $(this).addClass("active");
                        }.bind(this), 150);
                        
                        // 移除点击动画
                        setTimeout(function() {
                            $(this).removeClass("click-animation");
                        }.bind(this), 300);
                    }
                });
                
                // 添加点击动画样式
                $("<style>", { text: ".product-tab.click-animation { transform: scale(0.95); transition: transform 0.15s ease; }" }).appendTo("head");
                
                // 产品标签导航功能
                $("#product-tabs-prev").on("click", function() {
                    $("#product-tabs").animate({ scrollLeft: "-=200" }, 300);
                });
                
                $("#product-tabs-next").on("click", function() {
                    $("#product-tabs").animate({ scrollLeft: "+=200" }, 300);
                });
                
                // 隐藏/显示导航按钮
                function toggleNavButtons() {
                    var tabs = $("#product-tabs");
                    var prevBtn = $("#product-tabs-prev");
                    var nextBtn = $("#product-tabs-next");
                    
                    if (tabs.scrollLeft() > 0) {
                        prevBtn.fadeIn();
                    } else {
                        prevBtn.fadeOut();
                    }
                    
                    if (tabs.scrollLeft() < (tabs[0].scrollWidth - tabs.innerWidth())) {
                        nextBtn.fadeIn();
                    } else {
                        nextBtn.fadeOut();
                    }
                }
                
                // 初始化导航按钮状态
                toggleNavButtons();
                
                // 滚动时更新导航按钮状态
                $("#product-tabs").on("scroll", toggleNavButtons);
            });
        </script>
    ';

    // 获取订单信息
    $order_info = xk_auth_product_order_date('', $product_id);

    // 显示订单信息或购买提示
    if (!empty($order_info)) {
        global $post;
        $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);
        
        // 根据支付类型确定价格单位
        $pay_type = isset($order_info[0]['pay_type']) ? $order_info[0]['pay_type'] : 'balance';
        $is_points_payment = ($pay_type === 'points');
        
        // 安全获取订单价格
        $order_price = isset($order_info[0]['order_price']) ? $order_info[0]['order_price'] : 0;
        
        // 对于时间套餐，显示用户实际支付的套餐价格，而不是产品的基础价格
        // 直接使用订单价格作为显示价格，因为订单价格已经是用户实际支付的价格
        $price_unit = $is_points_payment ? '积分' : '￥';
        $display_price = $is_points_payment ? ($order_price * 100) : $order_price;
        $display_actual_price = $display_price;
        
        // 调试：记录价格信息到日志
        //error_log("[XK Auth] 订单价格调试: product_id=$product_id, pay_type=$pay_type, order_price=$order_price, display_price=$display_price, display_actual_price=$display_actual_price");
        
        $html .= '
            <div class="zib-widget pay-box mens" win-ajax-replace="true">
                <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>
                <div>
                    <div class="mb10"><b><a target="_blank" href="' . get_permalink($product_id) . '">' . (!empty(men_get_product_title($product_id)) ? men_get_product_title($product_id) : '未知的产品') . '</a></b></div>
                    <div class="meta-time em09 muted-2-color mb6">付款时间：' . $order_info[0]['pay_time'] . '</div>
                    <div class="meta-time em09 muted-2-color" title="点击复制订单号" data-clipboard-text="' . $order_info[0]['order_num'] . '" data-clipboard-tag="订单号">订单号：<i class="fa fa-files-o mr3"></i>' . $order_info[0]['order_num'] . '</div>
                    <div class="meta-time em09 muted-2-color"><span class="em12"><span class="pay-mark">价格：' . $price_unit . '</span>' . $display_price . '<span class="pay-mark ml10">实付金额：</span><span class="pay-mark">' . $price_unit . '</span>' . $display_actual_price . '</span></div>
                </div>
            </div>
        ';
    } else {
        // 用户未购买，显示购买提示
        $product_link = ($product_id > 0) ? esc_url(get_permalink($product_id)) : '';
        $product_target = ($product_id > 0) ? 'target="_blank"' : '';
        $product_name = ($product_id > 0) ? get_the_title($product_id) : '未知产品';

        $ajax_url = esc_js(admin_url('admin-ajax.php'));
        $html .= '
    <div class="zib-widget pay-box mens mb10">
        <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>
        <div>
            <div class="mb10">
                <b>
                    <a ' . $product_target . ' href="' . $product_link . '">
                        ' . esc_html($product_name) . '
                    </a>
                </b>
            </div>
            <div class="meta-time em09 muted-2-color mb10">当前您还未购买此产品，请先购买后再来管理您的授权吧</div>
            <div class="text-center mb10">
                <a class="but c-blue padding-lg" href="' . esc_url(get_permalink($product_id)) . '">
                    <i class="fa fa-cart-plus fa-fw" aria-hidden="true"></i> 购买授权
                </a>
            </div>
        </div>
    </div>
    <div class="zib-widget pay-box mens">
        <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">订单信息</div>
        <div>
            <p>
                <div class="meta-time em09 muted-2-color mb10">或者使用卡密获取授权：</div>
                <div class="text-center">
                    <div class="box" style="max-width: 400px; margin: 0 auto;">
                        <div class="mt10 mb10">
                            <input type="text" id="card_code" placeholder="请输入卡密" class="form-control">
                        </div>
                        <div class="mt10 mb10">
                            <input type="text" id="auth_domain" placeholder="请输入要授权的域名" class="form-control">
                        </div>
                        <div class="text-center">
                            <button type="button" class="but c-green padding-lg" onclick="xk_auth_use_card()">
                                <i class="fa fa-key fa-fw" aria-hidden="true"></i> 使用卡密
                            </button>
                        </div>
                        <div id="card_result" class="mt10 text-center"></div>
                    </div>
                </div>
            </p>
    <script type="text/javascript">
    // 定义ajaxurl变量
    var ajaxurl = "' . $ajax_url . '";
    var currentProductId = ' . $product_id . ';
            
            function xk_auth_use_card() {
                var card_code = document.getElementById("card_code").value;
                var auth_domain = document.getElementById("auth_domain").value;
                
                if (!card_code) {
                    notyf("请输入卡密", "danger");
                    return;
                }
                
                if (!auth_domain) {
                    notyf("请输入要授权的域名", "danger");
                    return;
                }
                
                // 显示加载状态
                notyf("正在验证卡密，请稍候...", "info");
                
                fetch(ajaxurl, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: "action=xk_auth_use_card&card_code=" + encodeURIComponent(card_code) + "&product_id=" + currentProductId + "&auth_domain=" + encodeURIComponent(auth_domain)
                })
                .then(response => response.json())
                .then(data => {
                    // 处理Zibll主题的错误格式
                    if (data.error) {
                        notyf(data.msg || "操作失败", data.ys || "danger");
                    } 
                    // 处理WordPress的成功格式
                    else if (data.success) {
                        notyf(data.data.message || "操作成功", "success");
                        // 刷新页面
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } 
                    // 处理其他情况
                    else {
                        notyf(data.msg || data.data.message || "未知错误", "danger");
                    }
                })
                .catch(error => {
                    notyf("发生错误：" + error.message, "danger");
                });
            }
            </script>
            </p>
        </div>
    </div>
';
    }

    // 产品授权模块
    if (xk_Auth::is_product('', $product_id)) {
        // 获取当前产品的授权配置
        $product_settings = xk_auth('product_settings');
        $current_product_auth = array();
        foreach ($product_settings as $settings) {
            if ($settings['product_id'] == $product_id) {
                $current_product_auth = $settings;
                break;
            }
        }
        $aut_logs = xk_auth_change_transference('', $product_id);

        // 安全地获取授权统计信息，避免未定义键错误
        $remaining_auths = isset($aut_logs['remaining_auths']) ? $aut_logs['remaining_auths'] : 0;
        $total_auths = isset($aut_logs['total_auths']) ? $aut_logs['total_auths'] : 0;

        // 授权对接方式
        $auth_system_type = isset($current_product_auth['auth_system_type']) ? $current_product_auth['auth_system_type'] : '0';
        // 获取授权QQ
        $auth_qq = get_user_meta($user_id, 'auth_qq', true);
        // 检查是否需要显示添加 QQ 链接
        $increase_qq_but = '';
        if ($auth_system_type !== '0' && empty($auth_qq)) {
            if (!$auth_qq) {
                $increase_qq_but .= xk_auth_increase_qq_link('but mm3 padding-lg jb-blue mb10');
            }
        }
        // 添加授权按钮显示规则
        $increase_aut_but = '';
        if ($auth_system_type == '0') {
            if ($remaining_auths >= 1) {
                $increase_aut_but .= xk_auth_get_increase_link('but mm3 padding-lg jb-blue mb10');
            }
        } else {
            if ($auth_qq) {
                if ($remaining_auths >= 1) {
                    $increase_aut_but .= xk_auth_get_increase_link('but mm3 padding-lg jb-blue mb10');
                }
            }
        }
        // 变更授权按钮显示规则
        $change_aut_but = '';
        if ($remaining_auths == 0) {
            // 统一使用带验证的变更授权链接，整合后的模态框会根据设置决定是否显示验证部分
            $args = array(
                'tag' => 'a',
                'data_class' => 'modal-dialog full-sm',
                'class' => 'but mm3 padding-lg jb-yellow mb10',
                'mobile_bottom' => true,
                'height' => 500, // 增加高度以适应整合后的内容
                'text' => '<i class="fa fa-refresh" aria-hidden="true"></i> 变更授权',
                'query_arg' => array(
                    'action' => 'xk_verify_before_change_auth',
                    'product_id' => $product_id,
                ),
            );
            $change_aut_but .= zib_get_refresh_modal_link($args);
            
        }
        $html .= '
        <div class="zib-widget pay-box" win-ajax-replace="true">
                    <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">授权信息</div>
                <div class="box-body">
                    <div class="c-red mb10"><i class="fa fa-diamond em12 mr10"></i><b>正版授权</b></div>
                    <div class="muted-2-color em09">
                        共可授权<span class="badg badg-sm c-red">' . $total_auths . '</span>个域名，还可授权<span class="badg c-red badg-sm">' . $remaining_auths . '</span>个域名如需更多域名授权，请与客服联系
                    </div>
                </div>';

        // 如果可授权等于总授权数那么则认为无授权域名
        if ($remaining_auths != $total_auths) {
            $html .= '
                    <div class="mb10">
                        <div class="author-set-left">授权有效期</div>
                        <div class="author-set-right"><span class="badg">点击授权中心的时间查询查看</span></div>
                    </div>
                    <div class="mb10">
                        <div class="author-set-left">验证类型</div>
                        <div class="author-set-right"><span class="badg">授权码+域名验证</span></div>
                    </div>
                    <div class="mb10">
                        <div class="author-set-left">授权域名</div>
                    </div>
                    <div class="mb10 text-center">
                        ' . xk_auth_for_product_domain_with_key('', $product_id) . '
                    </div>
                ';
        }
        elseif ($auth_system_type !== '0' && empty($auth_qq)) {
            $html .= '
                    <div class="mb10 text-center">请您先完成绑定授权QQ，此QQ关系到本站您的所有产品的售后，请谨慎填写！</div>
                ';
        } else {
            $html .= '
                    <div class="mb10 text-center">绑定授权域名后将为您生成授权信息</div>
                ';
        }
        $html .= '
                <div class="text-center mt10 mb10">
                    ' . $increase_qq_but . $increase_aut_but . $change_aut_but . '
                </div>
            </div>
        ';
    }
    
    // 卡密兑换或资源下载模块
    if (xk_Auth::is_product('', $product_id)) { // 如已经购买显示下载模块
        global $post;
        $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);
        $pay_extra_hide = $pay_mate['pay_extra_hide'];
        $error_message = '';

        // 获取所有产品设置
        $all_products = xk_auth('product_settings', array());
        $current_product = array(); // 当前选中产品的设置

        // 查找匹配的产品ID
        if (!empty($product_id) && is_array($all_products)) {
            foreach ($all_products as $product) {
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    $current_product = $product;
                    break;
                }
            }
        }

        // 如果未找到匹配的产品，设置默认值或错误信息
        if (empty($current_product)) {
            if (!empty($product_id)) {
                $error_message = '未找到ID为 ' . $product_id . ' 的产品';
            }

            // 设置默认值，避免未定义变量错误
            $current_product = array(
                'product_name' => '未知产品',
                'down_1' => '',
                'down_2' => '',
                'version' => '',
                'content' => '',
            );
        }

        // 安全地提取产品信息，确保所有变量都有默认值
        $product_name = isset($current_product['product_name']) ? $current_product['product_name'] : '未知产品';
        $down_1 = isset($current_product['down_1']) ? $current_product['down_1'] : '';
        $down_2 = isset($current_product['down_2']) ? $current_product['down_2'] : '';
        $version = isset($current_product['version']) ? $current_product['version'] : '';
        $content = isset($current_product['content']) ? $current_product['content'] : '';
        // 获取警示信息和群二维码
        $warning_message = isset($current_product['warning_message']) ? $current_product['warning_message'] : '';
        $official_group = isset($current_product['official_group']) ? $current_product['official_group'] : '';
        $group_qrcode = isset($current_product['group_qrcode']) ? $current_product['group_qrcode'] : '';

        // 检查是否启用域名绑定检验功能
        $enable_domain_check = xk_auth('enable_domain_check_download', true);
        // 检查是否启用下载验证
        $enable_download_verify = xk_auth('enable_download_verify', false);
        
        // 检查用户是否已绑定至少一个域名
        $has_domains = xk_Auth::has_bound_domains($user_id, $product_id);
        
        // 如果关闭了域名绑定检验，则认为用户已绑定域名
        if (!$enable_domain_check) {
            $has_domains = true;
        }
        
        $html .= '
            <div class="zib-widget pay-box" win-ajax-replace="true">
                <div class="pay-tag abs-center" style="left: auto;right: 0;border-radius: 0 var(--main-radius) 0 var(--main-radius);">资源下载</div>
                <div class="theme-box">
                    <div>
        ';
        
        if ($has_domains) {
            // 用户已绑定域名，显示下载按钮
            if ($enable_download_verify) {
                // 启用了下载验证，显示带验证的下载按钮
                // 生成极速下载按钮（带模态框）
                $args_main = array(
                    'tag' => 'a',
                    'data_class' => 'modal-dialog full-sm',
                    'class' => 'mr10 but jb-cyan',
                    'mobile_bottom' => false,
                    'height' => 500,
                    'text' => '<i class="fa fa-download" aria-hidden="true"></i>极速下载',
                    'query_arg' => array(
                        'action' => 'xk_download_resource_verify',
                        'product_id' => $product_id,
                        'resource_id' => 'main',
                    ),
                );
                $main_download_btn = zib_get_refresh_modal_link($args_main);
                
                // 生成备用下载按钮（带模态框）
                $args_backup = array(
                    'tag' => 'a',
                    'data_class' => 'modal-dialog full-sm',
                    'class' => 'mr10 but b-cyan',
                    'mobile_bottom' => false,
                    'height' => 500,
                    'text' => '<i class="fa fa-download" aria-hidden="true"></i>备用下载',
                    'query_arg' => array(
                        'action' => 'xk_download_resource_verify',
                        'product_id' => $product_id,
                        'resource_id' => 'backup',
                    ),
                );
                $backup_download_btn = zib_get_refresh_modal_link($args_backup);
            } else {
                // 未启用下载验证，显示直接下载链接
                $main_download_btn = '<a target="_blank" href="' . $down_1 . '" class="mr10 but jb-cyan">
                                    <i class="fa fa-download" aria-hidden="true"></i>极速下载
                                </a>';
                $backup_download_btn = '<a target="_blank" href="' . $down_2 . '" class="mr10 but b-cyan">
                                    <i class="fa fa-download" aria-hidden="true"></i>备用下载
                                </a>';
            }
            
            $html .= '
                        <div class="flex ac hh">
                            <div class="but-download flex ac">
                                ' . $main_download_btn . '
                                <span class="badg">版本：V' . $version . '</span>
                            </div>
                            <div class="but-download flex ac">
                                ' . $backup_download_btn . '
                                <span class="badg">版本：V' . $version . '</span>
                            </div>
                            ' . $content . '
                        </div>
            ';
        } else {
            // 用户未绑定域名，显示提示信息
            $html .= '
                        <div class="c-red mb10 text-center" style="margin:30px;">
                            <i class="fa fa-info-circle em12 mr10"></i>
                            <b>请先绑定至少一个域名才能下载资源</b>
                        </div>
            ';
        }
        
        // 添加警示信息和群二维码
        if (!empty($warning_message) || !empty($group_qrcode)) {
            $html .= '
                    <div style="margin-top: 20px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: flex-start; padding: 15px; background-color: #f8f9fa; border-radius: 8px;">
                        <div style="flex: 1; padding-right: 20px; min-width: 300px;">
                            ' . $warning_message . '
                        </div>
                        ';
            if (!empty($group_qrcode)) {
                $html .= '
                        <div style="text-align: center; min-width: 150px;">
                            <img src="' . $group_qrcode . '" alt="正版用户群二维码" style="max-width: 150px; height: auto; margin-bottom: 10px; border: 1px solid #eee; padding: 5px; border-radius: 5px;">
                            ';
                if (!empty($official_group)) {
                    $html .= '<p style="margin: 5px 0; color: #333; font-size: 14px;">扫码加入正版用户群</p>
                            <p style="margin: 0; color: #ff6600; font-weight: bold; font-size: 16px;">QQ群号：' . $official_group . '</p>';
                }
                $html .= '</div>';
            }
            $html .= '
                    </div>
            ';
        }
        
        $html .= '
                    </div>
                </div>
            </div>
        ';
    } else {
        // 用户未购买，显示订单导入模块
        $html .= '
            <div class="zib-widget pay-box">
                <div class="box-body theme-box">
                    <div class="c-red mb10"><i class="fa fa-angle-double-right em12 mr10"></i><b>导入订单</b></div>
                    <div class="muted-2-color em09">请输入您通过其他方式购买我们的产品，请在此处输入授权码导入授权。</div>
                </div>
                <form>
                    <div class="line-form theme-box">
                        <input type="text" name="auth_exchange_key" class="line-form-input text-center" tabindex="2" placeholder="请输入授权码">
                        <i class="line-form-line"></i>
                    </div>
                    <input type="hidden" name="product_id" value="' . $product_id . '">
                    <div class="box-body text-center">
                        <input type="hidden" name="action" value="import_order">
                        <button type="button" zibajax="submit" class="but jb-blue radius padding-lg" name="submit"><i class="fa fa-check mr10"></i>确认提交</button>
                    </div>
                </form>
            </div>
        ';
    }

    return zib_get_ajax_ajaxpager_one_centent($html);
}
add_filter('main_user_tab_content_product', 'xk_auth_main_user_tab_content_product');