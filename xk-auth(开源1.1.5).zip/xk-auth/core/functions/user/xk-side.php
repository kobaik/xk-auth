<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * @description: 用户中心侧边栏的第一个：数据统计
 * @param {*} $con
 * @return {*}
 */
function xk_auth_user_center_page_sidebar_statistics($con)
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return $con; // 未登录时返回原始内容
    }

    // 从设置中获取自定义标题和描述
    $sidebar_title = xk_auth('sidebar_title', '产品授权管理'); // 第二个参数为默认值
    $sidebar_desc = xk_auth('sidebar_desc', '管理您购买的所有产品授权');

    // 拼接HTML内容，使用设置项的值
    $con .= '
        <div class="colorful-bg jb-cyan zib-widget mb10-sm" data-onclick="[data-target=\'#user-tab-product\']">
            <div class="colorful-make" style="transform: rotate(-28deg) scale(.8);"></div>
            <div class="flex ab c jsb">
                <div class="">
                    <div class="flex ac">
                        <b class="em14">' . esc_html($sidebar_title) . '</b>
                    </div>
                    <div style="" class="em09 opacity8">
                        ' . esc_html($sidebar_desc) . '
                    </div>
                    <a href="javascript:;" class="mt6 but radius  jb-cyan px12 p2-10">
                        管理授权<i style="margin:0 0 0 6px;" class="fa fa-angle-right em12"></i>
                    </a>
                </div>
                <span class="avatar-img mr10 mt3" style="--this-size: 59px;">
                    <img alt="' . esc_attr(get_bloginfo('name')) . '" src="' . esc_url(_pz('iconpng')) . '" class="avatar">
                </span>
            </div>
        </div>
    ';
    return $con;
}
add_filter('user_center_page_sidebar', 'xk_auth_user_center_page_sidebar_statistics', 1);


/**
 * @description: 用户中心侧边栏的第二个：管理他人授权
 * @param {*} $con
 * @return {*}
 */
function xk_auth_user_center_page_sidebar($con)
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return $con; // 未登录时返回原始内容
    }

    // 检查用户是否有管理权限（管理员或授权用户）
    $is_admin = current_user_can('manage_options');
    $authorized_users = xk_auth('authorized_users', array());
    $is_authorized_user = in_array($user_id, $authorized_users);
    
    if (!$is_admin && !$is_authorized_user) {
        return $con; // 非管理员且非授权用户时返回原始内容
    }

    // 检查前端授权管理功能是否开启
    $frontend_auth_enabled = xk_auth('frontend_auth_enabled', true);
    if (!$frontend_auth_enabled) {
        return $con; // 前端授权管理功能未开启时返回原始内容
    }

    // 定义管理他人授权按钮
    $buttons[] = array(
        'icon' => 'fa fa-fw fa-users-cog', // 管理相关图标
        'name' => '管理他人授权',
        'style' => 'color: #ffffffff;',
        'type' => 'link', // 标记为链接跳转类型
        'url' => '/user/admin' // 目标跳转地址
    );

    // 生成按钮HTML
    $buttons_html = '';
    foreach ($buttons as $but) {
        if (empty($but['icon'])) {
            continue;
        }

        // 链接跳转类型按钮
        $buttons_html .= '
        <div class="colorful-bg jb-cyan zib-widget mb10-sm">
            <div class="colorful-make" style="transform: rotate(-28deg) scale(.8);"></div>
            <div class="flex ab c jsb">
                <div class="">
                    <div class="flex ac">
                        <a href="' . esc_url($but['url']) . '" style="' . esc_attr($but['style']) . '">
                            <b class="em14">' . esc_html($but['name']) . '</b>
                            <i style="margin:0 0 0 6px; font-weight: bold;" class="fa fa-angle-right em12"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        ';
    }

    $con .= $buttons_html;
    return $con;
}
add_filter('user_center_page_sidebar', 'xk_auth_user_center_page_sidebar', 2);

/**
 * @description: 用户中心第二行的显示按钮
 * @param {*} $con
 * @return {*}
 */
function xk_auth_gets_main_tab_auths_nav($con)
{
    $buttons[] = array(
        'icon' => 'fa fa-fw fa-gitlab',
        'name' => '正版查询',
        'ajax' => 'add_ajax_admin_auth',
        'style' => 'color: #0087e8;',
        'type' => 'modal' // 标记为弹窗类型按钮
    );

    $buttons[] = array(
        'icon' => 'fa fa-fw fa-clock-o',
        'name' => '时间查询',
        'ajax' => 'add_ajax_admin_time_auth',
        'style' => 'color: #0087e8;',
        'type' => 'modal' // 标记为弹窗类型按钮
    );

    // 新增第二个按钮：日志查询（跳转至/user/log）
    $buttons[] = array(
        'icon' => 'fa fa-fw fa-history', // 日志相关图标
        'name' => '日志查询',
        'style' => 'color: #0087e8;',
        'type' => 'link', // 标记为链接跳转类型
        'url' => '/user/log' // 目标跳转地址
    );

    // 新增举报功能按钮
    $buttons[] = array(
        'icon' => 'fa fa-fw fa-flag', // 举报相关图标
        'name' => '举报中心',
        'ajax' => 'add_ajax_admin_report',
        'style' => 'color: #0087e8;',
        'type' => 'modal' // 标记为弹窗类型按钮
    );

    // 新增第三个按钮：代理中心（跳转至/agent）
    // $buttons[] = array(
    //     'icon' => 'fa fa-fw fa-sitemap', // 代理/网络相关图标
    //     'name' => '代理中心',
    //     'style' => 'color: #0087e8;',
    //     'type' => 'link', // 标记为链接跳转类型
    //     'url' => '/user/agent' // 目标跳转地址
    // );

    $buttons = apply_filters('auths_user_center_page_sidebar_button_2_args', $buttons);

    $buttons_html = '';
    foreach ($buttons as $but) {
        if (empty($but['icon'])) {
            continue;
        }

        // 根据按钮类型生成不同HTML结构
        if ($but['type'] === 'link' && !empty($but['url'])) {
            // 链接跳转类型按钮（日志查询、代理中心）
            $buttons_html .= '
            <style>.xk-item {width: calc(25% - 10px);margin: 5px;min-width: 50px;max-width: 100px;}</style>
            <a class="xk-item" href="' . esc_url($but['url']) . '" style="' . esc_attr($but['style']) . '">
                <div class="em16"><i class="csf-tab-icon ' . esc_attr($but['icon']) . '"></i></div>
                <div class="px12 muted-color mt3">' . esc_html($but['name']) . '</div>
            </a>';
        } else {
            // 弹窗类型按钮（正版查询，保持原有逻辑）
            $buttons_html .= '
            <style>.xk-item {width: calc(25% - 10px);margin: 5px;min-width: 50px;max-width: 100px;}</style>
            <a class="xk-item" href="javascript:;" 
               data-remote="' . add_query_arg(['action' => $but['ajax']], admin_url('admin-ajax.php')) . '" 
               data-class="modal-mini full-sm modal-dialog" 
               data-toggle="RefreshModal"
               style="' . esc_attr($but['style']) . '">
                <div class="em16"><i class="csf-tab-icon ' . esc_attr($but['icon']) . '"></i></div>
                <div class="px12 muted-color mt3">' . esc_html($but['name']) . '</div>
            </a>';
        }
    }

    $con .= $buttons_html ? '<div class="zib-widget padding-6"><div class="padding-6 ml3">授权中心</div><div class="flex ac hh text-center icon-but-box user-icon-but-box">' . $buttons_html . '</div></div>' : '';

    return $con;
}
add_filter('user_center_page_sidebar', 'xk_auth_gets_main_tab_auths_nav');

/**
 * @description: 代理中心链接注册
 * @param {*} $tabs_array
 * @return {*}
 */
function xk_auth_agent_ctnter_main_tabs_array_filter_main($tabs_array)
{
    $tabs_array['agent'] = array(
        'title' => '代理中心',
        'nav_attr' => 'drawer-title="代理中心"',
        'loader' => '<div class="zib-widget"><div class="mt10"><div class="placeholder k1 mb10"></div><div class="placeholder k1 mb10"></div><div class="placeholder s1"></div></div><p class="placeholder k1 mb30"></p><div class="placeholder t1 mb30"></div><p class="placeholder k1 mb30"></p><p style="height: 120px;" class="placeholder t1"></p></div>',
    );
    return $tabs_array;
}
add_filter('user_ctnter_main_tabs_array', 'xk_auth_agent_ctnter_main_tabs_array_filter_main');




/**
 * @description: 管理中心链接注册
 * @param {*} $tabs_array
 * @return {*}
 */
function xk_auth_admin_ctnter_main_tabs_array_filter_main($tabs_array)
{
    $tabs_array['admin'] = array(
        'title' => '管理中心',
        'nav_attr' => 'drawer-title="管理中心"',
        'loader' => '<div class="zib-widget"><div class="mt10"><div class="placeholder k1 mb10"></div><div class="placeholder k1 mb10"></div><div class="placeholder s1"></div></div><p class="placeholder k1 mb30"></p><div class="placeholder t1 mb30"></div><p class="placeholder k1 mb30"></p><p style="height: 120px;" class="placeholder t1"></p></div>',
    );
    return $tabs_array;
}
add_filter('user_ctnter_main_tabs_array', 'xk_auth_admin_ctnter_main_tabs_array_filter_main');