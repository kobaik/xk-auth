<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

if (!defined('XK_AUTH_DIR')) {
    define('XK_AUTH_DIR', plugin_dir_path(__FILE__));
}

if (!function_exists('xk_auth')) {
    include_once XK_AUTH_DIR . '../../options/options.php';
}

if (!xk_auth('show_auth_widgets_product')) {
    return;
}

class XK_Auth_Product_Widget extends WP_Widget {

    public function __construct() {
        $widget_ops = array(
            'classname' => 'xk_auth_product_widget',
            'description' => __('展示产品小工具', 'xk-auth'),
        );
        parent::__construct('xk_auth_product_widget', __('星空授权产品列表', 'xk-auth'), $widget_ops);
    }


    public function widget($args, $instance) {
        // 获取小工具配置
        $title = apply_filters('widget_title', $instance['title']);
        $number = isset($instance['number']) ? absint($instance['number']) : 5;

                       // 添加内联响应式样式
echo '<style>/* 响应式样式 */ 
/* 响应式样式 */
@media (max-width: 768px) {
 .item-thumbnail-1{
    height: 150px !important; 
 }
 .item-heading-1{
    margin-top: -7px !important; 
    width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
 }
 .item-price-2{
    margin-top: -9px !important;
 }


 .meta-left-1{
    margin-top: -10px !important;
 }

}
/* 响应式样式 */
@media (max-width: 767px) {
 .item-thumbnail-1{
    height: 150px !important; 
 }
 .item-heading-1{
    margin-top: -7px !important; 
    width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
 }
 .item-price-2{
    margin-top: -9px !important;
 }


 .meta-left-1{
    margin-top: -10px !important;
 }

}

@media (max-width: 640px) {
 .item-thumbnail-1{
    height: 150px !important; 
 }
 .item-heading-1{
    margin-top: -7px !important; 
    width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
 }
 .item-price-2{
    margin-top: -9px !important;
 }


 .meta-left-1{
    margin-top: -10px !important;
 }

}


 }</style>';

        
        // 输出小工具开始标签
        if (!empty($title)) {
        // 添加自定义类和副标题
        $custom_before_title = str_replace('<h3>', '<h3 class="but c-blue" style="height: 35px;font-size: 18px;overflow: hidden;position: relative;display: flex;justify-content: space-between;align-items: center;">', $args['before_title']);
        $subtitle = isset($instance['subtitle']) ? $instance['subtitle'] : '最新上架'; // 从设置中获取副标题
        $subtitle_url = isset($instance['subtitle_url']) ? $instance['subtitle_url'] : ''; // 从设置中获取副标题链接
        $spaces = str_repeat(" ", 10);
        
        // 输出标题和带链接的副标题
        echo $custom_before_title . $title;
        if (!empty($subtitle)) {
            $subtitle_content = '<span style="font-size: 14px;color: #999;margin-left: 10px;">' . $subtitle . '</span>';
            if (!empty($subtitle_url)) {
                echo '<a href="' . esc_url($subtitle_url) . '" title="' . esc_attr($subtitle) . '" target="_blank">' . $subtitle_content . '</a>';
            } else {
                echo $subtitle_content;
            }
        }
        echo $args['after_title'];
        }

        $query_args = array(
            'post_type' => 'page',
            'posts_per_page' => $number,
            'meta_query' => array(
                array(
                    'key' => 'posts_zibpay_xkzhi',
                    'compare' => 'EXISTS'
                )
            ),
            'orderby' => 'date',
            'order' => 'DESC'
        );
        
        $auth_query = new WP_Query($query_args);

        if ($auth_query->have_posts()) {
            echo '<div class="xk-auth-product-grid grid grid-cols-1 gap12">';
            while ($auth_query->have_posts()) {
                $auth_query->the_post();
                global $post;
                $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);
                $permalink = get_permalink();
                $post_title = get_the_title();
                
                // 构建卡片样式
                $style = get_theme_mod('list_card_option_style', 'style1'); 
                $card_class = 'posts-item card ajax-item ' . $style;
                echo '<posts class="' . $card_class . '">';
                
                // 缩略图部分
                echo '<div class="item-thumbnail-1" style="height: 200px;">';
                
                if (has_post_thumbnail()) {
                    echo '<a href="' . $permalink . '" title="' . esc_attr($post_title) . '">';
                    the_post_thumbnail('medium', array('class' => 'fit-cover radius8', 'style' => 'height: 100%;'));
                    echo '</a>';
                } else {
                    $first_image = $this->get_first_image_from_content(get_the_ID());
                    if ($first_image) {
                        echo '<a href="' . $permalink . '" title="' . esc_attr($post_title) . '">';
                        echo '<img src="' . esc_url($first_image) . '" class="fit-cover radius8" style="height: 100%;" alt="' . esc_attr($post_title) . '" />';
                        echo '</a>';
                    } else { 
                        $default_thumbnail = WP_CONTENT_URL . '/themes/zibll/img/thumbnail.svg';
                        echo '<a href="' . $permalink . '" title="' . esc_attr($post_title) . '">';
                        echo '<img src="' . esc_url($default_thumbnail) . '" class="fit-cover radius8" style="height: 100%;" alt="' . esc_attr($post_title) . '" />';
                        echo '</a>';
                    }
                }
                
                echo '</div>';
                
                // 内容部分
                echo '<div class="item-body">';
                
                // 标题
                echo '<div class="item-heading-1" style="height: 42px; line-height: 42px; font-size: 16px; margin: 11px 0px 0px -1px; font-weight: bold;"><a href="' . $permalink . '" title="' . esc_attr($post_title) . '">' . $post_title . '</a></div>';
                

                echo '<div class="item-price-2" style="height: 42px; line-height: 20px; margin: 0px 0px 14px 0px; display: flex; justify-content: space-between; align-items: center;">';
                if ((isset($pay_mate['pay_price']) && $pay_mate['pay_price'] > 0) || (isset($pay_mate['points_price']) && $pay_mate['points_price'] > 0)) {
                    echo '<div class="meta-right-1" style="font-size: 1.4em;color: #ff4d4f; font-weight: bold;">';
                    // 检查是否为积分支付类型
                    if (isset($pay_mate['pay_modo']) && $pay_mate['pay_modo'] === 'points') {
                        // 积分支付，显示积分价格
                        echo '<span class="text-yellow">' . $spaces . $pay_mate['points_price'] . ' 积分</span>';
                    } else {
                        // 普通支付，显示人民币价格
                        echo '<span class="text-yellow">¥' . $spaces . $pay_mate['pay_price'] . '</span>';
                    }
                    echo '</div>';
                    
                    // 检查用户是否已登录
                    $user_id = get_current_user_id();
                    if ($user_id > 0) {
                        // 检查用户是否已购买该授权产品
                        global $wpdb;
                        $order_table = $wpdb->prefix . 'zibpay_order';
                        
                        // 直接查询数据库，检查是否已经存在有效订单
                        $is_paid = $wpdb->get_var(
                            $wpdb->prepare(
                                "SELECT COUNT(*) FROM $order_table 
                                     WHERE `user_id` = %d 
                                     AND `post_id` = %d 
                                     AND `order_type` IN (13, 15) 
                                     AND `status` = 1",
                                $user_id,
                                $post->ID
                            )
                        );
                        
                        if ($is_paid > 0) {
                            // 已购买，显示管理授权按钮
                            echo '<a href="/user/product" class="but pw-1em ml6 jb-yellow" style="padding: 6px 15px;  color: white; text-decoration: none; border-radius: 4px; font-size: 14px;">管理授权</a>';
                        } else {
                            // 未购买，显示立即购买按钮
                            echo '<a href="' . $permalink . '" class="but pw-1em ml6 jb-red" style="padding: 6px 15px;  color: white; text-decoration: none; border-radius: 4px; font-size: 14px;">立即购买</a>';
                        }
                    } else {
                        // 未登录，显示登录购买按钮
                        echo '<a href="/user/login" class="but pw-1em ml6 jb-red" style="padding: 6px 15px; color: white; text-decoration: none; border-radius: 4px; font-size: 14px;">登录购买</a>';
                    }
                }
                echo '</div>';
                
                
                // 元信息部分
                echo '<div class="item-meta muted-2-color flex jsb ac">';
                
                // 左侧：作者和时间
                echo '<div class="meta-left" style="font-size: 14px;">';
                // 作者头像
                echo '<span class="avatar-mini">' . get_avatar(get_the_author_meta('ID'), 20) . '</span>';
                // 作者名称
                echo '<span class="ml6">' . get_the_author() . '</span>';
                // 时间 - 总是显示
                echo '<span class="icon-circle ml6" title="' . get_the_time('Y-m-d H:i:s') . '">' . $this->get_time_ago(get_the_modified_time('Y-m-d H:i:s')) . '</span>';
                echo '</div>';
                
                // 右侧：浏览量（从子比主题获取）
                echo '<div class="meta-right">';
                echo '<item class="meta-view">' . zib_get_svg('view') . get_post_view_count('', '') . '</item>';
                echo '</div>';
                
                echo '</div>'; // 结束元信息
                echo '</div>'; // 结束item-body
                echo '</posts>'; // 结束卡片
            }
            echo '</div>'; // 结束网格容器
            
        } else {
            echo '<p class="xk-auth-product-none text-center p12">' . __('暂无授权产品', 'xk-auth') . '</p>';
        }

        wp_reset_postdata();
        

        echo $args['after_widget'];
    }

    /**
     * 小工具后端设置表单
     */
    public function form($instance) {
        // 设置默认值
        $title = !empty($instance['title']) ? $instance['title'] : __('授权产品', 'xk-auth');
        $subtitle = !empty($instance['subtitle']) ? $instance['subtitle'] : __('最新上架', 'xk-auth');
        $subtitle_url = !empty($instance['subtitle_url']) ? $instance['subtitle_url'] : '';
        $number = !empty($instance['number']) ? absint($instance['number']) : 5;
        
        // 表单字段
        echo '<p>';
        echo '<label for="' . $this->get_field_id('title') . '">' . __('标题:', 'xk-auth') . '</label>';
        echo '<input class="widefat" id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" type="text" value="' . esc_attr($title) . '" />';
        echo '</p>';
        
        echo '<p>';
        echo '<label for="' . $this->get_field_id('subtitle') . '">' . __('副标题:', 'xk-auth') . '</label>';
        echo '<input class="widefat" id="' . $this->get_field_id('subtitle') . '" name="' . $this->get_field_name('subtitle') . '" type="text" value="' . esc_attr($subtitle) . '" />';
        echo '<small>' . __('副标题将显示在主标题右侧，留空则不显示', 'xk-auth') . '</small>';
        echo '</p>';
        
        echo '<p>';
        echo '<label for="' . $this->get_field_id('subtitle_url') . '">' . __('副标题链接:', 'xk-auth') . '</label>';
        echo '<input class="widefat" id="' . $this->get_field_id('subtitle_url') . '" name="' . $this->get_field_name('subtitle_url') . '" type="text" value="' . esc_url($subtitle_url) . '" />';
        echo '<small>' . __('副标题点击后跳转的链接，留空则不添加链接', 'xk-auth') . '</small>';
        echo '</p>';
        
        echo '<p>';
        echo '<label for="' . $this->get_field_id('number') . '">' . __('显示数量:', 'xk-auth') . '</label>';
        echo '<input id="' . $this->get_field_id('number') . '" name="' . $this->get_field_name('number') . '" type="number" min="1" max="20" value="' . absint($number) . '" size="3" />';
        echo '</p>';
    }

    /**
     * 更新小工具设置
     */
    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['subtitle'] = sanitize_text_field($new_instance['subtitle']);
        $instance['subtitle_url'] = esc_url_raw($new_instance['subtitle_url']);
        $instance['number'] = absint($new_instance['number']);
        
        return $instance;
    }
    
    /**
     * 获取相对时间
     */
    private function get_time_ago($time) {
        $time_diff = current_time('timestamp') - strtotime($time);
        
        if ($time_diff < 60) {
            return $time_diff . '秒前';
        } elseif ($time_diff < 3600) {
            return floor($time_diff / 60) . '分钟前';
        } elseif ($time_diff < 86400) {
            return floor($time_diff / 3600) . '小时前';
        } elseif ($time_diff < 604800) {
            return floor($time_diff / 86400) . '天前';
        } else {
            return get_the_time('Y-m-d', strtotime($time));
        }
    }

  
    /**
     * 从文章内容中提取第一张图片
     */
    private function get_first_image_from_content($post_id) {
        $post = get_post($post_id);
        $content = $post->post_content;
        
        // 使用正则表达式匹配img标签中的src属性
        $pattern = '/<img.*?src=["\'](.*?)["\'].*?>/i';
        
        if (preg_match($pattern, $content, $matches)) {
            return $matches[1]; // 返回匹配到的第一个图片URL
        }
        
        return false; // 没有找到图片
    }
}



// 注册小工具
function xk_auth_register_widget() {
    register_widget('XK_Auth_Product_Widget');
}
add_action('widgets_init', 'xk_auth_register_widget');

// 加载小工具样式
function xk_auth_enqueue_widget_styles() {
    wp_enqueue_style('xk-auth-widget', plugin_dir_url(__FILE__) . '../../../css/xk-auth-widget.css', array(), '1.0.0');
}
add_action('wp_enqueue_scripts', 'xk_auth_enqueue_widget_styles');