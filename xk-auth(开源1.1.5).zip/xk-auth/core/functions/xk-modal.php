<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 确保函数已定义
if (!function_exists('xk_auth_check_admin_api_rate_limit')) {
    /**
     * @description: 检查API请求频率限制
     * @param string $action 操作类型
     * @param int $limit 限制次数
     * @param int $time_window 时间窗口（秒）
     * @return bool|array 如果请求被限制，返回包含错误信息的数组；否则返回true
     */
    function xk_auth_check_admin_api_rate_limit($action = 'default', $limit = 5, $time_window = 60) {
        // 检查是否开启了API请求限制
        $enable_limit = xk_auth('enable_api_rate_limit', false);
        if (!$enable_limit) {
            return true;
        }
        
        // 获取当前用户ID
        $user_id = get_current_user_id();
        if (!$user_id) {
            return true;
        }
        
        // 生成缓存键
        $cache_key = "xk_auth_admin_rate_limit_{$action}_{$user_id}";
        
        // 获取当前请求次数
        $request_count = get_transient($cache_key);
        
        // 如果缓存不存在，初始化计数
        if (false === $request_count) {
            set_transient($cache_key, 1, $time_window);
            return true;
        }
        
        // 检查是否超过限制
        if ($request_count >= $limit) {
            return array('msg' => "请求过于频繁，请在{$time_window}秒后重试");
        }
        
        // 增加计数
        set_transient($cache_key, $request_count + 1, $time_window);
        return true;
    }
}

if (!function_exists('xk_auth_validate_request_ip')) {
    /**
     * @description: 验证请求来源IP
     * @return bool 是否为有效IP
     */
    function xk_auth_validate_request_ip() {
        // 获取客户端IP
        $client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        // 检查IP是否有效
        if (empty($client_ip) || !filter_var($client_ip, FILTER_VALIDATE_IP)) {
            return false;
        }
        
        // 可以在这里添加IP白名单或黑名单逻辑
        
        return true;
    }
}

/**
 * @description: 生成前端管理用户查看授权拟态框
 *
 * @param int|string $user_id 用户ID
 * @param int|string $product_id 产品ID
 *
 * @return string 生成的查看授权拟态框的HTML
 */
function xk_auth_view_authorization_modal($user_id = '', $product_id = '') {
    if (!$user_id || !$product_id) {
        return '<div class="text-center py20 c-red">数据获取错误，请刷新后重试</div>';
    }

    // 获取订单信息
    $order_info = xk_auth_product_order_date($user_id, $product_id);
    if (empty($order_info)) {
        return '<div class="text-center py20 c-red">未找到该用户的订单信息</div>';
    }

    // 自己从数据库查询域名和授权码
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';
    $domains = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT domain, auth_key FROM $table_name WHERE user_id = %d AND product_id = %d ORDER BY domain ASC LIMIT 100",
            $user_id, $product_id
        )
    );

    // 生成域名和授权码列表
    $domains_with_keys = '';
    if (!empty($domains)) {
        $domains_with_keys .= '<div class="auth-domains-list">';
        foreach ($domains as $domain_info) {
            $domains_with_keys .= '    <div class="mb6 padding-6 theme-box">
        <div class="mb3"><strong>域名:</strong> ' . esc_html($domain_info->domain) . '</div>
        <div class="mb3"><strong>授权码:</strong> ' . esc_html($domain_info->auth_key) . '</div>
    </div>';
        }
        $domains_with_keys .= '</div>';
    } else {
        $domains_with_keys = '<div class="text-center c-gray">暂无授权域名</div>';
    }

    // 生成彩色头部
    $header = zib_get_modal_colorful_header('modal-colorful-header colorful-bg c-blue', '<i class="csf-tab-icon fa fa-fw fa-gitlab"></i>', '授权详情');

    // 生成拟态框HTML
    $modal_html = '    <div class="bbs-modal-form">' . $header . '<div>
        <ul class="muted-2-color theme-box mb10">
            <li class="c-blue"><i class="fa fa-info-circle mr6"></i>授权详情查询结果</li>
        </ul>
        
        <div class="mb6">
            <div class="padding-6 theme-box">
                <div class="mb3"><strong>购买时间:</strong> ' . esc_html($order_info[0]['pay_time']) . '</div>
                <div class="mb3"><strong>订单号:</strong> ' . esc_html($order_info[0]['order_num']) . '</div>
                <div><strong>支付金额:</strong> ' . esc_html($order_info[0]['order_price']) . ' ' . ($order_info[0]['pay_type'] === 'points' ? '积分' : '元') . '</div>
            </div>
        </div>

        <div class="mb6">
                <ul class="muted-2-color theme-box mb10">
            <li class="c-blue"><i class="fa fa-info-circle mr6"></i>授权域名及授权码:</li>
        </ul>
            <div class="muted-color">
                ' . $domains_with_keys . '
            </div>
        </div>
    </div></div>';


    return $modal_html;
}

/**
 * @description: 生成编辑用户授权拟态框
 *
 * @param int|string $user_id 用户ID
 * @param int|string $product_id 产品ID
 *
 * @return string 生成的编辑授权拟态框的HTML
 */
function xk_auth_edit_authorization_modal($user_id = '', $product_id = '') {
    if (!$user_id || !$product_id) {
        return '<div class="text-center py20 c-red">数据获取错误，请刷新后重试</div>';
    }

    // 获取订单信息
    $order_info = xk_auth_product_order_date($user_id, $product_id);
    if (empty($order_info)) {
        return '<div class="text-center py20 c-red">未找到该用户的订单信息</div>';
    }

    // 获取授权域名
    $domains = '';
    if (function_exists('xk_auth_for_product_domain')) {
        $domains = xk_auth_for_product_domain($user_id, $product_id, 'select');
    }

    // 生成彩色头部
    $header = zib_get_modal_colorful_header('modal-colorful-header colorful-bg c-blue', '<i class="csf-tab-icon fa fa-fw fa-gitlab"></i>', '编辑授权');

    // 生成拟态框HTML
    $modal_html = '    <form class="bbs-modal-form">' . $header . '<div>
        <ul class="muted-2-color theme-box mb10">
            <li class="c-blue"><i class="fa fa-info-circle mr6"></i>编辑用户授权信息</li>
        </ul>
        
        <div class="mb6">
            <div class="muted-color mb6">选择需更换域名:</div>
            <div class="muted-color">
                ' . $domains . '
            </div>
        </div>
        
        <div class="mb6">
            <div class="muted-color mb6">输入新域名:</div>
            <div class="flex ac">
                <input class="form-control" name="change_new_domain" type="text" placeholder="请输入新的授权域名">
            </div>
        </div>
        
        <div class="mb6">
            <div class="muted-color mb6">设置到期时间:</div>
            <div class="flex ac">
                <input class="form-control" name="expire_time" type="datetime-local" placeholder="请选择到期时间">
            </div>
        </div>
        
        <div class="mb6 text-center">
            <span class="muted-color mb6">永久授权:</span>
            <input type="checkbox" name="permanent" value="1">
        </div>
        
        <script>
        document.querySelector(\'form.bbs-modal-form\').addEventListener(\'submit\', function(e) {
            e.preventDefault();
            
            // 收集表单数据
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // 验证是否选择了域名
            if (!data.change_past_domain) {
                ElMessage.error(\'请选择一个域名\');
                return;
            }
            
            // 提交表单
            $.post(\'admin-ajax.php\', data).done(function(res) {
                if (res.error) {
                    if (res.msg) {
                        ElMessage.error(res.msg);
                    }
                } else {
                    if (res.msg) {
                        ElMessage.success(res.msg);
                    }
                    if (res.reload) {
                        location.reload();
                    }
                }
            }).fail(function(xhr, status, error) {
                ElMessage.error(\'提交失败，请检查控制台日志\');
            });
        });
        </script>
        
        <div class="mb6">
            <div class="muted-color mb6">设置状态:</div>
            <div class="flex ac">
                <select class="form-control" name="status">
                    <option value="1">启用</option>
                    <option value="0">禁用</option>
                </select>
            </div>
        </div>
        
        <input type="hidden" name="product_id" value="' . $product_id . '">
        <input type="hidden" name="user_id" value="' . $user_id . '">
        <input type="hidden" name="action" value="edit_auth">
        
        <div class="box-body text-center nobottom">
            <button type="submit" class="but jb-blue radius btn-block padding-lg wp-ajax-submit">
                <i class="fa fa-check" aria-hidden="true"></i>保存修改
            </button>
        </div>
    </div></form>';

    return $modal_html;
}

// 添加AJAX处理函数
function xk_auth_view_authorization_callback() {
    // 验证请求来源IP
    if (!xk_auth_validate_request_ip()) {
        wp_send_json_error(array('msg' => '请求来源无效'));
    }

    // 验证nonce
    $nonce = isset($_GET['security']) ? sanitize_text_field($_GET['security']) : '';
    if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
        wp_send_json_error(array('msg' => '请求已过期，请刷新页面重试'));
    }

    // 检查请求频率限制
    $rate_limit_check = xk_auth_check_admin_api_rate_limit('view_authorization', 5, 60);
    if (is_array($rate_limit_check)) {
        wp_send_json_error($rate_limit_check);
    }

    // 验证权限
    $user_id = get_current_user_id();
    $is_admin = current_user_can('manage_options');
    $options = get_option('xk_auth_setting', array());
    $authorized_users = isset($options['authorized_users']) ? $options['authorized_users'] : array();
    $is_authorized_user = in_array($user_id, $authorized_users);
    
    if (!$is_admin && !$is_authorized_user) {
        wp_send_json_error(array('msg' => '您没有权限执行此操作'));
    }

    $view_user_id = isset($_GET['user_id']) ? sanitize_text_field($_GET['user_id']) : '';
    $product_id = isset($_GET['product_id']) ? sanitize_text_field($_GET['product_id']) : '';

    if (!$view_user_id || !$product_id) {
        wp_send_json_error(array('msg' => '参数错误'));
    }

    // 记录前端管理操作日志
    // 获取用户和产品信息用于日志
    $user = get_userdata($view_user_id);
    $user_name = $user ? $user->display_name . ' (ID: ' . $view_user_id . ')' : '用户ID: ' . $view_user_id;
    
    // 获取产品名称
    $product_settings = xk_auth('product_settings', array());
    $product_name = '产品ID: ' . $product_id;
    foreach ($product_settings as $product) {
        if (isset($product['product_id']) && $product['product_id'] == $product_id && isset($product['product_name'])) {
            $product_name = $product['product_name'] . ' (ID: ' . $product_id . ')';
            break;
        }
    }
    
    // 记录查看授权操作日志
    xk_auth_log_frontend_admin_action(
        'view_authorization',
        $user_name,
        $product_name,
        '查看用户授权详情'
    );

    // 生成拟态框内容
    $modal_content = xk_auth_view_authorization_modal($view_user_id, $product_id);
    echo $modal_content;
    wp_die();
}
add_action('wp_ajax_xk_auth_view_authorization', 'xk_auth_view_authorization_callback');

/**
 * @description: 处理编辑授权的AJAX请求
 */
function xk_auth_edit_authorization_callback() {
    // 验证请求来源IP
    if (!xk_auth_validate_request_ip()) {
        wp_send_json_error(array('msg' => '请求来源无效'));
    }

    // 验证nonce
    $nonce = isset($_GET['security']) ? sanitize_text_field($_GET['security']) : '';
    if (empty($nonce) || !wp_verify_nonce($nonce, 'xk_auth_nonce')) {
        wp_send_json_error(array('msg' => '请求已过期，请刷新页面重试'));
    }

    // 检查请求频率限制
    $rate_limit_check = xk_auth_check_admin_api_rate_limit('edit_authorization', 5, 60);
    if (is_array($rate_limit_check)) {
        wp_send_json_error($rate_limit_check);
    }

    // 验证权限
    $current_user_id = get_current_user_id();
    $is_admin = current_user_can('manage_options');
    $options = get_option('xk_auth_setting', array());
    $authorized_users = isset($options['authorized_users']) ? $options['authorized_users'] : array();
    $is_authorized_user = in_array($current_user_id, $authorized_users);
    
    if (!$is_admin && !$is_authorized_user) {
        wp_send_json_error(array('msg' => '您没有权限执行此操作'));
    }

    $user_id = isset($_GET['user_id']) ? sanitize_text_field($_GET['user_id']) : '';
    $product_id = isset($_GET['product_id']) ? sanitize_text_field($_GET['product_id']) : '';

    if (!$user_id || !$product_id) {
        wp_send_json_error(array('msg' => '参数错误'));
    }

    // 生成拟态框内容
    $modal_content = xk_auth_edit_authorization_modal($user_id, $product_id);
    echo $modal_content;
    wp_die();
}
add_action('wp_ajax_xk_auth_edit_authorization', 'xk_auth_edit_authorization_callback');

/**
 * @description: 处理编辑授权信息的 AJAX 请求
 */
function xk_auth_edit_authorization_save() {
    // 验证请求来源IP
    if (!xk_auth_validate_request_ip()) {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '请求来源无效',
            'reload' => false
        ));
        exit;
    }

    // 检查请求频率限制
    $rate_limit_check = xk_auth_check_admin_api_rate_limit('save_authorization', 5, 60);
    if (is_array($rate_limit_check)) {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => $rate_limit_check['msg'],
            'reload' => false
        ));
        exit;
    }

    // 验证权限
    $current_user_id = get_current_user_id();
    $is_admin = current_user_can('manage_options');
    $options = get_option('xk_auth_setting', array());
    $authorized_users = isset($options['authorized_users']) ? $options['authorized_users'] : array();
    $is_authorized_user = in_array($current_user_id, $authorized_users);
    
    if (!$is_admin && !$is_authorized_user) {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '您没有权限执行此操作',
            'reload' => false
        ));
        exit;
    }

    // 检查动作标识
    if (!isset($_POST['action']) || $_POST['action'] !== 'edit_auth') {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '请求动作错误',
            'reload' => false
        ));
        exit;
    }

    // 读取表单数据
    $change_past_domain = !empty($_POST['change_past_domain']) ? sanitize_text_field($_POST['change_past_domain']) : '';
    $change_new_domain = !empty($_POST['change_new_domain']) ? sanitize_text_field($_POST['change_new_domain']) : '';
    $user_id = !empty($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $product_id = !empty($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $expire_time = !empty($_POST['expire_time']) ? sanitize_text_field($_POST['expire_time']) : '';
    $permanent = isset($_POST['permanent']) ? intval($_POST['permanent']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '1';

    if (!$user_id || !$product_id) {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '参数错误',
            'reload' => false
        ));
        exit;
    }
    
    // 验证是否选择了域名
    if (empty($change_past_domain)) {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '请选择一个域名',
            'reload' => false
        ));
        exit;
    }

    // 验证状态值
    if (!in_array($status, array('0', '1'))) {
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '状态值无效',
            'reload' => false
        ));
        exit;
    }

    // 检查是否已经存在该新域名
    global $wpdb;
    $table_name = $wpdb->prefix . 'product_auths';
    
    // 如果提供了新域名，检查是否已经存在
    if (!empty($change_new_domain)) {
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT domain FROM $table_name WHERE user_id = %d AND product_id = %d AND domain = %s",
            $user_id, $product_id, $change_new_domain
        ));

        if ($existing) {
            echo json_encode(array(
                'error' => 1,
                'ys' => 'danger',
                'msg' => '此域名已经存在',
                'reload' => false
            ));
            exit;
        }
    }

    // 准备更新数据
    $update_data = array(
        'status' => $status,
        'operation_time' => current_time('mysql'),
        'log' => '管理员修改了授权信息'
    );
    
    // 如果提供了新域名，添加到更新数据
    if (!empty($change_new_domain) && !empty($change_past_domain)) {
        $update_data['domain'] = $change_new_domain;
        $update_data['log'] = '管理员变更域名授权(' . $change_past_domain . '变更为' . $change_new_domain . ')';
    }
    
    // 处理到期时间
    if (!empty($expire_time)) {
        // 有指定到期时间，转换为正确的格式
        $db_expire_time = date('Y-m-d H:i:s', strtotime($expire_time));
        $update_data['expire_time'] = $db_expire_time;
    } elseif ($permanent) {
        // 永久授权，到期时间为null
        $update_data['expire_time'] = null;
    }

    // 准备更新条件
    $where_condition = array(
        'user_id' => $user_id,
        'product_id' => $product_id,
    );
    
    // 如果提供了原域名，添加到更新条件
    if (!empty($change_past_domain)) {
        $where_condition['domain'] = $change_past_domain;
    }

    // 执行更新操作
    $result = $wpdb->update(
        $table_name,
        $update_data,
        $where_condition,
        array(
            '%s', // status (修改为字符串类型)
            '%s', // operation_time
            '%s', // log
            isset($update_data['domain']) ? '%s' : '',
            isset($update_data['expire_time']) ? ($update_data['expire_time'] === null ? '%s' : '%s') : ''
        ),
        array(
            '%d', // user_id
            '%d', // product_id
            isset($where_condition['domain']) ? '%s' : ''
        )
    );

    if (false !== $result) {
        // 更新成功
        // 清除仪表盘数据缓存
        delete_transient('xk_auth_dashboard_data');
        
        // 获取用户和产品信息用于日志
        $user = get_userdata($user_id);
        $user_name = $user ? $user->display_name . ' (ID: ' . $user_id . ')' : '用户ID: ' . $user_id;
        
        // 获取产品名称
        $product_settings = xk_auth('product_settings', array());
        $product_name = '产品ID: ' . $product_id;
        foreach ($product_settings as $product) {
            if (isset($product['product_id']) && $product['product_id'] == $product_id && isset($product['product_name'])) {
                $product_name = $product['product_name'] . ' (ID: ' . $product_id . ')';
                break;
            }
        }
        
        // 构建操作详情
        $action_detail = '修改授权状态为: ' . ($status == '1' ? '启用' : '禁用');
        if (!empty($change_new_domain) && !empty($change_past_domain)) {
            $action_detail .= '，域名从 ' . $change_past_domain . ' 变更为 ' . $change_new_domain;
        }
        if (!empty($expire_time)) {
            $action_detail .= '，到期时间设置为: ' . $expire_time;
        } elseif ($permanent) {
            $action_detail .= '，设置为永久授权';
        }
        
        // 记录前端管理操作日志
        xk_auth_log_frontend_admin_action(
            'edit_authorization',
            $user_name,
            $product_name,
            $action_detail
        );
        
        echo json_encode(array(
            'error' => 0,
            'ys' => 'success',
            'msg' => '授权更新成功',
            'reload' => true
        ));
    } else {
        // 更新失败或没有变化
        echo json_encode(array(
            'error' => 1,
            'ys' => 'danger',
            'msg' => '授权更新失败，请稍后再试',
            'reload' => false
        ));
    }
    exit;
}

// 注册AJAX动作钩子
add_action('wp_ajax_edit_auth', 'xk_auth_edit_authorization_save');

/**
 * 生成添加授权模态框的HTML表单
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 *
 * @return string 生成的添加授权模态框的HTML表单
 */
function xk_auth_increase_modal($user_id = '', $product_id = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!$product_id) {
        zib_ajax_notice_modal('danger', '数据获取错误，请刷新后重试');
    }

    // 获取微信客服设置
    $wechat_customer_service_image = xk_auth('wechat_customer_service_image', 'https://www.xkzhi.cn/wp-content/uploads/2025/08/20250817123121664-576d5178d5d3bc2fc5e1348215ed46f4.jpg');
    $wechat_customer_service_mobile_link = xk_auth('wechat_customer_service_mobile_link', 'https://work.weixin.qq.com/kfid/kfc34fed29eefcf98f7');

    // 拉取授权日志信息
    if (!$product_id) {
        zib_ajax_notice_modal('danger', '产品ID获取错误，请刷新后重试');
    }
    // 在JavaScript中输出产品ID到控制台进行调试
    echo '<script>console.log("[XK Auth] 产品ID: " + "' . esc_js($product_id) . '");</script>';
    $aut_logs = xk_auth_change_transference('', $product_id);

    // 如果可授权数小于或等于0则视为授权额度已达到上限
    if ($aut_logs['remaining_auths'] <= 0) {
        zib_ajax_notice_modal('danger', '可授权额度已达到上限');
    }

    $form = '
        <div class="mb10 touch">
            <div class="mr10 inflex em12 mb20">
                <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>绑定授权</b>
            </div>
            <div class="muted-color">更换要求及说明:</div>
            <ul class="muted-2-color theme-box">
                <li class="c-red" style="--this-color: #f737a3;"><i class="fa fa-info-circle mr6"></i>授权域名名额添加完之后才能更换域名</li>
                <li class="c-red"><i class="fa fa-info-circle mr6"></i>更换前域名和新域名所有人为同一人</li>
                <li class="c-red" style="--this-color: #ff6643;"><i class="fa fa-info-circle mr6"></i>或者更换前域名和新域名备案人为同一人</li>
                <li class="mb10 em09">如果系统自动审核失败，请准备相关截图及待更换的域名与微信客服联系</li>

                <li class="">
                    <div class="text-center hide-sm" style="width: 120px;">
                        <img src="' . $wechat_customer_service_image . '">
                        <div class="px12">扫码联系微信客服</div>
                    </div>
                    <a target="_blank" href="' . $wechat_customer_service_mobile_link . '" class="but c-blue show-sm"><i class="fa fa-wechat"></i>点击联系微信客服</a>
                </li>
                </ul>
                <form>
                    <div class="mb10">
                        <input class="form-control" name="increase_domain" type="text" placeholder="请输入授权域名">
                    </div>
                    <input type="hidden" name="product_id" value="' . $product_id . '">
                    <div class="box-body text-center nobottom">
                        <input type="hidden" name="action" value="increase_auth">
                        <button type="button" zibajax="submit" class="but jb-blue radius btn-block padding-lg" name="submit"><i class="fa fa-check mr10"></i>确认提交</button>
                    </div>
                </form>           
            </div>
        </div>
    ';

    return $form;
}

/**
 * 生成举报功能的模态框
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 *
 * @return string 生成的举报功能模态框的HTML表单
 */
function xk_auth_report_modal($user_id = '', $product_id = '')
{
    // 检查举报功能是否开启
    $report_enabled = xk_auth('report_enabled', true);

    if (!$report_enabled) {
        zib_ajax_notice_modal('danger', '此功能未开启');
    }
    
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!$user_id) {
        zib_ajax_notice_modal('danger', '请先登录');
    }

    // 获取产品列表
    $product_settings = xk_auth('product_settings', array());
    $product_list = array();
    if (!empty($product_settings) && is_array($product_settings)) {
        foreach ($product_settings as $product) {
            if (!empty($product['product_id']) && !empty($product['product_name'])) {
                $product_list[] = array(
                    'id' => intval($product['product_id']),
                    'name' => sanitize_text_field($product['product_name'])
                );
            }
        }
    }

    // 从设置中获取举报类型
    $report_types = xk_auth('report_types', array(
        array('key' => 'piracy', 'label' => '盗版使用'),
        array('key' => 'unauthorized', 'label' => '未授权使用'),
        array('key' => 'fake', 'label' => '假冒产品'),
        array('key' => 'other', 'label' => '其他问题')
    ));
    
    // 转换为关联数组格式
    $report_types_assoc = array();
    foreach ($report_types as $type) {
        if (isset($type['key']) && isset($type['label'])) {
            $report_types_assoc[$type['key']] = $type['label'];
        }
    }
    
    // 使用转换后的关联数组
    $report_types = $report_types_assoc;

    // 生成举报功能模态框
    $form = '    
        <div class="mb10 touch">
            <div class="mr10 inflex em12 mb20">
                <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>举报中心</b>
            </div>
            <div class="padding-10">
                <div class="muted-color mb10">请填写举报信息，我们将尽快处理</div>
                
                <form>
                    <div class="mb10">
                        <div class="mb6">选择产品</div>
                        <select class="form-control" name="report_product_id" required>
                            <option value="">请选择产品</option>';
    
    // 添加产品选项
    foreach ($product_list as $product) {
        $form .= '<option value="' . esc_attr($product['id']) . '">' . esc_html($product['name']) . '</option>';
    }
    
    $form .= '                    </select>
                    </div>
                    
                    <div class="mb10">
                        <div class="mb6">举报类型</div>
                        <select class="form-control" name="report_type" required>
                            <option value="">请选择举报类型</option>';
    
    // 添加举报类型选项
    foreach ($report_types as $value => $label) {
        $form .= '<option value="' . esc_attr($value) . '">' . esc_html($label) . '</option>';
    }
    
    $form .= '                    </select>
                    </div>
                    
                    <div class="mb10">
                        <div class="mb6">举报域名</div>
                        <input class="form-control" name="report_url" type="text" placeholder="请输入举报域名（如盗版网站域名）" pattern="(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)">
                    </div>
                    
                    <div class="mb10">
                        <div class="mb6">举报内容</div>
                        <textarea class="form-control" name="report_content" rows="4" placeholder="请详细描述举报内容" required maxlength="500"></textarea>
                    </div>
                    
                    <input type="hidden" name="user_id" value="' . esc_attr($user_id) . '">
                    <input type="hidden" name="security" value="' . wp_create_nonce('submit_report_nonce') . '">
                    <div class="box-body text-center nobottom">
                        <input type="hidden" name="action" value="submit_report">
                        <button type="button" zibajax="submit" class="but jb-blue radius btn-block padding-lg" name="submit"><i class="fa fa-check mr10"></i>提交举报</button>
                    </div>
                </form>
            </div>
        </div>';

    return $form;
}
/**
 * 生成变更授权前的验证模态框
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 *
 * @return string 生成的验证模态框的HTML表单
 */
function xk_auth_verify_before_change_modal($user_id = '', $product_id = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!$product_id) {
        // 修复：返回错误信息而不是调用可能不存在的函数
        zib_ajax_notice_modal('danger', '产品ID获取错误，请刷新后重试');
    }

    // 获取验证设置 - 如果 xk_auth 函数不存在，使用默认值
    $enable_verify = function_exists('xk_auth') ? xk_auth('enable_verify', false) : false;
    $verify_type = function_exists('xk_auth') ? xk_auth('verify_type', 'email') : 'email';

    // 获取用户信息
    $current_user = get_user_by('ID', $user_id);
    if (!$current_user) {
        zib_ajax_notice_modal('danger', '用户不存在');
    }

    $user_email = $current_user->user_email;
    $user_phone = get_user_meta($user_id, 'mobile', true);

    // 判断使用哪种验证方式
    $use_email = ($verify_type == 'email' || empty($user_phone));
    $use_phone = ($verify_type == 'phone' && !empty($user_phone));

    // 显示的联系方式
    $contact_value = $use_email ? $user_email : $user_phone;
    $contact_type = $use_email ? 'email' : 'phone';
    $contact_label = $use_email ? '邮箱' : '手机号';

    // 获取ajaxurl
    $ajaxurl = admin_url('admin-ajax.php');

    // 获取微信客服设置
    $wechat_customer_service_image = function_exists('xk_auth') ? xk_auth('wechat_customer_service_image', 'https://www.xkzhi.cn/wp-content/uploads/2025/08/20250817123121664-576d5178d5d3bc2fc5e1348215ed46f4.jpg') : 'https://www.xkzhi.cn/wp-content/uploads/2025/08/20250817123121664-576d5178d5d3bc2fc5e1348215ed46f4.jpg';
    $wechat_customer_service_mobile_link = function_exists('xk_auth') ? xk_auth('wechat_customer_service_mobile_link', 'https://work.weixin.qq.com/kfid/kfca772106896c80838') : 'https://work.weixin.qq.com/kfid/kfca772106896c80838';

    // 在JavaScript中输出产品ID到控制台进行调试
    echo '<script>console.log("[XK Auth] 验证授权产品ID: " + "' . esc_js($product_id) . '");</script>';
    // 拉取授权日志信息 - 检查函数是否存在
    $aut_logs = function_exists('xk_auth_change_transference') ? xk_auth_change_transference('', $product_id) : '';

    // 生成验证和变更授权整合表单
    $form = '    
        <style>
            /* 只读输入框样式，继承form-control的自动主题切换 */
            .form-control[readonly],
            .form-control.readonly {
                /* 使用CSS变量实现自动主题切换 */
                background-color: var(--main-bg-color) !important;
                color: var(--main-color) !important;
                border: 1px solid var(--main-border-color) !important;
                opacity: 1 !important;
                cursor: not-allowed;
            }
            
            /* 确保在所有主题下都有良好的可读性 */
            .form-control[readonly],
            .form-control.readonly {
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
            }
        </style>
        <div class="mb10 touch">
            <!-- 验证码验证部分 - 根据设置决定是否显示 -->
            <div id="xk-verify-section" ' . ($enable_verify ? '' : 'style="display: none;"') . '>
                <div class="mr10 inflex em12 mb20">
                    <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>安全验证</b>
                </div>
                <div class="padding-10">
                    <div class="muted-color mb10">为了您的账号安全，变更授权需要进行身份验证</div>
                    
                    <form id="xk-verify-form">
                        <div class="mb10">
                            <div class="mb6">您的' . $contact_label . '</div>
                            <div class="form-control readonly" readonly="readonly">' . esc_html($contact_value) . '</div>
                            <input type="hidden" name="contact_type" value="' . esc_attr($contact_type) . '">
                            <input type="hidden" name="contact_value" value="' . esc_attr($contact_value) . '">
                        </div>
                        <div class="mb10">
                            <div class="flex">
                                <input class="form-control" name="captcha" type="text" placeholder="请输入验证码" style="flex: 1;">
                                <button type="button" id="xk-send-captcha" class="but jb-blue ml10" style="min-width: 120px;">发送验证码</button>
                            </div>
                        </div>
                        <input type="hidden" name="product_id" value="' . esc_attr($product_id) . '">
                        <div class="box-body text-center nobottom">
                            <input type="hidden" name="action" value="xk_verify_before_change_auth">
                            <button type="button" id="xk-verify-submit" class="but jb-blue radius btn-block padding-lg" name="submit"><i class="fa fa-check mr10"></i>确认验证</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- 变更授权部分 -->
            <div id="xk-change-auth-section" style="display: ' . ($enable_verify ? 'none' : 'block') . ';">
                <div class="mr10 inflex em12 mb20">
                    <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>变更授权</b>
                </div>
                <div class="padding-10">
                <div class="muted-color">更换要求及说明:</div>
                <ul class="muted-2-color theme-box">
                    <li class="c-red" style="--this-color: #f737a3;"><i class="fa fa-info-circle mr6"></i>授权域名名额添加完之后才能更换域名</li>
                    <li class="c-red"><i class="fa fa-info-circle mr6"></i>更换前域名和新域名所有人为同一人</li>
                    <li class="c-red" style="--this-color: #ff6643;"><i class="fa fa-info-circle mr6"></i>或者更换前域名和新域名备案人为同一人</li>
                    <li class="mb10 em09">如果系统自动审核失败，请准备相关截图及待更换的域名与微信客服联系</li>

                    <li class="">
                        <div class="text-center hide-sm" style="width: 120px;">
                            <img src="' . esc_url($wechat_customer_service_image) . '">
                            <div class="px12">扫码联系微信客服</div>
                        </div>
                        <a target="_blank" href="' . esc_url($wechat_customer_service_mobile_link) . '" class="but c-blue show-sm"><i class="fa fa-wechat"></i>点击联系微信客服</a>
                    </li>
                    </ul>

                    <form id="xk-change-auth-form">
                        <div class="mb10">
                        <div class="mb6">选择需更换域名</div>
                            <div class="muted-color">
                                ' . (function_exists('xk_auth_for_product_domain') ? xk_auth_for_product_domain('', $product_id, 'select') : '') . '
                            </div>
                        </div>
                        <div class="mb10">
                        <div class="mb10">输入新域名</div>
                            <input class="form-control" name="change_new_domain" type="text" placeholder="请输入新的授权域名">
                        </div>
                        <input type="hidden" name="product_id" value="' . esc_attr($product_id) . '">
                        <div class="box-body text-center nobottom">
                            <input type="hidden" name="action" value="change_auth">
                            <button type="button" zibajax="submit" class="but jb-blue radius btn-block padding-lg" name="submit"><i class="fa fa-check mr10"></i>确认提交</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script type="text/javascript">
        // 全局调试功能，确保可以在控制台访问
           /* if (typeof window !== "undefined" && typeof window.console !== "undefined") {
                window.xkAuthSkipVerify = function(productId) {
                    console.log("跳过验证码验证，直接显示变更授权表单");
                    jQuery.ajax({
                        url: "' . esc_js($ajaxurl) . '",
                        type: "POST",
                        data: {
                            action: "xk_set_verify_passed",
                            product_id: productId
                        },
                        success: function(response) {
                            // 直接显示变更授权部分
                            jQuery("#xk-verify-section").hide();
                            jQuery("#xk-change-auth-section").show();
                            
                            // 触发窗口调整事件，确保样式正确应用
                            jQuery(window).trigger("resize");
                            
                            // 重新初始化zibajax绑定
                            if (typeof zib_ajax_init === "function") {
                                zib_ajax_init();
                            }
                            
                            console.log("已成功跳过验证，显示变更授权表单");
                        }
                    });
                };
            }*/
        
        jQuery(document).ready(function($) {
            var ajaxurl = "' . esc_js($ajaxurl) . '";
            
            // 清除之前的验证通过状态，确保每次打开模态框都是新的验证流程
            if (typeof window.xkAuthVerifyPassed !== "undefined") {
                delete window.xkAuthVerifyPassed;
            }
            
            // 清除可能存在的验证成功提示 - 安全检查notyf类型和方法存在性
            if (typeof notyf !== "undefined" && typeof notyf === "object" && typeof notyf.dismissAll === "function") {
                notyf.dismissAll();
            }
            
            // 每次打开模态框时，重置验证状态和UI
            jQuery("#xk-download-verify-section").show();
            jQuery("#xk-download-confirm-section").hide();
            jQuery("#xk-download-verify-form [name=captcha]").val("");
            jQuery("#xk-download-verify-submit").attr("disabled", false).html("<i class=\"fa fa-check mr10\"></i>确认验证");
            
            // 在控制台打印调试信息
           /* if (typeof window !== "undefined" && typeof window.console !== "undefined") {
                var product_id = jQuery("[name=product_id]").val();
                console.log("=== XK-AUTH 调试模式 ===");
                console.log("要跳过验证码验证，请在控制台执行:");
                console.log("xkAuthSkipVerify(\"" + product_id + "\")");
            }*/
            
            // 发送验证码 - 使用window对象存储冷却状态，确保跨模态框实例保持
            if (typeof window.xkAuthCaptchaState === "undefined") {
                window.xkAuthCaptchaState = {
                    countdown: 0,
                    timer: null,
                    startTime: 0
                };
            }
            
            // 检查是否需要恢复冷却状态
            function checkAndRestoreCountdown() {
                var btn = jQuery("#xk-send-captcha");
                var currentTime = new Date().getTime();
                var elapsedTime = Math.floor((currentTime - window.xkAuthCaptchaState.startTime) / 1000);
                
                // 如果还有冷却时间
                if (window.xkAuthCaptchaState.countdown > 0 && elapsedTime < 60) {
                    var remaining = 60 - elapsedTime;
                    btn.attr("disabled", true);
                    btn.addClass("disabled");
                    btn.text(remaining + "秒后重新发送");
                    
                    // 清除之前的计时器
                    if (window.xkAuthCaptchaState.timer) {
                        clearInterval(window.xkAuthCaptchaState.timer);
                    }
                    
                    // 启动新的计时器
                    window.xkAuthCaptchaState.timer = setInterval(function() {
                        remaining--;
                        btn.text(remaining + "秒后重新发送");
                        if (remaining <= 0) {
                            clearInterval(window.xkAuthCaptchaState.timer);
                            btn.attr("disabled", false);
                            btn.removeClass("disabled");
                            btn.text("发送验证码");
                            window.xkAuthCaptchaState.countdown = 0;
                            window.xkAuthCaptchaState.startTime = 0;
                        }
                    }, 1000);
                }
            }
            
            function startCountdown() {
                var btn = jQuery("#xk-send-captcha");
                btn.attr("disabled", true);
                btn.addClass("disabled");
                window.xkAuthCaptchaState.countdown = 60;
                window.xkAuthCaptchaState.startTime = new Date().getTime();
                btn.text(window.xkAuthCaptchaState.countdown + "秒后重新发送");
                
                // 清除之前的计时器
                if (window.xkAuthCaptchaState.timer) {
                    clearInterval(window.xkAuthCaptchaState.timer);
                }
                
                window.xkAuthCaptchaState.timer = setInterval(function() {
                    window.xkAuthCaptchaState.countdown--;
                    btn.text(window.xkAuthCaptchaState.countdown + "秒后重新发送");
                    if (window.xkAuthCaptchaState.countdown <= 0) {
                        clearInterval(window.xkAuthCaptchaState.timer);
                        btn.attr("disabled", false);
                        btn.removeClass("disabled");
                        btn.text("发送验证码");
                        window.xkAuthCaptchaState.countdown = 0;
                        window.xkAuthCaptchaState.startTime = 0;
                    }
                }, 1000);
            }
            
            // 页面加载时检查并恢复冷却状态
            checkAndRestoreCountdown();
            
            jQuery("#xk-send-captcha").on("click", function() {
                if (window.xkAuthCaptchaState.countdown > 0) return;
                
                var contact_type = jQuery("[name=contact_type]").val();
                var contact_value = jQuery("[name=contact_value]").val();
                var product_id = jQuery("[name=product_id]").val();
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: {
                        action: "xk_send_verify_captcha",
                        contact_type: contact_type,
                        contact_value: contact_value,
                        product_id: product_id
                    },
                    success: function(response) {
                        var data;
                        console.log("验证码发送响应:", response);
                        
                        try {
                            if (typeof response === "object") {
                                data = response;
                            } else {
                                var cleanResponse = response.trim();
                                data = JSON.parse(cleanResponse);
                            }
                            
                            if (!data || typeof data !== "object") {
                                data = { error: 1, msg: "无效的响应数据" };
                            }
                            
                            console.log("解析后的数据:", data);
                            
                            // 使用更安全的通知方式
                            if (data.error === 0 || (data.msg && (data.msg.includes("成功") || data.msg.includes("验证码已发送")))) {
                                if (typeof notyf !== "undefined") {
                                    notyf(data.msg || "验证码发送成功", "success");
                                } else {
                                    alert(data.msg || "验证码发送成功");
                                }
                                startCountdown();
                            } else {
                                if (typeof notyf !== "undefined") {
                                    notyf(data.msg || "验证码发送失败", "danger");
                                } else {
                                    alert(data.msg || "验证码发送失败");
                                }
                            }
                        } catch (e) {
                            console.error("响应解析错误:", e);
                            // 即使解析失败也启动倒计时
                            if (typeof notyf !== "undefined") {
                                notyf("验证码可能已发送，请检查您的邮箱/手机", "warning");
                            } else {
                                alert("验证码可能已发送，请检查您的邮箱/手机");
                            }
                            startCountdown();
                        }
                    },
                    error: function() {
                        if (typeof notyf !== "undefined") {
                            notyf("发送验证码失败，请重试", "danger");
                        } else {
                            alert("发送验证码失败，请重试");
                        }
                    }
                });
            });
            
            // 提交验证
            jQuery("#xk-verify-submit").on("click", function() {
                var captcha = jQuery("[name=captcha]").val();
                var contact_type = jQuery("[name=contact_type]").val();
                var contact_value = jQuery("[name=contact_value]").val();
                var product_id = jQuery("[name=product_id]").val();
                
                if (!captcha) {
                    if (typeof notyf !== "undefined") {
                        notyf("请输入验证码", "warning");
                    } else {
                        alert("请输入验证码");
                    }
                    return;
                }
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: {
                        action: "xk_check_verify_captcha",
                        captcha: captcha,
                        contact_type: contact_type,
                        contact_value: contact_value,
                        product_id: product_id
                    },
                    success: function(response) {
                        var data;
                        console.log("验证码验证响应:", response);
                        
                        try {
                            if (typeof response === "object") {
                                data = response;
                            } else {
                                var cleanResponse = response.trim();
                                data = JSON.parse(cleanResponse);
                            }
                            
                            if (!data || typeof data !== "object") {
                                data = { error: 1, msg: "无效的响应数据" };
                            }
                            
                            console.log("解析后的数据:", data);
                            
                            if (data.error === 0 || data.success || (data.msg && data.msg.includes("成功"))) {
                                // 验证成功后，隐藏验证部分，显示变更授权部分
                                jQuery("#xk-verify-section").hide();
                                jQuery("#xk-change-auth-section").show();
                                
                                // 触发窗口调整事件，确保样式正确应用
                                jQuery(window).trigger("resize");
                                
                                // 重新初始化zibajax绑定
                                if (typeof zib_ajax_init === "function") {
                                    zib_ajax_init();
                                }
                                
                                // 显示成功消息
                                if (typeof notyf !== "undefined") {
                                    notyf("验证成功，请填写变更授权信息", "success");
                                } else {
                                    alert("验证成功，请填写变更授权信息");
                                }
                            } else {
                                if (typeof notyf !== "undefined") {
                                    notyf(data.msg || "验证码错误或已过期，请重新获取验证码", "danger");
                                } else {
                                    alert(data.msg || "验证码错误或已过期，请重新获取验证码");
                                }
                            }
                        } catch (e) {
                            console.error("响应解析错误:", e);
                            if (typeof notyf !== "undefined") {
                                notyf("验证码验证过程中出现错误，请刷新页面后重试", "danger");
                            } else {
                                alert("验证码验证过程中出现错误，请刷新页面后重试");
                            }
                        }
                    },
                    error: function() {
                        if (typeof notyf !== "undefined") {
                            notyf("验证失败，请重试", "danger");
                        } else {
                            alert("验证失败，请重试");
                        }
                    }
                });
            });
        });
        </script>
    ';

    return $form; // 修复：添加了缺失的分号
}

/**
 * 生成变更授权模态框的HTML表单
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 *
 * @return string 生成的变更授权模态框的HTML表单
 */
function xk_auth_change_modal($user_id = '', $product_id = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!$product_id) {
        zib_ajax_notice_modal('danger', '数据获取错误，请刷新后重试');
    }

    // 获取微信客服设置
    $wechat_customer_service_image = xk_auth('wechat_customer_service_image', 'https://www.xkzhi.cn/wp-content/uploads/2025/08/20250817123121664-576d5178d5d3bc2fc5e1348215ed46f4.jpg');
    $wechat_customer_service_mobile_link = xk_auth('wechat_customer_service_mobile_link', 'https://work.weixin.qq.com/kfid/kfca772106896c80838');

    // 在JavaScript中输出产品ID到控制台进行调试
    echo '<script>console.log("[XK Auth] 变更授权产品ID: " + "' . esc_js($product_id) . '");</script>';
    // 拉取授权日志信息
    $aut_logs = xk_auth_change_transference('', $product_id);

    // 如果可授权数大于0则视为还有剩余未授权域名额度
    if ($aut_logs['remaining_auths'] > 0) {
        zib_ajax_notice_modal('danger', '请先授权完剩余域名再进行变更');
    }

    // 添加变更域名授权表单
    $form = '
        <div class="mb10 touch">
            <div class="mr10 inflex em12 mb20">
                <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>变更授权</b>
            </div>
            <div class="padding-10">
            <div class="muted-color">更换要求及说明:</div>
            <ul class="muted-2-color theme-box">
                <li class="c-red" style="--this-color: #f737a3;"><i class="fa fa-info-circle mr6"></i>授权域名名额添加完之后才能更换域名</li>
                <li class="c-red"><i class="fa fa-info-circle mr6"></i>更换前域名和新域名所有人为同一人</li>
                <li class="c-red" style="--this-color: #ff6643;"><i class="fa fa-info-circle mr6"></i>或者更换前域名和新域名备案人为同一人</li>
                <li class="mb10 em09">如果系统自动审核失败，请准备相关截图及待更换的域名与微信客服联系</li>

                <li class="">
                    <div class="text-center hide-sm" style="width: 120px;">
                        <img src="' . $wechat_customer_service_image . '">
                        <div class="px12">扫码联系微信客服</div>
                    </div>
                    <a target="_blank" href="' . $wechat_customer_service_mobile_link . '" class="but c-blue show-sm"><i class="fa fa-wechat"></i>点击联系微信客服</a>
                </li>
                </ul>

                <form>
                    <div class="mb10">
                    <div class="mb6">选择需更换域名</div>
                        <div class="muted-color">
                            ' . xk_auth_for_product_domain('', $product_id, 'select') . '
                        </div>
                    </div>
                    <div class="mb10">
                    <div class="mb10">输入新域名</div>
                        <input class="form-control" name="change_new_domain" type="text" placeholder="请输入新的授权域名">
                    </div>
                    <input type="hidden" name="product_id" value="' . $product_id . '">
                    <div class="box-body text-center nobottom">
                        <input type="hidden" name="action" value="change_auth">
                        <button type="button" zibajax="submit" class="but jb-blue radius btn-block padding-lg" name="submit"><i class="fa fa-check mr10"></i>确认提交</button>
                    </div>
                </form>
            </div>
        </div>
    ';

    return $form;
}

/**
 * 生成下载授权资源前的邮箱验证模态框
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 * @param string $resource_id 资源ID（可选，默认为空字符串）
 *
 * @return string 生成的下载授权资源邮箱验证模态框的HTML表单
 */
function xk_auth_download_resource_verify_modal($user_id = '', $product_id = '', $resource_id = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!$product_id) {
        zib_ajax_notice_modal('danger', '产品ID获取错误，请刷新后重试');
    }
    if (!$resource_id) {
        zib_ajax_notice_modal('danger', '资源ID获取错误，请刷新后重试');
    }

    // 获取用户信息
    $current_user = get_user_by('ID', $user_id);
    if (!$current_user) {
        zib_ajax_notice_modal('danger', '用户不存在');
    }

    $user_email = $current_user->user_email;
    $contact_type = 'email';
    $contact_label = '邮箱';
    $contact_value = $user_email;

    // 获取产品设置，用于获取下载链接
    $all_products = xk_auth('product_settings', array());
    $current_product = array();

    // 查找匹配的产品ID
    if (!empty($all_products)) {
        foreach ($all_products as $product) {
            if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                $current_product = $product;
                break;
            }
        }
    }

    // 获取ajaxurl
    $ajaxurl = admin_url('admin-ajax.php');

    // 生成下载按钮HTML
    $download_buttons_html = '';
    if (!empty($current_product)) {
        // 极速下载按钮 - 从后台设置中获取链接 (admin-settings.php#L288-295)
        if (isset($current_product['down_1'])) {
            $download_buttons_html .= '<a href="' . esc_url($current_product['down_1']) . '" target="_blank" class="but jb-green radius padding-lg"><i class="fa fa-download mr10"></i>极速下载</a>';
        }
        // 备用下载按钮 - 从后台设置中获取链接 (admin-settings.php#L296-303)
        if (isset($current_product['down_2'])) {
            $download_buttons_html .= '<a href="' . esc_url($current_product['down_2']) . '" target="_blank" class="but jb-cyan radius padding-lg"><i class="fa fa-download mr10"></i>备用下载</a>';
        }
    } else {
        $download_buttons_html = '<div class="c-red mb10">未找到产品下载链接，请联系管理员</div>';
    }

    // 生成验证表单
    $form = '    
        <style>
            /* 只读输入框样式，继承form-control的自动主题切换 */
            .form-control[readonly],
            .form-control.readonly {
                /* 使用CSS变量实现自动主题切换 */
                background-color: var(--main-bg-color) !important;
                color: var(--main-color) !important;
                border: 1px solid var(--main-border-color) !important;
                opacity: 1 !important;
                cursor: not-allowed;
            }
            
            /* 确保在所有主题下都有良好的可读性 */
            .form-control[readonly],
            .form-control.readonly {
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
            }
        </style>
        <div class="mb10 touch">
            <!-- 验证码验证部分 -->
            <div id="xk-download-verify-section">
                <div class="mr10 inflex em12 mb20">
                    <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>下载验证</b>
                </div>
                <div class="padding-10">
                    <div class="muted-color mb10">为了您的账号安全，下载授权资源需要进行身份验证</div>
                    
                    <form id="xk-download-verify-form">
                        <div class="mb10">
                            <div class="mb6">您的' . $contact_label . '</div>
                            <div class="form-control readonly" readonly="readonly">' . esc_html($contact_value) . '</div>
                            <input type="hidden" name="contact_type" value="' . esc_attr($contact_type) . '">
                            <input type="hidden" name="contact_value" value="' . esc_attr($contact_value) . '">
                        </div>
                        <div class="mb10">
                            <div class="flex">
                                <input class="form-control" name="captcha" type="text" placeholder="请输入验证码" style="flex: 1;">
                                <button type="button" id="xk-download-send-captcha" class="but jb-blue ml10" style="min-width: 120px;">发送验证码</button>
                            </div>
                        </div>
                        <input type="hidden" name="product_id" value="' . esc_attr($product_id) . '">
                        <input type="hidden" name="resource_id" value="' . esc_attr($resource_id) . '">
                        <div class="box-body text-center nobottom">
                            <button type="button" id="xk-download-verify-submit" class="but jb-blue radius btn-block padding-lg" name="submit"><i class="fa fa-check mr10"></i>确认验证</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- 下载确认部分 -->
            <div id="xk-download-confirm-section" style="display: none;">
                <div class="mr10 inflex em12 mb20">
                    <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg><b>下载确认</b>
                </div>
                <div class="padding-10">
                    <div class="muted-color mb10">身份验证成功，请选择下载方式</div>
                    
                    <div class="box-body text-center nobottom">
                        <div class="flex flex-col gap10">' . $download_buttons_html . '</div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            var ajaxurl = "' . esc_js($ajaxurl) . '";
            
            // 发送验证码 - 使用window对象存储冷却状态，确保跨模态框实例保持
            if (typeof window.xkAuthCaptchaState === "undefined") {
                window.xkAuthCaptchaState = {
                    countdown: 0,
                    timer: null,
                    startTime: 0
                };
            }
            
            // 检查是否需要恢复冷却状态
            function checkAndRestoreCountdown() {
                var btn = jQuery("#xk-download-send-captcha");
                var currentTime = new Date().getTime();
                var elapsedTime = Math.floor((currentTime - window.xkAuthCaptchaState.startTime) / 1000);
                
                // 如果还有冷却时间
                if (window.xkAuthCaptchaState.countdown > 0 && elapsedTime < 60) {
                    var remaining = 60 - elapsedTime;
                    btn.attr("disabled", true);
                    btn.addClass("disabled");
                    btn.text(remaining + "秒后重新发送");
                    
                    // 清除之前的计时器
                    if (window.xkAuthCaptchaState.timer) {
                        clearInterval(window.xkAuthCaptchaState.timer);
                    }
                    
                    // 启动新的计时器
                    window.xkAuthCaptchaState.timer = setInterval(function() {
                        remaining--;
                        btn.text(remaining + "秒后重新发送");
                        if (remaining <= 0) {
                            clearInterval(window.xkAuthCaptchaState.timer);
                            btn.attr("disabled", false);
                            btn.removeClass("disabled");
                            btn.text("发送验证码");
                            window.xkAuthCaptchaState.countdown = 0;
                            window.xkAuthCaptchaState.startTime = 0;
                        }
                    }, 1000);
                }
            }
            
            function startCountdown() {
                var btn = jQuery("#xk-download-send-captcha");
                btn.attr("disabled", true);
                btn.addClass("disabled");
                window.xkAuthCaptchaState.countdown = 60;
                window.xkAuthCaptchaState.startTime = new Date().getTime();
                btn.text(window.xkAuthCaptchaState.countdown + "秒后重新发送");
                
                // 清除之前的计时器
                if (window.xkAuthCaptchaState.timer) {
                    clearInterval(window.xkAuthCaptchaState.timer);
                }
                
                window.xkAuthCaptchaState.timer = setInterval(function() {
                    window.xkAuthCaptchaState.countdown--;
                    btn.text(window.xkAuthCaptchaState.countdown + "秒后重新发送");
                    if (window.xkAuthCaptchaState.countdown <= 0) {
                        clearInterval(window.xkAuthCaptchaState.timer);
                        btn.attr("disabled", false);
                        btn.removeClass("disabled");
                        btn.text("发送验证码");
                        window.xkAuthCaptchaState.countdown = 0;
                        window.xkAuthCaptchaState.startTime = 0;
                    }
                }, 1000);
            }
            
            // 页面加载时检查并恢复冷却状态
            checkAndRestoreCountdown();
            
            jQuery("#xk-download-send-captcha").on("click", function() {
                if (window.xkAuthCaptchaState.countdown > 0) return;
                
                var contact_type = jQuery("[name=contact_type]").val();
                var contact_value = jQuery("[name=contact_value]").val();
                var product_id = jQuery("[name=product_id]").val();
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: {
                        action: "xk_send_verify_captcha",
                        contact_type: contact_type,
                        contact_value: contact_value,
                        product_id: product_id
                    },
                    success: function(response) {
                        var data;
                        console.log("验证码发送响应:", response);
                        
                        try {
                            if (typeof response === "object") {
                                data = response;
                            } else {
                                var cleanResponse = response.trim();
                                data = JSON.parse(cleanResponse);
                            }
                            
                            if (!data || typeof data !== "object") {
                                data = { error: 1, msg: "无效的响应数据" };
                            }
                            
                            console.log("解析后的数据:", data);
                            
                            // 使用更安全的通知方式
                            if (data.error === 0 || (data.msg && (data.msg.includes("成功") || data.msg.includes("验证码已发送")))) {
                                if (typeof notyf !== "undefined") {
                                    notyf(data.msg || "验证码发送成功", "success");
                                } else {
                                    alert(data.msg || "验证码发送成功");
                                }
                                startCountdown();
                            } else {
                                if (typeof notyf !== "undefined") {
                                    notyf(data.msg || "验证码发送失败", "danger");
                                } else {
                                    alert(data.msg || "验证码发送失败");
                                }
                            }
                        } catch (e) {
                            console.error("响应解析错误:", e);
                            // 即使解析失败也启动倒计时
                            if (typeof notyf !== "undefined") {
                                notyf("验证码可能已发送，请检查您的邮箱", "warning");
                            } else {
                                alert("验证码可能已发送，请检查您的邮箱");
                            }
                            startCountdown();
                        }
                    },
                    error: function() {
                        if (typeof notyf !== "undefined") {
                            notyf("发送验证码失败，请重试", "danger");
                        } else {
                            alert("发送验证码失败，请重试");
                        }
                    }
                });
            });
            
            // 提交验证
            jQuery("#xk-download-verify-submit").on("click", function() {
                var captcha = jQuery("[name=captcha]").val();
                var contact_type = jQuery("[name=contact_type]").val();
                var contact_value = jQuery("[name=contact_value]").val();
                var product_id = jQuery("[name=product_id]").val();
                
                if (!captcha) {
                    if (typeof notyf !== "undefined") {
                        notyf("请输入验证码", "warning");
                    } else {
                        alert("请输入验证码");
                    }
                    return;
                }
                
                // 禁用验证按钮，防止重复点击
                var verifyBtn = jQuery(this);
                verifyBtn.attr("disabled", true).text("验证中...");
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: {
                        action: "xk_check_verify_captcha",
                        captcha: captcha,
                        contact_type: contact_type,
                        contact_value: contact_value,
                        product_id: product_id
                    },
                    timeout: 10000, // 设置10秒超时
                    success: function(response) {
                        var data;
                        console.log("验证码验证响应:", response);
                        
                        try {
                            if (typeof response === "object") {
                                data = response;
                            } else {
                                var cleanResponse = response.trim();
                                data = JSON.parse(cleanResponse);
                            }
                            
                            if (!data || typeof data !== "object") {
                                data = { error: 1, msg: "无效的响应数据" };
                            }
                            
                            console.log("解析后的数据:", data);
                            
                            if (data.error === 0 || data.success || (data.msg && data.msg.includes("成功"))) {
                                // 验证成功后，隐藏验证部分，显示下载确认部分
                                jQuery("#xk-download-verify-section").hide();
                                jQuery("#xk-download-confirm-section").show();
                                
                                // 触发窗口调整事件，确保样式正确应用
                                jQuery(window).trigger("resize");
                                
                                // 显示成功消息
                                if (typeof notyf !== "undefined") {
                                    notyf("验证成功，请选择下载方式", "success");
                                } else {
                                    alert("验证成功，请选择下载方式");
                                }
                            } else {
                                if (typeof notyf !== "undefined") {
                                    notyf(data.msg || "验证码错误或已过期，请重新获取验证码", "danger");
                                } else {
                                    alert(data.msg || "验证码错误或已过期，请重新获取验证码");
                                }
                            }
                        } catch (e) {
                            console.error("响应解析错误:", e);
                            if (typeof notyf !== "undefined") {
                                notyf("验证码验证过程中出现错误，请刷新页面后重试", "danger");
                            } else {
                                alert("验证码验证过程中出现错误，请刷新页面后重试");
                            }
                        } finally {
                            // 恢复验证按钮状态
                            verifyBtn.attr("disabled", false).html("<i class=\"fa fa-check mr10\"></i>确认验证");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("验证请求错误:", status, error);
                        if (typeof notyf !== "undefined") {
                            notyf("验证失败，请重试", "danger");
                        } else {
                            alert("验证失败，请重试");
                        }
                        // 恢复验证按钮状态
                        verifyBtn.attr("disabled", false).html("<i class=\"fa fa-check mr10\"></i>确认验证");
                    }
                });
            });
            
            // 下载按钮直接使用链接，无需额外的点击事件处理
            // 验证成功后直接显示下载链接，用户点击即可下载
        });
        </script>
    ';

    return $form;
}

/**
 * 生成带时间套餐选择的支付模态框
 *
 * @param int $user_id 用户ID
 * @param int $product_id 产品ID
 * @return string 模态框HTML内容
 */
function xk_auth_pay_modal($user_id = '', $product_id = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    if (!$product_id) {
        $html = '<div class="em12 text-center c-red" style="padding: 30px 0;">产品ID获取错误，请刷新后重试</div>';
        return $html;
    }

    // 检查用户是否登录，如果未登录，显示登录按钮
    if (!$user_id) {
        $html = '<div class="text-center" style="padding: 30px 20px;">
            <div class="mb10">
                <svg class="em48 mb10" aria-hidden="true"><use xlink:href="#icon-sign_in"></use></svg>
            </div>
            <div class="mb10 text-lg">您还未登录</div>
            <div class="mb20 text-sm muted-2-color">登录后即可购买产品授权</div>
            <div>
                <a href="javascript:;" class="but jb-blue signin-loader padding-lg">
                    <i class="fa fa-sign-in mr10" aria-hidden="true"></i>立即登录
                </a>
            </div>
        </div>';
        return $html;
    }



    // 获取产品信息
    $pay_mate = get_post_meta($product_id, 'posts_zibpay', true);

    // 获取用户余额信息
    $user_balance = zibpay_get_user_balance($user_id);

    // 获取时间套餐
    $time_packages = xk_auth_get_product_time_packages($product_id);

    // 获取积分图标
    $points_icon = zib_get_svg('points');
    $money_icon = zib_get_svg('money-color-2', null, 'em12 mr6');



    // 生成套餐选择HTML
    $package_html = '';

    // 检查文章的支付设置
    $is_points_modo = zibpay_post_is_points_modo($pay_mate);

    // 获取用户会员等级和会员价格
    $user_vip_level = 0;
    if (function_exists('zib_get_user_vip_level')) {
        $user_vip_level = zib_get_user_vip_level($user_id);
    }

    // 函数：计算会员价格
    function calculate_vip_price($original_price, $user_vip_level, $pay_mate, $is_points = false, $package = null)
    {
        // 如果不是会员，返回原价
        if (!$user_vip_level) {
            return $original_price;
        }

        // 优先使用套餐自身的会员价格设置
        if (!empty($package)) {
            if ($is_points) {
                // 积分支付套餐，检查是否有对应的会员积分价格设置
                $vip_points_key = 'package_vip_' . $user_vip_level . '_points_price';
                if (isset($package[$vip_points_key]) && $package[$vip_points_key] > 0) {
                    // 返回套餐中设置的会员积分价格
                    return $package[$vip_points_key];
                }
            } else {
                // 现金支付套餐，检查是否有对应的会员价格设置
                $vip_price_key = 'package_vip_' . $user_vip_level . '_price';
                if (isset($package[$vip_price_key]) && $package[$vip_price_key] > 0) {
                    // 返回套餐中设置的会员价格
                    return $package[$vip_price_key];
                }
            }
        }

        // 如果套餐没有设置会员价格，尝试使用文章的会员价格设置
        if (is_array($pay_mate)) {
            // 会员积分价格处理
            if ($is_points) {
                // 检查是否有对应的会员积分价格设置
                $vip_points_key = 'vip_' . $user_vip_level . '_points';
                if (isset($pay_mate[$vip_points_key]) && $pay_mate[$vip_points_key] > 0) {
                    // 返回会员积分价格
                    return $pay_mate[$vip_points_key];
                }

                // 检查是否有会员积分折扣
                if (isset($pay_mate['vip_points_discount']) && $pay_mate['vip_points_discount'] > 0) {
                    // 计算积分折扣价格
                    $discount = $pay_mate['vip_points_discount'] / 100;
                    return $original_price * $discount;
                }

                // 检查是否有通用的会员折扣
                if (isset($pay_mate['vip_discount']) && $pay_mate['vip_discount'] > 0) {
                    // 使用通用会员折扣计算积分价格
                    $discount = $pay_mate['vip_discount'] / 100;
                    return $original_price * $discount;
                }
            } else {
                // 现金价格处理
                // 检查是否有对应的会员价格设置
                $vip_price_key = 'vip_' . $user_vip_level . '_price';
                if (isset($pay_mate[$vip_price_key]) && $pay_mate[$vip_price_key] > 0) {
                    // 返回会员价格
                    return $pay_mate[$vip_price_key];
                }

                // 如果没有找到对应的会员价格，检查是否启用了会员折扣
                if (isset($pay_mate['vip_discount']) && $pay_mate['vip_discount'] > 0) {
                    // 计算折扣价格
                    $discount = $pay_mate['vip_discount'] / 100;
                    return $original_price * $discount;
                }
            }
        }

        // 默认返回原价
        return $original_price;
    }

    if (!empty($time_packages)) {
        foreach ($time_packages as $index => $package) {
            $is_active = $index === 0 ? ' active' : '';

            // 获取当前套餐的支付类型，默认为money
            $package_payment_type = isset($package['package_payment_type']) ? $package['package_payment_type'] : 'money';

            // 计算会员价格
            $original_price = $package['package_price'];
            $original_points_price = $package['package_points_price'];

            // 根据支付类型计算对应的会员价格
            $display_price = $original_price;
            $display_points_price = $original_points_price;

            if ($package_payment_type === 'money') {
                // 现金支付，计算现金会员价格，传递套餐数据
                $display_price = calculate_vip_price($original_price, $user_vip_level, $pay_mate, false, $package);
            } else {
                // 积分支付，计算积分会员价格，传递套餐数据
                $display_points_price = calculate_vip_price($original_points_price, $user_vip_level, $pay_mate, true, $package);
            }

            // 更新套餐数据中的价格为会员价格
            $package_html .= '<div class="zib-widget vip-product relative product-box' . $is_active . '" data-for="time_package" data-value="' . $index . '" data-price="' . $display_price . '" data-points-price="' . $display_points_price . '" data-duration="' . $package['package_duration'] . '" data-payment-type="' . $package_payment_type . '">
                <div class="package-duration">' . ($package['package_duration'] > 0 ? $package['package_duration'] . '天' : '永久') . '</div>
                <div class="emmmm15" style="color: #585d62;font-weight: 900;font-size: large;white-space: nowrap;"><b>' . esc_html($package['package_name']) . '</b></div>';

            // 根据套餐的支付类型显示对应价格
            if ($package_payment_type === 'money') {
                $package_html .= '<div class="c-red mt6 text-center">
                    <span class="px12">' . zibpay_get_pay_mark() . '</span>
                    <span class="em12">' . esc_html($display_price) . '</span>';

                // 如果有会员折扣，显示原价和折扣（单独一行）
                if ($user_vip_level && $display_price < $original_price) {
                    $package_html .= '<div class="em08 muted-2-color mt3">
                        <del>' . esc_html($original_price) . '</del>
                    </div>
                    <div class="em08 c-green mt1">会员折扣</div>';
                }

                $package_html .= '</div>';
            } else {
                $package_html .= '<div class="c-yellow mt6 text-center">
                <span class="px12 xk-points-icon-custom">' . $points_icon . '</span>
                <span class="em12">' . $display_points_price . ' 积分</span>';

                // 如果有会员积分折扣，显示原价和折扣（单独一行）
                if ($user_vip_level && $display_points_price < $original_points_price) {
                    $package_html .= '<div class="em08 muted-2-color mt3">
                        <del>' . $original_points_price . ' 积分</del>
                    </div>
                    <div class="em08 c-green mt1">会员折扣</div>';
                }

                $package_html .= '</div>';
            }

            $package_html .= '</div>';

        }
    } else {
        // 当没有设置时间套餐时，根据文章支付设置生成默认套餐
        $is_points_modo = zibpay_post_is_points_modo($pay_mate);

        // 计算默认套餐的会员价格
        $original_price = $pay_mate['pay_price'];
        $vip_price = calculate_vip_price($original_price, $user_vip_level, $pay_mate, false);

        $default_package_name = '默认授权套餐';
        $default_price = $is_points_modo ? 0 : $vip_price;
        // 获取正确的积分价格，优先使用points_price，如果没有则使用pay_price
        $points_price = isset($pay_mate['points_price']) ? $pay_mate['points_price'] : $pay_mate['pay_price'];
        // 计算积分会员价格
        $vip_points_price = calculate_vip_price($points_price, $user_vip_level, $pay_mate, true);
        $default_points_price = $is_points_modo ? $vip_points_price : 0;
        $default_duration = 0; // 永久授权
        $default_payment_type = $is_points_modo ? 'points' : 'money';

        $package_html .= '<div class="zib-widget vip-product relative product-box active" data-for="time_package" data-value="0" data-price="' . $default_price . '" data-points-price="' . $default_points_price . '" data-duration="' . $default_duration . '" data-payment-type="' . $default_payment_type . '">
            <div class="package-duration">' . ($default_duration > 0 ? $default_duration . '天' : '永久') . '</div>
            <div class="emmmm15" style="color: #585d62;font-weight: 900;font-size: large;white-space: nowrap;"><b>' . $default_package_name . '</b></div>';

        // 根据支付类型显示对应价格
        if ($default_payment_type === 'money') {
            $package_html .= '<div class="c-red mt6 text-center">
                <span class="px14">' . zibpay_get_pay_mark() . '</span>
                <span class="em18 font-bold">' . $default_price . '</span>';

            // 如果有会员折扣，显示原价和折扣（单独一行）
            if ($user_vip_level && $default_price < $original_price) {
                $package_html .= '<div class="em08 muted-2-color mt3">
                    <del>' . $original_price . '</del>
                </div>
                <div class="em08 c-green mt1">会员折扣</div>';
            }

            $package_html .= '</div>';
        } else {
            $package_html .= '<div class="c-yellow mt6 text-center">
                <span class="px14 xk-points-icon-custom">' . $points_icon . '</span>
                <span class="em18 font-bold">' . $default_points_price . ' 积分</span>';

            // 如果有会员积分折扣，显示原价和折扣（单独一行）
            if ($user_vip_level && $default_points_price < $points_price) {
                $package_html .= '<div class="em08 muted-2-color mt3">
                    <del>' . $points_price . ' 积分</del>
                </div>
                <div class="em08 c-green mt1">会员折扣</div>';
            }

            $package_html .= '</div>';
        }

        $package_html .= '</div>';
    }

    // 默认选中的套餐
    if (!empty($time_packages)) {
        // 如果有时间套餐，使用第一个套餐，但更新其价格为会员价格
        $default_package = $time_packages[0];

        // 计算会员价格
        $original_price = $default_package['package_price'];
        $original_points_price = $default_package['package_points_price'];
        $package_payment_type = isset($default_package['package_payment_type']) ? $default_package['package_payment_type'] : 'money';

        // 根据支付类型计算对应的会员价格
        if ($package_payment_type === 'money') {
            // 现金支付，计算现金会员价格，传递套餐数据
            $display_price = calculate_vip_price($original_price, $user_vip_level, $pay_mate, false, $default_package);
            $default_package['package_price'] = $display_price;
        } else {
            // 积分支付，计算积分会员价格，传递套餐数据
            $display_points_price = calculate_vip_price($original_points_price, $user_vip_level, $pay_mate, true, $default_package);
            $default_package['package_points_price'] = $display_points_price;
        }
    } else {
        // 当没有设置时间套餐时，根据文章支付设置生成默认套餐
        $is_points_modo = zibpay_post_is_points_modo($pay_mate);

        // 计算会员价格
        $original_price = $pay_mate['pay_price'];
        $vip_price = calculate_vip_price($original_price, $user_vip_level, $pay_mate, false);

        // 使用会员价格

        // 获取正确的积分价格，并计算积分会员价格
        $points_price = isset($pay_mate['points_price']) ? $pay_mate['points_price'] : $pay_mate['pay_price'];
        $vip_points_price = calculate_vip_price($points_price, $user_vip_level, $pay_mate, true);

        $default_package = array(
            'package_price' => $is_points_modo ? 0 : $vip_price,
            'package_points_price' => $is_points_modo ? $vip_points_price : 0,
            'package_duration' => 0,
            'package_payment_type' => $is_points_modo ? 'points' : 'money'
        );
    }

    // 根据默认套餐的支付类型设置默认价格
    $is_points_modo = isset($default_package['package_payment_type']) && $default_package['package_payment_type'] === 'points' ? true : false;

    $header = '<div class="mb10 touch">
        <button class="close" data-dismiss="modal">' . zib_get_svg('close', null, 'ic-close') . '</button>
        <b class="modal-title flex ac">
            购买授权
        </b>
    </div>';

    // 支付方式选择
    $payment_methods = zibpay_get_payment_methods();
    $is_points_modo = zibpay_post_is_points_modo($pay_mate);

    // 获取用户积分
    $user_points = 0;
    if (function_exists('zibpay_get_user_points')) {
        $user_points = zibpay_get_user_points(get_current_user_id());
        $user_points = is_numeric($user_points) ? intval($user_points) : 0;
    }

    // 显示用户余额和积分
    $user_balance_box = '
    <div 
    class="mb10 muted-box padding-h10"
    >
        <div class="flex jsb ac">
            <span class="muted-2-color">' . $money_icon . '我的余额</span>
            <div><span class="c-blue-2"><span class="em14">' . zibpay_get_pay_mark() . $user_balance . '</span></div>
        </div>
        <div class="flex jsb ac mt3" >
            <span class="muted-2-color" >
                <span class="xk-points-icon" style="margin-right: 5px;">' . $points_icon . '</span>
                我的积分
            </span>
            <div><span class="c-yellow"><span class="em14">' . $user_points . '</span></div>
        </div>
    </div>';


    // 根据默认套餐的支付类型显示对应价格
    $default_package_payment_type = isset($default_package['package_payment_type']) ? $default_package['package_payment_type'] : 'money';
    $price_display = '';
    if (!empty($time_packages)) {
        // 如果有时间套餐，使用第一个套餐的数据
        $first_package = $time_packages[0];
        $first_package_payment_type = isset($first_package['package_payment_type']) ? $first_package['package_payment_type'] : 'money';

        // 获取第一个套餐的会员价格
        // 注意：对于积分套餐，我们直接使用套餐中配置的积分价格，而不使用文章的支付设置
        $first_package_price = $first_package['package_price'];
        $first_package_points_price = $first_package['package_points_price'];

        // 根据支付类型计算对应的会员价格
        if ($first_package_payment_type === 'money') {
            // 现金支付，使用文章支付设置计算现金会员价格
            $first_package_price = calculate_vip_price($first_package_price, $user_vip_level, $pay_mate, false);
            $price_display = '<div class="c-red em18"><span id="xk-modal-current-price">' . zibpay_get_pay_mark() . $first_package_price . '</span></div>';
        } else {
            // 积分支付，直接使用套餐中配置的积分价格
            // 这里不再使用calculate_vip_price函数，因为它会使用文章的支付设置
            $price_display = '<div class="c-yellow em18">' . $points_icon . '<span id="xk-modal-current-price">' . $first_package_points_price . ' 积分</span></div>';
        }
    } else {
        // 没有时间套餐时，使用计算后的价格
        if ($default_package_payment_type === 'money') {
            $price_display = '<div class="c-red em18"><span id="xk-modal-current-price">' . zibpay_get_pay_mark() . $default_package['package_price'] . '</span></div>';
        } else {
            $price_display = '<div class="c-yellow em18">' . $points_icon . '<span id="xk-modal-current-price">' . $default_package['package_points_price'] . ' 积分</span></div>';
        }
    }

    $form = '<style>
        /* 套餐容器样式 - 确保flex布局生效 */
        .xk-pay-form .xk-packages-container {
            display: flex !important;
            flex-wrap: wrap !important;
            gap: 15px !important;
            margin-bottom: 20px !important;
            width: 96.5% !important;
            padding: 0 !important;
        }
        
        /* 单个套餐样式 - 方形布局，拟态效果 */
.xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box {
    flex: 1 0 calc(33.333% - 10px) !important;
    min-width: calc(33.333% - 10px) !important;
    max-width: calc(33.333% - 10px) !important;
    box-sizing: border-box !important;
    margin: 0 !important;
    padding: 10px !important;
    border-radius: 3px !important;
    background: var(--main-shadow);
    transition: all 0.3s ease !important;
    position: relative !important;
    display: flex !important;
    flex-direction: column !important;
    justify-content: center !important;
    align-items: center !important;
    z-index: 1 !important;
    overflow: visible !important;
}
        
        /* 套餐激活状态 */
        .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box.active {
            z-index: 1 !important;
        }
        .dark-theme .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box.active {
            z-index: 1 !important;

        }
        
        /* 套餐悬停效果 - 仅桌面端 */
        @media (min-width: 769px) {
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box:hover {
                transform: translateY(-5px) !important;
                box-shadow: 10px 10px 20px rgba(220, 220, 220, 0.3), -10px -10px 20px rgba(255, 255, 255, 0) !important;
            }
        }
        
        /* 移动端无悬浮效果 */
        @media (max-width: 768px) {
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box:hover {
                transform: none !important;
                box-shadow: 4px 4px 12px rgba(220, 220, 220, 0.2) !important;
            }
        }
        
        /* 时间显示样式 - 右上角方形 */
.xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .package-duration {
    position: absolute !important;
    top: -8px !important;
    right: -11px !important;
    background: #fc6857 !important;
    color: white !important;
    padding: 1px 5px !important;
    border-radius: 4px !important;
    font-size: 12px !important;
    font-weight: 500 !important;
    z-index: 9999 !important;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2) !important;
    transform: translateZ(0) !important;
}
        
        /* 套餐标题样式 */
        .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .emmmm15 {
            font-size: 16px !important;
            font-weight: 700 !important;
            color: #333333 !important;
            margin-bottom: 15px !important;
            text-align: center !important;
        }
        
        /* 价格显示样式 */
        .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-red,
        .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-yellow {
            margin-bottom: 10px !important;
            font-size: 18px !important;
            font-weight: bold !important;
        }
        
        /* 价格数字样式 */
        .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-red span,
        .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-yellow span {
            font-size: 18px !important;
            font-weight: bold !important;
        }
        
        /* 移动端响应式设计 */
        @media (max-width: 768px) {
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box {
                flex: 1 0 calc(33.333% - 10px) !important;
                min-width: calc(33.333% - 10px) !important;
                max-width: calc(33.333% - 10px) !important;
                min-height: 100px !important;
                padding: 15px !important;
            }
            
            /* 移动端标题样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .emmmm15 {
                font-size: 14px !important;
                margin-bottom: 10px !important;
            }
            
            /* 移动端价格样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-red,
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-yellow {
                font-size: 16px !important;
                font-weight: bold !important;
            }
            
            /* 移动端价格数字样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-red span,
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-yellow span {
                font-size: 16px !important;
                font-weight: bold !important;
            }
            
            /* 移动端时间标签样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .package-duration {
                font-size: 11px !important;
                padding: 4px 10px !important;
                top: -8px !important;
                right: -8px !important;
            }

            .xk-pay-form .xk-packages-container {
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 12px !important;
    margin-bottom: 20px !important;
    width: 96.5% !important;
    padding: 0 !important;
}
        }
        
        @media (max-width: 480px) {
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box {
                flex: 1 0 calc(33.333% - 8px) !important;
                min-width: calc(33.333% - 8px) !important;
                max-width: calc(33.333% - 8px) !important;
                min-height: 100px !important;
                padding: 10px !important;
            }

            .xk-pay-form .xk-packages-container {
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 12px !important;
    margin-bottom: 20px !important;
    width: 96.5% !important;
    padding: 0 !important;
}
            
            /* 小屏幕标题样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .emmmm15 {
                font-size: 13px !important;
                margin-bottom: 8px !important;
            }
            
            /* 小屏幕价格样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-red,
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .c-yellow {
                font-size: 14px !important;
            }
            
            /* 小屏幕时间标签样式 */
            .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .package-duration {
                font-size: 10px !important;
                padding: 4px 8px !important;
                top: -8px !important;
                right: -8px !important;
            }
        }
        
        /* 暗色模式 */
        .dark-theme .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box {
            background: rgba(255, 255, 255, 0.05) !important;
        }
        
        
        .dark-theme .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box:hover {
            box-shadow: 6px 6px 16px rgba(0, 0, 0, 0.5) !important;
        }
        
        .dark-theme .xk-pay-form .xk-packages-container .zib-widget.vip-product.product-box .emmmm15 {
            color: var(--text-color, #ffffff) !important;
        }
    </style>
    <form class="xk-pay-form mini-scrollbar scroll-y max-vh7">
        <div class="muted-color mb10">请选择授权时长套餐</div>
        <div class="xk-packages-container">' . $package_html . '</div>
        
        <div class="mt20">
            <div class="muted-color mb6">当前价格</div>
            <div class="price-display flex jsb ac" style="padding: 1px 0px 10px 10px;font-size: 32px;font-weight: bold;">
                ' . $price_display . '
            </div>
        </div>
        
        <!-- 优惠码功能 -->
        <div class="mt20" id="xk-promo-section">
            <div class="muted-color mb6">优惠码</div>
            <div class="flex gap10">
                <input type="text" class="form-control" id="xk-promo-code" placeholder="请输入优惠码" style="width: 280px;">
                <button type="button" class="but jb-blue" id="xk-validate-promo" style="width: 86px;">验证</button>
            </div>
            <div id="xk-promo-result" class="mt6" style="font-size: 12px;"></div>
            <input type="hidden" name="promo_code" id="promo_code" value="">
            <input type="hidden" name="promo_discount" id="promo_discount" value="0">
        </div>
        
        ' . $user_balance_box . '
        
        <div class="dependency-box mt20">
            <input type="hidden" name="product_id" value="' . $product_id . '">
            <input type="hidden" name="time_package_index" id="time_package_index" value="0">
            <input type="hidden" name="time_package_duration" id="time_package_duration" value="' . $default_package['package_duration'] . '">
            <input type="hidden" name="selected_price" id="selected_price" value="' . $default_package['package_price'] . '">
            <input type="hidden" name="selected_points_price" id="selected_points_price" value="' . $default_package['package_points_price'] . '">
            <input type="hidden" name="selected_payment_method" id="selected_payment_method" value="balance">
            
            <!-- 支付方式选择 - 根据默认套餐类型决定是否显示 -->
            <div class="mb15" style="display: ' . ($default_package_payment_type === 'money' ? 'block' : 'none') . '">
                <div class="muted-2-color em09 mb6">请选择支付方式</div>
                <div class="flex mb10">
                    <div class="flex jc hh payment-method-radio hollow-radio flex-auto pointer active" style="font-size:16px;" data-for="payment_method" data-value="balance">' . $money_icon . '<div>余额</div></div>
                    ';
    // 获取其他支付方式
    $other_payment_methods = zibpay_get_payment_methods();
    if (!empty($other_payment_methods)) {
        $ii = 2;
        foreach ($other_payment_methods as $method_key => $method_info) {
            if ($method_key !== 'balance') {
                $form .= '<div class="flex jc hh payment-method-radio hollow-radio flex-auto pointer' . ($ii === 1 ? ' active' : '') . '" data-for="payment_method" data-value="' . esc_attr($method_key) . '">' . (isset($method_info['img']) ? $method_info['img'] : '<i class="fa fa-credit-card"></i>') . '<div>' . esc_html($method_info['name']) . '</div></div>';
                $ii++;
            }
        }
    }
    $form .= '
                </div>
            </div>
            
            ';
    // 根据当前选中套餐的支付类型生成支付按钮
    $default_package_payment_type = isset($default_package['package_payment_type']) ? $default_package['package_payment_type'] : 'money';
    if ($default_package_payment_type === 'points') {
        $form .= '<a href="javascript:void(0)" class="mt6 but jb-yellow btn-block radius" id="xk-pay-with-points">立即支付</a>';
    } else {
        $form .= '<a href="javascript:void(0)" class="mt6 but jb-red btn-block radius" id="xk-pay-with-money">立即支付</a>';
    }

    $form .= '</div>
    </form>';

    $html = $header . $form;

    // 添加JavaScript
    $ajaxurl = admin_url('admin-ajax.php');
    $html .= '<script type="text/javascript">
        jQuery(document).ready(function($) {
            // 定义全局变量防止重复点击
            window.xkAuthClicktype = true;
            
            // 套餐选择
            $(document).on("click", ".product-box", function() {
                // 更新选中状态
                $(this).addClass("active").siblings().removeClass("active");
                
                // 获取选中套餐信息
                var package_index = $(this).data("value");
                var price = $(this).data("price");
                var points_price = $(this).data("points-price");
                var duration = $(this).data("duration");
                var package_payment_type = $(this).data("payment-type");
                
                // 更新隐藏字段
                $("#time_package_index").val(package_index);
                $("#time_package_duration").val(duration);
                $("#selected_price").val(price);
                $("#selected_points_price").val(points_price);
                
                // 更新显示价格
                if (package_payment_type === "money") {
                    $("#xk-modal-current-price").html("' . zibpay_get_pay_mark() . '" + price);
                    $("#xk-modal-current-price").closest("div").removeClass("c-yellow").addClass("c-red");
                } else {
                    $("#xk-modal-current-price").html(points_price + " 积分");
                    $("#xk-modal-current-price").closest("div").removeClass("c-red").addClass("c-yellow");
                }
                
                // 更新优惠码区域显示
                if (package_payment_type === "points") {
                    // 积分支付时隐藏优惠码区域
                    $("#xk-promo-section").hide();
                    // 重置优惠码
                    $("#xk-promo-code").val("");
                    $("#promo_code").val("");
                    $("#promo_discount").val("0");
                    $("#xk-promo-result").html("");
                } else {
                    // 现金支付时显示优惠码区域
                    $("#xk-promo-section").show();
                }
                
                // 更新支付按钮
                if (package_payment_type === "points") {
                    // 移除原支付按钮
                    $(".dependency-box a[id^=\'xk-pay-with-\']").remove();
                    // 添加积分支付按钮
                    $(".dependency-box").append("<a href=\"javascript:void(0)\" class=\"mt6 but jb-yellow btn-block radius\" id=\"xk-pay-with-points\">立即支付</a>");
                    // 隐藏支付方式选择（积分支付时不需要选择支付方式）
                    $(".payment-method-radio").closest("div.mb15").hide();
                    $("[data-controller=payment_method]").hide();
                } else {
                    // 移除原支付按钮
                    $(".dependency-box a[id^=\'xk-pay-with-\']").remove();
                    // 添加余额支付按钮
                    $(".dependency-box").append("<a href=\"javascript:void(0)\" class=\"mt6 but jb-red btn-block radius\" id=\"xk-pay-with-money\">立即支付</a>");
                    // 显示支付方式选择
                    $(".payment-method-radio").closest("div.mb15").show();
                    $("[data-controller=payment_method]").show();
                }
            });
            
            // 支付方式选择处理 - 先解绑再绑定，避免重复绑定
            $(document).off("click", ".payment-method-radio").on("click", ".payment-method-radio", function(e) {
                e.stopPropagation();
                console.log("Payment method item clicked:", $(this));
                
                // 移除所有支付方式的选中状态
                $(".payment-method-radio").removeClass("active");
                // 添加当前支付方式的选中状态
                $(this).addClass("active");
                // 更新选中的支付方式
                var selected_method = $(this).attr("data-value");
                console.log("Selected method:", selected_method);
                $("#selected_payment_method").val(selected_method);
                console.log("Updated selected_payment_method value:", $("#selected_payment_method").val());
            });
            
            // 初始化检查：默认选中余额支付
            setTimeout(function() {
                console.log("Initializing payment method selection");
                
                // 默认选中余额支付
                var balanceItem = $(document).find(".payment-method-radio[data-value=balance] ");
                console.log("Balance item found:", balanceItem.length > 0);
                if (balanceItem.length > 0) {
                    balanceItem.click();
                    console.log("Default payment method selected: balance");
                }
            }, 300);
            
            // 显示通知的函数，使用子比主题的notyf系统
            function showNotification(message, type) {
                // 确保message有值
                message = message || "操作完成";
                // 使用子比主题的notyf函数
                if (typeof notyf === "function") {
                    notyf(message, type);
                } else {
                    // 降级方案
                    alert(message);
                }
            }
            
            // 优惠码输入验证
            $("#xk-promo-code").on("input", function() {
                var promoCode = $(this).val();
                // 限制优惠码长度不超过30个字符
                if (promoCode.length > 30) {
                    $(this).val(promoCode.substring(0, 30));
                }

            });
            
            // 优惠码验证功能
            $("#xk-validate-promo").on("click", function() {
                var promoCode = $("#xk-promo-code").val().trim();
                if (!promoCode) {
                    showNotification("请输入优惠码", "danger");
                    return;
                }
                
                // 验证优惠码格式
                if (!/^[a-zA-Z0-9_-]+$/.test(promoCode)) {
                    showNotification("优惠码格式错误，只能包含英文、数字、下划线和短横线", "danger");
                    return;
                }
                
                // 验证优惠码长度
                if (promoCode.length > 30) {
                    showNotification("优惠码长度不能超过30个字符", "danger");
                    return;
                }
                
                // 获取当前选中的价格
                var selectedPrice = parseFloat($("#selected_price").val());
                var selectedPointsPrice = parseFloat($("#selected_points_price").val());
                var productId = $("input[name=product_id]").val();
                var isPointsPayment = false;
                
                // 检查当前是现金支付还是积分支付
                if ($("#xk-modal-current-price").closest("div").hasClass("c-yellow")) {
                    isPointsPayment = true;
                }
                
                // 积分支付不支持使用优惠码
                if (isPointsPayment) {
                    showNotification("积分支付不支持使用优惠码", "danger");
                    $(this).attr("disabled", false).text("验证优惠码");
                    return;
                }
                
                // 禁用验证按钮，防止重复点击
                $(this).attr("disabled", true).text("验证中...");
                showNotification("正在验证...", "danger")
                
                // 发送AJAX请求验证优惠码
                $.ajax({
                    type: "POST",
                    url: "' . esc_js($ajaxurl) . '",
                    data: {
                        action: "validate_promo_code",
                        code: promoCode,
                        amount: isPointsPayment ? selectedPointsPrice : selectedPrice,
                        product_id: productId,
                        security: "' . wp_create_nonce('xk_auth_nonce') . '"
                    },
                    success: function(response) {
                        var result = response;
                        if (typeof result === "string") {
                            try {
                                result = JSON.parse(result);
                            } catch (e) {
                                result = { error: 1, msg: "验证失败，响应格式错误" };
                            }
                        }
                        
                        if (result.error === 0) {
                            // 优惠码验证成功
                            $("#xk-promo-result").html(\'<span class="c-green">\' + result.msg + \'，优惠金额：\' + (isPointsPayment ? \'\' : \'¥\') + result.discount + \'</span>\');
                            $("#promo_code").val(promoCode);
                            $("#promo_discount").val(result.discount);
                            
                            // 更新显示价格
                            var currentDisplayPrice = $("#xk-modal-current-price").text();
                            var originalPrice = isPointsPayment ? selectedPointsPrice : selectedPrice;
                            var discountedPrice = originalPrice - result.discount;
                            discountedPrice = Math.max(discountedPrice, 0);
                            
                            if (isPointsPayment) {
                                $("#xk-modal-current-price").html(discountedPrice + " 积分");
                            } else {
                                $("#xk-modal-current-price").html("' . zibpay_get_pay_mark() . '" + discountedPrice);
                            }
                        } else {
                            // 优惠码验证失败
                            showNotification(result.msg || "未知错误", "danger");
                            $("#xk-promo-result").html("");
                            $("#promo_code").val("");
                            $("#promo_discount").val("0");
                        }
                    },
                    error: function() {
                        showNotification("验证失败，网络错误", "danger");
                        $("#xk-promo-result").html("");
                        $("#promo_code").val("");
                        $("#promo_discount").val("0");
                    },
                    complete: function() {
                        // 恢复验证按钮状态
                        $("#xk-validate-promo").attr("disabled", false).text("验证");
                    }
                });
            });
            
            // 套餐切换时重置优惠码
            $(".product-box").on("click", function() {
                $("#xk-promo-code").val("");
                $("#promo_code").val("");
                $("#promo_discount").val("0");
                $("#xk-promo-result").html("");
            });
            
            // 立即支付按钮（根据选择的支付方式处理）
            $("#xk-pay-with-money").on("click", function() {
                console.log("Payment button clicked");
                if (window.xkAuthClicktype == false) {
                    console.log("Payment already in progress");
                    return false;
                }
                window.xkAuthClicktype = false;
                
                // 直接使用选择器获取值
                var product_id = $(".xk-pay-form input[name=product_id]").val();
                var package_index = $(".xk-pay-form #time_package_index").val();
                var selected_price = parseFloat($(".xk-pay-form #selected_price").val());
                var selected_payment_method = $(".xk-pay-form #selected_payment_method").val();
                var selected_duration = $(".xk-pay-form #time_package_duration").val();
                var promo_code = $(".xk-pay-form #promo_code").val();
                var promo_discount = parseFloat($(".xk-pay-form #promo_discount").val());
                
                // 计算实际支付价格（应用优惠码折扣）
                var actual_price = selected_price - promo_discount;
                actual_price = Math.max(actual_price, 0); // 确保价格不为负数
                
                console.log("Payment details:", {
                    product_id: product_id,
                    package_index: package_index,
                    selected_price: selected_price,
                    actual_price: actual_price,
                    selected_payment_method: selected_payment_method,
                    selected_duration: selected_duration,
                    promo_code: promo_code,
                    promo_discount: promo_discount
                });
                
                var text = "<i class=loading mr6></i> 支付中...";
                $(this).attr("disabled", true);
                $(this).html(text);
                
                // 根据选择的支付方式处理
                if (selected_payment_method === "balance") {
                    console.log("Processing balance payment");
                    // 调用余额支付
                    $.ajax({
                        type: "POST",
                        url: "' . esc_js($ajaxurl) .  '",
                        data: {
                            action: "xk_auth_pay_with_balance",
                            product_id: product_id,
                            package_index: package_index,
                            promo_code: promo_code,
                            promo_discount: promo_discount,
                            selected_price: actual_price,
                            selected_duration: selected_duration,
                            client_timestamp: new Date().getTime(),
                            client_user_agent: navigator.userAgent
                        },
                        success: function(response) {
                            console.log("Balance payment response:", response);
                            
                            // 尝试解析JSON响应
                            var result = response;
                            if (typeof response === "string") {
                                try {
                                    result = JSON.parse(response);
                                } catch (parseError) {
                                    console.error("[XK Auth] JSON解析失败:", parseError);
                                    console.error("[XK Auth] 原始响应内容:", response);
                                    showNotification("响应解析失败，请查看控制台日志", "danger");
                                    return;
                                }
                            }
                            
                            // 确保result是对象
                            result = result || {};
                            
                            console.log("Processed result:", result);
                            
                            if (result.msg == 1) {
                                showNotification(result.name || "支付成功", "success");
                                setTimeout(function() {
                                    window.location.reload();
                                }, 1500);
                            } else {
                                showNotification(result.name || "操作失败", "danger");
                            }
                        },
                        error: function(xhr, status, error) {
                            // 记录详细的错误日志到控制台
                            console.error("[XK Auth] 余额支付请求失败:", {
                                status: status,
                                error: error,
                                statusText: xhr.statusText,
                                responseText: xhr.responseText,
                                readyState: xhr.readyState,
                                statusCode: xhr.status
                            });
                            
                            // 显示更详细的错误信息
                            var errorMsg = "请求失败: " + status;
                            if (error) {
                                errorMsg += " - " + error;
                            }
                            if (xhr.status) {
                                errorMsg += " (状态码: " + xhr.status + ")";
                            }
                            showNotification(errorMsg, "danger");
                        },
                        complete: function() {
                            console.log("Balance payment request complete");
                            window.xkAuthClicktype = true;
                            $("#xk-pay-with-money").html("立即支付");
                            $("#xk-pay-with-money").attr("disabled", false);
                        }
                    });
                } else {
                    console.log("Processing other payment method:", selected_payment_method);
                    // 其他支付方式处理 - 调用zibll主题的支付系统
                    $.ajax({
                        type: "POST",
                        url: "' . esc_js($ajaxurl) .  '",
                        data: {
                            action: "xk_auth_pay_with_other_method",
                            product_id: product_id,
                            package_index: package_index,
                            selected_price: actual_price,
                            selected_duration: selected_duration,
                            selected_payment_method: selected_payment_method,
                            promo_code: promo_code,
                            promo_discount: promo_discount,
                            client_timestamp: new Date().getTime(),
                            client_user_agent: navigator.userAgent
                        },
                        success: function(response) {
                            console.log("Other payment method response:", response);
                            
                            // 尝试解析JSON响应
                            var result = response;
                            if (typeof response === "string") {
                                try {
                                    result = JSON.parse(response);
                                } catch (parseError) {
                                    console.error("[XK Auth] JSON解析失败:", parseError);
                                    console.error("[XK Auth] 原始响应内容:", response);
                                    showNotification("响应解析失败，请查看控制台日志", "danger");
                                    return;
                                }
                            }
                            
                            // 确保result是对象
                            result = result || {};
                            
                            // 处理zib_send_json_success格式的响应
                            var final_result = result;
                            if (result.success && result.data) {
                                final_result = result.data;
                            }
                            
                            console.log("Processed result:", final_result);
                            
                            // 处理zibpay_initiate_pay返回的结果格式
                            if (final_result.float_btn) {
                                // 处理子比主题的浮动支付按钮
                                console.log("Processing float button");
                                var float_box = $(".float-right-wait-pay");
                                if (float_box.length) {
                                    float_box.prop("outerHTML", final_result.float_btn);
                                } else {
                                    $("body").append(final_result.float_btn);
                                }
                            } else if (final_result.open_url && final_result.url) {
                                // 跳转到支付页面
                                console.log("Redirecting to:", final_result.url);
                                window.location.href = final_result.url;
                            } else if (final_result.form_html) {
                                // 处理需要自动提交的表单
                                console.log("Processing form_html response");
                                // 创建临时表单并提交
                                var tempForm = document.createElement("div");
                                tempForm.innerHTML = final_result.form_html;
                                document.body.appendChild(tempForm);
                                // 自动提交表单
                                var form = tempForm.querySelector("form");
                                if (form) {
                                    form.submit();
                                }
                            } else if (final_result.jsapiParams) {
                                // 处理微信JSAPI支付
                                console.log("Processing JSAPI payment");
                                console.log("JSAPI params:", final_result.jsapiParams);
                                
                                // 检查是否在微信浏览器中
                                if (typeof WeixinJSBridge == "undefined") {
                                    if (document.addEventListener) {
                                        document.addEventListener("WeixinJSBridgeReady", function() {
                                            onBridgeReady(final_result.jsapiParams, final_result.jsapi_return);
                                        }, false);
                                    } else if (document.attachEvent) {
                                        document.attachEvent("WeixinJSBridgeReady", function() {
                                            onBridgeReady(final_result.jsapiParams, final_result.jsapi_return);
                                        });
                                        document.attachEvent("onWeixinJSBridgeReady", function() {
                                            onBridgeReady(final_result.jsapiParams, final_result.jsapi_return);
                                        });
                                    }
                                } else {
                                    onBridgeReady(final_result.jsapiParams, final_result.jsapi_return);
                                }
                                
                                // 微信支付回调函数
                                function onBridgeReady(params, return_url) {
                                    WeixinJSBridge.invoke(
                                        "getBrandWCPayRequest", params,
                                        function(res) {
                                            if (res.err_msg == "get_brand_wcpay_request:ok") {
                                                // 支付成功
                                                showNotification("支付成功", "success");
                                                if (return_url) {
                                                    window.location.href = return_url;
                                                } else {
                                                    setTimeout(function() {
                                                        window.location.reload();
                                                    }, 1500);
                                                }
                                            } else if (res.err_msg == "get_brand_wcpay_request:cancel") {
                                                // 支付取消
                                                showNotification("支付已取消", "warning");
                                            } else {
                                                // 支付失败
                                                showNotification("支付失败，请重试", "danger");
                                            }
                                        }
                                    );
                                }
                            } else if (final_result.msg == 1) {
                                // 支付成功
                                if (final_result.redirect) {
                                    // 跳转到支付页面
                                    console.log("Redirecting to:", final_result.redirect);
                                    window.location.href = final_result.redirect;
                                } else {
                                    showNotification(final_result.name || "支付成功", "success");
                                    setTimeout(function() {
                                        window.location.reload();
                                    }, 1500);
                                }
                            } else if (!final_result.error) {
                                // 其他成功情况
                                if (final_result.url_qrcode) {
                                    // 显示二维码支付界面 - 调用子比主题的支付模态框
                                    console.log("QR code URL:", final_result.url_qrcode);
                                    
                                    // 检查是否已初始化子比主题的支付模态框
                                    if (typeof window._win !== "undefined" && typeof window.jQuery !== "undefined") {
                                        // 使用子比主题的支付模态框
                                        var _modal = jQuery("#zibpay_modal");
                                        if (_modal.length > 0) {
                                            // 设置二维码
                                    _modal.find(".pay-qrcode img").attr("src", final_result.url_qrcode);
                                    
                                    // 设置订单信息
                                    final_result.order_name && _modal.find(".pay-title").html(final_result.order_name);
                                    final_result.order_price && _modal.find(".pay-price").html(final_result.order_price);
                                    final_result.payment_method && _modal.find(".pay-payment").removeClass("wechat alipay").addClass(final_result.payment_method);
                                    final_result.over_time && _modal.find(".pay-over-time").html("<span class=\"ml6 badg badg-sm\" int-second=\"1\" data-over-text=\"交易已关闭\" data-countdown=\"" + final_result.over_time + "\"></span>");
                                    
                                    // 更新通知信息，替换"正在生成订单，请稍候"
                                    _modal.find(".pay-notice .notice").removeClass("load warning success danger").html("请扫码支付，支付成功后会自动跳转");
                                    
                                    // 在显示新弹窗之前，关闭所有已打开的弹窗
                                    jQuery(".modal.in").modal("hide");
                                    
                                    // 显示模态框
                                    _modal.modal("show");
                                    
                                    // 初始化倒计时元素
                                    if (typeof jQuery.fn.countdown === "function") {
                                        _modal.find("[data-countdown]").countdown();
                                    }
                                    
                                    // 显示提示消息
                                    showNotification("请扫码支付，支付成功后会自动跳转", "success");
                                    
                                    // 设置订单信息到全局变量，以便子比主题的支付系统检测支付状态
                                    if (typeof window.order_result === "undefined") {
                                        window.order_result = {};
                                    }
                                    window.order_result = {
                                        order_num: final_result.order_num || final_result.order_id || "",
                                        check_sdk: final_result.check_sdk || "",
                                        url: final_result.url || "",
                                        open_url: final_result.open_url || ""
                                    };
                                    
                                    // 确保子比主题的支付检测状态
                                    if (typeof window.order_result !== "undefined" && typeof window.is_verify === "undefined") {
                                        window.is_verify = false;
                                    }
                                    
                                    // 调用子比主题的支付检测函数或自己实现
                                    function startPaymentVerification() {
                                        if (typeof verify_pay === "function") {
                                            // 调用子比主题的支付检测函数
                                            verify_pay();
                                        } else if (typeof window.order_result !== "undefined" && window.order_result.order_num) {
                                            // 子比主题的支付检测函数不存在，使用子比主题的check_pay action检测支付状态
                                            var checkPayInterval;
                                            function checkPaymentStatus() {
                                                $.ajax({
                                                    type: "POST",
                                                    url: window.ajax_url || "' . esc_js($ajaxurl) . '",
                                                    data: {
                                                        action: "check_pay",
                                                        order_num: window.order_result.order_num,
                                                        check_sdk: window.order_result.check_sdk || ""
                                                    },
                                                    dataType: "json",
                                                    success: function(response) {
                                                        if (response && response.status == "1") {
                                                            // 支付成功
                                                            clearInterval(checkPayInterval);
                                                            _modal.find(".pay-notice .notice").removeClass("load warning success danger").addClass("success").html("支付成功，页面跳转中");
                                                            showNotification("支付成功", "success");
                                                            
                                                            // 300毫秒后关闭弹窗并刷新页面（与子比主题保持一致）
                                                            setTimeout(function() {
                                                                // 关闭模态框
                                                                _modal.modal("hide");
                                                                // 刷新页面
                                                                window.location.reload();
                                                            }, 300);
                                                        } else if (response && response.status == "-1") {
                                                            // 支付超时
                                                            clearInterval(checkPayInterval);
                                                            _modal.find(".pay-notice .notice").removeClass("load warning success danger").addClass("danger").html("订单支付超时，请重新下单");
                                                        }
                                                    }
                                                });
                                            }
                                            // 立即检测一次，然后每2秒检测一次
                                            checkPaymentStatus();
                                            checkPayInterval = setInterval(checkPaymentStatus, 2000);
                                        }
                                    }
                                    
                                    // 5.9秒后开始检测（与子比主题保持一致）
                                    setTimeout(function() {
                                        startPaymentVerification();
                                        window.is_verify = true;
                                    }, 5900);
                                        } else {
                                            // 如果子比主题的模态框不存在，使用简单通知
                                            showNotification("请使用手机扫码支付", "success");
                                        }
                                    } else {
                                        // 如果子比主题的支付系统未初始化，使用简单通知
                                        showNotification("请使用手机扫码支付", "success");
                                    }
                                } else {
                                    // 没有明确的支付方式，显示错误
                                    showNotification("支付处理失败，请选择其他支付方式", "danger");
                                }
                            } else {
                                showNotification(final_result.msg || "操作失败", "danger");
                            }
                        },
                        error: function(xhr, status, error) {
                            // 记录详细的错误日志到控制台
                            console.error("[XK Auth] 其他支付方式请求失败:", {
                                status: status,
                                error: error,
                                statusText: xhr.statusText,
                                responseText: xhr.responseText,
                                readyState: xhr.readyState,
                                statusCode: xhr.status
                            });
                            
                            // 显示更详细的错误信息
                            var errorMsg = "请求失败: " + status;
                            if (error) {
                                errorMsg += " - " + error;
                            }
                            if (xhr.status) {
                                errorMsg += " (状态码: " + xhr.status + ")";
                            }
                            showNotification(errorMsg, "danger");
                        },
                        complete: function() {
                            console.log("Other payment method request complete");
                            window.xkAuthClicktype = true;
                            $("#xk-pay-with-money").html("立即支付");
                            $("#xk-pay-with-money").attr("disabled", false);
                        }
                    });
                }
            });
            
            // 积分支付按钮 - 先解绑再绑定，避免重复绑定
            $(document).off("click", "#xk-pay-with-points").on("click", "#xk-pay-with-points", function() {
                if (window.xkAuthClicktype == false) return false;
                window.xkAuthClicktype = false;
                
                var product_id = $(".xk-pay-form input[name=product_id]").val();
                var package_index = $(".xk-pay-form #time_package_index").val();
                var points_price = $(".xk-pay-form #selected_points_price").val();
                
                
                var text = "<i class=loading mr6></i> 支付中...";
                $(this).attr("disabled", true);
                $(this).html(text);
                
                $.ajax({
                    type: "POST",
                    url: "' . esc_js($ajaxurl) . '",
                    dataType: "json",
                    data: {
                        action: "xk_auth_pay_with_points",
                        product_id: product_id,
                        package_index: package_index,
                        points_price: points_price,
                        client_timestamp: new Date().getTime(),
                        client_user_agent: navigator.userAgent
                    },
                    success: function(response) {
                        
                        // 确保result是对象
                        var result = response;
                        if (typeof response === "string") {
                            try {
                                result = JSON.parse(response);
                            } catch (parseError) {
                                console.error("[XK Auth] JSON解析失败:", parseError);
                                console.error("[XK Auth] 原始响应内容:", response);
                                showNotification("响应解析失败，请查看控制台日志", "danger");
                                return;
                            }
                        }
                        
                        // 确保result是对象
                        result = result || {};
                        
                        if (result.msg == 1) {
                            showNotification(result.name || "支付成功", "success");
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            showNotification(result.name || "支付失败", "danger");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("[XK Auth] 积分支付请求失败:", {
                            status: status,
                            error: error,
                            statusText: xhr.statusText,
                            responseText: xhr.responseText,
                            readyState: xhr.readyState,
                            statusCode: xhr.status
                        });
                        showNotification("请求失败，请重试", "danger");
                    },
                    complete: function() {
                        window.xkAuthClicktype = true;
                        $("#xk-pay-with-points").html("立即支付");
                        $("#xk-pay-with-points").attr("disabled", false);
                        console.log("[XK Auth] 积分支付请求完成");
                    }
                });
            });
        });
    </script>';

    return $html;
}

/**
 * 生成绑定授权QQ模态框的HTML表单
 *
 * @param int|string $user_id 用户ID（可选，默认为空字符串）
 * @param int|string $product_id 产品ID（可选，默认为空字符串）
 *
 * @return string 生成的添加QQ模态框的HTML表单
 */
function xk_auth_increase_qq_form($user_id = '')
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    $form = '
        <div class="mb10 touch">
            <div class="mr10 inflex em12 mb20">
                <svg class="em14 mr10" aria-hidden="true"><use xlink:href="#icon-vip_2"></use></svg>
                <b>绑定QQ</b>
            </div>
            <form>
                <div class="mb10">
                    <input class="form-control" name="auth_qq" type="text" placeholder="请输授权QQ"><br>
                    <li class="c-red" style="--this-color: #ff6643;">
                        <i class="fa fa-info-circle mr6"></i>
                        此QQ为后期售后服务的唯一标识此站所有产品都为这个且不可修改！请谨慎填写！！！
                    </li>
                </div>
                <div class="box-body text-center nobottom">
                    <input type="hidden" name="action" value="increase_auth_qq">
                    <button type="button" zibajax="submit" class="but jb-blue radius btn-block padding-lg" name="submit">
                        <i class="fa fa-check mr10"></i> 确认提交
                    </button>
                </div>
            </form>           
        </div>
    ';

    return $form;
}