<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

/**
 * 检查用户是否已购买当前产品并记录授权日志
 * 
 * @param int $user_id 用户ID
 * @return array|bool 返回订单数据或false
 */
function xk_auth_pay_is_pid($user_id)
{
    // 如果未提供用户ID，则获取当前登录用户ID
    if (empty($user_id)) {
        $user_id = get_current_user_id();
    }

    // 确保用户已登录
    if (empty($user_id)) {
        return false;
    }

    // 产品ID与页面ID一致，获取当前页面ID作为产品ID
    $product_id = get_the_ID();

    // 确保获取到有效的产品ID（页面ID）
    if (empty($product_id)) {
        return false;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'zibpay_order';

    // 查询已支付的订单（匹配用户ID和产品ID=页面ID）
    $db_order = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $table_name WHERE `status` = 1 AND `user_id` = %d AND `post_id` = %d",
            $user_id,
            $product_id
        )
    );

    $auth_log_table = $wpdb->prefix . 'auth_logs';

    // 检查是否已经存在任何授权日志
    $existing_logs = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $auth_log_table 
                 WHERE `user_id` = %d 
                 AND `product_id` = %d",
            $user_id,
            $product_id
        )
    );

    // 如果有订单记录，但还没有授权日志，从插件配置中获取授权数量并插入日志
    if (!empty($db_order) && empty($existing_logs)) {
        // 获取插件配置中的产品设置
        $product_settings = xk_auth('product_settings', array());
        $auth_count = null; // 初始化为空，用于判断是否找到配置

        // 遍历配置中的产品，匹配当前产品ID（页面ID）
        if (!empty($product_settings)) {
            foreach ($product_settings as $product) {
                // 产品ID与页面ID一致，匹配成功
                if (isset($product['product_id']) && $product['product_id'] == $product_id) {
                    // 从配置中获取授权个数（转为整数）
                    $auth_count = intval($product['auth_count']);
                    break;
                }
            }
        }
        // 写入数据库
        xk_auth_insert_authorization_log(
            $user_id,
            $product_id,
            $auth_count, // 总授权数
            $auth_count, // 剩余授权数（初始等于总授权数）
            "用户初次购买获得额度",
            NULL // 到期时间（初次购买时可能还没有到期时间，后续会从支付流程中获取）
        );

        return $db_order;
    }

    return false;
}

/**
 * 为子比主题V8.2支付单独适配 - 修复版本
 * 当order_type为我们的自定义类型时，提供订单数据
 */
function xk_auth_handle_custom_order_type_fixed($data, $post_data)
{
    // 检查是否是我们的订单类型 - 使用更严格的验证
    if (empty($post_data['order_type']) || (int) $post_data['order_type'] != 15) {
        return $data;
    }

    // 获取当前用户ID
    $user_id = get_current_user_id();
    if (!$user_id && !_pz('pay_no_logged_in', true)) {
        zib_send_json_error('请先登录');
    }

    // 获取产品ID
    $post_id = !empty($post_data['post_id']) ? (int) $post_data['post_id'] : 0;
    if (!$post_id) {
        zib_send_json_error('产品数据获取错误');
    }

    // 获取页面信息
    $post = get_post($post_id);
    if (empty($post->post_author)) {
        zib_send_json_error('产品数据获取错误');
    }

    // 获取支付配置
    $pay_mate = get_post_meta($post_id, 'posts_zibpay', true);
    if (empty($pay_mate)) {
        zib_send_json_error('支付配置获取失败');
    }

    // 确保支付类型正确设置为15
    $pay_mate['pay_type'] = 15;

    // 获取支付价格
    $order_price = isset($pay_mate['pay_price']) ? round((float) $pay_mate['pay_price'], 2) : 0;

    // 处理会员价格
    if ($user_id) {
        $vip_level = zib_get_user_vip_level($user_id);
        if ($vip_level && _pz('pay_user_vip_' . $vip_level . '_s', true) && isset($pay_mate['vip_' . $vip_level . '_price'])) {
            if (!$pay_mate['vip_' . $vip_level . '_price']) {
                zib_send_json_error('会员免费，请刷新页面', 'info');
            }
            $vip_price = round((float) $pay_mate['vip_' . $vip_level . '_price'], 2);
            // 会员金额和正常金额取更小值
            $order_price = $vip_price < $order_price ? $vip_price : $order_price;
        }
    }

    // 构建完整的订单数据
    $__data = array(
        'user_id' => $user_id,
        'post_id' => $post_id,
        'post_author' => $post->post_author,
        'order_type' => 15, // 统一使用15
        'product_id' => !empty($pay_mate['product_id']) ? $pay_mate['product_id'] : 'custom_' . $post_id,
        'order_price' => $order_price,
        'payment_method' => !empty($post_data['payment_method']) ? $post_data['payment_method'] : 'wechat'
    );

    // 设置全局订单元数据
    global $__mate_order_data;
    $__mate_order_data = array(
        'author_id' => $post->post_author,
        'product_id' => $post->ID,
        'product_title' => $post->post_title,
        'prices' => array(
            'total_price' => $order_price,
            'unit_price' => $order_price,
            'pay_price' => $order_price
        )
    );

    return $__data;
}

// 移除旧的过滤器，添加新的
remove_filter('initiate_order_data_type_3', 'xk_auth_handle_custom_order_type');
add_filter('initiate_order_data_type_15', 'xk_auth_handle_custom_order_type_fixed', 10, 2);

/**
 * 为自定义支付类型添加主动查询支持
 */
function xk_auth_payment_status_query($order_id)
{
    global $wpdb;

    $order = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}zibpay_order WHERE id = %d",
        $order_id
    ));

    if ($order && $order->order_type == 15) {
        // 这里是您的自定义支付状态查询逻辑
        // 返回支付状态：1=已支付，0=待支付，-1=已关闭
        return xk_auth_check_payment_status($order);
    }

    return false;
}

add_filter('zibpay_custom_payment_status_query', 'xk_auth_payment_status_query');

/**
 * 检查授权支付状态
 * 
 * @param object $order 订单对象
 * @return int 返回支付状态：1=已支付，0=待支付，-1=已关闭
 */
function xk_auth_check_payment_status($order) {
    global $wpdb;
    
    // 检查订单是否存在
    if (!isset($order->id)) {
        return 0; // 订单不存在，返回待支付状态
    }
    
    // 直接从订单对象获取状态
    if (isset($order->status)) {
        return (int)$order->status;
    }
    
    // 如果订单对象没有status属性，则查询数据库获取最新状态
    $latest_status = $wpdb->get_var($wpdb->prepare(
        "SELECT status FROM {$wpdb->prefix}zibpay_order WHERE id = %d",
        $order->id
    ));
    
    if ($latest_status !== null) {
        return (int)$latest_status;
    }
    
    // 默认返回待支付状态
    return 0;
}

/**
 * 调试支付数据
 */
function xk_auth_debug_payment_data()
{
    if (current_user_can('manage_options') && isset($_GET['debug_payment'])) {
        global $post;
        $pay_mate = get_post_meta($post->ID, 'posts_zibpay', true);
        echo '<pre>支付配置数据：';
        print_r($pay_mate);
        echo '</pre>';

        $user_id = get_current_user_id();
        $order_data = xk_auth_pay_is_pid($user_id);
        echo '<pre>订单数据：';
        print_r($order_data);
        echo '</pre>';
    }
}
add_action('wp_head', 'xk_auth_debug_payment_data');

/**
 * 修复支付表单初始化
 */
function xk_auth_fix_pay_form_init()
{
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            // 确保支付表单正确初始化
            $('.pay-form').on('click', '.initiate-pay', function (e) {
                e.preventDefault();

                // 验证支付方式选择
                var payment_method = $('input[name="payment_method"]').val();
                if (!payment_method) {
                    zib_js_alert('warning', '请选择支付方式');
                    return false;
                }

                // 提交支付请求
                xk_auth_submit_payment();
            });

            // 支付方式切换
            $('.payment-method-radio').on('click', function () {
                var method = $(this).data('value');
                $('input[name="payment_method"]').val(method);
                $(this).addClass('active').siblings().removeClass('active');
            });
        });

        function xk_auth_submit_payment() {
            var formData = new FormData();
            formData.append('action', 'submit_order');
            formData.append('order_type', 15);
            formData.append('post_id', '<?php echo get_the_ID(); ?>');
            formData.append('payment_method', $('input[name="payment_method"]').val());

            // 添加AJAX请求
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        // 支付发起成功
                        if (response.data.pay_url) {
                            window.location.href = response.data.pay_url;
                        } else if (response.data.msg) {
                            zib_js_alert('success', response.data.msg);
                        }
                    } else {
                        zib_js_alert('error', response.data);
                    }
                },
                error: function () {
                    zib_js_alert('error', '网络请求失败，请稍后重试');
                }
            });
        }
    </script>
    <?php
}
add_action('wp_footer', 'xk_auth_fix_pay_form_init');