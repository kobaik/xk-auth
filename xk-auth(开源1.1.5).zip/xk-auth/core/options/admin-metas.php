<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 页面配置参数详情
function xk_auth_add_meta_box_args($args)
{
    $post_id = !empty($_GET['post']) ? $_GET['post'] : '';
    $post_type = !empty($_GET['post_type']) ? $_GET['post_type'] : get_post_type($post_id);
    if ($post_type == 'page') {
        $args[0] = array(
            'title' => '授权购买',
            'id' => 'pay_type',
            'type' => 'radio',
            'default' => 'no',
            'desc' => '开启并完成下方配置，可获得子比同款产品购买页面',
            'inline' => true,
            'options' => array(
                'no' => __('关闭', 'zib_language'),
                15 => __('开启', 'zib_language'),
            ),
        );
        $args[] = array(
            'dependency' => array('pay_type', '==', '15'),
            'title' => __('', 'zib_language'),
            'id' => 'product_id1',
            'type' => 'submessage',
            'class' => 'mini pay-hide',
            'content' => '<h4>内容配置</h4>
                <p style="color:#fb2121;background:undefined">商品名称、介绍、更多详情为必填项，请务必填写</p>',
        );
        $args[] = array(
            'dependency' => array('pay_type', '==', '15'),
            'title' => __('幻灯片', 'zib_language'),
            'id' => 'pay_slides',
            'desc' => __('并注意保持图片尺寸一致', 'zib_language'),
            'class' => 'pay-hide',
            'default' => '',
            'type' => 'gallery',
        );
        $args[] = array(
            'dependency' => array('pay_type', '==', '15'),
            'title' => __('幻灯片下方按钮', 'zib_language'),
            'id' => 'pay_button',
            'desc' => __('幻灯片底部按钮', 'zib_language'),
            'class' => 'pay-hide',
            'default' => '',
            'type' => 'group',
            'fields' => array(
                array(
                    'title' => __('文字', 'zib_language'),
                    'id' => 'button_text',
                    'placeholder' => '输入按钮文字',
                    'preview' => false,
                    'type' => 'text',
                ),
                array(
                    'title' => __('链接', 'zib_language'),
                    'id' => 'button_link',
                    'placeholder' => '输入链接',
                    'preview' => false,
                    'type' => 'text',
                ),
            ),
        );
        $args[] = array(
            'dependency' => array('pay_type', '==', '15'),
            'id' => 'pay_countdown_price',
            'title' => __('限时活动', 'zib_language'),
            'desc' => __('可开启限时活动折扣倒计时', 'zib_language'),
            'default' => '',
            'type' => 'switcher',
        );
        $args[] = array(
            'dependency' => array('pay_countdown_price', '!=', ''),
            'title' => __(' ', 'zib_language'),
            'subtitle' => __('限时活动标题', 'zib_language'),
            'id' => 'countdown_activity_title',
            'class' => 'pay-hide',
            'default' => '',
            'type' => 'text',
        );
        $args[] = array(
            'dependency' => array('pay_countdown_price', '!=', ''),
            'title' => ' ',
            'subtitle' => __('限时活动简介', 'zib_language'),
            'id' => 'countdown_activity_desc',
            'class' => 'pay-hide compact',
            'default' => '',
            'type' => 'textarea',
        );
        $args[] = array(
            'dependency' => array('pay_countdown_price', '!=', ''),
            'title' => ' ',
            'subtitle' => __('限时结束时间', 'zib_language'),
            'class' => 'pay-hide compact',
            'id' => 'stop_time',
            'type' => 'date',
            'default' => '',
            'settings' => array(
                'dateFormat' => 'yy-mm-dd 23:59:59',
                'changeMonth' => true,
                'changeYear' => true,
            ),
        );
        // $args[] = array(
        //     'id' => 'auth_system_type',
        //     'title' => '授权对接方式选择',
        //     'default' => '0',
        //     'inline' => true,
        //     'type' => 'radio',
        //     'options' => array(
        //         '0' => __('本地数据库', 'zib_language'),
        //         '1' => __('南逸多应用授权系统', 'zib_language'),
        //     ),
        //     'desc' => '选择其他系统仍然会在本站数据库存储授权信息哦~',
        // );
        // $args[] = array(
        //     'dependency' => array('auth_system_type', '==', '1'),
        //     'id' => 'nanyi_auth_option',
        //     'type' => 'accordion',
        //     'title' => '南逸授权系统',
        //     'accordions' => array(
        //         array(
        //             'title' => '南逸授权系统对接信息配置',
        //             'fields' => array(
        //                 array(
        //                     'title' => '站点域名',
        //                     'id' => 'nanyi_auth_domain',
        //                     'desc' => '填写您授权站的域名，前为http(s)://后为/',
        //                     'default' => '',
        //                     'type' => 'text',
        //                 ),
        //                 array(
        //                     'title' => '产品ID',
        //                     'class' => 'compact',
        //                     'id' => 'nanyi_auth_appid',
        //                     'desc' => '填写您授权站要对接的产品ID',
        //                     'default' => '',
        //                     'type' => 'text',
        //                 ),
        //                 array(
        //                     'title' => '用户名',
        //                     'class' => 'compact',
        //                     'id' => 'nanyi_auth_adminna',
        //                     'desc' => '填写您授权站管理员的用户名',
        //                     'default' => '',
        //                     'type' => 'text',
        //                 ),
        //                 array(
        //                     'title' => '密码',
        //                     'class' => 'compact',
        //                     'id' => 'nanyi_auth_adminpw',
        //                     'desc' => '填写您授权站管理员的密码',
        //                     'default' => '',
        //                     'type' => 'text',
        //                 ),
        //                 array(
        //                     'title' => 'WebKey',
        //                     'class' => 'compact',
        //                     'id' => 'nanyi_auth_weykey',
        //                     'desc' => '填写您授权站设置的WebKey<br><p style="color: #ee3f17;padding:0px 3px">如不明白如何填写，请查看<a target="_blank" href="https://www.mengdo.cn/">官方教程</a></p>',
        //                     'default' => '',
        //                     'type' => 'text',
        //                 ),
        //             ),
        //         ),
        //     ),
        // );
    }
    return $args;
}