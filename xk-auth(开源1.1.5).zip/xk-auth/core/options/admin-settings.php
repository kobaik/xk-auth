<?php
/*
 * @Author: 星空
 * @Url: xkzhi.com
 * @Date: 2024-12-15 05:17:45
 * @LastEditTime: 2026-1-2 08:07:45
 * @Email: 1397403557@qq.com
 * @Project: 星空授权插件
 * @Description: 子比多功能授权插件
 * @Remind: 使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */


if (class_exists('CSF')) {

    $prefix = 'xk_auth_setting';
    $img = '/wp-content/plugins/xk-auth/img/';

    // 确保XK_AUTH_VERSION常量已定义
    if (!defined('XK_AUTH_VERSION')) {
        define('XK_AUTH_VERSION', '1.1.5');
    }

    // 开始构建
    CSF::createOptions(
        $prefix,
        array(
            'menu_title' => '星空授权设置',
            'framework_title' => '星空授权插件',
            'menu_slug' => $prefix,
            'theme' => 'light',
            'show_in_customizer' => true,
            'footer_text' => '<i class="fa fa-fw fa-heart-o" aria-hidden="true"></i>更好的子比主题授权功能方案-星空授权插件 V' . XK_AUTH_VERSION,
            'footer_credit' => '<i class="fa fa-fw fa-heart-o" aria-hidden="true"></i> ',
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'id' => 'product',
            'title' => '产品配置',
            'icon' => 'fa fa-fw fa-search',
        )
    );


    CSF::createSection(
        $prefix,
        array(
            'parent' => 'product',
            'title' => '全局设置',
            'icon' => 'fa fa-fw fa-tags',
            'description' => '',
            'fields' => array(
                array(
                    'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 星空授权使用许可协议：</h3>
                    <p>星空授权插件是一款良心、厚道的好产品！创作不易，支持正版，从我做起！</p>
                    <div style="margin:10px 14px;"><ul>
                    <li>本页面由星空网络一人制作，请大家在使用的时候遵守原作者的辛苦劳动</li>
                    <li>唯一官网网址(功能教程及授权售卖)：<a target="_blank" href="https://www.xkzhi.cn">https://www.xkzhi.cn</a></li>
                    <li>如果有涉及自带HTML代码的输入框功能，需要自行注意代码规范以及代码闭合。</li>
                    <li>如有任何疑问问题可以联系作者QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1397403557&amp;site=qq&amp;menu=yes">QQ 1397403557</a></li></ul></div>',
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
                array(
                    'id' => 'sidebar_title',
                    'type' => 'text',
                    'title' => '用户中心侧边栏标题',
                    'subtitle' => '自定义用户中心侧边栏的主标题',
                    'desc' => '例如："产品授权管理"',
                    'default' => '产品授权管理',
                ),
                array(
                    'id' => 'sidebar_desc',
                    'type' => 'text',
                    'title' => '用户中心侧边栏描述',
                    'subtitle' => '自定义用户中心侧边栏的说明文本',
                    'desc' => '例如："管理您购买的所有产品授权"',
                    'default' => '管理您购买的所有产品授权',
                ),
                array(
                    'id' => 'default_product_id',
                    'type' => 'number',
                    'title' => '默认产品ID',
                    'subtitle' => '当用户未选择产品时使用的默认产品ID',
                    'desc' => '此处产品ID与页面ID一致',
                    "after" => '<a target="_blank" href="https://demo.xkzil.com/152/.html">页面ID查看教程</a>',
                    'default' => '',
                ),
                array(
                    'id' => 'auth_query_enabled',
                    'type' => 'switcher',
                    'title' => '启用授权查询功能',
                    'subtitle' => '允许通过公开页面查询授权信息',
                    'desc' => '开启后，访问 /wp-content/plugins/xk-auth/auth-query.php 可进入授权查询页面',
                    'default' => true,
                ),
                array(
                    'id' => 'auth_query_logo',
                    'type' => 'upload',
                    'title' => '授权查询页面Logo',
                    'subtitle' => '自定义授权查询页面顶部显示的Logo',
                    'desc' => '上传Logo图片，留空则不显示Logo',
                    'default' => '',
                    'dependency' => array('auth_query_enabled', '==', true),
                ),
                array(
                    'id' => 'auth_query_logo_width',
                    'type' => 'slider',
                    'title' => 'Logo宽度',
                    'subtitle' => '设置Logo图片的显示宽度',
                    'desc' => '单位：像素',
                    'min' => 50,
                    'max' => 300,
                    'step' => 10,
                    'default' => 150,
                    'dependency' => array('auth_query_enabled', '!=', ''),
                ),
            ),
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'product',
            'title' => '接口设置',
            'icon' => 'fa fa-fw fa-tags',
            'description' => '',
            'fields' => array(
                array(
                    'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 星空授权使用许可协议：</h3>
                    <p>星空授权插件是一款良心、厚道的好产品！创作不易，支持正版，从我做起！</p>
                    <div style="margin:10px 14px;"><ul>
                    <li>本页面由星空网络一人制作，请大家在使用的时候遵守原作者的辛苦劳动</li>
                    <li>唯一官网网址(功能教程及授权售卖)：<a target="_blank" href="https://www.xkzhi.cn">https://www.xkzhi.cn</a></li>
                    <li>如果有涉及自带HTML代码的输入框功能，需要自行注意代码规范以及代码闭合。</li>
                    <li>如有任何疑问问题可以联系作者QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1397403557&amp;site=qq&amp;menu=yes">QQ 1397403557</a></li></ul></div>',
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
            array(
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> token获取</h3>
                    <p>通过授权API路由的&action=get_dynamic_token获取</p>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
                array(
                    'title' => '授权API路由',
                    'id' => 'auth_api',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'id' => 'authorization',
                            'title' => '授权路由器',
                            'class' => 'mini-input',
                            'default' => 'Authorization/v1',
                            'type' => 'text',
                            'desc' => '设置后自定义公告路由器 Authorization/v1 改自设置的内容',
                        ),
                        array(
                            'title' => '识别密钥',
                            'id' => 'authorization_key',
                            'type' => 'text',
                            'default' => 'key',
                            'desc' => '设置后自定义识别密钥后 key 改自设置的内容',
                        ),
                        array(
                            'type' => 'notice',
                            'style' => 'info ',
                            'content' => '接口地址：/wp-json/Authorization/v1/key?product_id=产品ID&domain=请求域名&auth_key=授权码&(括号去掉和汉字)current_version=版本号&dynamic_token=动态token',
                        ),
                    ),
                ),
                array(
                    'title' => '更新API路由',
                    'id' => 'update_api',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'id' => 'pdate',
                            'title' => '更新路由器',
                            'class' => 'mini-input',
                            'default' => 'Update/v1',
                            'type' => 'text',
                            'desc' => '设置后自定义公告路由器 Update/v1 改自设置的内容',
                        ),
                        array(
                            'title' => '识别密钥',
                            'id' => 'update_key',
                            'type' => 'text',
                            'default' => 'key',
                            'desc' => '设置后自定义识别密钥后 key 改自设置的内容',
                        ),
                        array(
                            'type' => 'notice',
                            'style' => 'info ',
                            'content' => '接口地址：/wp-json/Update/v1/key?product_id=产品ID&domain=请求域名&auth_key=授权码&(括号去掉和汉字)current_version=当前版本号&dynamic_token=动态token',
                        ),
                    ),
                ),
                array(
                    'title' => '公告API路由',
                    'id' => 'notice_api',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'id' => 'notice',
                            'title' => '公告路由器',
                            'class' => 'mini-input',
                            'default' => 'Notice/v1',
                            'type' => 'text',
                            'desc' => '设置后自定义公告路由器 Notice/v1 改自设置的内容',
                        ),
                        array(
                            'title' => '识别密钥',
                            'id' => 'notice_key',
                            'type' => 'text',
                            'default' => 'key',
                            'desc' => '设置后自定义识别密钥后 key 改自设置的内容',
                        ),
                        array(
                            'type' => 'notice',
                            'style' => 'info ',
                            'content' => '接口地址：/wp-json/Notice/v1/key?product_id=产品ID&domain=请求域名&auth_key=授权码&dynamic_token=动态token',
                        ),
                    ),
                ),
            ),
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'product',
            'title' => '产品信息',
            'icon' => 'fa fa-fw fa-tags',
            'description' => '',
            'fields' => array(
                array(
                    'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 星空授权使用许可协议：</h3>
                    <p>星空授权插件是一款良心、厚道的好产品！创作不易，支持正版，从我做起！</p>
                    <div style="margin:10px 14px;"><ul>
                    <li>本页面由星空网络一人制作，请大家在使用的时候遵守原作者的辛苦劳动</li>
                    <li>唯一官网网址(功能教程及授权售卖)：<a target="_blank" href="https://www.xkzhi.cn">https://www.xkzhi.cn</a></li>
                    <li>如果有涉及自带HTML代码的输入框功能，需要自行注意代码规范以及代码闭合。</li>
                    <li>如有任何疑问问题可以联系作者QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1397403557&amp;site=qq&amp;menu=yes">QQ 1397403557</a></li></ul></div>',
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
                array(
                    'id' => 'product_settings',
                    'type' => 'group',
                    'min' => '1',
                    'button_title' => '添加产品',
                    'title' => '产品授权设置',
                    'subtitle' => '配置多个产品的授权信息',
                    'desc' => '添加多个产品的授权信息，每个产品可设置独立的授权数量和ID',
                    'default' => array(),
                    'fields' => array(
                        array(
                            'id' => 'product_name',
                            'type' => 'text',
                            'title' => '产品名称',
                            'subtitle' => '输入产品的显示名称',
                            'desc' => '将显示在用户界面的产品名称',
                            'default' => '',
                        ),
                        array(
                            'id' => 'product_id',
                            'type' => 'number',
                            'title' => '产品ID',
                            'subtitle' => '输入产品的唯一标识ID',
                            'desc' => '此处填写对应产品的页面ID',
                            "after" => '<a target="_blank" href="https://demo.xkzil.com/152/.html">页面ID查看教程</a>',
                            'default' => '',
                            'min' => 1,
                        ),
                        array(
                            'id' => 'auth_count',
                            'type' => 'number',
                            'title' => '授权个数',
                            'subtitle' => '设置该产品的可用授权数量',
                            'desc' => '允许用户激活的设备或用户数量',
                            'default' => 3,
                            'min' => 1,
                        ),
                        array(
                            'id' => 'down_1',
                            'type' => 'text',
                            'title' => '极速下载',
                            'subtitle' => '下载按钮1',
                            'desc' => '在此处填写极速下载下载链接',
                            'default' => '',
                        ),
                        array(
                            'id' => 'down_2',
                            'type' => 'text',
                            'title' => '备用下载',
                            'subtitle' => '下载按钮2',
                            'desc' => '在此处填写备用下载下载链接',
                            'default' => '',
                        ),
                        array(
                            'id' => 'version',
                            'type' => 'text',
                            'title' => '版本号',
                            'subtitle' => '输入数字即可',
                            'desc' => '下载链接旁的版本号自带“V”',
                            'default' => '',
                        ),
                        array(
                            'id' => 'auth_system_type',
                            'type' => 'select',
                            'title' => '授权系统类型',
                            'subtitle' => '选择授权对接方式',
                            'desc' => '本地数据库：仅存储在当前站点数据库<br>南逸多应用授权系统：对接外部授权API',
                            'options' => array(
                                '0' => '本地数据库',
                                '1' => '南逸多应用授权系统'
                            ),
                            'default' => '0',
                        ),
                        array(
                            'id' => 'nanyi_site_domain',
                            'type' => 'text',
                            'title' => '南逸授权站点域名',
                            'subtitle' => '南逸授权系统的站点域名',
                            'desc' => '填写南逸授权系统的站点域名',
                            'default' => '',
                            'dependency' => array('auth_system_type', '==', '1'),
                        ),
                        array(
                            'id' => 'nanyi_product_id',
                            'type' => 'text',
                            'title' => '南逸产品ID',
                            'subtitle' => '在南逸授权系统中的产品ID',
                            'desc' => '与南逸授权系统中创建的产品ID一致',
                            'default' => '',
                            'dependency' => array('auth_system_type', '==', '1'),
                        ),
                        array(
                            'id' => 'nanyi_username',
                            'type' => 'text',
                            'title' => '南逸授权用户名',
                            'subtitle' => '南逸授权系统的登录用户名',
                            'default' => '',
                            'dependency' => array('auth_system_type', '==', '1'),
                        ),
                        array(
                            'id' => 'nanyi_password',
                            'type' => 'text',
                            'title' => '南逸授权密码',
                            'subtitle' => '南逸授权系统的登录密码',
                            'default' => '',
                            'dependency' => array('auth_system_type', '==', '1'),
                        ),
                        array(
                            'id' => 'nanyi_webkey',
                            'type' => 'text',
                            'title' => '南逸WebKey',
                            'subtitle' => '南逸授权系统的API密钥',
                            'desc' => '在南逸授权系统-API设置中获取',
                            'default' => '',
                            'dependency' => array('auth_system_type', '==', '1'),
                        ),
                        array(
                            'id' => 'warning_message',
                            'type' => 'textarea',
                            'title' => '提示信息',
                            'subtitle' => '显示在产品授权页面的警示信息',
                            'desc' => '支持HTML标签，左侧显示的提示信息',
                            'default' => '<div class="mt10 mr20">
        <div class="ml20">
            <li class="c-yellow-2 mb6">严禁用于任何违法内容，一经发现直接报警<a target="_blank" class="focus-color" href="#">【查看详情】</a></li>
            <li class="c-yellow-2 mb6">请严格遵守授权规范，违规使用将做封号处理<a target="_blank" class="focus-color" href="#">【查看详情】</a></li><li class="c-blue mb6">首次使用请查看<a href="#" target="_blank" class="focus-color">【WordPress搭建教程】</a>、<a href="#" target="_blank" class="focus-color">【主题安装教程及准备】</a></li>
            <li class="c-blue-2 mb6">更新主题推荐使用一键在线更新<a href="#" target="_blank" class="focus-color">【查看教程】</a></li>
<li class="c-blue mb6">更新授权域名后，如需更换网站域名请使用<a href="#" target="_blank" class="focus-color">【一键换域名插件】</a></li>
            <li class="c-yellow">
                更新主题请务必<b class="c-red">清空浏览器缓存</b>、<b class="c-red">刷新CDN缓存</b></li>

        </div>
        <div class="mt10 ml10"><a target="_blank" href="#" class="but c-blue mt6 mr10"><i aria-hidden="true" class="fa fa-cloud-upload"></i>更新日志</a>
            <a target="_blank" class="but c-blue mt6 mr10" href="#"><i aria-hidden="true" class="fa fa-grav"></i>社区论坛</a>
            <a target="_blank" class="but c-blue mt6 mr10" href="#"><i aria-hidden="true" class="fa fa-bookmark"></i>主题文档</a></div>
    </div>',
                            'settings' => array(
                                'rows' => 5,
                                'placeholder' => '请输入信息，支持HTML！',
                            ),
                        ),
                        array(
                            'id' => 'official_group',
                            'type' => 'text',
                            'title' => '正版群号',
                            'subtitle' => '正版用户群的QQ号码',
                            'desc' => '显示在二维码下方的群号',
                            'default' => '',
                        ),
                        array(
                            'id' => 'group_qrcode',
                            'type' => 'upload',
                            'title' => '群二维码图片链接',
                            'subtitle' => '正版用户群的二维码图片链接',
                            'desc' => '右侧显示的二维码图片',
                            'default' => 'https://oss.xkzhi.com/2025/12/20/vpzj8z.webp',
                        ),
                        array(
                            'id' => 'time_packages',
                            'type' => 'group',
                            'title' => '时间套餐设置',
                            'subtitle' => '为该产品配置不同的时间套餐',
                            'desc' => '添加多个时间套餐，每个套餐可设置时长、支付类型和对应价格',
                            'button_title' => '添加套餐',
                            'fields' => array(
                                array(
                                    'id' => 'package_name',
                                    'type' => 'text',
                                    'title' => '套餐名称',
                                    'subtitle' => '输入套餐的显示名称',
                                    'desc' => '例如：1个月、1年',
                                    'default' => '',
                                ),
                                array(
                                    'id' => 'package_duration',
                                    'type' => 'number',
                                    'title' => '时长（天）',
                                    'subtitle' => '设置套餐的有效天数',
                                    'desc' => '例如：30表示1个月，365表示1年，0表示永久授权',
                                    'default' => 30,
                                    'min' => 0,
                                ),
                                array(
                                    'id' => 'package_payment_type',
                                    'type' => 'select',
                                    'title' => '套餐支付类型',
                                    'subtitle' => '选择该套餐的支付方式',
                                    'desc' => '该套餐只能使用一种支付方式，价格或积分',
                                    'options' => array(
                                        'money' => '价格支付',
                                        'points' => '积分支付',
                                    ),
                                    'default' => 'money',
                                ),
                                array(
                                    'id' => 'package_price',
                                    'type' => 'text',
                                    'title' => '套餐价格',
                                    'subtitle' => '设置套餐的基础价格（非会员价格）',
                                    'desc' => '支持小数，例如：9.99',
                                    'default' => '0.00',
                                    'dependency' => array('package_payment_type', '==', 'money'),
                                ),
                                array(
                                    'id' => 'package_vip_1_price',
                                    'type' => 'text',
                                    'title' => '黄金会员价格',
                                    'subtitle' => '设置黄金会员购买该套餐的价格',
                                    'desc' => '支持小数，留空则按照折扣自动计算',
                                    'default' => '0.00',
                                    'dependency' => array('package_payment_type', '==', 'money'),
                                ),
                                array(
                                    'id' => 'package_vip_2_price',
                                    'type' => 'text',
                                    'title' => '钻石会员价格',
                                    'subtitle' => '设置钻石会员购买该套餐的价格',
                                    'desc' => '支持小数，留空则按照折扣自动计算',
                                    'default' => '0.00',
                                    'dependency' => array('package_payment_type', '==', 'money'),
                                ),
                                array(
                                    'id' => 'package_points_price',
                                    'type' => 'number',
                                    'title' => '积分价格',
                                    'subtitle' => '设置套餐的基础积分价格（非会员价格）',
                                    'desc' => '用户可以使用积分购买该套餐',
                                    'default' => 0,
                                    'min' => 0,
                                    'dependency' => array('package_payment_type', '==', 'points'),
                                ),
                                array(
                                    'id' => 'package_vip_1_points_price',
                                    'type' => 'number',
                                    'title' => '黄金会员积分价格',
                                    'subtitle' => '设置黄金会员购买该套餐的积分价格',
                                    'desc' => '留空则按照折扣自动计算',
                                    'default' => 0,
                                    'min' => 0,
                                    'dependency' => array('package_payment_type', '==', 'points'),
                                ),
                                array(
                                    'id' => 'package_vip_2_points_price',
                                    'type' => 'number',
                                    'title' => '钻石会员积分价格',
                                    'subtitle' => '设置钻石会员购买该套餐的积分价格',
                                    'desc' => '留空则按照折扣自动计算',
                                    'default' => 0,
                                    'min' => 0,
                                    'dependency' => array('package_payment_type', '==', 'points'),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        )
    );

    CSF::createSection(
        $prefix,
        array(
            'parent' => 'safe',
            'title' => '接口设置',
            'icon' => 'fa fa-fw fa-tags',
            'description' => '',
            'fields' => array(
                array(
                    'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 星空授权使用许可协议：</h3>
                    <p>星空授权插件是一款良心、厚道的好产品！创作不易，支持正版，从我做起！</p>
                    <div style="margin:10px 14px;"><ul>
                    <li>本页面由星空网络一人制作，请大家在使用的时候遵守原作者的辛苦劳动</li>
                    <li>唯一官网网址(功能教程及授权售卖)：<a target="_blank" href="https://www.xkzhi.cn">https://www.xkzhi.cn</a></li>
                    <li>如果有涉及自带HTML代码的输入框功能，需要自行注意代码规范以及代码闭合。</li>
                    <li>如有任何疑问问题可以联系作者QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1397403557&amp;site=qq&amp;menu=yes">QQ 1397403557</a></li></ul></div>',
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
                array(
                    'title' => '授权API路由',
                    'id' => 'auth_api',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'id' => 'authorization',
                            'title' => '授权路由器',
                            'class' => 'mini-input',
                            'default' => 'Authorization/v1',
                            'type' => 'text',
                            'desc' => '设置后自定义公告路由器 Authorization/v1 改自设置的内容',
                        ),
                        array(
                            'title' => '识别密钥',
                            'id' => 'authorization_key',
                            'type' => 'text',
                            'default' => 'key',
                            'desc' => '设置后自定义识别密钥后 key 改自设置的内容',
                        ),
                        array(
                            'type' => 'notice',
                            'style' => 'info ',
                            'content' => '接口地址：/wp-json/Authorization/v1/key?product_id=产品ID&domain=请求域名&auth_key=授权码&(括号去掉和汉字)current_version=版本号',
                        ),
                    ),
                ),
                array(
                    'title' => '更新API路由',
                    'id' => 'update_api',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'id' => 'pdate',
                            'title' => '更新路由器',
                            'class' => 'mini-input',
                            'default' => 'Update/v1',
                            'type' => 'text',
                            'desc' => '设置后自定义公告路由器 Update/v1 改自设置的内容',
                        ),
                        array(
                            'title' => '识别密钥',
                            'id' => 'update_key',
                            'type' => 'text',
                            'default' => 'key',
                            'desc' => '设置后自定义识别密钥后 key 改自设置的内容',
                        ),
                        array(
                            'type' => 'notice',
                            'style' => 'info ',
                            'content' => '接口地址：/wp-json/Update/v1/key?product_id=产品ID&domain=请求域名&auth_key=授权码&(括号去掉和汉字)current_version=当前版本号',
                        ),
                    ),
                ),
                array(
                    'title' => '公告API路由',
                    'id' => 'notice_api',
                    'type' => 'fieldset',
                    'fields' => array(
                        array(
                            'id' => 'notice',
                            'title' => '公告路由器',
                            'class' => 'mini-input',
                            'default' => 'Notice/v1',
                            'type' => 'text',
                            'desc' => '设置后自定义公告路由器 Notice/v1 改自设置的内容',
                        ),
                        array(
                            'title' => '识别密钥',
                            'id' => 'notice_key',
                            'type' => 'text',
                            'default' => 'key',
                            'desc' => '设置后自定义识别密钥后 key 改自设置的内容',
                        ),
                        array(
                            'type' => 'notice',
                            'style' => 'info ',
                            'content' => '接口地址：/wp-json/Notice/v1/key?product_id=产品ID&domain=请求域名&auth_key=授权码',
                        ),
                    ),
                ),
            ),
        )
    );
    
    // API请求频率限制设置
    CSF::createSection(
        $prefix,
        array(
            'id' => 'api_rate_limit',
            'title' => 'API请求限制',
            'icon' => 'fa fa-shield',
            'fields' => array(
                array(
                    'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> API请求频率限制：</h3>
                    <p>设置API请求的频率限制，防止恶意请求</p>',
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
                array(
                    'id' => 'enable_api_rate_limit',
                    'type' => 'switcher',
                    'title' => '开启API请求限制',
                    'subtitle' => '是否开启API请求频率限制功能',
                    'desc' => '开启后，系统将限制同一IP的API请求频率',
                    'default' => false,
                ),
                array(
                    'id' => 'api_rate_limit_count',
                    'type' => 'number',
                    'title' => '请求限制次数',
                    'subtitle' => '在指定时间内允许的最大请求次数',
                    'desc' => '例如：5表示在指定时间内最多允许5次请求',
                    'default' => 5,
                    'min' => 1,
                    'max' => 100,
                    'dependency' => array('enable_api_rate_limit', '==', true),
                ),
                array(
                    'id' => 'api_rate_limit_time',
                    'type' => 'number',
                    'title' => '限制时间(秒)',
                    'subtitle' => '请求限制的时间窗口',
                    'desc' => '例如：60表示1分钟如果被限制后所限制时间',
                    'default' => 60,
                    'min' => 10,
                    'max' => 3600,
                    'dependency' => array('enable_api_rate_limit', '==', true),
                ),
                array(
                    'id' => 'api_rate_limit_message',
                    'type' => 'textarea',
                    'title' => '限制提示信息',
                    'subtitle' => '请求被限制时返回的提示信息',
                    'desc' => '支持HTML标签',
                    'default' => '请求过于频繁，请稍后重试',
                    'dependency' => array('enable_api_rate_limit', '==', true),
                ),
            ),
        )
    );
// 卡密管理菜单
CSF::createSection(
    $prefix,
    array(
        'id' => 'card_management',
        'title' => '卡密管理',
        'icon' => 'fa fa-key',
        'fields' => array(
            array(
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 卡密管理：</h3>
                    <p>在这里可以生成和管理产品的卡密，用户可以使用卡密获取授权</p>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
            array(
                'id' => 'generate_cards',
                'type' => 'fieldset',
                'title' => '生成卡密',
                'fields' => array(
                    array(
                        'id' => 'card_product_id',
                        'type' => 'number',
                        'title' => '产品ID',
                        'subtitle' => '选择要生成卡密的产品',
                        'desc' => '此处填写对应产品的页面ID',
                        'default' => '',
                        'min' => 1,
                    ),
                    array(
                        'id' => 'card_count',
                        'type' => 'number',
                        'title' => '生成数量',
                        'subtitle' => '要生成的卡密数量',
                        'desc' => '一次最多生成100个卡密',
                        'default' => 1,
                        'min' => 1,
                        'max' => 100,
                    ),
                    array(
                        'id' => 'card_expire_days',
                        'type' => 'number',
                        'title' => '有效期（天）',
                        'subtitle' => '卡密的有效期',
                        'desc' => '0表示永久有效',
                        'default' => 365,
                        'min' => 0,
                    ),
                    array(
                        'id' => 'card_auth_count',
                        'type' => 'number',
                        'title' => '授权域名数量',
                        'subtitle' => '每个卡密可授权的域名数量',
                        'desc' => '设置为0表示不限制授权数量',
                        'default' => 1,
                        'min' => 0,
                    ),
                    array(
                        'id' => 'card_allowed_users',
                        'type' => 'textarea',
                        'title' => '允许使用的用户ID',
                        'subtitle' => '限制哪些用户可以使用这些卡密',
                        'desc' => '多个用户ID请用逗号分隔，留空表示所有用户都可以使用',
                        'default' => '',
                        'settings' => array(
                            'rows' => 3,
                            'placeholder' => '例如：1,2,3',
                        ),
                    ),
                    array(
                        'id' => 'generate_cards_button',
                        'type' => 'content',
                        'content' => '<button type="button" class="button button-primary" onclick="xk_auth_generate_cards()">生成卡密</button>',
                    ),
                    array(
                        'id' => 'cards_result',
                        'type' => 'content',
                        'content' => '<div id="cards_result" style="margin-top: 10px; padding: 10px; background: #f5f5f5; border-radius: 4px; display: none;"></div>',
                    ),
                ),
            ),
            array(
                'id' => 'cards_list',
                'type' => 'content',
                'title' => '卡密列表',
                'content' => '<div id="cards_list_container">' . xk_auth_get_cards_list() . '</div>',
            ),
        ),
    )
);
    // 添加公告管理菜单
    CSF::createSection(
        $prefix,
        array(
            'id' => 'notice',
            'title' => '公告管理',
            'icon' => 'fa fa-bullhorn',
            'description' => '管理产品的公告信息',
            'fields' => array(
                array(
                    'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 公告管理：</h3>
                    <p>在这里可以设置不同产品的公告信息，公告将通过API返回给授权用户</p>',
                    'style' => 'warning',
                    'type' => 'submessage',
                ),
                array(
                    'id' => 'notice_settings',
                    'type' => 'group',
                    'min' => '1',
                    'button_title' => '添加公告',
                    'title' => '公告设置',
                    'subtitle' => '为产品添加公告信息',
                    'desc' => '可以为不同产品设置不同的公告内容',
                    'default' => array(),
                    'fields' => array(
                        array(
                            'id' => 'product_id',
                            'type' => 'number',
                            'title' => '产品ID',
                            'subtitle' => '选择公告对应的产品ID',
                            'desc' => '此处填写对应产品的页面ID',
                            'default' => '',
                            'min' => 1,
                        ),
                        array(
                            'id' => 'title',
                            'type' => 'text',
                            'title' => '公告标题',
                            'subtitle' => '公告的标题',
                            'desc' => '显示在公告列表中的标题',
                            'default' => '',
                        ),
                        array(
                            'id' => 'content',
                            'type' => 'textarea',
                            'title' => '公告内容',
                            'subtitle' => '公告的详细内容',
                            'desc' => '支持HTML标签',
                            'default' => '',
                            'settings' => array(
                                'rows' => 5,
                                'placeholder' => '请输入公告内容...',
                            ),
                        ),
                        array(
                            'id' => 'type',
                            'type' => 'select',
                            'title' => '公告类型',
                            'subtitle' => '选择公告的类型',
                            'options' => array(
                                'info' => '信息',
                                'warning' => '警告',
                                'error' => '错误',
                                'success' => '成功',
                            ),
                            'default' => 'info',
                        ),
                        array(
                            'id' => 'status',
                            'type' => 'switcher',
                            'title' => '启用公告',
                            'subtitle' => '是否启用该公告',
                            'default' => true,
                        ),
                        array(
                            'id' => 'created_at',
                            'type' => 'text',
                            'title' => '发布时间',
                            'subtitle' => '公告的发布时间',
                            'desc' => '格式：Y-m-d H:i:s',
                            'default' => date('Y-m-d H:i:s'),
                        ),
                        array(
                            'id' => 'start_time',
                            'type' => 'text',
                            'title' => '开始时间',
                            'subtitle' => '公告开始显示的时间',
                            'desc' => '留空表示立即开始显示，格式：Y-m-d H:i:s',
                            'default' => '',
                        ),
                        array(
                            'id' => 'end_time',
                            'type' => 'text',
                            'title' => '结束时间',
                            'subtitle' => '公告结束显示的时间',
                            'desc' => '留空表示永久显示，格式：Y-m-d H:i:s',
                            'default' => '',
                        ),
                        array(
                            'id' => 'priority',
                            'type' => 'number',
                            'title' => '优先级',
                            'subtitle' => '公告显示的优先级',
                            'desc' => '数字越大，优先级越高',
                            'default' => 0,
                            'min' => 0,
                        ),
                        array(
                            'id' => 'category',
                            'type' => 'select',
                            'title' => '公告分类',
                            'subtitle' => '选择公告的分类',
                            'options' => array(
                                'system' => '系统公告',
                                'activity' => '活动公告',
                                'update' => '更新公告',
                                'important' => '重要通知',
                                'other' => '其他',
                            ),
                            'default' => 'system',
                        ),
                        array(
                            'id' => 'push_type',
                            'type' => 'select',
                            'title' => '推送类型',
                            'subtitle' => '选择公告的推送范围',
                            'options' => array(
                                'all' => '全部用户',
                                'specific' => '特定用户',
                                'domain' => '特定域名',
                            ),
                            'default' => 'all',
                        ),
                        array(
                            'id' => 'push_target',
                            'type' => 'textarea',
                            'title' => '推送目标',
                            'subtitle' => '根据推送类型填写对应的目标',
                            'desc' => '推送类型为特定用户时填写用户ID，一行一个；推送类型为特定域名时填写域名，一行一个；全部用户时留空',
                            'default' => '',
                            'settings' => array(
                                'rows' => 3,
                                'placeholder' => '一行一个目标...',
                            ),
                        ),

                    ),
                ),
            ),
        )
    );
}


CSF::createSection(
    $prefix,
    array(
        'id' => 'customer_service',
        'title' => '微信客服设置',
        'icon' => 'fa fa-wechat',
        'fields' => array(
            array(
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 微信客服设置：</h3>
                    <p>设置在前端变更授权或绑定授权时展示的微信客服信息</p>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
            array(
                'id' => 'wechat_customer_service_image',
                'type' => 'text',
                'title' => '微信客服图片链接',
                'subtitle' => '在绑定授权和变更授权页面显示的微信客服二维码图片链接',
                'default' => 'https://www.xkzhi.cn/wp-content/uploads/2025/08/20250817123121664-576d5178d5d3bc2fc5e1348215ed46f4.jpg',
            ),
            array(
                'id' => 'wechat_customer_service_mobile_link',
                'type' => 'text',
                'title' => '手机端微信客服链接',
                'subtitle' => '在移动端显示的微信客服跳转链接',
                'default' => 'https://work.weixin.qq.com/kfid/kfc34fed29eefcf98f7',
            ),
        ),
    )
);

CSF::createSection(
    $prefix,
    array(
        'id' => 'auth_settings',
        'title' => '前端设置',
        'icon' => 'fa fa-key',
        'fields' => array(
        array(
                'id' => 'show_auth_expire_time_auth',
                'type' => 'switcher',
                'title' => '显示授权到期时间',
                'subtitle' => '是否在授权域名下方显示到期时间',
                'desc' => '开启后，授权域名下方将显示到期时间信息',
                'default' => true,
            ),
            array(
                'id' => 'show_auth_widgets_product',
                'type' => 'switcher',
                'title' => '展示产品小工具',
                'desc' => '如果有不显示，请访问页面刷新下',
                'default' => false,
            ),
        ),
    )
);

CSF::createSection(
    $prefix,
    array(
        'id' => 'verify_settings',
        'title' => '验证设置',
        'icon' => 'fa fa-shield',
        'fields' => array(
            array(
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 验证设置：</h3>
                    <p>控制在前台更换授权时是否需要进行<b>邮箱验证</b></p><br>
                    <p>使用前请先配置邮箱在子比设置，否则无法进行邮箱验证，此功能只能邮箱验证，因为我没短信套餐所以没开发</p>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
            array(
                'id' => 'enable_verify',
                'type' => 'switcher',
                'title' => '开启授权验证',
                'desc' => '开启后，用户在前台更换授权时需要进行验证',
                'default' => false,
            ),
            array(
                'id' => 'verify_type',
                'type' => 'select',
                'title' => '验证方式',
                'subtitle' => '选择邮箱验证或手机验证',
                'options' => array(
                    'email' => '邮箱验证',
                ),
                'default' => 'email',
                'dependency' => array('enable_verify', '==', true),
            ),
            array(
                'type' => 'notice',
                'style' => 'info',
                'content' => '以下设置控制下载资源时的域名绑定检验功能',
            ),
            array(
                'id' => 'enable_domain_check_download',
                'type' => 'switcher',
                'title' => '开启下载检验绑定域名',
                'subtitle' => '控制用户是否需要绑定至少一个域名才能下载资源',
                'desc' => '开启后，用户必须绑定至少一个域名才能下载资源；关闭后，用户无需绑定域名即可下载资源',
                'default' => true,
            ),
            array(
                'id' => 'enable_download_verify',
                'type' => 'switcher',
                'title' => '开启下载验证',
                'subtitle' => '控制用户下载资源前是否需要进行邮箱验证',
                'desc' => '开启后，用户下载资源前需要进行邮箱验证；关闭后，用户无需验证即可直接下载资源',
                'default' => false,
            ),
        ),
    )
);

CSF::createSection(
    $prefix,
    array(
        'id' => 'auth_notify_settings',
        'title' => '通知管理',
        'icon' => 'fa fa-envelope',
        'fields' => array(
            array(
                'id' => 'auth_change_notify',
                'type' => 'switcher',
                'title' => '授权变更通知',
                'subtitle' => '当用户更换授权域名时发送邮件通知',
                'desc' => '开启后，用户在更换授权域名时会收到邮件通知',
                'default' => true,
            ),
        ),
    )
);

// 用户授权管理设置
CSF::createSection(
    $prefix,
    array(
        'id' => 'user_auth_management',
        'title' => '用户授权管理',
        'icon' => 'fa fa-users',
        'fields' => array(
            array(
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 用户授权管理：</h3>
                    <p>在这里可以限制特定用户是否允许更换授权</p>',
                'style' => 'warning',
                'type' => 'submessage',
            ),
            array(
                'id' => 'disable_auth_change_for_all',
                'type' => 'switcher',
                'title' => '全局禁止更换授权',
                'subtitle' => '是否禁止所有用户更换授权',
                'desc' => '开启后，所有用户都将无法更换授权域名',
                'default' => false,
            ),
            array(
                'id' => 'restricted_users_display',
                'type' => 'textarea',
                'title' => '限制更换授权的用户列表',
                'subtitle' => '列出不允许更换授权的用户ID',
                'desc' => '多个用户ID请用逗号分隔，例如：1,2,3<br>这些用户将无法在前台更换授权域名',
                'default' => '',
                'dependency' => array('disable_auth_change_for_all', '!=', true),
                'settings' => array(
                    'rows' => 5,
                ),
            ),
        ),
    )
);

CSF::createSection(
    $prefix,
    array(
        'title' => '插件授权',
        'icon' => 'fa fa-gitlab',
        'fields' => xk_auth_Core_license::auth(),
    )
);

CSF::createSection(
    $prefix,
    array(
        'title' => '文档更新',
        'icon' => 'fa fa-cloud-upload',
        'fields' => xk_auth_Core_license::update(),
    )
);

// 备份导入功能
CSF::createSection(
    $prefix,
    array(
        'title' => '备份&导入',
        'icon' => 'fa fa-copy',
        'fields' => array(
            array(
                'type' => 'submessage',
                'style' => 'warning',
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 备份&恢复</h3>
                <ajaxform class="ajax-form">
                <div style="margin:10px 0">
                <p>系统会在重置、更新等重要操作时自动备份插件设置，您可以此进行恢复备份或手动备份</p>
                <p>恢复备份后，请先保存一次插件设置，然后刷新后再做其它操作！</p>
                <p class="c-yellow">系统最多只能保存20次备份，如需长期保存，请手动下载后存留</p>
                <p class="c-yellow">请注意：恢复非当前网站或非当前插件版本的备份数据，可能会出现异常</p>
                <p><b>备份列表：</b></p>
                <div class="backup-list">' . xk_auth_get_backup_list() . '</div>
                </div>
                <a href="javascript:;" ajax-url="' . admin_url('admin-ajax.php', 'relative') . '?action=xk_auth_options_backup" class="but jb-blue ajax-get">备份当前配置</a>
                <a href="javascript:;" ajax-url="' . admin_url('admin-ajax.php', 'relative') . '?action=xk_auth_options_backup_delete_surplus&key=all" data-confirm="确认要删除多余的备份数据吗？删除后不可恢复！" class="but jb-red ajax-get">删除备份 保留最新3份</a>
                <div class="ajax-notice" style="margin-top: 10px;"></div>
                </ajaxform>',
            ),
            array(
                'type' => 'submessage',
                'style' => 'warning',
                'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 导入&导出</h3>
                <ajaxform class="ajax-form">
                <div style="margin:10px 0">
                <p>您可以在此处将插件配置导出为json文件，同时也可以使用json格式的配置内容进行配置导入，导入时请确保json格式正确</p>
                <textarea ajax-name="import_data" style="width: 100%;min-height: 200px;" placeholder="粘贴导出的json数据以进行导入"></textarea>
                </div>
                <input type="hidden" ajax-name="action" value="xk_auth_options_import">
                <a href="javascript:;" class="but jb-yellow ajax-submit"><i class="fa fa-paper-plane-o"></i> 导入配置</a>
                <a href="' . admin_url('admin-ajax.php', 'relative') . '?action=xk_auth_options_export" class="but jb-green" target="_blank">导出当前配置</a>
                <div class="ajax-notice" style="margin-top: 10px;"></div>
                </ajaxform>',
            ),
        ),
    )
);


