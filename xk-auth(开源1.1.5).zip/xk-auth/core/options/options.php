<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */
$include_once = array(
    'settings',
    'metas',
);

foreach ($include_once as $inc) {
    include XK_AUTH_DIR_PATH . 'core/options/admin-' . $inc . '.php';
}

// 快捷获取插件配置信息
function xk_auth($name, $default = false, $subname = '')
{
    // 声明静态变量以加速获取
    static $options = null;
    if ($options === null) {
        $options = get_option('xk_auth_setting');
    }

    if (isset($options[$name])) {
        if ($subname) {
            return isset($options[$name][$subname]) ? $options[$name][$subname] : $default;
        } else {
            return $options[$name];
        }
    }
    return $default;
}

// 引入Font Awesome图标库
function xk_auth_load_font_awesome()
{
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
}
add_action('admin_enqueue_scripts', 'xk_auth_load_font_awesome');

// 授权管理菜单添加 Font Awesome 图标
function xk_auth_add_custom_menu_icon()
{
    ?>
    <style>
        #toplevel_page_auth_page .wp-menu-image:before {
            font-family: 'FontAwesome';
            content: "\f2c2";
            /* fa-id-card-o 的 Unicode 值 */
            font-size: 16px;
        }
    </style>
    <?php
}
add_action('admin_head', 'xk_auth_add_custom_menu_icon');