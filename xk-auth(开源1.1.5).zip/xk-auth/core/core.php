<?php
/*
 * @Project Name: 星空授权插件
 * @Project URI: https://www.xkzhi.cn/
 * @Author URI: https://www.xkzhi.cn/
 * @Description: 感谢您使用授权插件，插件源码有详细的注释，支持二次开发。
 * @Remind me: 无利不起早，使用盗版插件会存在各种未知风险。支持正版，从我做起！
 */

// 引入设置框架
include_once XK_AUTH_DIR_PATH . 'core/codestar-framework/codestar-framework.php';
include_once XK_AUTH_DIR_PATH . 'core/csf-framework/classes/zib-csf.class.php';

//  插件依赖检测
if (!function_exists('xk_auth_check_theme_before_activation')) {
function xk_auth_check_theme_before_activation()
{
    // 获取当前主题
    $active_theme = wp_get_theme();

    // 检查主题名称
    if ($active_theme->get('Name') !== '子比主题') {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('本插件依赖子比主题，请先安装子比主题后再试。');
    }
    // 检查主题版本
    if (version_compare($active_theme->get('Version'), '8.1', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('本插件依赖子比主题版本8.1及以上，请更新子比主题后再试。');
    }
}
}

// 去除链接协议头
if (!function_exists('xk_auth_replace_url')) {
function xk_auth_replace_url($url)
{
    // 去除 http:// 和 https://
    $urlWithoutProtocol = str_replace(array('http://', 'https://'), '', $url);

    // 返回去除协议后的 URL
    return $urlWithoutProtocol;
}
}

// 引入插件核心文件
if (!function_exists('xk_auth_core_files')) {
function xk_auth_core_files()
{
    include_once 'options/options.php';
    include_once 'functions/functions.php';
}
add_action('plugins_loaded', 'xk_auth_core_files');
}